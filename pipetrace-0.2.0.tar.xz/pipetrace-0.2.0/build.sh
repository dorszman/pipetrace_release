#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD="$ROOT/build"
TP="$ROOT/third_party"
TOOLS="$ROOT/tools"

mkdir -p "$BUILD" "$TOOLS"

vendor_ready() {
  [[ -f "$TP/sqlite/sqlite3.c" ]] \
    && [[ -f "$TP/glfw/CMakeLists.txt" ]] \
    && [[ -f "$TP/imgui/imgui.cpp" ]] \
    && [[ -f "$TP/implot/implot.cpp" ]] \
    && [[ -f "$TP/googletest/CMakeLists.txt" ]]
}

if vendor_ready; then
  echo "Using vendored dependencies in third_party/ (offline-capable build)."
else
  echo "third_party/ incomplete — run ./scripts/vendor_deps.sh once (needs network), or build will download deps."
  mkdir -p "$TP"

  fetch_repo() {
    local name="$1" url="$2" tag="$3"
    if [[ ! -d "$TP/$name/.git" ]] && [[ ! -f "$TP/$name/.vendor-tag" ]]; then
      git clone --depth 1 --branch "$tag" "$url" "$TP/$name"
    fi
  }

  if [[ ! -f "$TP/sqlite/sqlite3.c" ]]; then
    mkdir -p "$TP/sqlite"
    curl -fsSL "https://www.sqlite.org/2024/sqlite-amalgamation-3460100.zip" -o "$TP/sqlite.zip"
    rm -rf "$TP/sqlite"/*
    unzip -qo "$TP/sqlite.zip" -d "$TP/sqlite"
    if [[ -d "$TP/sqlite/sqlite-amalgamation-3460100" ]]; then
      mv "$TP/sqlite/sqlite-amalgamation-3460100"/* "$TP/sqlite/"
      rmdir "$TP/sqlite/sqlite-amalgamation-3460100"
    fi
    rm -f "$TP/sqlite.zip"
  fi

  fetch_repo glfw https://github.com/glfw/glfw.git 3.4
  fetch_repo imgui https://github.com/ocornut/imgui.git v1.91.5
  fetch_repo implot https://github.com/epezent/implot.git v0.16
  fetch_repo googletest https://github.com/google/googletest.git v1.15.2
fi

if ! command -v cmake >/dev/null 2>&1; then
  if vendor_ready; then
    echo "Error: cmake is required for offline builds (install cmake or vendor a binary under tools/)." >&2
    exit 1
  fi
  CMAKE_VERSION="3.30.5"
  CMAKE_DIR="$TOOLS/cmake-${CMAKE_VERSION}-linux-x86_64"
  if [[ ! -x "$CMAKE_DIR/bin/cmake" ]]; then
    echo "Bootstrapping CMake ${CMAKE_VERSION}..."
    curl -fsSL "https://github.com/Kitware/CMake/releases/download/v${CMAKE_VERSION}/cmake-${CMAKE_VERSION}-linux-x86_64.tar.gz" \
      -o "$TOOLS/cmake.tar.gz"
    tar -xzf "$TOOLS/cmake.tar.gz" -C "$TOOLS"
    rm "$TOOLS/cmake.tar.gz"
  fi
  export PATH="$CMAKE_DIR/bin:$PATH"
fi

# Optional no-sudo X11 prefix (see scripts/bootstrap_x11_prefix.sh)
X11_PREFIX="${PIPetrace_X11_PREFIX:-$ROOT/deps/x11-prefix}"
CMAKE_ARGS=(-DCMAKE_BUILD_TYPE=Release -DPIPetrace_BUILD_TESTS=ON)
if [[ -d "$X11_PREFIX/include" ]] || [[ -d "$X11_PREFIX/lib" ]]; then
  echo "Using local X11 prefix: $X11_PREFIX"
  export PKG_CONFIG_PATH="$X11_PREFIX/lib/pkgconfig${PKG_CONFIG_PATH:+:$PKG_CONFIG_PATH}"
  export CMAKE_PREFIX_PATH="$X11_PREFIX${CMAKE_PREFIX_PATH:+:$CMAKE_PREFIX_PATH}"
  CMAKE_ARGS+=(-DCMAKE_PREFIX_PATH="$CMAKE_PREFIX_PATH")
fi

cmake -S "$ROOT" -B "$BUILD" "${CMAKE_ARGS[@]}"
cmake --build "$BUILD" -j"$(nproc)"

if [[ -x "$BUILD/pipetrace-ptj-synthgen" ]]; then
  "$BUILD/pipetrace-ptj-synthgen" generate --objects 100 --output "$ROOT/data/sample.ptj"
  "$BUILD/pipetrace-ptj-synthgen" info --store "$ROOT/data/sample.ptj.db"
fi

if [[ -x "$BUILD/pipetrace-view" ]]; then
  echo "GUI built: $BUILD/pipetrace-view"
else
  echo "GUI not built (need X11 -dev packages, or ./scripts/bootstrap_x11_prefix.sh then rebuild)"
fi

echo "Built $BUILD/pipetrace-ptj-synthgen"
