# Prefer third_party/ sources when present (offline builds).

set(PIPetrace_VENDOR_DIR "${CMAKE_SOURCE_DIR}/third_party" CACHE PATH
    "Directory containing vendored dependency sources")

function(pipetrace_vendor_path out_var subpath)
  set("${out_var}" "${PIPetrace_VENDOR_DIR}/${subpath}" PARENT_SCOPE)
endfunction()

function(pipetrace_has_vendor out_var subpath marker)
  pipetrace_vendor_path(_dir "${subpath}")
  if(EXISTS "${_dir}/${marker}")
    set(${out_var} TRUE PARENT_SCOPE)
  else()
    set(${out_var} FALSE PARENT_SCOPE)
  endif()
endfunction()

function(pipetrace_declare_sqlite)
  pipetrace_has_vendor(_has sqlite sqlite3.c)
  if(_has)
    pipetrace_vendor_path(_dir sqlite)
    message(STATUS "Using vendored SQLite at ${_dir}")
    FetchContent_Declare(sqlite SOURCE_DIR "${_dir}")
  else()
    FetchContent_Declare(
      sqlite
      URL https://www.sqlite.org/2024/sqlite-amalgamation-3460100.zip
      DOWNLOAD_EXTRACT_TIMESTAMP TRUE
    )
  endif()
endfunction()

function(pipetrace_declare_googletest)
  pipetrace_has_vendor(_has googletest CMakeLists.txt)
  if(_has)
    pipetrace_vendor_path(_dir googletest)
    message(STATUS "Using vendored GoogleTest at ${_dir}")
    FetchContent_Declare(googletest SOURCE_DIR "${_dir}")
  else()
    FetchContent_Declare(
      googletest
      GIT_REPOSITORY https://github.com/google/googletest.git
      GIT_TAG v1.15.2
      GIT_SHALLOW TRUE
    )
  endif()
endfunction()

function(pipetrace_declare_glfw)
  pipetrace_has_vendor(_has glfw CMakeLists.txt)
  if(_has)
    pipetrace_vendor_path(_dir glfw)
    message(STATUS "Using vendored GLFW at ${_dir}")
    FetchContent_Declare(glfw SOURCE_DIR "${_dir}")
  else()
    FetchContent_Declare(
      glfw
      GIT_REPOSITORY https://github.com/glfw/glfw.git
      GIT_TAG 3.4
      GIT_SHALLOW TRUE
    )
  endif()
endfunction()

function(pipetrace_declare_imgui)
  pipetrace_has_vendor(_has imgui imgui.cpp)
  if(_has)
    pipetrace_vendor_path(_dir imgui)
    message(STATUS "Using vendored Dear ImGui at ${_dir}")
    FetchContent_Declare(imgui SOURCE_DIR "${_dir}")
  else()
    FetchContent_Declare(
      imgui
      GIT_REPOSITORY https://github.com/ocornut/imgui.git
      GIT_TAG v1.91.5
      GIT_SHALLOW TRUE
    )
  endif()
endfunction()

function(pipetrace_declare_implot)
  pipetrace_has_vendor(_has implot implot.cpp)
  if(_has)
    pipetrace_vendor_path(_dir implot)
    message(STATUS "Using vendored ImPlot at ${_dir}")
    FetchContent_Declare(implot SOURCE_DIR "${_dir}")
  else()
    FetchContent_Declare(
      implot
      GIT_REPOSITORY https://github.com/epezent/implot.git
      GIT_TAG v0.16
      GIT_SHALLOW TRUE
    )
  endif()
endfunction()
