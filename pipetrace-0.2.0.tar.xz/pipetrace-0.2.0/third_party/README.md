# Vendored third-party sources

Populated by `./scripts/vendor_deps.sh` and committed to git for **offline builds**.

| Directory | Upstream | Tag |
|-----------|----------|-----|
| `sqlite/` | [SQLite amalgamation](https://www.sqlite.org/amalgamation.html) | 3460100 |
| `googletest/` | [google/googletest](https://github.com/google/googletest) | v1.15.2 |
| `glfw/` | [glfw/glfw](https://github.com/glfw/glfw) | 3.4 |
| `imgui/` | [ocornut/imgui](https://github.com/ocornut/imgui) | v1.91.5 |
| `implot/` | [epezent/implot](https://github.com/epezent/implot) | v0.16 |

Each tree contains a `.vendor-tag` file with the pinned version. Do not edit manually; re-run `vendor_deps.sh` to upgrade.

`vendor_deps.sh` strips upstream **prebuilt binaries** (`.lib` / `.exe` / `.dll` / `.dylib`, e.g. ImGui example MSVC GLFW libs). pipetrace builds GLFW/ImGui from source; those files are unused and trip email scanners.

CMake uses these when present (`cmake/VendoredDeps.cmake`). System packages still required: **compiler, CMake, X11, OpenGL** (for GUI).
