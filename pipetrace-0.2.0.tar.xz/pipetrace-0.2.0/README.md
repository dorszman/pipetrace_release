
# Generic Large-Trace Visualizer — MVP Specification

Build a local desktop GUI for interactively visualizing very large event traces. CPU pipeline traces are the first use case, but all data models, labels, colors, and layouts must be generic and data-driven.

## Implementation Language

The project must be implemented in **C++**. This includes ingestion, indexed storage, viewport querying, rendering, and the interactive GUI. Third-party C/C++ libraries are allowed; the application core must not depend on JavaScript or other non-C++ runtimes for primary functionality.

## Data Model

A trace contains:

* Object types and objects.
* Timestamped events belonging to objects.
* Instant events (single point in time).
* Optional event attributes and relationships between objects.

Example: a `uop` may have `decode`, `rename`, `dispatch`, `issue`, `execute`, and `retire` events.

Define a simple extensible input format and import it into an indexed local store. Preserve timestamps as 64-bit integers.

## Visualization

* Horizontal axis: time.
* Vertical axis: visible objects, grouped optionally by type.
* Events: configurable points, rectangles, intervals, labels, and colors.
* Pan, wheel zoom, zoom-to-selection, filtering, search, hover details, and object selection.
* Virtualize rows and render only the visible time and object ranges.
* When zoomed out, show aggregated event density; reveal individual objects and events when zoomed in.

## Large-Trace Architecture

Support millions of objects without loading the entire trace into memory.

* Partition/index data by time.
* Store each object’s `first_time` and `last_time`.
* Query only objects overlapping the viewport:
  `first_time <= view_end AND last_time >= view_start`.
* Load a small prefetch margin around the viewport.
* Use background workers, bounded caches, and cancellable queries.
* Return compact columnar/binary buffers to the renderer, not large JSON object arrays.
* Keep ingestion, storage, viewport querying, and rendering behind separate interfaces.

Initially benchmark SQLite with an R-tree interval index and DuckDB/partitioned Parquet.

## Rendering Candidates

Implement the same timeline prototype in C++ with:

1. **Perfetto UI / custom tracks** — closest existing large-trace viewer; includes timeline navigation, SQL trace analysis, tracks, filtering, and plugins.
2. **Dear ImGui + ImPlot** — GPU-accelerated C++ GUI/plotting stack with direct control over custom timeline rendering and interactions.
3. **Custom C++ GPU renderer** — e.g. OpenGL/Vulkan/WebGPU via bgfx or similar, with binary buffers, GPU picking, and orthographic views.

Do not use SVG, HTML canvas with one DOM element per event, or JavaScript-based renderers.

Benchmark each primary candidate using identical synthetic traces and interactions:

* 1 million total objects.
* At least 100,000 visible events in stress views.
* Pan and continuous zoom.
* Hover/picking.
* Row virtualization.
* Memory usage, frame time, query latency, implementation complexity, license, and maintainability.

Do not select the final renderer before recording the benchmark results. Use Perfetto as the behavioral reference even if another renderer is selected.

## Deliverables

1. Synthetic generic and CPU-pipeline trace generators.
2. Importer and indexed local storage.
3. Identical prototypes for the three primary rendering candidates.
4. Written benchmark comparison and final selection.
5. Working MVP with tests and architecture documentation.

Target smooth interaction, bounded memory consumption, and no UI blocking during database access.

## v0.1 Status

First version includes:

- PTJ trace format (JSON Lines)
- Synthetic CPU pipeline (wide decode, 108 event types) and generic trace generators
- SQLite indexed storage with viewport and occurrence-count queries
- Columnar query results for rendering
- Dear ImGui **cycle-grid** timeline viewer (instant events, occurrence header strips, event-type marking, per-event attributes, sticky popups)
- CLI tools for generate/import/info
- Unit tests and documentation: `docs/ARCHITECTURE.md`, `docs/STATUS.md`, `docs/MIGRATION.md`, `docs/INSTALLATION.md`, `docs/USAGE.md`, `AGENTS.md`

For AI-assisted development or migration to a new machine/user, start with **`docs/MIGRATION.md`**, then **`AGENTS.md`**. To build from scratch, see **`docs/INSTALLATION.md`**. For viewer controls, see **`docs/USAGE.md`**.

### Quick start

```bash
chmod +x build.sh
./build.sh

# CLI (always built)
./build/pipetrace-ptj-synthgen generate --objects 5000
./build/pipetrace-ptj-synthgen info --store data/sample.ptj.db

# GUI (requires libx11-dev and libgl-dev)
./build/pipetrace-view --generate --objects 5000
```

## License

pipetrace is released under the [MIT License](LICENSE). Copyright (c) 2026 Doron Cohen (dorszman@gmail.com).

Third-party dependencies under `third_party/` keep their own licenses (SQLite public domain; Dear ImGui / ImPlot MIT; GLFW zlib/libpng; GoogleTest BSD-3).
