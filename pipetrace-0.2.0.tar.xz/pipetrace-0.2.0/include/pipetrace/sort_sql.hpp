#pragma once

#include <string>
#include <vector>

#include "pipetrace/app_config.hpp"

namespace pipetrace {

bool is_valid_attribute_sort_key(const std::string& key);

// Builds "ORDER BY <exprs>, id" (no leading ORDER BY keyword if empty columns).
std::string build_object_sort_order_by_clause(const SortScheme& scheme);

// SQL expression comparing one attribute value for ORDER BY (missing-last for asc).
std::string build_attribute_sort_key_sql(const std::string& attribute_key, bool ascending);

// Stable fingerprint of scheme names + column keys/orders for skip-if-up-to-date.
std::string build_sort_schemes_fingerprint(const std::vector<SortScheme>& schemes);

// True if any column key starts with "Dual" (needs dual-analyze attributes).
bool sort_scheme_references_dual_keys(const SortScheme& scheme);

}  // namespace pipetrace
