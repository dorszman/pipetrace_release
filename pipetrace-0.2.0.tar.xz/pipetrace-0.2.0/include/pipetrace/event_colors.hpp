#pragma once

#include <array>
#include <cstdint>
#include <string>

namespace pipetrace {

/// Sentinel "unassigned" event color (neutral grey). Cast leaves this in the DB/config
/// when no user color exists; analyze replaces it with a deterministic palette color.
/// Schema uses NOT NULL INTEGER, so NULL is not available — this sentinel means unset.
/// Prefer not treating `#888888` as a real user-chosen color.
constexpr std::uint32_t kUnassignedEventTypeColor = 0xFF888888U;

inline bool is_unassigned_event_type_color(const std::uint32_t rgba) {
  return rgba == kUnassignedEventTypeColor;
}

/// Deterministic palette color for an event type name (analyze invents colors this way).
inline std::uint32_t hash_event_type_color_rgba(const std::string& name) {
  std::uint32_t hash = 2166136261U;
  for (unsigned char ch : name) {
    hash ^= ch;
    hash *= 16777619U;
  }
  static constexpr std::array<std::uint32_t, 12> palette = {
      0xFF4CAF50U, 0xFF2196F3U, 0xFFFF9800U, 0xFFE91E63U, 0xFF9C27B0U, 0xFF00BCD4U,
      0xFF795548U, 0xFF607D8BU, 0xFFCDDC39U, 0xFF3F51B5U, 0xFF009688U, 0xFFFF5722U,
  };
  return palette[hash % palette.size()];
}

}  // namespace pipetrace
