#pragma once

#include <algorithm>
#include <cstddef>
#include <optional>
#include <string>

#include "pipetrace/app_config.hpp"
#include "pipetrace/sort_sql.hpp"

namespace pipetrace {

class RowSortState {
 public:
  bool user_mode() const { return user_mode_; }
  std::size_t config_scheme_index() const { return config_scheme_index_; }
  const std::string& user_column_key() const { return user_column_key_; }
  bool user_ascending() const { return user_ascending_; }

  bool set_config_scheme_index(std::size_t index, const AppConfig& config) {
    if (config.sort_schemes.empty()) {
      return false;
    }
    const std::size_t clamped = std::min(index, config.sort_schemes.size() - 1);
    bool changed = false;
    if (user_mode_) {
      user_mode_ = false;
      changed = true;
    }
    if (clamped != config_scheme_index_) {
      config_scheme_index_ = clamped;
      changed = true;
    }
    return changed;
  }

  /// Maps a header double-click onto a configured scheme (or its reverse) when possible.
  /// Returns true when the viewport sort scheme changed.
  bool apply_header_double_click(const std::string& column_key, const AppConfig& config) {
    if (!is_valid_attribute_sort_key(column_key)) {
      return false;
    }

    std::optional<std::size_t> matching_asc;
    std::optional<std::size_t> matching_desc;
    for (std::size_t i = 0; i < config.sort_schemes.size(); ++i) {
      const SortScheme& scheme = config.sort_schemes[i];
      if (scheme.columns.empty() || scheme.columns[0].key != column_key) {
        continue;
      }
      if (scheme.columns[0].order == "desc") {
        matching_desc = i;
      } else {
        matching_asc = i;
      }
    }

    if (!user_mode_ && !config.sort_schemes.empty()) {
      const SortScheme& current =
          config.sort_schemes[std::min(config_scheme_index_, config.sort_schemes.size() - 1)];
      if (!current.columns.empty() && current.columns[0].key == column_key) {
        const bool currently_asc = current.columns[0].order != "desc";
        if (currently_asc && matching_desc.has_value()) {
          return set_config_scheme_index(*matching_desc, config);
        }
        if (!currently_asc && matching_asc.has_value()) {
          return set_config_scheme_index(*matching_asc, config);
        }
        // No reverse scheme in config: triangles only; keep ranked order.
        user_mode_ = true;
        user_column_key_ = column_key;
        user_ascending_ = !currently_asc;
        user_scheme_cache_valid_ = false;
        return false;
      }
    }

    if (matching_asc.has_value()) {
      return set_config_scheme_index(*matching_asc, config);
    }
    if (matching_desc.has_value()) {
      return set_config_scheme_index(*matching_desc, config);
    }

    // Unconfigured column: triangles only (no JSON / no ad-hoc ranks).
    if (user_mode_ && user_column_key_ == column_key) {
      user_ascending_ = !user_ascending_;
    } else {
      user_mode_ = true;
      user_column_key_ = column_key;
      user_ascending_ = true;
    }
    user_scheme_cache_valid_ = false;
    return false;
  }

  void clamp_config_scheme_index(const AppConfig& config) {
    if (config.sort_schemes.empty()) {
      config_scheme_index_ = 0;
      return;
    }
    config_scheme_index_ = std::min(config_scheme_index_, config.sort_schemes.size() - 1);
  }

  /// Scheme used for UI labels / triangles (may be user-mode triangles-only).
  const SortScheme* active_sort_scheme(const AppConfig& config) const {
    if (user_mode_) {
      if (!user_scheme_cache_valid_) {
        user_scheme_cache_.name = "User";
        user_scheme_cache_.columns = {
            {user_column_key_, user_ascending_ ? "asc" : "desc"}};
        user_scheme_cache_valid_ = true;
      }
      return &user_scheme_cache_;
    }
    if (config.sort_schemes.empty()) {
      return nullptr;
    }
    const std::size_t idx = std::min(config_scheme_index_, config.sort_schemes.size() - 1);
    return &config.sort_schemes[idx];
  }

  /// Scheme used for viewport row order (config schemes with prep-time ranks only).
  /// User-mode triangles do not change order — keep the last config scheme.
  const SortScheme* viewport_sort_scheme(const AppConfig& config) const {
    if (config.sort_schemes.empty()) {
      return nullptr;
    }
    const std::size_t idx = std::min(config_scheme_index_, config.sort_schemes.size() - 1);
    return &config.sort_schemes[idx];
  }

  std::optional<bool> active_sort_direction_for_column(const std::string& column_key,
                                                       const AppConfig& config) const {
    if (user_mode_) {
      if (column_key != user_column_key_) {
        return std::nullopt;
      }
      return user_ascending_;
    }
    const SortScheme* scheme = active_sort_scheme(config);
    if (scheme == nullptr || scheme->columns.empty()) {
      return std::nullopt;
    }
    if (scheme->columns[0].key != column_key) {
      return std::nullopt;
    }
    return scheme->columns[0].order == "asc";
  }

  std::string display_label(const AppConfig& config) const {
    if (user_mode_) {
      const char* order = user_ascending_ ? "asc" : "desc";
      return "User (" + user_column_key_ + " " + order + ")";
    }
    if (config.sort_schemes.empty()) {
      return "Default";
    }
    const std::size_t idx = std::min(config_scheme_index_, config.sort_schemes.size() - 1);
    return config.sort_schemes[idx].name;
  }

 private:
  bool user_mode_{false};
  std::size_t config_scheme_index_{0};
  std::string user_column_key_;
  bool user_ascending_{true};
  mutable SortScheme user_scheme_cache_;
  mutable bool user_scheme_cache_valid_{false};
};

}  // namespace pipetrace
