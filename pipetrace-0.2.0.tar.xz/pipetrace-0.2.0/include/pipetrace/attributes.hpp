#pragma once

#include <optional>
#include <string>
#include <utility>
#include <vector>

namespace pipetrace {

std::optional<std::string> extract_json_object_field(const std::string& line,
                                                     const std::string& key);

std::vector<std::pair<std::string, std::string>> parse_object_attributes(
    const std::string& json_object);

std::string format_object_attributes_json(
    const std::vector<std::pair<std::string, std::string>>& attributes);

std::string attribute_value(const std::vector<std::pair<std::string, std::string>>& attributes,
                            const std::string& key);

}  // namespace pipetrace
