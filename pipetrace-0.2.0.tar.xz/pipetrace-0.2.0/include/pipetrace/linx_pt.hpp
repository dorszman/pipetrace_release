#pragma once

#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

#include "pipetrace/progress.hpp"
#include "pipetrace/types.hpp"

namespace pipetrace {

struct LinxPtCastOptions {
  std::string input_path;
  std::string store_path;
  std::string config_path;
  std::string trace_name;
  std::string log_path;
  StatusMode status_mode{StatusMode::Pretty};
  bool verbose{false};
  bool force{false};
  ProgressReporter* progress{nullptr};
};

struct LinxPtCastStats {
  std::size_t lines_read{0};
  std::size_t lines_parsed{0};
  std::size_t lines_skipped{0};
  std::size_t objects{0};
  std::size_t events{0};
  std::size_t config_entries_added{0};
  std::size_t warnings{0};
  bool cast_skipped{false};
};

struct LinxPtGenerateOptions {
  std::string output_path;
  std::int64_t object_count{1000};
  std::int64_t events_per_object{4};
  std::int64_t uops_per_instruction{4};
  std::int64_t cycle_span{100};
  std::int64_t seed{42};
  bool include_tree{true};
  bool partial_retire{false};
};

LinxPtCastStats cast_linx_pt_to_store(const LinxPtCastOptions& options);
void generate_linx_pt_trace(const LinxPtGenerateOptions& options);

}  // namespace pipetrace
