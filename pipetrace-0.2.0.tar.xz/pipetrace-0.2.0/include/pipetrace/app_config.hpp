#pragma once

#include <cstdint>
#include <optional>
#include <string>
#include <unordered_map>
#include <vector>

#include "pipetrace/event_colors.hpp"

namespace pipetrace {

struct PinnedRowAttribute {
  std::string key;
  std::string label;
  float width_px{80.0f};
  /// Always | SingleTrace | DualTrace — default Always when omitted.
  std::string scope{"Always"};
};

struct EventTypeDisplay {
  std::string name;
  char display_char{'?'};
  std::uint32_t color_rgba{kUnassignedEventTypeColor};
};

struct CastToolConfig {
  std::string command{"./build/pipetrace-linx-parser"};
};

struct AnalysisToolConfig {
  std::string command{"./build/pipetrace-linx-analyze"};
};

struct SortColumn {
  std::string key;
  std::string order{"asc"};  // "asc" or "desc"
};

struct SortScheme {
  std::string name;
  std::vector<SortColumn> columns;
};

struct ObjectAttributeStrengthRule {
  std::string key;
  std::string color;
  std::string highlight{"max"};  // "max" or "min"; used by analyze only
};

struct AppConfig {
  CastToolConfig cast_tool;
  AnalysisToolConfig analysis_tool;
  std::vector<PinnedRowAttribute> pinned_row_attributes;
  std::vector<EventTypeDisplay> event_type_display;
  std::vector<SortScheme> sort_schemes;
  std::vector<ObjectAttributeStrengthRule> object_attribute_strength;
  std::vector<std::string> search_attributes;
  std::string sync_attribute;

  float row_panel_width() const;
  bool has_row_panel() const { return !pinned_row_attributes.empty(); }
  bool has_sync_attribute() const { return !sync_attribute.empty(); }
  const EventTypeDisplay* find_event_type_display(const std::string& name) const;
  EventTypeDisplay* find_event_type_display(const std::string& name);
};

AppConfig load_app_config(const std::string& path);
AppConfig default_app_config();
void save_app_config(const std::string& path, const AppConfig& config);

/// Filename looked up next to pipetrace-view (not under a config/ subdirectory).
/// Packaging copies config/pipetrace.linx.json → this name beside the exe.
inline constexpr const char* kAppConfigFileName = "pipetrace.app.json";

/// Directory of the running binary. Prefers the canonical executable path
/// (/proc/self/exe or GetModuleFileName); falls back to argv0.
std::string executable_directory(const std::string& argv0);

/// Resolves the app config path.
/// 1. flag_path non-empty: use --config (always wins; fail if missing).
/// 2. allow_env: PIPETRACE_CONFIG (fail if set but missing).
/// 3. exe_dir non-empty (viewer): <exe_dir>/pipetrace.app.json — not <exe_dir>/config/.
/// Config is mandatory: throws if unresolved or a specified path is missing.
std::string resolve_app_config_path(const std::string& flag_path, bool allow_env = false,
                                    const std::string& exe_dir = {});

std::size_t merge_event_type_display(AppConfig& config,
                                     const std::vector<EventTypeDisplay>& discovered);

std::unordered_map<std::string, bool> default_pinned_attribute_checks(
    const AppConfig& config, const std::vector<std::string>& available_keys);

std::vector<PinnedRowAttribute> build_active_pinned_row_columns(
    const AppConfig& config, const std::vector<std::string>& available_keys,
    const std::unordered_map<std::string, bool>& checked, bool dual_layout = false);

// Parses #RRGGBB or #RRGGBBAA into 0xAARRGGBB (alpha defaults to 0xFF).
std::optional<std::uint32_t> parse_hex_color_rgba(const std::string& text);

// Formats #RRGGBBAA from RGBA components.
std::string format_hex_color_rgba_string(std::uint8_t r, std::uint8_t g, std::uint8_t b,
                                         std::uint8_t a);

// Builds #RRGGBBAA using fixed RGB from base_color_hex and alpha from strength [0,1].
std::string strength_color_from_base(const std::string& base_color_hex, double strength);

}  // namespace pipetrace
