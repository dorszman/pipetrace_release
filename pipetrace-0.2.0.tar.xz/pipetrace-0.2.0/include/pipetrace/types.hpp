#pragma once

#include <cstdint>
#include <optional>
#include <string>
#include <vector>

namespace pipetrace {

using Timestamp = std::int64_t;
using ObjectId = std::int64_t;
using EventId = std::int64_t;

struct ObjectType {
  std::int64_t id{};
  std::string name;
  std::string display_name;
};

struct EventType {
  std::int64_t id{};
  std::string name;
  std::int64_t object_type_id{};
  char display_char{'?'};
  std::uint32_t color_rgba{0xFF4CAF50};
};

struct TraceObject {
  ObjectId id{};
  ObjectId parent_id{-1};
  std::int64_t object_type_id{};
  std::string name;
  Timestamp first_time{};
  Timestamp last_time{};
  std::vector<std::pair<std::string, std::string>> attributes;
};

struct TraceEvent {
  EventId id{};
  ObjectId object_id{};
  std::int64_t event_type_id{};
  std::string kind;
  Timestamp time{};
  std::vector<std::pair<std::string, std::string>> attributes;
};

struct TraceMeta {
  std::string name{"trace"};
  Timestamp min_time{};
  Timestamp max_time{};
  std::int64_t object_count{};
  std::int64_t event_count{};
};

struct Viewport {
  Timestamp time_start{};
  Timestamp time_end{};
  std::int64_t row_start{};
  std::int64_t row_end{};
};

struct CycleOccurrenceCount {
  Timestamp cycle{};
  std::size_t count{};
};

}  // namespace pipetrace
