#pragma once

#include <chrono>
#include <cstdint>
#include <fstream>
#include <mutex>
#include <optional>
#include <string>

namespace pipetrace {

enum class StatusMode {
  Pretty,
  Plain,
};

StatusMode parse_status_mode(const std::string& text);
std::string status_mode_to_string(StatusMode mode);

/// One snapshot of progress. format_status_plain() is the single source of status text;
/// pretty mode only decorates how that text is written.
struct StatusSnapshot {
  std::string tool;
  std::string phase;
  std::uint64_t done{0};
  std::uint64_t total{0};
  std::string msg;
  std::string outcome;
};

std::string format_status_plain(const StatusSnapshot& snapshot);

class ProgressReporter {
 public:
  ProgressReporter(std::string tool_name, StatusMode mode, std::string log_path = {});
  ~ProgressReporter();

  ProgressReporter(const ProgressReporter&) = delete;
  ProgressReporter& operator=(const ProgressReporter&) = delete;

  StatusMode mode() const { return mode_; }
  const std::string& log_path() const { return log_path_; }

  void set_phase(std::string phase, std::string msg = {});
  void set_counts(std::uint64_t done, std::uint64_t total = 0, std::string msg = {});
  void warn(const std::string& message);
  void log(const std::string& message);
  void finish(const std::string& outcome, const std::string& message = {});

 private:
  void emit(bool force);
  void write_stdout(const std::string& body, bool final_line);
  void write_log_line(const std::string& line);

  std::string tool_;
  StatusMode mode_{StatusMode::Pretty};
  std::string log_path_;
  std::ofstream log_file_;
  StatusSnapshot snapshot_;
  std::chrono::steady_clock::time_point last_emit_{};
  bool pretty_line_open_{false};
  bool finished_{false};
  std::mutex mutex_;
  static constexpr std::chrono::milliseconds kMinEmitInterval{100};
};

}  // namespace pipetrace
