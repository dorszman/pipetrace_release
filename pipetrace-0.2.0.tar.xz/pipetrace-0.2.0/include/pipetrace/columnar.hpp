#pragma once

#include <cstdint>
#include <vector>

#include "pipetrace/types.hpp"

namespace pipetrace {

// Compact columnar buffers returned to the renderer.
struct ColumnarEvents {
  std::vector<EventId> ids;
  std::vector<ObjectId> object_ids;
  std::vector<Timestamp> times;
  std::vector<std::int64_t> event_type_ids;
  std::vector<std::string> kinds;
  std::vector<char> display_chars;
  std::vector<std::uint32_t> colors_rgba;
  std::vector<std::string> attributes_json;
};

struct ColumnarObjects {
  std::vector<ObjectId> ids;
  std::vector<std::int64_t> object_type_ids;
  std::vector<Timestamp> first_times;
  std::vector<Timestamp> last_times;
  std::vector<std::int32_t> row_indices;
  std::vector<std::string> attributes_json;
};

}  // namespace pipetrace
