#pragma once

#include <string>

#include "pipetrace/types.hpp"

namespace pipetrace {

TraceMeta import_ptj_trace(const std::string& input_path,
                           const std::string& store_path);

}  // namespace pipetrace
