#pragma once

#include <string>

#include "pipetrace/types.hpp"

namespace pipetrace {

struct GeneratorConfig {
  std::int64_t object_count{1000};
  Timestamp time_span{100000};
  std::uint32_t seed{42};
};

struct CpuPipelineConfig : GeneratorConfig {
  std::int64_t stages{6};
  std::int64_t decode_width{4};
};

class TraceGenerator {
 public:
  virtual ~TraceGenerator() = default;
  virtual TraceMeta generate(const std::string& output_path) = 0;
};

TraceMeta generate_cpu_pipeline_trace(const CpuPipelineConfig& config,
                                      const std::string& output_path);
TraceMeta generate_generic_trace(const GeneratorConfig& config,
                                 const std::string& output_path);

}  // namespace pipetrace
