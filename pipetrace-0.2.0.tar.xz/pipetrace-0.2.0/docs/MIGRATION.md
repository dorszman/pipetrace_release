# Migration guide

How to move **pipetrace** to a new machine, new developer, or new AI assistant — without losing project context.

All instructions below are **tool-agnostic**. Rules and conventions live in git (`AGENTS.md`, this file, architecture docs), not in editor-specific config.

---

## What travels in git

| File | Purpose |
|------|---------|
| `docs/MIGRATION.md` | This guide — setup and handoff checklist |
| `docs/INSTALLATION.md` | Install dependencies, compile, test, run |
| `docs/USAGE.md` | Viewer controls, crosshair/markers, sidebar, app config |
| `AGENTS.md` | AI/human onboarding, conventions, doc-maintenance rules |
| `docs/ARCHITECTURE.md` | Current design and implementation |
| `docs/STATUS.md` | Implemented features, gaps, roadmap |
| `README.md` | Original product spec and long-term goals |

**Source of truth for AI rules:** `AGENTS.md`. Optional tool-specific files (Cursor, Claude Code, Copilot) should only **point** to `AGENTS.md`, never duplicate it.

---

## Quick checklist

- [ ] Clone or copy the repo
- [ ] Install and build — see [`docs/INSTALLATION.md`](INSTALLATION.md)
- [ ] Regenerate sample trace if `data/sample.ptj.db` is missing or stale
- [ ] New AI: run the [onboarding prompt](#onboarding-prompt-for-ai-assistants) before coding
- [ ] Optional: add a one-line pointer file for your AI tool (see [Optional tool wiring](#optional-tool-wiring))

---

## 1. Move the repository

```bash
git clone <repo-url> pipetrace
cd pipetrace
```

Or copy the directory and verify git history is intact:

```bash
git log --oneline -15
```

You do **not** need `.cursor/`, local IDE settings, or chat transcripts. Everything required for development is in the repo.

---

## 2. Environment setup

Follow **[`docs/INSTALLATION.md`](INSTALLATION.md)** for dependency install, compile, test, and sample data.

Quick path (Debian/Ubuntu, offline-capable clone):

```bash
sudo apt install -y build-essential cmake libx11-dev libgl1-mesa-dev
chmod +x build.sh && ./build.sh
ctest --test-dir build --output-on-failure
./build/pipetrace-ptj-synthgen generate --objects 100 --output data/sample.ptj
```

---

## 3. Understand the project (reading order)

Read in this order before making non-trivial changes:

1. **`README.md`** — product vision, scale targets, long-term goals (some details predate the current viewer).
2. **`AGENTS.md`** — how to work today: key files, build/run, pitfalls, doc rules.
3. **`docs/ARCHITECTURE.md`** — data model, storage queries, viewer layout, generators.
4. **`docs/USAGE.md`** — end-user viewer controls (pan, zoom, crosshair, markers).
5. **`docs/STATUS.md`** — what's done, what's not, known limits.
6. **`git log --oneline -15`** — recent implementation history.

### Core design (must internalize)

| Concept | Rule |
|---------|------|
| Row | One traced object per row; row index = dense rank by `objects.id` (`ORDER BY id`, 0-based) |
| Time | Discrete cycles (64-bit integer) |
| Event | **Instant** at one `time` — not an interval |
| Storage | SQLite on disk; viewer loads **visible rows/cycles + buffer** only |
| Scale | Virtualization is mandatory (~100 visible rows at min zoom) |
| UI data | Event types, colors, chars come from the store / PTJ — not hard-coded lists |

Current viewer: **cycle × row grid** with occurrence header strips for marked event types (not interval bars).

---

## 4. Onboarding prompt for AI assistants

Paste this as the **first message** to any new AI session:

```
Read README.md (product spec), then AGENTS.md, docs/ARCHITECTURE.md, docs/STATUS.md, and docs/MIGRATION.md.
Then inspect git log --oneline -15 for recent history.
Do not change code until you understand the cycle-grid model and viewport virtualization.
```

Wait for the assistant to confirm it has read the docs before assigning implementation work.

---

## 5. Optional tool wiring

If your AI tool reads a project-local config file, add a **minimal pointer** — do not copy rules from `AGENTS.md`.

| Tool | File | Suggested content |
|------|------|-------------------|
| Cursor | `.cursor/rules/pipetrace.mdc` | `Read and follow AGENTS.md and docs/MIGRATION.md in this repo.` |
| Claude Code | `CLAUDE.md` | Same one-liner |
| GitHub Copilot | `.github/copilot-instructions.md` | Same one-liner |

Example Cursor rule frontmatter (optional):

```yaml
---
description: pipetrace project context
alwaysApply: true
---
Read and follow AGENTS.md and docs/MIGRATION.md in this repo.
```

---

## 6. Handoff between humans

When passing the project to another developer:

1. Ensure `docs/STATUS.md` reflects current reality (bump "Last updated" date).
2. Note any uncommitted local work or open branches.
3. Mention whether sample DBs were regenerated recently.
4. Point them to this file and `AGENTS.md`.

When ending an AI session and starting a new one:

1. Commit or stash work (user decides when to commit).
2. Update `docs/STATUS.md` if features or roadmap changed.
3. Start the new session with the [onboarding prompt](#onboarding-prompt-for-ai-assistants).

---

## 7. Keeping docs current after migration

When you change behavior, update docs **in the same task** (full rules in `AGENTS.md` § Documentation maintenance):

| Change type | Update |
|-------------|--------|
| Storage schema or queries | `docs/ARCHITECTURE.md`, `docs/STATUS.md` |
| Viewer layout or interaction | `docs/ARCHITECTURE.md`, `AGENTS.md` |
| Generator or CLI flags | `docs/ARCHITECTURE.md`, `docs/STATUS.md`, `AGENTS.md` |
| Major milestone | Also update `README.md` v0.1 status summary |
| Migration process itself | `docs/MIGRATION.md` |
| Install / build steps change | `docs/INSTALLATION.md` |

Ask: *Would a new AI on a fresh machine misunderstand this?* If yes, update docs before considering the task done.

---

## 8. Troubleshooting

| Problem | Action |
|---------|--------|
| GUI won't start | Install OpenGL/GLFW dev packages; rebuild with `./build.sh` |
| Empty or wrong viewer | Regenerate trace: `pipetrace-ptj-synthgen generate --objects 100 --output data/sample.ptj` |
| Tests fail after pull | Rebuild; regenerate sample data if generator changed |
| AI suggests interval bars / old pan model | Point it at `docs/ARCHITECTURE.md` — viewer is cycle-grid instants |
| AI loads all rows at once | Reinforce viewport virtualization from `AGENTS.md` |

---

## Related docs

- [`AGENTS.md`](../AGENTS.md) — daily development guide
- [`INSTALLATION.md`](INSTALLATION.md) — install, compile, test, run
- [`ARCHITECTURE.md`](ARCHITECTURE.md) — technical design
- [`STATUS.md`](STATUS.md) — feature checklist and roadmap
- [`README.md`](../README.md) — product specification
