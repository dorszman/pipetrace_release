# Status

Last updated: 2026-09-04 (event color ownership: analyze invents; cast/viewer do not).

## Tool binaries

| Binary | Role |
|--------|------|
| `pipetrace-view` | GUI viewer |
| `pipetrace-linx` | Orchestrator / main Linx entry |
| `pipetrace-linx-parser` | Linx `.pt` → DB |
| `pipetrace-linx-analyze` | Single/dual DB analysis |
| `pipetrace-linx-synthgen` | Synthetic Linx `.pt` |
| `pipetrace-ptj-synthgen` | Synthetic PTJ (main); also `import` / `info` |

Notes:
- **PTJ** = Pipetrace Trace JSON (JSON Lines), not Linx `.pt`.
- Config source file: `config/pipetrace.linx.json`. Packaging / CMake copy it to `pipetrace.app.json` next to `pipetrace-view` (Windows ZIP same).
- `pipetrace-view` config order: `--config PATH`, then `PIPETRACE_CONFIG`, then `pipetrace.app.json` next to the executable (no `<exe_dir>/config/` fallback).
- `pipetrace-view` takes positional store paths (`view [a.db] [b.db]`), not `--store` / `--store2`.
- `pipetrace-linx` may resolve config from `PIPETRACE_CONFIG`; parser and analyze take `--config` only.

## Implemented

### Storage and format
- [x] PTJ JSON Lines import
- [x] SQLite store with viewport object/event queries
- [x] Contiguous-id viewport `BETWEEN` queries (O(visible); no full-object maps)
- [x] Prep-time `object_sort_rank` tables from analyze; viewer O(viewport) scheme sorts
- [x] Columnar query results
- [x] Event type display chars and colors (`event_type_display`)
- [x] Event color ownership: cast leaves unset sentinel (`#888888`); analyze invents hash palette + updates config; viewer/store read DB RGBA with no fallback
- [x] `query_event_cycle_counts(type, time_start, time_end)` — time-bounded; GUI uses cached viewport events

### Generator
- [x] Generic task trace generator
- [x] CPU pipeline generator (6 stages)
- [x] Wide decode (`decode_width`, default 4)
- [x] Common overlays: cancel, stall
- [x] 100 rare event types with low individual probability
- [x] CLI: `generate`, `import`, `info`; flags `--objects`, `--width`, `--output`

### Timeline viewer
- [x] Cycle × row grid (instant events as chars in cells)
- [x] Stable cycle-number x-axis with adaptive label spacing
- [x] Zoom anchoring (pan/zoom without drift)
- [x] Row virtualization + query cache with prefetch margin
- [x] Multi-event same cell (concat chars, priority by event type id)
- [x] Adjustable event char size (sidebar)
- [x] Event type marking (multi-select)
- [x] Occurrence header strips with per-cycle **counts**
- [x] Header label column (full event name); clipping at high zoom
- [x] Filterable virtualized event-type sidebar list
- [x] Per-object attributes (PTJ/SQLite); pinned row columns via app config
- [x] Named `sort_schemes` from config reorder rows when ranks were materialized at analyze
- [x] Per-event attributes (PTJ `attrs`, SQLite `events.attributes`); hover tooltip, sidebar, sticky popups
- [x] Sticky attribute popups (**X** to pin, drag header, close, scroll); foreground draw-list overlay
- [x] Crosshair on grid click; pinned markers on Ctrl+click; clear markers button
- [x] Marker bands extend across pinned row columns (not just grid)
- [x] Color schemes: Night, Day, Gay (sidebar theme button)
- [x] User guide: `docs/USAGE.md`

### Tooling
- [x] `build.sh`, CMake, unit tests
- [x] Sample trace: `data/sample.ptj` / `data/sample.ptj.db`
- [x] Migration and AI onboarding docs: `docs/MIGRATION.md`, `AGENTS.md`
- [x] Installation guide: `docs/INSTALLATION.md`
- [x] Vendored `third_party/` deps for offline builds (`scripts/vendor_deps.sh`)
- [x] Linx import pipeline: `pipetrace-linx-parser` (PT → Raw DB), `pipetrace-linx-analyze` (single/dual on DB), `pipetrace-linx` orchestrator, status `--status pretty|plain` — see `docs/LINX_DB_ANALYSIS.md`
- [x] Windows CI release (`.github/workflows/release-windows.yml`): builds `pipetrace-view.exe` only on MSVC; ZIP includes `pipetrace.app.json` (renamed from `config/pipetrace.linx.json`) next to the exe; public zip in `pipetrace_release`; **verified working** on Windows (2026-09-03)

## Not yet implemented

- [ ] Density aggregation when zoomed out (bucket/heatmap instead of per-cell chars)
- [ ] Background query workers and cancellable loads
- [ ] UI non-blocking during DB access
- [ ] Minimap / overview strip for 10M+ rows
- [ ] Perfetto and custom GPU renderer benchmarks (per original README plan)
- [ ] Object grouping by type in the row axis
- [ ] Zoom-to-selection, search beyond event-type filter

## Known limitations

- Windows packaging ships `pipetrace-view.exe` and `pipetrace.app.json` in the same folder; Linx/PTJ CLI tools remain Linux-only.
- Event-type list is loaded on open (O(types), not O(objects); currently dozens to hundreds).
- Occurrence strips count marked types among **cached viewport rows**, not globally across all objects.
- Header double-click on a column that is not (and not the reverse of) a configured scheme shows triangles only — it does not run JSON `ORDER BY` (that would be O(objects) at 1M scale).
- Incremental **/** search matches attributes in the cached row window only.
- Dual-trace InstID sync does not build a full-object map; partners follow the same row index.
- `README.md` MVP spec describes interval events and multi-renderer benchmarks; current code is cycle-grid instant events with ImGui only.

## Recent history (git)

```
7409eae Replace sticky popups with foreground draw-list overlays.
8962285 Add per-event attributes and sticky cell attribute popups.
d3929af Extend marker bands across pinned row columns and expand layout docs.
bb4c46c Add Night, Day, and Gay viewer color schemes.
b432ce9 Add wide decode generation and per-cycle occurrence counts.
```

## Sample trace stats (100 objects, default generator)

- ~108 event types (6 stages + 2 common + 100 rare)
- ~1000+ events (pipeline + overlays + rare)
- Wide decode: 4 uops per decode cycle

Regenerate after generator changes:

```bash
./build/pipetrace-ptj-synthgen generate --objects 100 --output data/sample.ptj
```
