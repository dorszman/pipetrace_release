# Linx `.pt` import tool — requirements

Status: **implemented**.

## Decisions (locked)

| # | Topic | Decision |
|---|--------|----------|
| 1 | Binary name | **`pipetrace-linx-parser`** |
| 2 | Config keys | `event_type_display`: `[{ "name", "char", "color" }]` — `color` is `#RRGGBB` or `#RRGGBBAA` |
| 3 | Object tree | **`objects.id`** (existing PK) + new **`objects.parent_id`** column; not only JSON |
| 4 | DB output | **Always overwrite** `--store` path (delete/recreate file) |
| 5 | Implementation | **C++**; **open-source libs only**; **runtime performance critical** (millions of objects) |

## Purpose

Provide a **standalone CLI** (not `pipetrace-ptj-synthgen`) that reads the proprietary **Linx `.pt` trace format** and produces:

1. A **pipetrace-compatible SQLite store** (`.db`) suitable for `./build/pipetrace-view … path.db`.
2. An **updated application config** at `config/pipetrace.linx.json` with **new** event-type display entries (char hints; colors filled later by analyze).

The tool is format-specific and lives beside pipetrace; it does not extend the generic PTJ pipeline CLI.

## Tool identity

| Item | Value |
|------|--------|
| Binary | **`pipetrace-linx-parser`** |
| Generator | **`pipetrace-linx-synthgen`** — synthetic `.pt` stimulus traces |
| CMake target | `pipetrace_linx_pt` library + two executables |
| Not part of | `pipetrace-ptj-synthgen` |

Example invocation:

```bash
./build/pipetrace-linx-parser \
  --input /path/to/trace.pt \
  --store /path/to/trace.db \
  --config config/pipetrace.linx.json

# Synthetic stimulus trace (testing / benchmarks)
./build/pipetrace-linx-synthgen --output /tmp/big.pt --objects 100000 --events-per-object 4

# Partial retire demo (some instructions/uops omit retire events)
./build/pipetrace-linx-synthgen --output /tmp/partial.pt --objects 20 --uops-per-instruction 4 --partial-retire
```

Generated traces use quoted attributes with spaces (e.g. `disasm:"add r0, r3 slot 0"`) to match real Linx exports.

Each generated instruction owns several uops (`type:Instruction` / `type:Uop`, default 4 uops per instruction). Uop attribute lines carry `disasm` only. Every uop gets a `retire_uop(R)` event. Every instruction gets a `retire_inst(R)` event; `InstID:<serial>` is **event metadata on that line only** — not an object attribute on instructions or uops until analysis runs.

With **`--partial-retire`**: instructions where `inst_serial % 3 == 2` omit `retire_inst` (child uops get no `InstID` after analysis); the 2nd uop (`uop_index == 1`) in each instruction omits `retire_uop`.

All flags required unless defaults are documented below.

---

## Implementation constraints

### Language and dependencies

| Rule | Detail |
|------|--------|
| Language | **C++17** (same as pipetrace) |
| Libraries | **Open source only** — no proprietary or network services at cast time |
| Allowed deps | **SQLite** (bundled), **pipetrace_core** / existing storage layer, **C++ standard library** |
| Not allowed | Python/Rust/Java cast tools; commercial parsers; runtime `exec` of helper binaries for parsing |
| GUI | None — CLI only |

Link against existing `pipetrace_core` + `pipetrace_sqlite` where possible (shared schema, insert helpers, attribute JSON utilities) rather than duplicating DB logic.

### Scale target

Design for traces with **millions of objects** and ** tens of millions of events**. Cast time and peak memory must stay practical on a single workstation (no cluster, no external DB server).

| Metric | Target (guideline) |
|--------|---------------------|
| Objects | **≥ 1M** supported |
| Events | **≥ 10M** supported |
| Memory | **O(unique objects + event batch buffer)** — must **not** require loading the full `.pt` file into RAM as one string |
| I/O | **Single sequential pass** over the input file (streaming) |
| DB write | **One transaction** for bulk insert; commit at end |

### Performance architecture (required)

**Parse phase (streaming)**

- Read input with a **buffered `std::ifstream`** or memory-mapped file (`mmap` optional on Linux — OSS, no extra lib).
- Parse **one line at a time**; no full-file `std::getline` into a giant vector of lines.
- Line parser: hand-written state machine or pointer scan — **no regex** on hot path (e.g. no `std::regex`).
- Aggregate into structures keyed by `OBJ_ID`:
  - **`std::unordered_map`** (or sorted vector + binary search if IDs dense 0..N-1) with **`reserve()`** when object count hint available.
  - For **dense IDs** `0..N-1`, prefer **`std::vector<ObjectAccum>`** indexed by id to avoid hash overhead (implementation may auto-detect density after first pass or use vector with sparse fallback).

**Object aggregation**

- Per object: `parent_id`, attribute map, `first_time` / `last_time`, event list or **streaming event spill**.
- If event count exceeds in-memory budget: **spill events to a temp SQLite DB or sorted temp file** during pass 1, merge in pass 2 — document if implemented; default acceptable approach is **batched event buffer** flushed periodically inside the same output DB transaction.

**DB write phase**

- Reuse **`SqliteStore`** insert paths with **prepared statements** kept hot.
- Wrap entire import in **`BEGIN IMMEDIATE`** … **`COMMIT`** (same pattern as PTJ import).
- SQLite pragmas during cast (restore after): `synchronous=OFF`, `journal_mode=MEMORY` or `WAL`, `cache_size` tuned — **trade crash safety for cast speed** (cast is reproducible from `.pt`).
- Insert order: `object_types` / `event_types` → `objects` (with `parent_id`) → `events` in **batches** (e.g. 4k–16k rows per step) to limit statement bind overhead.
- Build **`objects.attributes` JSON** once per object at insert time; avoid repeated string concatenation in inner loops (use small buffer or pre-sized `std::string`).

**Config merge phase**

- Run **after** parse/type discovery; single read + single write of `pipetrace.linx.json`.
- Config file is tiny — performance not critical here.

**Progress / observability**

- Optional `--verbose`: print objects/events processed every N lines (default N large to avoid stderr overhead).

### Performance tests (acceptance)

Add benchmarks or timed tests (not necessarily CI-gated initially):

1. **Synthetic 1M-object trace** (minimal attrs + few events each) completes within agreed budget (e.g. < 60s on dev machine — record baseline in test).
2. Peak RSS **sub-linear** vs file size (streaming verified — file 2× size must not 2× peak memory if object count fixed).
3. Correctness subset: spot-check IDs, parent_id, event counts against small golden `.pt`.

---

## Input: `.pt` line format

UTF-8 text, one logical record per line. No comment syntax. Lines that contain only whitespace are skipped.

### Line validity

| Line content | Behavior |
|--------------|----------|
| Empty or whitespace only | **Skip** silently |
| Any other non-blank content that fails to parse | **Fatal error** — abort cast, non-zero exit |

### Line classification (by prefix)

| Kind | Prefix | Meaning |
|------|--------|---------|
| **Attribute line** | `[OBJ_ID]` | Object metadata |
| **Event line** | `[OBJ_ID] [CYCLE]` | Event at cycle for object |

- `OBJ_ID` and `CYCLE` are non-negative integers in square brackets.
- After the prefix, the remainder is a whitespace-separated list of **fields**.

### Field syntax

- Default form: `key:value`
- **Unquoted** `value` is a single token (no spaces).
- **Quoted** `value` uses double quotes: `key:"any text here"` including spaces and special characters.
- On a single **event line**, each metadata **key must be unique** (duplicate keys on one line → parse error for that line).

Example (`/home/doron/linx_example.pt`):

```text
[0] type:AAA parent:-1
[0] disasm:"das das das das"
[0] [1] event_type(f) EVEN:1 VA:0x50000200
[1] dsfds:FDSFD parent:0
```

---

## Parsing semantics

### Streaming aggregation (order-independent)

- Lines may appear in **any order**.
- Input may be **truncated at head or tail** (partial export). Valid lines import; a **malformed non-blank line** (including a truncated tail line with visible content) is a **fatal error**.
- Each valid line **aggregates** into in-memory (then DB) state:

| Line kind | Effect |
|-----------|--------|
| Attribute | Merge `key:value` fields into `objects[OBJ_ID].attributes` |
| Event | Append one event for `(OBJ_ID, CYCLE)` |

**Attribute merge rule:** later line **overwrites** the same key on the same object (last wins).

**Object stub:** attribute or event line for an unseen `OBJ_ID` creates a stub object immediately.

### Object fields

| Field | Treatment |
|-------|-----------|
| `OBJ_ID` | Primary key; numeric; unique |
| `type` | Ordinary object attribute (not a separate schema entity) |
| `parent` | **Special** — parsed from attr line; stored as **`objects.parent_id`** (see schema below). Also omitted from generic attributes JSON once promoted to column. |
| Any other key | Stored as generic object attribute JSON |

No requirement that attributes precede events.

### Event fields

| Field | Treatment |
|-------|-----------|
| `event_type` or `event_type(c)` | Event **kind** / type name. Optional `(c)` is a one-character **display char** hint. Parentheses may be omitted entirely. |
| All other `key:value` fields on the line | Per-event attributes (e.g. `EVEN`, `VA`, `InstID` on `retire_inst`) stored as JSON on the event row |

- **Multiple events** per object are supported, including **multiple events on the same cycle**.
- `event_type(…)` is the event kind; there is no separate “kind” key.

### Display char conflicts (trace vs config)

While scanning the trace:

- First time an event type name is seen with an optional `(char)` hint, record that hint.
- If the same type name appears later with a **different** `(char)` hint → **keep first**, emit **warning** to stderr (do not fail).

---

## Output 1: SQLite store (`.db`)

Must be loadable by the existing pipetrace viewer and reuse `TraceStore` / `sqlite_store` conventions.

### Mapping to pipetrace model

| `.pt` concept | pipetrace storage |
|---------------|-------------------|
| Object | `objects` row: `id = OBJ_ID`, `parent_id` from `parent` attr (default **-1** if never set), `first_time` / `last_time` from min/max event cycles |
| Object attrs | JSON blob on `objects.attributes` (`type`, `disasm`, … — **excluding** `parent` once stored in column) |
| Event | `events` row: `object_id`, `start_time = CYCLE`, `kind = event_type name`, `attributes` JSON for remaining fields |
| Event type | `event_types` + `event_type_display` rows derived from distinct `event_type` names seen in trace |

### DB schema: `objects.id` and `parent_id`

**Today** the `objects` table already has a primary key **`id`** (`INTEGER PRIMARY KEY`) plus `object_type_id`, `name`, `first_time`, `last_time`, `attributes`.

**It does not yet have `parent_id`.** Implementation must add it via the existing migration path (`migrate_schema()` in `sqlite_store.cpp`):

```sql
ALTER TABLE objects ADD COLUMN parent_id INTEGER NOT NULL DEFAULT -1;
```

| Column | Source | Notes |
|--------|--------|-------|
| `id` | `[OBJ_ID]` on each line | Same as `.pt` object id |
| `parent_id` | `parent:` attribute line | `-1` = no parent / root; viewer tree UI deferred |

Importer and viewer must tolerate older DBs without the column until migrated; new casts always write `parent_id`.

### DB overwrite

If `--store` path exists, **delete and recreate** the SQLite file on each run (full rebuild, no merge into old DB).

### Source trace metadata

Each cast records provenance in the **`meta`** table (alongside `name`, `object_count`, etc.):

| Key | Value |
|-----|--------|
| **`source_trace_path`** | Absolute path to `--input` |
| **`source_trace_mtime`** | Unix mtime (seconds) of that file at cast time |
| **`cast_at`** | Unix timestamp when cast completed |
| **`analysis_state`** | **`Raw`** — set on every successful cast; analysis advances this later |

Cast **skips** when the store already exists, **`source_trace_path`** matches the absolute input path, and PT mtime matches **`source_trace_mtime`** (unless **`--force`**). Analyze skip/freshness is entirely DB-state based — see [`LINX_DB_ANALYSIS.md`](LINX_DB_ANALYSIS.md).

### Time axis

- `.pt` **cycle** maps to pipetrace **timestamp** (`start_time` on events; object bounds updated from events).

### Empty / partial traces

- Zero events → still produce valid DB with zero or stub objects if attrs were seen.
- Truncated last line with non-whitespace content that does not parse → **error** (no partial commit).

---

## Output 2: `config/pipetrace.linx.json` (deployment profile)

Pass the profile with **`--config PATH`** (required on cast / analysis). Only **`pipetrace-linx`** may resolve config from **`PIPETRACE_CONFIG`** when `--config` is omitted; it then forwards `--config <resolved>` to child tools. **`pipetrace-view`** also accepts `PIPETRACE_CONFIG` and, if both are omitted, `pipetrace.app.json` next to the executable (CMake / Windows packaging rename `config/pipetrace.linx.json` → that name).

This file is the **complete customization profile** for a specific pipetrace deployment: viewer layout, event-type appearance, and the **cast tool** used to import proprietary `.pt` traces.

### Config layout

```json
{
  "cast_tool": {
    "command": "./build/pipetrace-linx-parser"
  },
  "pinned_row_attributes": [
    { "key": "type", "label": "Type", "width_px": 88 },
    { "key": "InstID", "label": "Inst", "width_px": 44 },
    { "key": "RetirePushup", "label": "Pushup", "width_px": 56 },
    { "key": "disasm", "label": "Disasm", "width_px": 320 }
  ],
  "event_type_display": [
    { "name": "fetch", "char": "f", "color": "#2E8D30" }
  ]
}
```

| Section | Purpose |
|---------|---------|
| **`cast_tool.command`** | Path or command name for **`pipetrace-linx-parser`** — canonical pointer so scripts, docs, and users know which binary belongs to this profile |
| **`pinned_row_attributes`** | Existing viewer row-panel columns |
| **`event_type_display`** | Event type → display char + color. Cast appends **char** hints (color unset); analyze fills colors. Shipped default is **`[]`**. |

Both **`pipetrace-linx-parser`** and **`pipetrace-linx-analyze`** update the same config file. The viewer reads colors from the store at runtime (DB RGBA; no invent fallback).

### `event_type_display` merge rules (critical)

1. **Never remove** existing entries; **do not change** char or a user-chosen (non-sentinel) color.
2. **Cast** — for each event type name discovered in the trace:
   - If an entry with that `name` **already exists** → keep char; keep color as-is (including unset/`#888888` sentinel). Write that color into the DB (sentinel stays unset for analyze).
   - If **missing** → **append** new entry with `char` from the first `(char)` hint in the trace (else name fallback) and **no invented color** (omit `color` / leave sentinel).
3. **Analyze** — for every DB event type whose color is unset/sentinel `#888888` / `0xFF888888`:
   - Prefer an existing non-sentinel config color; otherwise assign `hash_event_type_color_rgba(name)`.
   - Update DB `event_types` / `event_type_display` and append/update config.
   - Skip when all types already have real colors (unless `--force`; force still does not overwrite real colors).
4. Once a non-sentinel color is written, it stays stable across subsequent imports/analyzes.

### Color assignment for new types

- Trace does not carry colors; **analyze** invents them (not cast, not the viewer).
- Unset sentinel is `0xFF888888` (`#888888`) because schema columns are `NOT NULL` — prefer not treating that grey as a real user color.
- Config entries that omit `color` / `color_rgba` load as unset until analyze.
- Viewer/store reads paint stored RGBA with **no** grey→hash fallback.

### Relationship to DB `event_type_display`

- After a full cast→analyze pipeline, DB rows hold effective char + color.
- Config is the long-lived user-facing map; analyze keeps it in sync when inventing colors.
---

## CLI interface

```
pipetrace-linx-parser --input PATH.pt --store PATH.db --config PATH [--trace-name NAME] [--force]
```

| Flag | Required | Description |
|------|----------|-------------|
| `--input` | yes | Source `.pt` file |
| `--store` | yes | Output SQLite path (**overwrites** if exists) |
| `--config` | yes | App config to merge (no env / no default path) |
| `--trace-name` | no | Metadata name in DB (default: input stem) |

### Exit codes

| Code | Meaning |
|------|---------|
| 0 | Completed; warnings may have been printed |
| >0 | Fatal error (missing input, cannot write DB/config, etc.) |

### Stderr warnings (non-fatal)

- Duplicate display char hint for same event type
- Object referenced only by attrs, no events (informational optional)

### Fatal errors (stderr + non-zero exit)

- Unparseable non-blank line (with line number)
- Event line missing `event_type`

---

## Non-goals (this phase)

- Viewer tree UI for `parent` (parse and store only)
- Incremental append to existing DB (full rebuild per run is OK unless specified later)
- PTJ output
- Integration into `pipetrace-ptj-synthgen`

---

## Tests (acceptance)

1. Parse `linx_example.pt` → expected object/event counts.
2. Quoted attribute with spaces round-trips.
3. Out-of-order attrs/events produce same DB as ordered file.
4. Truncated malformed tail line fails cast (no `.db` written).
5. Config merge: pre-populate one event type; import must not overwrite char/color.
6. Config merge: new type from trace appends entry with char from `(f)` or fallback.
7. Display char conflict in trace → first wins + warning.
8. Two events same object same cycle → both stored.
9. `parent_id` column set correctly (`parent:0` → `0`, missing → `-1`); queryable from DB.

---

## Implementation order

1. Schema migration: `objects.parent_id`
2. **Streaming** `.pt` line parser (C++, no regex hot path)
3. **Batched** DB writer via `pipetrace_core` / `SqliteStore` (single transaction, prepared statements)
4. Config merge (`event_type_display` append-only)
5. CMake target + binary **`pipetrace-linx-parser`** (links `pipetrace_core`, no GUI deps)
6. Correctness tests + **scale/perf smoke test** (1M-object synthetic trace)
