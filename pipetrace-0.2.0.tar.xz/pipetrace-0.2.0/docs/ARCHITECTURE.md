# Architecture

pipetrace is a C++ desktop trace visualizer for large instant-event traces. The MVP uses Dear ImGui + OpenGL; storage is SQLite with viewport-scoped queries.

## Pipeline

```
PTJ file  →  Importer  →  SQLite store  →  Viewport queries  →  Timeline viewer
Generator ----^
```

## Data model

Defined in `include/pipetrace/types.hpp`.

| Concept | Description |
|---------|-------------|
| **Object type** | Schema for a class of traced entities (e.g. `uop`) |
| **Event type** | Schema for events: name, color, display char |
| **Object** | One traced entity; `first_time` / `last_time` bounds |
| **Event** | Single instant at `time` (stored as `start_time` in SQLite); optional key/value attributes |
| **Row** | Viewer row index = dense rank by `objects.id` (`ORDER BY id`, 0-based), or by prep-time `object_sort_rank` when a named sort scheme is active |

Events are **instants**, not intervals. Timestamps are 64-bit integers (cycles in the CPU generator).

### Columnar query results

`ColumnarObjects` and `ColumnarEvents` (`include/pipetrace/columnar.hpp`) return parallel arrays for efficient rendering without per-event heap allocations.

### Cycle occurrence counts

`CycleOccurrenceCount { cycle, count }` — number of events of a given type at a cycle (across all objects). Used by marked-type header strips.

## Input format (PTJ)

Pipetrace Trace JSON Lines — one JSON object per line.

| Record | Purpose |
|--------|---------|
| `meta` | Trace name and version |
| `object_type` | Object schema |
| `event_type` | Event schema: `name`, `object_type`, `color`, `char` or `char_code` |
| `object` | Entity with `id`, times, name |
| `event` | `object_id`, `kind`, `time`, optional `attrs` (JSON object) |

Example:

```json
{"type":"event_type","name":"decode","object_type":"uop","color":4281240880,"char":"D"}
{"type":"object","id":1,"object_type":"uop","name":"uop_0_s0","first_time":0,"last_time":5}
{"type":"event","object_id":1,"kind":"decode","time":0,"attrs":{"phase":"front","port":0}}
```

Import path: `src/importer/trace_importer.cpp` → `src/storage/sqlite_store.cpp`.

### Display metadata

Table `event_type_display` stores `display_char` and color per event type. Importer accepts `"char":"D"` or `"char_code":68`.

**Color ownership:**
- **Cast** (`pipetrace-linx-parser`) creates event type rows and keeps PT display-char hints. Color stays **unset** (`0xFF888888` / `#888888` sentinel — schema is `NOT NULL`, so NULL is unavailable). Cast merges **existing** non-sentinel config colors into the DB; it does not invent palette colors.
- **Analyze** (`pipetrace-linx-analyze`) invents colors in progress phase `event_colors` (near `sort_ranks`): for every type still on the sentinel, assigns `hash_event_type_color_rgba`, updates DB `event_types` / `event_type_display`, and appends/updates `event_type_display` in `--config`. Skips when all types already have real colors (unless `--force`, which still never overwrites non-sentinel colors).
- **Viewer / store reads** paint whatever RGBA is in the DB — no grey→hash fallback.

Shared helper: `include/pipetrace/event_colors.hpp`. Shipped `config/pipetrace.linx.json` keeps `event_type_display: []`; cast may append char-only entries; analyze fills colors.

## Storage

SQLite backend: `src/storage/sqlite_store.cpp`.

**Indexes:** objects by `(first_time, last_time)`; events by `(object_id, start_time, end_time)`. Viewer `open()` does not create new indexes (that would scan the full store).

**Viewport object query (viewer hot path):** for contiguous INTEGER PRIMARY KEY ids (`max(id)-min(id)+1 == object_count`), rows map to ids with `WHERE id BETWEEN ? AND ?` — **O(visible rows + buffer)**. Sparse id spaces fall back to `ORDER BY id LIMIT/OFFSET`. When a named `SortScheme` is active and prep-time ranks exist in `object_sort_rank`, the viewer uses `WHERE scheme=? AND rank BETWEEN ? AND ?` joined to `objects` — also **O(viewport)**. Missing ranks fall back to id order (never live `json_extract` `ORDER BY` on the GUI path).

**Viewport event query:** events for those object IDs with `start_time` in the viewport time window (+ buffer). Uses `idx_events_object_time`. **O(events in the window for those objects)**.

**Occurrence strips:** counted from the cached viewport events for marked types (**O(cached events)**), not a full `GROUP BY` over the event table.

**Attribute keys:** read the small `object_attribute_keys` table only (populated at import). Viewer open does not `json_each` every object.

**Prep-time sort ranks:** table `object_sort_rank(scheme, rank, object_id)` with `PRIMARY KEY (scheme, rank)` and `UNIQUE (scheme, object_id)`. Built as the last stage of single `pipetrace-linx-analyze` for each `sort_schemes` entry in the app config, using the same typed `ORDER BY` as `build_object_sort_order_by_clause` / `sort_sql.cpp`. Meta key `object_sort_ranks_fingerprint` stores the scheme list fingerprint for skip-if-up-to-date; `--force` or fingerprint mismatch rebuilds. After dual analyze, schemes whose keys start with `Dual` (e.g. `DualRetirePushup`) are rebuilt so ranks see dual attributes.

**Dual-trace sync:** does not build an InstID→row map of all objects. Empty index ⇒ partner uses the same row index.

Interface: `TraceStore` in `include/pipetrace/storage.hpp`.

## Generators

### CPU pipeline (`src/generator/cpu_pipeline_generator.cpp`)

| Parameter | Default | Meaning |
|-----------|---------|---------|
| `object_count` | 1000 | Number of uops |
| `time_span` | 100000 | Cycle budget |
| `stages` | 6 | Pipeline stages (1–6) |
| `decode_width` | 4 | Uops decoded per cycle (wide machine) |
| `seed` | 42 | RNG seed |

**Scheduling:** uop `i` decodes at cycle `i / decode_width`; stages are consecutive cycles. Names: `uop_<i>_s<i % decode_width>`.

**Event types emitted:**

- 6 pipeline stages (`D R A I E T`)
- 2 common overlays: `cancel`, `stall`
- 100 rare types: `{tlb,icache,dcache,...}_{miss,stall,replay,fault,retry}`

**Overlay rates (per uop):** cancel ~33%, stall ~25%, each rare type ~4%.

### Generic trace (`src/generator/generic_generator.cpp`)

Simple task workflow trace for non-CPU testing.

Both generators write PTJ and import to `<output>.db`.

## Timeline viewer

Main implementation: `src/app/timeline_view.cpp`. GUI shell and side panels: `src/app/main.cpp`.

End-user panel guide: [`docs/USAGE.md` § Layout](USAGE.md#layout).

### Window layout

Left to right: **sidebar** (`BeginChild("sidebar")`) → **detail_panels** (`pinned_markers` + `object_attrs`) → **timeline** (`TimelineView::draw("timeline")`).

The **timeline** child contains a custom-drawn **plot** (`plot_origin` / `plot_size`), optional **left_gutter** (**row_panel** + **occurrence_label_origin**), **plot_header** (**cycle_axis** + **occurrence_panel** rows), scrollable **grid**, and an ImGui **footer** (`kTimelineFooterHeight`).

Full name table: [`docs/USAGE.md` § Layout vocabulary](USAGE.md#layout-vocabulary-code-names).

### Timeline plot layout

```
timeline BeginChild("timeline")
├─ plot (plot_origin, plot_size)          ← ImDrawList custom draw
│  ├─ plot_header (plot_header_height)
│  │  ├─ row_panel + occurrence_label_origin + cycle_axis
│  │  └─ occurrence_panel × marked types
│  └─ grid (grid_origin, grid_size)       ← scrolls with row_panel body
└─ footer (kTimelineFooterHeight)         ← ImGui::Text after Dummy(plot_size)
```

- Header height = `kCycleAxisHeight` (24px) + `kOccurrencePanelHeight` (22px) × marked type count.
- **row_panel** width = `AppConfig::row_panel_width()` (sum of `pinned_row_attributes[].width_px`).
- **occurrence_label_origin** width = `occurrence_label_width()` (min 72px); omitted when no types marked.
- **grid** and header ticks share x-alignment starting at `cycle_origin` (= `plot_origin.x + left_gutter_width`).

### Cell rendering

- One rectangle per (row, cycle).
- Events in the same cell grouped; display chars concatenated by `event_type_id` order when space allows.
- Char size adjustable (8–32 px) from sidebar.

### Interaction

| Input | Action |
|-------|--------|
| Left drag | Pan cycles and rows |
| Wheel | Zoom cycle width and row height (anchor-preserving) |
| Click grid cell | Move active row/column bands; select object on that row if present |
| Ctrl + click grid cell | Pin row/column bands at clicked cell, then move active bands there |
| Sidebar **Clear markers** | Remove all pinned markers (crosshair unchanged) |
| Pinned markers panel | Click entry to navigate; **X** removes one marker |
| Sidebar **Theme** button | Cycle color scheme: Night → Day → Gay |
| Sidebar click | Toggle mark on event type |
| Hover grid cell | Tooltip with events and per-event attributes |
| **X** while hovering cell | Pin sticky attribute popup (foreground overlay) |
| Sticky popup header drag | Move pinned popup |
| Sticky popup **X** | Close that popup |
| Wheel over sticky body | Scroll long attribute lists |

### Sticky attribute popups

Pinned cell-inspection panels are **not** ImGui windows. They are drawn with `ImGui::GetForegroundDrawList()` after the main window closes, so they sit on top of the timeline without parent clipping.

- Layout (`layout_sticky_popup`) measures text once at pin time; size stays fixed.
- Input (`handle_sticky_popups_input`) uses the same screen rects as drawing (drag header, close button, scroll body).
- Hover tooltips (before pinning) remain a small ImGui tooltip window.

### Caching

`refresh_cache()` loads objects/events for viewport ± buffer. Skipped while panning; refreshed on release or when scroll exits cache.

### Sidebar (`src/app/main.cpp`)

- Filter box (case-insensitive match on name or display char).
- Virtualized list (`ImGuiListClipper`) for large type catalogs.
- Marked types stay marked when filtered out.

## Virtualization and scale

At minimum zoom (~8 px row height), ~100 rows fit on screen. The store may hold millions of objects; the viewer always queries and draws **O(visible rows × visible cycles + buffer)**. No viewer hot path scans or materializes all objects or events.

Not yet implemented: density aggregation when zoomed out, background query workers, minimap.

## Build

```bash
./build.sh
./build/pipetrace-view --config config/pipetrace.linx.json data/sample.ptj.db
ctest --test-dir build
```

Requires C++20, OpenGL/GLFW dev packages for the GUI. Viewer config: `--config`, else `PIPETRACE_CONFIG`, else `pipetrace.app.json` next to the binary.

## Tests

| Test | Covers |
|------|--------|
| `Storage.ViewportQueryReturnsOverlappingObjects` | Viewport queries, display chars, cycle counts |
| `Storage.ViewportEventsRespectTimeWindow` | Event queries clip to viewport cycles |
| `Storage.RankedViewportReturnsSubset` | Prep-time sort ranks + `rank BETWEEN` viewport |
| `Storage.AttributeSortViewportIsStableAcrossQueries` | Ranked scheme viewport is stable across queries |
| `Generator.CreatesCpuPipelineTrace` | CPU trace generation, ≥108 event types |

## Related docs

- `README.md` — original MVP specification and long-term goals
- `AGENTS.md` — AI onboarding and conventions
- `docs/MIGRATION.md` — new machine / new AI handoff guide
- `docs/INSTALLATION.md` — install dependencies, compile, and run
- `docs/STATUS.md` — implemented features and roadmap
