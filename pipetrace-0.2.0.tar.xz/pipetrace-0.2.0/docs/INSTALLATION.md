# Installation guide

Complete steps to install dependencies, compile, test, and run **pipetrace** on a fresh system.

For project handoff and AI onboarding, see [`MIGRATION.md`](MIGRATION.md).

---

## Choose your profile

| Profile | Install | Build | Network |
|---------|---------|-------|---------|
| **A — Full offline** | System packages only | `./build.sh` | Not needed if `third_party/` is in the repo |
| **B — First clone (online once)** | System packages + `./scripts/vendor_deps.sh` | `./build.sh` | Once to populate vendors |
| **C — CLI + tests only** | Compiler + CMake (no X11/GL) | `./build.sh` or `-DPIPetrace_BUILD_GUI=OFF` | Same as A or B |

**Vendored in `third_party/`** (no system packages): SQLite, GoogleTest, GLFW, Dear ImGui, ImPlot.

**From the OS**: C++20 compiler, CMake 3.20+, and for the GUI — X11 + OpenGL (Mesa).

---

## 1. Get the source

```bash
git clone git@github.com:dorszman/pipetrace.git
cd pipetrace
```

Or copy an existing checkout. Verify vendored deps:

```bash
test -f third_party/sqlite/sqlite3.c && echo "third_party OK"
```

If `third_party/` is missing or incomplete, run [step 3](#3-populate-vendored-libraries-online-once) before building.

---

## 2. Install system dependencies

### Debian / Ubuntu

**Full build — CLI + GUI + tests (offline-capable after clone):**

```bash
sudo apt update
sudo apt install -y build-essential cmake \
  libx11-dev libxrandr-dev libxinerama-dev libxcursor-dev libxi-dev libxext-dev \
  libgl1-mesa-dev
```

GLFW also needs the X11 extension `-dev` packages (`libxrandr-dev`, …), not only `libx11-dev`.

**CLI + tests only (no GUI):**

```bash
sudo apt update
sudo apt install -y build-essential cmake
```

**First-time setup — also populate `third_party/` (needs network):**

```bash
sudo apt update
sudo apt install -y build-essential git curl unzip cmake \
  libx11-dev libxrandr-dev libxinerama-dev libxcursor-dev libxi-dev libxext-dev \
  libgl1-mesa-dev
```

### No sudo (missing X11 `-dev`, e.g. libXrandr)

Do **not** expect to vendor X11 into `third_party/` like SQLite — it must match the machine’s X11 runtime.

Without root, stage a **user prefix** (headers + linker symlinks to system `.so`, or optional full compile):

```bash
# On a machine with network (or with tarballs already copied):
./scripts/bootstrap_x11_prefix.sh
# Offline: copy x.org tarballs into deps/x11-src/ then:
# ./scripts/bootstrap_x11_prefix.sh --tarball-dir deps/x11-src

# If system .so files are missing entirely:
# ./scripts/bootstrap_x11_prefix.sh --from-source   # needs meson+ninja

./build.sh   # auto-detects deps/x11-prefix
```

Or manually:

```bash
export CMAKE_PREFIX_PATH="$PWD/deps/x11-prefix"
export PKG_CONFIG_PATH="$PWD/deps/x11-prefix/lib/pkgconfig"
cmake -S . -B build -DCMAKE_PREFIX_PATH="$CMAKE_PREFIX_PATH" -DCMAKE_BUILD_TYPE=Release
cmake --build build -j"$(nproc)"
```

`deps/` is gitignored (local to the machine).

**Run the GUI on a headless server** (software OpenGL + virtual display):

```bash
sudo apt install -y libgl1-mesa-dri mesa-utils xvfb
export LIBGL_ALWAYS_SOFTWARE=1
xvfb-run -a ./build/pipetrace-view --config config/pipetrace.linx.json data/sample.ptj.db
```

### Fedora / RHEL

```bash
sudo dnf install -y gcc-c++ cmake libX11-devel mesa-libGL-devel mesa-dri-drivers
```

CLI only:

```bash
sudo dnf install -y gcc-c++ cmake
```

### Arch Linux

```bash
sudo pacman -S --needed base-devel cmake libx11 mesa
```

### macOS (Homebrew)

The GUI targets Linux/X11 today. CLI + tests:

```bash
brew install cmake
```

---

## 3. Populate vendored libraries (online once)

Skip this if `third_party/` is already complete in your clone.

```bash
chmod +x scripts/vendor_deps.sh
./scripts/vendor_deps.sh
```

This downloads into `third_party/`:

| Library | Version |
|---------|---------|
| SQLite amalgamation | 3.46.1 |
| GoogleTest | v1.15.2 |
| GLFW | 3.4 |
| Dear ImGui | v1.91.5 |
| ImPlot | v0.16 |

Maintainers: commit `third_party/` after refreshing so offline sites need no network.

---

## 4. Compile

### Quick build (recommended)

```bash
chmod +x build.sh
./build.sh
```

You should see:

```text
Using vendored dependencies in third_party/ (offline-capable build).
```

**Artifacts:**

| Binary | When built |
|--------|------------|
| `./build/pipetrace-ptj-synthgen` | Always |
| `./build/pipetrace-linx-parser` | Always |
| `./build/pipetrace-linx-analyze` | Always |
| `./build/pipetrace-linx-synthgen` | Always |
| `./build/pipetrace-linx` | Always |
| `./build/pipetrace-view` | X11 + OpenGL dev packages present |
| Test binaries | Default (`PIPetrace_BUILD_TESTS=ON`) |

### Manual CMake build

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DPIPetrace_BUILD_TESTS=ON
cmake --build build -j"$(nproc)"
```

**CLI only** (explicit, no GUI):

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release \
  -DPIPetrace_BUILD_GUI=OFF -DPIPetrace_BUILD_TESTS=ON
cmake --build build -j"$(nproc)"
```

### CMake options

| Option | Default | Effect |
|--------|---------|--------|
| `PIPetrace_BUILD_GUI` | `ON` | Timeline viewer (needs X11 + OpenGL) |
| `PIPetrace_BUILD_TESTS` | `ON` | GoogleTest targets |
| `PIPetrace_VENDOR_DIR` | `third_party` | Vendored source path |

---

## 5. Run tests

```bash
ctest --test-dir build --output-on-failure
```

---

## 6. Sample trace and run

Sample data is not in git. Generate after first build:

```bash
mkdir -p data
./build/pipetrace-ptj-synthgen generate --objects 100 --output data/sample.ptj
./build/pipetrace-ptj-synthgen info --store data/sample.ptj.db
```

**CLI usage:**

```bash
./build/pipetrace-ptj-synthgen generate --objects 500 --width 4 --output data/my.ptj
./build/pipetrace-ptj-synthgen import --input data/my.ptj --store data/my.ptj.db
./build/pipetrace-ptj-synthgen info --store data/my.ptj.db
```

Flags: `--objects N`, `--width W` (decode width, default 4), `--generic`, `--output path.ptj`.

**GUI:**

```bash
./build/pipetrace-view --config config/pipetrace.linx.json data/sample.ptj.db
```

Requires `$DISPLAY` (local desktop, `ssh -X`, or `xvfb-run`).

After a GUI build, CMake copies `config/pipetrace.linx.json` → `pipetrace.app.json` next to `pipetrace-view`, so `--config` can be omitted. Resolution order: `--config`, then `PIPETRACE_CONFIG`, then that exe-adjacent file (not `<exe_dir>/config/`).

### Windows ZIP

The GitHub Actions Windows release ZIP ships `pipetrace-view.exe` and `pipetrace.app.json` in the **same folder**. Drop a store next to them (or pass `--store`) and run the viewer; it loads the adjacent config automatically.

---

## 7. Verify installation

```bash
c++ --version          # GCC 10+ or Clang 12+ (C++20)
cmake --version        # 3.20+
./build/pipetrace-ptj-synthgen --help 2>/dev/null || ./build/pipetrace-ptj-synthgen info --help
```

**OpenGL available?** (optional, for GUI):

```bash
sudo apt install -y mesa-utils    # Debian/Ubuntu
glxinfo | grep "OpenGL version"   # needs a display
```

---

## OpenGL on systems without it

Not every machine has OpenGL or a display. pipetrace **CLI and tests do not need OpenGL**.

To **build** the GUI:

```bash
# Debian/Ubuntu
sudo apt install -y libgl1-mesa-dev libx11-dev
```

To **run** the GUI without a GPU:

```bash
sudo apt install -y libgl1-mesa-dri mesa-utils xvfb
export LIBGL_ALWAYS_SOFTWARE=1
xvfb-run -a ./build/pipetrace-view --config config/pipetrace.linx.json data/sample.ptj.db
```

| Package | Purpose |
|---------|---------|
| `libgl1-mesa-dev` | Headers to compile against OpenGL |
| `libgl1-mesa-dri` | Mesa runtime (software or GPU) |
| `libx11-dev` | X11 headers (window system) |
| `xvfb` | Virtual framebuffer when no physical display |

---

## End-to-end copy-paste recipes

### Offline site (vendored `third_party/` in repo)

```bash
git clone git@github.com:dorszman/pipetrace.git && cd pipetrace
sudo apt update
sudo apt install -y build-essential cmake libx11-dev libgl1-mesa-dev
chmod +x build.sh && ./build.sh
ctest --test-dir build --output-on-failure
./build/pipetrace-ptj-synthgen generate --objects 100 --output data/sample.ptj
./build/pipetrace-view --config config/pipetrace.linx.json data/sample.ptj.db
```

### Fresh clone, online, full setup

```bash
git clone git@github.com:dorszman/pipetrace.git && cd pipetrace
sudo apt update
sudo apt install -y build-essential git curl unzip cmake libx11-dev libgl1-mesa-dev
./scripts/vendor_deps.sh
chmod +x build.sh && ./build.sh
ctest --test-dir build --output-on-failure
./build/pipetrace-ptj-synthgen generate --objects 100 --output data/sample.ptj
./build/pipetrace-view --config config/pipetrace.linx.json data/sample.ptj.db
```

### Headless server (CLI only)

```bash
git clone git@github.com:dorszman/pipetrace.git && cd pipetrace
sudo apt install -y build-essential cmake
chmod +x build.sh && ./build.sh
./build/pipetrace-ptj-synthgen generate --objects 100 --output data/sample.ptj
./build/pipetrace-ptj-synthgen info --store data/sample.ptj.db
```

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `cmake: command not found` | `sudo apt install cmake` (required for offline builds) |
| `third_party/ incomplete` | Run `./scripts/vendor_deps.sh` on an online machine |
| GUI not built | Install `libx11-dev libgl1-mesa-dev`, re-run `./build.sh` |
| `cannot open display` | Set `$DISPLAY`, use `ssh -X`, or `xvfb-run` |
| `OpenGL` / `glx` errors | Install `libgl1-mesa-dri`; try `LIBGL_ALWAYS_SOFTWARE=1` |
| Empty viewer | Regenerate: `pipetrace-ptj-synthgen generate --objects 100 --output data/sample.ptj` |
| Tests fail after pull | Rebuild; regenerate sample data if generator changed |

---

## Disk space

| Path | Approximate size |
|------|------------------|
| `third_party/` | ~30 MB |
| `build/` | 200–500 MB after compile |

---

## Related docs

- [`MIGRATION.md`](MIGRATION.md) — new machine / AI handoff
- [`ARCHITECTURE.md`](ARCHITECTURE.md) — design and data flow
- [`AGENTS.md`](../AGENTS.md) — development conventions
- [`README.md`](../README.md) — product specification
