# pipetrace viewer usage

End-user guide for the pipetrace desktop GUI. For install and build, see [`INSTALLATION.md`](INSTALLATION.md).

## Launch

```bash
./build/pipetrace-view --config config/pipetrace.linx.json data/sample.ptj.db
```

Dual-trace (second store is optional):

```bash
./build/pipetrace-view --config config/pipetrace.linx.json trace_a.db trace_b.db
```

On Windows, associating `.db` with `pipetrace-view.exe` and using **Open with** (one or two files) passes those paths as positional arguments the same way.

| Argument | Purpose |
|----------|---------|
| `--config PATH` | Application config (pinned row columns, etc.). Optional if env or exe-adjacent file is present. |
| `--generate` | Regenerate sample trace before opening |
| `--objects N` | Object count when generating |
| `--trace path.ptj` | PTJ input path |
| `store.db` | Positional: primary SQLite store |
| `store2.db` | Positional: optional second store (dual-trace) |

`pipetrace-view` resolves config in this order (first match wins; a given path that is missing is an error, not a skip):

1. `--config PATH`
2. `PIPETRACE_CONFIG`
3. `pipetrace.app.json` in the same directory as the executable (not `<exe_dir>/config/`)

The `pipetrace-linx` orchestrator still uses `--config` or `PIPETRACE_CONFIG`, then passes `--config` to child tools. Parser and analyze remain `--config` only.

## Layout

The window is arranged left to right in **five vertical regions**. A menu bar spans the top; the timeline **footer** spans the bottom of the **plot** area. Code-matched names: **sidebar** → **detail_panels** → **timeline** (see [Layout vocabulary](#layout-vocabulary-code-names)).

```
┌──────────┬────────────┬──────────────────────────────────────────────┐
│ Sidebar  │ Pinned     │ Pinned row cols │ Occurrence │  Timeline     │
│  260px   │ markers    │   ~364px*       │  labels†   │  grid         │
│          │  150px     │  cycle axis + occurrence header strips       │
│          ├────────────┤──────────────────────────────────────────────┤
│          │ Selected   │  cycle × row grid (main plot)                │
│          │ object     │                                              │
│          │  (rest)    │                                              │
└──────────┴────────────┴──────────────────────────────────────────────┘
│ footer: viewport stats, crosshair, hover text, marked types            │
```

\* Width from app config (`pipetrace.app.json`; source tree: `config/pipetrace.linx.json`) (default Inst 44px + Asm 320px).  
† Only visible when one or more event types are marked; width adapts to the longest marked type name.

### Layout vocabulary (code names)

Use these names when discussing UI regions — they match ImGui child IDs, variables, and draw functions in `main.cpp` and `timeline_view.cpp`.

#### Top-level window (`main.cpp`)

| Name | Code | File |
|------|------|------|
| Root window | `ImGui::Begin("pipetrace", …)` | `main.cpp` |
| Menu bar | `ImGui::BeginMenuBar()` | `main.cpp` |

#### Main columns (left → right)

| Name | Code | Size / notes |
|------|------|----------------|
| **sidebar** | `BeginChild("sidebar")` | 260px; trace stats, theme, controls, crosshair readout, event-type list |
| **event_types_list** | `BeginChild("event_types_list")` | nested inside **sidebar**; virtualized markable type list |
| **detail_panels** | `BeginChild("detail_panels")` | 220px; stacks the two panels below |
| **pinned_markers** | `BeginChild("pinned_markers")` | 150px tall inside **detail_panels** |
| **pinned_markers_list** | `BeginChild("pinned_markers_list")` | scroll list inside **pinned_markers** |
| **object_attrs** | `BeginChild("object_attrs")` | remaining height in **detail_panels**; selected object + cell events |
| **timeline** | `TimelineView::draw("timeline", …)` → `BeginChild(label)` | fills remaining width |

#### Timeline child internals (`TimelineView::draw`)

The **timeline** child splits into a custom-drawn **plot** and an ImGui **footer**.

| Name | Code | Notes |
|------|------|-------|
| **plot** | `plot_origin`, `plot_size`, `plot_max` | full draw area above footer (`inner_avail.y - kTimelineFooterHeight`) |
| **footer** | ImGui widgets after `ImGui::Dummy(plot_size)` | reserved `kTimelineFooterHeight` (40px); cycles/rows stats, crosshair line, `hover_text`, marked-type summary |
| **plot_header** | `plot_header_height()` | top band of **plot**; height = `kCycleAxisHeight` + marked types × `kOccurrencePanelHeight` |
| **left_gutter** | `left_gutter_width` | `row_panel_width + label_width`; non-scrollable left strip |

#### Left gutter (inside **plot**)

| Name | Code / function | Notes |
|------|-----------------|-------|
| **row_panel** | `row_panel_origin`, `row_panel_width`, `draw_row_attributes_panel()` | config columns from `AppConfig::pinned_row_attributes` (`PinnedRowAttribute`: `key`, `label`, `width_px`, optional `scope`: `Always`, `SingleTrace`, `DualTrace`) |
| **occurrence_label_origin** | `occurrence_label_origin`, `draw_header_label_column()` | marked-type names (e.g. `'D' decode`); width from `occurrence_label_width()`; hidden when no types marked |
| **cycle_origin** | `cycle_origin`, `cycle_width_px` | left edge of cycle axis and occurrence strips (right of **left_gutter**) |

#### Header band (top of **plot**, height = **plot_header**)

| Name | Code / function | Height |
|------|-----------------|--------|
| **cycle_axis** | `draw_cycle_axis()`, `kCycleAxisHeight` | 24px; cycle number labels |
| **occurrence_panel** | `draw_occurrence_panel_bars()`, `draw_occurrence_panel_counts()`, `kOccurrencePanelHeight` | 22px per marked event type; bars + per-cycle counts |

#### Scrollable body (below **plot_header**)

| Name | Code | Notes |
|------|------|-------|
| **grid** | `grid_origin`, `grid_size`, `grid_max` | main cycle × row event cells |
| **row_panel** body | same `draw_row_attributes_panel()` | pinned attribute values scroll with rows |
| **row_panel_marker_fills** | `draw_row_panel_marker_fills()` | crosshair/pinned marker tints on **row_panel** rows |
| **grid_marker_fills** / **grid_marker_guides** | `draw_grid_marker_fills()`, `draw_grid_marker_guides()` | crosshair/pinned marker bands on **grid** |

#### Overlays (drawn after root window, on top of everything)

| Name | Code | Notes |
|------|------|-------|
| **sticky_event_popups_** | `StickyEventPopup`, `draw_sticky_popup_overlay()`, `draw_event_popups()` | pinned with **X**; foreground `ImDrawList` |
| **event_hover_popup** | `ImGui::Begin("##event_hover_popup")` | hover tooltip before pinning; anchor = `hover_popup_anchor` |

#### Marker / selection state (not panels)

| Name | Code | Meaning |
|------|------|---------|
| **crosshair** | `TimelineState::crosshair`, `has_crosshair` | active blue row/column bands (click grid) |
| **pinned_markers_** | `TimelineView::pinned_markers_` | amber marker bands (Ctrl+click); listed in **pinned_markers** panel |

### Menu bar

- **Trace → Reset view** — jump to trace start, clear crosshair and pinned markers.
- Trace name (read-only).

### Sidebar (`sidebar`, 260px, full height)

Left column for trace summary and global controls.

| Section | Purpose |
|---------|---------|
| **Trace stats** | Object count, event count, time span |
| **Theme** | Button labeled with the active scheme (`Night`, `Day`, `Gay`); click to cycle |
| **Controls** | Short reminder of pan, zoom, crosshair, markers, and event attribute popups |
| **Crosshair** | Current cycle and row of the active cross-band |
| **Pinned markers** | Count and **Clear markers** button (removes all pinned markers) |
| **Event chars** | **Char −** / **Char +** to resize display characters in grid cells |
| **Event types** | Filter box + scrollable list; click a type to mark/unmark it for header strips |

### Detail column (220px, full height)

Two stacked panels to the right of the sidebar.

#### Pinned markers (top, 150px)

Lists every position saved with **Ctrl+click** on the grid.

- Each row shows `Cycle X, row Y`.
- **Click** a row to navigate the view to that marker (centers viewport, moves crosshair, selects object on that row).
- **X** removes that marker only.

#### Selected object (bottom, remaining height)

Shows full detail for the object on the row you last clicked in the grid.

- Row index, object id, name, cycle span `[first_time, last_time]`.
- Complete attribute list from the trace (all keys, not just pinned columns).
- When a grid cell is selected: **Events at cycle X, row Y** — each event’s kind, id, and per-event attributes.
- Empty state: *Click a row in the timeline*.

### Timeline area (fills remaining width)

Implemented in `timeline_view.cpp`. Pans and zooms as one unit.

| Region | Purpose |
|--------|---------|
| **Pinned row columns** | **row_panel** — `draw_row_attributes_panel()`, `pinned_row_attributes` in config |
| **Occurrence label column** | **occurrence_label_origin** — `draw_header_label_column()` |
| **Cycle axis** | **cycle_axis** — `draw_cycle_axis()`, `kCycleAxisHeight` |
| **Occurrence strips** | **occurrence_panel** — `draw_occurrence_panel_bars/counts()`, `kOccurrencePanelHeight` |
| **Grid** | **grid** — `grid_origin`, event cells |
| **Footer** | **footer** — ImGui text after `Dummy(plot_size)`; `kTimelineFooterHeight` |

Color scheme (**Night**, **Day**, **Gay**) affects sidebar chrome, detail panels, and all timeline regions above; event colors come from the trace data.

See [Application config](#application-config) for pinned row column settings.

## Navigation

| Input | Action |
|-------|--------|
| **Left drag** on timeline | Pan cycles (horizontal) and rows (vertical) |
| **Mouse wheel** on timeline | Zoom cell size (cycle width and row height), anchored under cursor |
| **/** | Enter incremental search on the first configured attribute (default: `seqnum`) |
| **/** (while searching) | Cycle to the next search attribute (`InstID`, then wrap) |
| **Enter** / **Escape** | Exit search and clear match highlight |
| **Backspace** | Edit the search query (updates match each keystroke) |

Use **Trace → Reset view** in the menu bar to return to the trace start and clear markers.

Click the **Theme** button in the sidebar to cycle color schemes: Night → Day → Gay.

## Incremental search

Press **/** to search object attributes configured in `search_attributes` (default: `seqnum`, then `InstID`). Type to filter — matches update on every keystroke without Enter. Prefix matching applies to the full attribute value (`4` matches `42`, not `124`). Search looks at **currently cached rows** (visible + buffer) only so it stays O(viewport). On match, the timeline scrolls to that row and briefly highlights it. Press **/** again to switch fields; **Enter** or **Escape** exits search.

In dual-trace mode, search applies only to the hovered/focused trace panel.

Status overlay: `Search [seqnum]: 42|` appears in the timeline footer and as a small overlay while searching.

## Crosshair and pinned markers

The timeline has an **active cross-band** (blue row + column through the clicked cell) and **pinned markers** (amber row + column bands at Ctrl+click positions).

| Input | Action |
|-------|--------|
| **Left click** on a grid cell | Move the active row/column bands to that cycle and row |
| **Ctrl + left click** on a grid cell | Pin marker bands at the **clicked cell**, then move the active bands there |
| **Clear markers** (sidebar) | Remove all pinned markers; the active highlight stays where it is |

The **Pinned markers** panel (in the detail column, above Selected object) lists pinned positions. Click an entry to navigate there; use **X** to remove one marker. **Clear markers** in the sidebar removes all pinned markers at once.

Notes:

- The active bands are **not** pinned markers — they always follow your clicks.
- Pinned markers are **session-only** (not saved to the store or config).
- A small click (no drag) is required; dragging still pans the view.
- Clicking a row that has an object also selects it in the **Selected object** panel.

## Event types

In the sidebar **Event types** list:

- **Click** a type to mark or unmark it.
- Marked types get a **header strip** above the grid with per-cycle occurrence counts.
- Use the **Filter** box to search by name or display character.
- Adjust event character size with **Char −** / **Char +**.

Several event types can be marked at once; each gets its own strip.

## Event attributes

Events can carry key/value attributes (stored in PTJ as `"attrs"` on each `event` line and in SQLite). The viewer surfaces them in three places:

| Context | What you see |
|---------|----------------|
| **Hover** | Tooltip listing events in the cell under the cursor, with attributes; shows *Press X to pin* |
| **Sticky popup** | Press **X** while hovering a cell to pin the tooltip as a floating panel |
| **Selected object** | After clicking a cell, events and attributes for that cycle/row appear under the object details |

### Sticky attribute popups

Pinned popups are drawn as overlays on top of the timeline (not ImGui windows).

| Input | Action |
|-------|--------|
| **X** (while hovering a cell with events) | Pin a sticky popup at the cursor |
| **Drag header** (`Cycle X, row Y` bar) | Move the popup |
| **X** (on popup) | Close that popup |
| **Mouse wheel** (over popup body) | Scroll when content exceeds max height |

Notes:

- Size is fixed when pinned; multiple stickies can be open at once.
- Re-pinning the same cell with **X** refreshes its contents.
- Stickies are session-only (cleared on **Reset view**).
- Moving the crosshair does not close stickies.

Object attributes (on the object record) and event attributes (on individual events) are separate — both appear in the UI where relevant.

## Application config

`pipetrace.app.json` (source tree: `config/pipetrace.linx.json`) controls pinned row columns:

```json
{
  "pinned_row_attributes": [
    { "key": "type", "label": "Type", "width_px": 88 },
    { "key": "InstID", "label": "Inst", "width_px": 44 },
    { "key": "RetirePushup", "label": "Pushup", "width_px": 56 },
    { "key": "disasm", "label": "Disasm", "width_px": 320 }
  ]
}
```

Object attributes come from the trace (PTJ / generator). The config chooses which keys appear as fixed columns beside the grid.

`search_attributes` lists object attribute keys used by **/** incremental search (default: `["seqnum", "InstID"]`). Order determines field cycling.

### Event type display colors

`event_type_display` maps event type name → display char + optional `color` (`#RRGGBB` or `#RRGGBBAA`).

| Stage | Role |
|-------|------|
| **Cast** | Creates event types; keeps PT char hints; leaves color **unset** (omit `color`, or sentinel `#888888`). Merges existing **user** colors from config into the DB. |
| **Analyze** | Invents missing colors (`hash_event_type_color_rgba`), writes them to the store, and updates this config. Progress phase `event_colors`. |
| **Viewer** | Paints RGBA from the DB as-is (no grey→hash fallback). Grey cells mean analyze has not assigned colors yet. |

### Row sort schemes

`sort_schemes` in the app config define named row orders. At analyze time, `pipetrace-linx-analyze` materializes a dense rank map (`object_sort_rank`) for each scheme so the viewer can reorder with `rank BETWEEN` — **O(viewport)** even at ~1M objects. Without ranks (or for an unconfigured header column), rows stay in object-id order.

Implicit **Default** order is `objects.id` (no rank table). Missing attribute values sort last; final tie-break is `objects.id`.

Default schemes in `config/pipetrace.linx.json`:

| Name | Columns |
|------|---------|
| `seqnum` | `seqnum` asc |
| `InstID/seqnum` | `InstID` asc, `seqnum` asc (retirement / InstID order) |
| `PC/seqnum` | `PC` asc, `seqnum` asc |
| `RetirePushup` | `RetirePushup` desc |
| `DualRetirePushup` | `DualRetirePushup` desc (needs dual analyze) |
| `PcCount` | `PcCount` desc, `PC` asc |

```json
{
  "sort_schemes": [
    {
      "name": "seqnum",
      "columns": [ { "key": "seqnum", "order": "asc" } ]
    }
  ]
}
```

- The first scheme in the array is the default at startup.
- Use the **Row sort** dropdown in the sidebar to switch schemes for the current session (selection is not saved to config). Switching uses prep-time ranks when present.
- **Double-click** a pinned attribute column header: if it matches a configured scheme (first column key), or the reverse of one, that scheme is applied. Otherwise the UI shows sort **triangles only** and does not scan the store with JSON sort.
- Active sort column headers show a small **up** or **down** triangle (ascending / descending). In User (triangles-only) mode that is the double-clicked column; in a named scheme only the **first** key in the scheme is marked.
- Changing sort (header double-click that maps to a scheme, or sidebar dropdown) keeps the crosshair on the same object and cycle, repositions its row under the new order, and centers the viewport on that row (same behavior as **/** search). With no crosshair, only the row cache refreshes.
- In dual-trace view, one sort applies to **both** traces (shared across panels). Re-anchor and center apply to the hovered or focused trace panel only. Dual sync stays by **InstID**, not row index.
- Attribute keys must match JSON keys on objects exactly (e.g. `seqnum`, `InstID`, `PC`).
- Sort compares each value as hex (`0x` prefix), integer, float, or string (auto-detected per row). Missing or empty attributes sort last when ascending.
- Only **configured** schemes work at million-object scale. Re-analyze after changing `sort_schemes` (`--force` if the store is already analyzed).

Event attributes use the same JSON object shape in PTJ (`"attrs": {"key": "value", ...}` on `event` lines).

## CLI (no GUI)

```bash
./build/pipetrace-ptj-synthgen generate --objects 100 --output data/sample.ptj
./build/pipetrace-ptj-synthgen info --store data/sample.ptj.db
```

See [`INSTALLATION.md`](INSTALLATION.md) for full build and test instructions.
