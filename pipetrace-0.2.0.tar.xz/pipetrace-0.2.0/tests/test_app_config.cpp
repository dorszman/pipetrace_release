#include <cstdint>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <optional>
#include <string>
#include <unordered_map>

#include "gtest/gtest.h"
#include "pipetrace/app_config.hpp"

namespace {

std::string temp_path(const std::string& name) {
  return (std::filesystem::temp_directory_path() / name).string();
}

}  // namespace

TEST(AppConfig, ResolveConfigPathRequiresFlagWhenEnvDisallowed) {
  unsetenv("PIPETRACE_CONFIG");
  EXPECT_THROW(pipetrace::resolve_app_config_path("", /*allow_env=*/false),
               std::runtime_error);
}

TEST(AppConfig, ResolveConfigPathIgnoresEnvWhenDisallowed) {
  const std::string env_path = temp_path("pipetrace_env_ignored.json");
  {
    std::ofstream out(env_path, std::ios::trunc);
    out << "{}\n";
  }
  setenv("PIPETRACE_CONFIG", env_path.c_str(), 1);
  EXPECT_THROW(pipetrace::resolve_app_config_path("", /*allow_env=*/false),
               std::runtime_error);
  unsetenv("PIPETRACE_CONFIG");
}

TEST(AppConfig, ResolveConfigPathEnvOnlyWhenAllowed) {
  const std::string flag_path = temp_path("pipetrace_flag_config.json");
  const std::string env_path = temp_path("pipetrace_env_config.json");
  {
    std::ofstream out(flag_path, std::ios::trunc);
    out << "{}\n";
  }
  {
    std::ofstream out(env_path, std::ios::trunc);
    out << "{}\n";
  }
  setenv("PIPETRACE_CONFIG", env_path.c_str(), 1);
  EXPECT_EQ(pipetrace::resolve_app_config_path(flag_path, /*allow_env=*/true), flag_path);
  EXPECT_EQ(pipetrace::resolve_app_config_path("", /*allow_env=*/true), env_path);
  unsetenv("PIPETRACE_CONFIG");
  EXPECT_THROW(pipetrace::resolve_app_config_path("", /*allow_env=*/true),
               std::runtime_error);
}

TEST(AppConfig, ViewerUsesExeAdjacentConfig) {
  unsetenv("PIPETRACE_CONFIG");
  const std::filesystem::path root =
      std::filesystem::temp_directory_path() / "pipetrace_cfg_exe_adj";
  std::filesystem::create_directories(root);
  const std::filesystem::path cfg = root / pipetrace::kAppConfigFileName;
  {
    std::ofstream out(cfg, std::ios::trunc);
    out << "{}\n";
  }
  EXPECT_EQ(pipetrace::resolve_app_config_path("", /*allow_env=*/true, root.string()),
            cfg.string());
}

TEST(AppConfig, ViewerDoesNotUseConfigSubdirectory) {
  unsetenv("PIPETRACE_CONFIG");
  const std::filesystem::path root =
      std::filesystem::temp_directory_path() / "pipetrace_cfg_no_subdir";
  std::filesystem::create_directories(root / "config");
  {
    std::ofstream out(root / "config" / pipetrace::kAppConfigFileName, std::ios::trunc);
    out << "{}\n";
  }
  EXPECT_THROW(pipetrace::resolve_app_config_path("", /*allow_env=*/true, root.string()),
               std::runtime_error);
}

TEST(AppConfig, ViewerEnvBeatsExeAdjacent) {
  const std::filesystem::path root =
      std::filesystem::temp_directory_path() / "pipetrace_cfg_env_beats_exe";
  std::filesystem::create_directories(root);
  const std::filesystem::path exe_cfg = root / pipetrace::kAppConfigFileName;
  const std::string env_path = temp_path("pipetrace_env_beats_exe.json");
  {
    std::ofstream out(exe_cfg, std::ios::trunc);
    out << "{}\n";
  }
  {
    std::ofstream out(env_path, std::ios::trunc);
    out << "{}\n";
  }
  setenv("PIPETRACE_CONFIG", env_path.c_str(), 1);
  EXPECT_EQ(pipetrace::resolve_app_config_path("", /*allow_env=*/true, root.string()), env_path);
  unsetenv("PIPETRACE_CONFIG");
}

TEST(AppConfig, MissingFlagPathDoesNotFallThroughToExe) {
  unsetenv("PIPETRACE_CONFIG");
  const std::filesystem::path root =
      std::filesystem::temp_directory_path() / "pipetrace_cfg_flag_missing";
  std::filesystem::create_directories(root);
  {
    std::ofstream out(root / pipetrace::kAppConfigFileName, std::ios::trunc);
    out << "{}\n";
  }
  const std::string missing = (root / "missing.json").string();
  EXPECT_THROW(
      pipetrace::resolve_app_config_path(missing, /*allow_env=*/true, root.string()),
      std::runtime_error);
}

TEST(AppConfig, MissingEnvPathDoesNotFallThroughToExe) {
  const std::filesystem::path root =
      std::filesystem::temp_directory_path() / "pipetrace_cfg_env_missing";
  std::filesystem::create_directories(root);
  {
    std::ofstream out(root / pipetrace::kAppConfigFileName, std::ios::trunc);
    out << "{}\n";
  }
  const std::string missing = (root / "missing_env.json").string();
  setenv("PIPETRACE_CONFIG", missing.c_str(), 1);
  EXPECT_THROW(pipetrace::resolve_app_config_path("", /*allow_env=*/true, root.string()),
               std::runtime_error);
  unsetenv("PIPETRACE_CONFIG");
}

TEST(AppConfig, ExecutableDirectoryResolvesRunningBinary) {
  const std::string dir = pipetrace::executable_directory("unused");
  EXPECT_FALSE(dir.empty());
  EXPECT_TRUE(std::filesystem::is_directory(dir));
}

TEST(AppConfig, LoadsPinnedRowAttributes) {
  const std::string path = temp_path("pipetrace_app_config.json");
  std::ofstream out(path, std::ios::trunc);
  out << R"({
  "pinned_row_attributes": [
    { "key": "inst_id", "label": "Inst", "width_px": 64 },
    { "key": "asm", "label": "Asm", "width_px": 180 }
  ]
})";
  out.close();

  const pipetrace::AppConfig config = pipetrace::load_app_config(path);
  ASSERT_EQ(config.pinned_row_attributes.size(), 2U);
  EXPECT_EQ(config.pinned_row_attributes[0].key, "inst_id");
  EXPECT_EQ(config.pinned_row_attributes[1].key, "asm");
  EXPECT_FLOAT_EQ(config.row_panel_width(), 244.0f);
}

TEST(AppConfig, FiltersPinnedColumnsByScope) {
  pipetrace::AppConfig config;
  config.pinned_row_attributes = {
      {"type", "Type", 88.0f, "Always"},
      {"RetirePushup", "Pushup", 56.0f, "SingleTrace"},
      {"DualRetirePushup", "DualPush", 56.0f, "DualTrace"},
  };

  const std::vector<std::string> available = {"type", "RetirePushup", "DualRetirePushup"};
  const std::unordered_map<std::string, bool> checked = {
      {"type", true}, {"RetirePushup", true}, {"DualRetirePushup", true}};

  const std::vector<pipetrace::PinnedRowAttribute> single =
      pipetrace::build_active_pinned_row_columns(config, available, checked, false);
  ASSERT_EQ(single.size(), 2U);
  EXPECT_EQ(single[0].key, "type");
  EXPECT_EQ(single[1].key, "RetirePushup");

  const std::vector<pipetrace::PinnedRowAttribute> dual =
      pipetrace::build_active_pinned_row_columns(config, available, checked, true);
  ASSERT_EQ(dual.size(), 2U);
  EXPECT_EQ(dual[0].key, "type");
  EXPECT_EQ(dual[1].key, "DualRetirePushup");
}

TEST(AppConfig, LoadsPinnedRowScope) {
  const std::string path = temp_path("pipetrace_app_config_scope.json");
  std::ofstream out(path, std::ios::trunc);
  out << R"({
  "pinned_row_attributes": [
    { "key": "PcRetirePushupAvg", "label": "Avg", "width_px": 72, "scope": "SingleTrace" },
    { "key": "DualPcRetirePushupAvg", "label": "DualAvg", "width_px": 72, "scope": "DualTrace" }
  ]
})";
  out.close();

  const pipetrace::AppConfig config = pipetrace::load_app_config(path);
  ASSERT_EQ(config.pinned_row_attributes.size(), 2U);
  EXPECT_EQ(config.pinned_row_attributes[0].scope, "SingleTrace");
  EXPECT_EQ(config.pinned_row_attributes[1].key, "DualPcRetirePushupAvg");
  EXPECT_EQ(config.pinned_row_attributes[1].scope, "DualTrace");
}

TEST(AppConfig, BuildsActivePinnedColumnsFromChecks) {
  pipetrace::AppConfig config;
  config.pinned_row_attributes = {
      {"type", "Type", 88.0f},
      {"InstID", "Inst", 44.0f},
      {"missing", "Missing", 40.0f},
  };

  const std::vector<std::string> available = {"InstID", "disasm", "type"};
  const std::unordered_map<std::string, bool> checked = {
      {"type", true}, {"InstID", true}, {"disasm", false}, {"missing", true}};

  const std::vector<pipetrace::PinnedRowAttribute> active =
      pipetrace::build_active_pinned_row_columns(config, available, checked);
  ASSERT_EQ(active.size(), 2U);
  EXPECT_EQ(active[0].key, "type");
  EXPECT_EQ(active[1].key, "InstID");
  EXPECT_FLOAT_EQ(active[0].width_px, 88.0f);
}

TEST(AppConfig, DefaultPinnedChecksUsesConfigOnly) {
  pipetrace::AppConfig config;
  config.pinned_row_attributes = {
      {"InstID", "Inst", 44.0f},
      {"ghost", "Ghost", 40.0f},
  };

  const std::vector<std::string> available = {"InstID", "disasm", "type"};
  const std::unordered_map<std::string, bool> checked =
      pipetrace::default_pinned_attribute_checks(config, available);
  EXPECT_TRUE(checked.at("InstID"));
  EXPECT_FALSE(checked.at("disasm"));
  EXPECT_FALSE(checked.at("type"));
  EXPECT_FALSE(checked.contains("ghost"));
}

TEST(AppConfig, LoadsRepositoryDefaultConfig) {
  const pipetrace::AppConfig config = pipetrace::load_app_config(
      std::string(PIPETRACE_SOURCE_DIR) + "/config/pipetrace.linx.json");
  EXPECT_EQ(config.cast_tool.command, "./build/pipetrace-linx-parser");
  EXPECT_EQ(config.analysis_tool.command, "./build/pipetrace-linx-analyze");
  EXPECT_GE(config.pinned_row_attributes.size(), 4U);
  EXPECT_EQ(config.pinned_row_attributes[0].key, "type");
  EXPECT_EQ(config.pinned_row_attributes[1].key, "InstID");
  EXPECT_EQ(config.pinned_row_attributes[2].key, "RetirePushup");
  EXPECT_EQ(config.pinned_row_attributes[2].scope, "SingleTrace");
  EXPECT_EQ(config.pinned_row_attributes[5].key, "PcRetirePushupAvg");
  EXPECT_EQ(config.pinned_row_attributes[5].scope, "SingleTrace");
  EXPECT_EQ(config.pinned_row_attributes[8].key, "DualPcRetirePushupAvg");
  EXPECT_EQ(config.pinned_row_attributes[8].scope, "DualTrace");
  EXPECT_GE(config.pinned_row_attributes.size(), 4U);
  EXPECT_TRUE(config.event_type_display.empty());
  EXPECT_EQ(config.sync_attribute, "InstID");
  EXPECT_TRUE(config.has_sync_attribute());
  ASSERT_EQ(config.object_attribute_strength.size(), 1U);
  EXPECT_EQ(config.object_attribute_strength[0].key, "RetirePushup");
  ASSERT_EQ(config.sort_schemes.size(), 6U);
  EXPECT_EQ(config.sort_schemes[0].name, "seqnum");
  ASSERT_EQ(config.sort_schemes[0].columns.size(), 1U);
  EXPECT_EQ(config.sort_schemes[0].columns[0].key, "seqnum");
  EXPECT_EQ(config.sort_schemes[1].name, "InstID/seqnum");
  EXPECT_EQ(config.sort_schemes[4].name, "DualRetirePushup");
  EXPECT_EQ(config.sort_schemes[5].name, "PcCount");
  ASSERT_EQ(config.search_attributes.size(), 2U);
  EXPECT_EQ(config.search_attributes[0], "seqnum");
  EXPECT_EQ(config.search_attributes[1], "InstID");
  ASSERT_EQ(config.object_attribute_strength.size(), 1U);
  EXPECT_EQ(config.object_attribute_strength[0].key, "RetirePushup");
}

TEST(AppConfig, LoadsObjectAttributeStrength) {
  const std::string path = temp_path("pipetrace_app_config_strength.json");
  std::ofstream out(path, std::ios::trunc);
  out << R"({
  "object_attribute_strength": [
    { "key": "RetirePushup", "color": "#FF4400", "highlight": "max" },
    { "key": "MyMetric", "color": "#00FF00AA", "highlight": "min" }
  ]
})";
  out.close();

  const pipetrace::AppConfig config = pipetrace::load_app_config(path);
  ASSERT_EQ(config.object_attribute_strength.size(), 2U);
  EXPECT_EQ(config.object_attribute_strength[0].key, "RetirePushup");
  EXPECT_EQ(config.object_attribute_strength[0].color, "#FF4400");
  EXPECT_EQ(config.object_attribute_strength[0].highlight, "max");
  EXPECT_EQ(config.object_attribute_strength[1].key, "MyMetric");
  EXPECT_EQ(config.object_attribute_strength[1].color, "#00FF00AA");
  EXPECT_EQ(config.object_attribute_strength[1].highlight, "min");
}

TEST(AppConfig, ObjectAttributeStrengthDefaultsHighlightToMax) {
  const std::string path = temp_path("pipetrace_app_config_strength_default.json");
  std::ofstream out(path, std::ios::trunc);
  out << R"({
  "object_attribute_strength": [
    { "key": "MyMetric", "color": "#112233" }
  ]
})";
  out.close();

  const pipetrace::AppConfig config = pipetrace::load_app_config(path);
  ASSERT_EQ(config.object_attribute_strength.size(), 1U);
  EXPECT_EQ(config.object_attribute_strength[0].highlight, "max");
}

TEST(AppConfig, ParseHexColorRgba) {
  const std::optional<std::uint32_t> rgb = pipetrace::parse_hex_color_rgba("#FF4400");
  ASSERT_TRUE(rgb.has_value());
  EXPECT_EQ(*rgb, 0xFFFF4400U);

  const std::optional<std::uint32_t> rgba = pipetrace::parse_hex_color_rgba("#FF440088");
  ASSERT_TRUE(rgba.has_value());
  EXPECT_EQ(*rgba, 0x88FF4400U);

  EXPECT_FALSE(pipetrace::parse_hex_color_rgba("FF4400").has_value());
  EXPECT_FALSE(pipetrace::parse_hex_color_rgba("#GG0000").has_value());
  EXPECT_FALSE(pipetrace::parse_hex_color_rgba("#FF00").has_value());
}

TEST(AppConfig, StrengthColorFromBaseUsesFixedRgbAndStrengthAlpha) {
  EXPECT_EQ(pipetrace::strength_color_from_base("#FF4400", 0.0), "#FF440000");
  EXPECT_EQ(pipetrace::strength_color_from_base("#FF4400", 1.0), "#FF4400FF");
  EXPECT_EQ(pipetrace::strength_color_from_base("#FF4400", 0.5), "#FF440080");
}

TEST(AppConfig, LoadsSearchAttributes) {
  const std::string path = temp_path("pipetrace_app_config_search.json");
  std::ofstream out(path, std::ios::trunc);
  out << R"({
  "search_attributes": ["InstID", "seqnum"]
})";
  out.close();

  const pipetrace::AppConfig config = pipetrace::load_app_config(path);
  ASSERT_EQ(config.search_attributes.size(), 2U);
  EXPECT_EQ(config.search_attributes[0], "InstID");
  EXPECT_EQ(config.search_attributes[1], "seqnum");
}

TEST(AppConfig, DefaultIncludesSearchAttributes) {
  const pipetrace::AppConfig config = pipetrace::default_app_config();
  ASSERT_EQ(config.search_attributes.size(), 2U);
  EXPECT_EQ(config.search_attributes[0], "seqnum");
  EXPECT_EQ(config.search_attributes[1], "InstID");
}

TEST(AppConfig, LoadsSortSchemes) {
  const std::string path = temp_path("pipetrace_app_config_sort.json");
  std::ofstream out(path, std::ios::trunc);
  out << R"({
  "sort_schemes": [
    {
      "name": "seqnum/InstID",
      "columns": [
        { "key": "seqnum", "order": "asc" },
        { "key": "InstID", "order": "desc" }
      ]
    }
  ]
})";
  out.close();

  const pipetrace::AppConfig config = pipetrace::load_app_config(path);
  ASSERT_EQ(config.sort_schemes.size(), 1U);
  EXPECT_EQ(config.sort_schemes[0].name, "seqnum/InstID");
  ASSERT_EQ(config.sort_schemes[0].columns.size(), 2U);
  EXPECT_EQ(config.sort_schemes[0].columns[0].order, "asc");
  EXPECT_EQ(config.sort_schemes[0].columns[1].order, "desc");
}

TEST(AppConfig, DefaultIncludesSortScheme) {
  const pipetrace::AppConfig config = pipetrace::default_app_config();
  ASSERT_EQ(config.sort_schemes.size(), 6U);
  EXPECT_EQ(config.sort_schemes[0].name, "seqnum");
  EXPECT_EQ(config.sort_schemes[1].name, "InstID/seqnum");
  EXPECT_EQ(config.sort_schemes[2].name, "PC/seqnum");
  EXPECT_EQ(config.sort_schemes[3].name, "RetirePushup");
  EXPECT_EQ(config.sort_schemes[4].name, "DualRetirePushup");
  EXPECT_EQ(config.sort_schemes[5].name, "PcCount");
  ASSERT_EQ(config.sort_schemes[0].columns.size(), 1U);
  EXPECT_EQ(config.sort_schemes[0].columns[0].key, "seqnum");
}

TEST(AppConfig, LoadsSyncAttribute) {
  const std::string path = temp_path("pipetrace_app_config_sync.json");
  std::ofstream out(path, std::ios::trunc);
  out << R"({
  "sync_attribute": "InstID",
  "pinned_row_attributes": []
})";
  out.close();

  const pipetrace::AppConfig config = pipetrace::load_app_config(path);
  EXPECT_EQ(config.sync_attribute, "InstID");
  EXPECT_TRUE(config.has_sync_attribute());
}

TEST(AppConfig, LoadsCastToolAndEventTypeDisplay) {
  const std::string path = temp_path("pipetrace_app_config_full.json");
  std::ofstream out(path, std::ios::trunc);
  out << R"({
  "cast_tool": {
    "command": "/opt/bin/pipetrace-linx-parser"
  },
  "pinned_row_attributes": [],
  "event_type_display": [
    { "name": "fetch", "char": "f", "color": "#2E8D30" }
  ]
})";
  out.close();

  const pipetrace::AppConfig config = pipetrace::load_app_config(path);
  EXPECT_EQ(config.cast_tool.command, "/opt/bin/pipetrace-linx-parser");
  ASSERT_EQ(config.event_type_display.size(), 1U);
  EXPECT_EQ(config.event_type_display[0].name, "fetch");
  EXPECT_EQ(config.event_type_display[0].display_char, 'f');
  EXPECT_EQ(config.event_type_display[0].color_rgba, 4281240880U);
  EXPECT_NE(config.find_event_type_display("fetch"), nullptr);
  EXPECT_EQ(config.find_event_type_display("missing"), nullptr);
}

TEST(AppConfig, LoadsLegacyDecimalColorRgba) {
  const std::string path = temp_path("pipetrace_app_config_legacy_color.json");
  std::ofstream out(path, std::ios::trunc);
  out << R"({
  "event_type_display": [
    { "name": "fetch", "char": "f", "color_rgba": 4281240880 }
  ]
})";
  out.close();

  const pipetrace::AppConfig config = pipetrace::load_app_config(path);
  ASSERT_EQ(config.event_type_display.size(), 1U);
  EXPECT_EQ(config.event_type_display[0].color_rgba, 4281240880U);
}

TEST(AppConfig, SavesEventTypeDisplayAsHexColor) {
  const std::string path = temp_path("pipetrace_app_config_save_color.json");
  pipetrace::AppConfig config;
  pipetrace::EventTypeDisplay entry;
  entry.name = "fetch";
  entry.display_char = 'f';
  entry.color_rgba = 0xFF4CAF50U;
  config.event_type_display.push_back(entry);

  pipetrace::save_app_config(path, config);

  std::ifstream in(path);
  const std::string saved((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
  EXPECT_NE(saved.find("\"color\": \"#4CAF50\""), std::string::npos);
  EXPECT_EQ(saved.find("color_rgba"), std::string::npos);
}

TEST(AppConfig, MissingColorStaysUnassignedUntilAnalyze) {
  const std::string path = temp_path("pipetrace_app_config_missing_color.json");
  std::ofstream out(path, std::ios::trunc);
  out << R"({
  "event_type_display": [
    { "name": "retire_uop", "char": "R" }
  ]
})";
  out.close();

  const pipetrace::AppConfig config = pipetrace::load_app_config(path);
  ASSERT_EQ(config.event_type_display.size(), 1U);
  EXPECT_EQ(config.event_type_display[0].color_rgba, pipetrace::kUnassignedEventTypeColor);
}

TEST(EventColors, UnassignedSentinelHelper) {
  EXPECT_TRUE(pipetrace::is_unassigned_event_type_color(pipetrace::kUnassignedEventTypeColor));
  EXPECT_FALSE(pipetrace::is_unassigned_event_type_color(0xFF4CAF50U));
  EXPECT_NE(pipetrace::hash_event_type_color_rgba("alloc"), pipetrace::kUnassignedEventTypeColor);
}
