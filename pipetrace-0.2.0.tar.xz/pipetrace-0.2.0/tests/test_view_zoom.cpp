#include <gtest/gtest.h>

#include "app/view_zoom.hpp"

namespace pipetrace {
namespace {

TEST(ViewZoom, PreserveAnchorKeepsWorldPointUnderCursor) {
  double scroll = 10.0;
  double cell_size = 20.0;
  const double mouse_local = 100.0;
  const double world_before = scroll + mouse_local / cell_size;

  ASSERT_TRUE(zoom_preserve_anchor(scroll, cell_size, mouse_local, 2.0, 4.0, 80.0));
  EXPECT_DOUBLE_EQ(world_before, scroll + mouse_local / cell_size);
}

TEST(ViewZoom, PreserveAnchorToSizeKeepsWorldPointUnderCursor) {
  double scroll = 5.0;
  double cell_size = 10.0;
  const double mouse_local = 50.0;
  const double world_before = scroll + mouse_local / cell_size;

  ASSERT_TRUE(zoom_preserve_anchor_to_size(scroll, cell_size, mouse_local, 30.0, 4.0, 80.0));
  EXPECT_DOUBLE_EQ(world_before, scroll + mouse_local / cell_size);
}

TEST(ViewZoom, PreserveAnchorNoOpWhenClamped) {
  double scroll = 0.0;
  double cell_size = 80.0;
  EXPECT_FALSE(zoom_preserve_anchor(scroll, cell_size, 40.0, 2.0, 4.0, 80.0));
  EXPECT_DOUBLE_EQ(80.0, cell_size);
  EXPECT_DOUBLE_EQ(0.0, scroll);
}

}  // namespace
}  // namespace pipetrace
