#include <filesystem>
#include <fstream>
#include <string>

#include "gtest/gtest.h"
#include "linx_pt/linx_pt_parser.hpp"
#include "pipetrace/app_config.hpp"
#include "pipetrace/attributes.hpp"
#include "pipetrace/event_colors.hpp"
#include "pipetrace/linx_pt.hpp"
#include "pipetrace/storage.hpp"

namespace {

std::string temp_path(const std::string& name) {
  return (std::filesystem::temp_directory_path() / name).string();
}

}  // namespace

TEST(LinxPtParser, ParsesAttributeAndEventLines) {
  const pipetrace::linx_pt::ParseResult attr =
      pipetrace::linx_pt::parse_line("[0] type:AAA parent:-1");
  ASSERT_EQ(attr.status, pipetrace::linx_pt::ParseStatus::Ok);
  ASSERT_TRUE(attr.attribute.has_value());
  EXPECT_EQ(attr.attribute->object_id, 0);
  ASSERT_EQ(attr.attribute->fields.size(), 2U);

  const pipetrace::linx_pt::ParseResult quoted =
      pipetrace::linx_pt::parse_line("[0] disasm:\"das das das das\"");
  ASSERT_TRUE(quoted.attribute.has_value());
  EXPECT_EQ(quoted.attribute->fields[0].value, "das das das das");

  const pipetrace::linx_pt::ParseResult event =
      pipetrace::linx_pt::parse_line("[0] [1] event_type(f) EVEN:1 VA:0x50000200");
  ASSERT_TRUE(event.event.has_value());
  EXPECT_EQ(event.event->object_id, 0);
  EXPECT_EQ(event.event->cycle, 1);
  EXPECT_EQ(event.event->event_type, "event_type");
  ASSERT_TRUE(event.event->display_char_hint.has_value());
  EXPECT_EQ(*event.event->display_char_hint, 'f');
  ASSERT_EQ(event.event->attributes.size(), 2U);
}

TEST(LinxPtParser, RejectsDuplicateEventKeys) {
  const pipetrace::linx_pt::ParseResult event =
      pipetrace::linx_pt::parse_line("[0] [1] fetch(f) EVEN:1 EVEN:2");
  EXPECT_EQ(event.status, pipetrace::linx_pt::ParseStatus::Error);
}

TEST(LinxPtCast, CastsExampleTrace) {
  const std::string input = temp_path("linx_example.pt");
  const std::string store = temp_path("linx_example.pt.db");
  const std::string config = temp_path("linx_cast_app_config.json");

  {
    std::ofstream out(input, std::ios::trunc);
    out << "[0] type:AAA parent:-1\n";
    out << "[0] disasm:\"das das das das\"\n";
    out << "[0] [1] event_type(f) EVEN:1 VA:0x50000200\n";
    out << "[1] dsfds:FDSFD parent:0\n";
  }

  {
    std::ofstream out(config, std::ios::trunc);
    out << R"({
  "cast_tool": { "command": "./build/pipetrace-linx-parser" },
  "pinned_row_attributes": [],
  "event_type_display": []
})";
  }

  pipetrace::LinxPtCastOptions options;
  options.input_path = input;
  options.store_path = store;
  options.config_path = config;

  const pipetrace::LinxPtCastStats stats = pipetrace::cast_linx_pt_to_store(options);
  EXPECT_EQ(stats.objects, 2U);
  EXPECT_EQ(stats.events, 1U);
  EXPECT_GE(stats.config_entries_added, 1U);

  auto db = pipetrace::create_sqlite_store();
  ASSERT_TRUE(db->open(store));
  const pipetrace::TraceMeta meta = db->meta();
  EXPECT_EQ(meta.object_count, 2);
  EXPECT_EQ(meta.event_count, 1);

  const auto object0 = db->find_object(0);
  ASSERT_TRUE(object0.has_value());
  EXPECT_EQ(object0->parent_id, -1);
  EXPECT_EQ(pipetrace::attribute_value(object0->attributes, "disasm"), "das das das das");

  const auto object1 = db->find_object(1);
  ASSERT_TRUE(object1.has_value());
  EXPECT_EQ(object1->parent_id, 0);

  const pipetrace::AppConfig app_config = pipetrace::load_app_config(config);
  EXPECT_NE(app_config.find_event_type_display("event_type"), nullptr);
}

TEST(LinxPtGenerateCast, GeneratesAndCastsManyObjects) {
  const std::string input = temp_path("linx_generated.pt");
  const std::string store = temp_path("linx_generated.pt.db");
  const std::string config = temp_path("linx_generated_app_config.json");

  pipetrace::LinxPtGenerateOptions gen;
  gen.output_path = input;
  gen.object_count = 128;
  gen.events_per_object = 2;
  gen.uops_per_instruction = 4;
  gen.cycle_span = 32;
  gen.seed = 7;
  pipetrace::generate_linx_pt_trace(gen);

  {
    std::ofstream out(config, std::ios::trunc);
    out << R"({
  "cast_tool": { "command": "./build/pipetrace-linx-parser" },
  "pinned_row_attributes": [],
  "event_type_display": []
})";
  }

  pipetrace::LinxPtCastOptions cast;
  cast.input_path = input;
  cast.store_path = store;
  cast.config_path = config;
  const pipetrace::LinxPtCastStats stats = pipetrace::cast_linx_pt_to_store(cast);
  EXPECT_EQ(stats.objects, 160U);
  EXPECT_EQ(stats.events, 416U);

  auto db = pipetrace::create_sqlite_store();
  ASSERT_TRUE(db->open(store));
  EXPECT_EQ(db->meta().object_count, 160);
  EXPECT_EQ(db->meta().event_count, 416);

  const auto instruction1 = db->find_object(5);
  ASSERT_TRUE(instruction1.has_value());
  EXPECT_EQ(pipetrace::attribute_value(instruction1->attributes, "type"), "Instruction");
  EXPECT_EQ(instruction1->parent_id, -1);
  EXPECT_EQ(pipetrace::attribute_value(instruction1->attributes, "InstID"), "");

  const auto object7 = db->find_object(7);
  ASSERT_TRUE(object7.has_value());
  EXPECT_EQ(pipetrace::attribute_value(object7->attributes, "type"), "Uop");
  EXPECT_EQ(object7->parent_id, 5);
  EXPECT_EQ(pipetrace::attribute_value(object7->attributes, "inst_id"), "");
  EXPECT_EQ(pipetrace::attribute_value(object7->attributes, "InstID"), "");
  const std::string disasm = pipetrace::attribute_value(object7->attributes, "disasm");
  EXPECT_NE(disasm.find(' '), std::string::npos);
  EXPECT_EQ(disasm, "xor r7, r10 slot 7");
  EXPECT_EQ(pipetrace::attribute_value(object7->attributes, "asm"), "");
}

TEST(LinxPtGenerate, WritesInstructionUopHierarchyAndRetireEvents) {
  const std::string input = temp_path("linx_hierarchy_gen.pt");

  pipetrace::LinxPtGenerateOptions gen;
  gen.output_path = input;
  gen.object_count = 4;
  gen.events_per_object = 1;
  gen.uops_per_instruction = 4;
  gen.cycle_span = 8;
  gen.seed = 1;
  pipetrace::generate_linx_pt_trace(gen);

  std::ifstream in(input);
  ASSERT_TRUE(in.good());
  std::string line;
  bool saw_instruction = false;
  bool saw_uop = false;
  bool saw_uop_parent = false;
  bool saw_retire_uop = false;
  bool saw_retire_inst = false;
  bool saw_inst_id = false;
  bool saw_spaced_disasm = false;
  while (std::getline(in, line)) {
    if (line.find("type:Instruction") != std::string::npos) {
      saw_instruction = true;
      EXPECT_EQ(line.find("InstID:"), std::string::npos);
    }
    if (line.find("type:Uop") != std::string::npos) {
      saw_uop = true;
      EXPECT_EQ(line.find("inst_id:"), std::string::npos);
      EXPECT_EQ(line.find("InstID:"), std::string::npos);
    }
    if (line.find("type:Uop parent:0") != std::string::npos) {
      saw_uop_parent = true;
    }
    if (line.find("retire_uop(R)") != std::string::npos) {
      saw_retire_uop = true;
    }
    if (line.find("retire_inst(R)") != std::string::npos) {
      saw_retire_inst = true;
    }
    if (line.find("InstID:0") != std::string::npos) {
      saw_inst_id = true;
    }
    if (line.find("disasm:\"") != std::string::npos && line.find(" slot ") != std::string::npos) {
      saw_spaced_disasm = true;
      EXPECT_EQ(line.find(" asm:\""), std::string::npos);
    }
  }
  EXPECT_TRUE(saw_instruction);
  EXPECT_TRUE(saw_uop);
  EXPECT_TRUE(saw_uop_parent);
  EXPECT_TRUE(saw_retire_uop);
  EXPECT_TRUE(saw_retire_inst);
  EXPECT_TRUE(saw_inst_id);
  EXPECT_TRUE(saw_spaced_disasm);
}

TEST(LinxPtGenerate, PartialRetireOmitsSomeRetireEvents) {
  const std::string input = temp_path("linx_partial_retire_gen.pt");

  pipetrace::LinxPtGenerateOptions gen;
  gen.output_path = input;
  gen.object_count = 20;
  gen.events_per_object = 1;
  gen.uops_per_instruction = 4;
  gen.cycle_span = 8;
  gen.seed = 1;
  gen.partial_retire = true;
  pipetrace::generate_linx_pt_trace(gen);

  std::ifstream in(input);
  ASSERT_TRUE(in.good());
  std::string line;
  std::size_t retire_inst_count = 0;
  std::size_t retire_uop_count = 0;
  bool saw_inst_serial_2_without_retire = false;
  while (std::getline(in, line)) {
    if (line.find("retire_inst(R)") != std::string::npos) {
      ++retire_inst_count;
      if (line.find("InstID:2") != std::string::npos) {
        saw_inst_serial_2_without_retire = true;
      }
    }
    if (line.find("retire_uop(R)") != std::string::npos) {
      ++retire_uop_count;
    }
  }
  EXPECT_EQ(retire_inst_count, 4U);
  EXPECT_LT(retire_uop_count, 20U);
  EXPECT_FALSE(saw_inst_serial_2_without_retire);
}

TEST(LinxPtParser, SkipsWhitespaceOnlyLines) {
  const pipetrace::linx_pt::ParseResult blank =
      pipetrace::linx_pt::parse_line("   \t  ");
  EXPECT_EQ(blank.status, pipetrace::linx_pt::ParseStatus::Skip);
}

TEST(LinxPtCast, FailsOnMalformedNonBlankLine) {
  const std::string input = temp_path("linx_bad.pt");
  const std::string store = temp_path("linx_bad.pt.db");
  const std::string config = temp_path("linx_bad_config.json");

  {
    std::ofstream out(input, std::ios::trunc);
    out << "[0] type:AAA parent:-1\n";
    out << "this is not valid\n";
  }

  {
    std::ofstream out(config, std::ios::trunc);
    out << R"({
  "cast_tool": { "command": "./build/pipetrace-linx-parser" },
  "pinned_row_attributes": [],
  "event_type_display": []
})";
  }

  pipetrace::LinxPtCastOptions options;
  options.input_path = input;
  options.store_path = store;
  options.config_path = config;

  EXPECT_THROW(pipetrace::cast_linx_pt_to_store(options), std::runtime_error);
  EXPECT_FALSE(std::filesystem::exists(store));
}

TEST(AppConfig, MergePreservesExistingEventTypeDisplay) {
  const std::string path = temp_path("linx_merge_config.json");
  {
    std::ofstream out(path, std::ios::trunc);
    out << R"({
  "cast_tool": { "command": "./build/pipetrace-linx-parser" },
  "pinned_row_attributes": [],
  "event_type_display": [
    { "name": "fetch", "char": "F", "color_rgba": 111 }
  ]
})";
  }

  pipetrace::AppConfig config = pipetrace::load_app_config(path);
  pipetrace::EventTypeDisplay discovered;
  discovered.name = "fetch";
  discovered.display_char = 'x';
  discovered.color_rgba = 999;
  EXPECT_EQ(pipetrace::merge_event_type_display(config, {discovered}), 0U);
  EXPECT_EQ(config.event_type_display[0].display_char, 'F');
  EXPECT_EQ(config.event_type_display[0].color_rgba, 111U);
}

TEST(LinxPtCast, LeavesUnassignedColorsForAnalyze) {
  const std::string input = temp_path("linx_cast_unset_color.pt");
  const std::string store = temp_path("linx_cast_unset_color.pt.db");
  const std::string config = temp_path("linx_cast_unset_color_config.json");

  {
    std::ofstream out(input, std::ios::trunc);
    out << "[0] type:Uop parent:-1\n";
    out << "[0] [1] retire_uop(R)\n";
  }
  {
    std::ofstream out(config, std::ios::trunc);
    out << R"({
  "cast_tool": { "command": "./build/pipetrace-linx-parser" },
  "pinned_row_attributes": [],
  "event_type_display": [
    { "name": "retire_uop", "char": "R", "color": "#888888" }
  ]
})";
  }

  pipetrace::LinxPtCastOptions options;
  options.input_path = input;
  options.store_path = store;
  options.config_path = config;
  options.force = true;
  pipetrace::cast_linx_pt_to_store(options);

  const pipetrace::AppConfig app_config = pipetrace::load_app_config(config);
  ASSERT_EQ(app_config.event_type_display.size(), 1U);
  EXPECT_EQ(app_config.event_type_display[0].display_char, 'R');
  EXPECT_EQ(app_config.event_type_display[0].color_rgba, pipetrace::kUnassignedEventTypeColor);

  auto db = pipetrace::create_sqlite_store();
  ASSERT_TRUE(db->open(store));
  const auto types = db->event_types();
  ASSERT_EQ(types.size(), 1U);
  EXPECT_EQ(types[0].color_rgba, pipetrace::kUnassignedEventTypeColor);
  EXPECT_EQ(types[0].display_char, 'R');
}

TEST(LinxPtCast, PreservesExistingUserConfigColors) {
  const std::string input = temp_path("linx_cast_user_color.pt");
  const std::string store = temp_path("linx_cast_user_color.pt.db");
  const std::string config = temp_path("linx_cast_user_color_config.json");

  {
    std::ofstream out(input, std::ios::trunc);
    out << "[0] type:Uop parent:-1\n";
    out << "[0] [1] retire_uop(R)\n";
  }
  {
    std::ofstream out(config, std::ios::trunc);
    out << R"({
  "cast_tool": { "command": "./build/pipetrace-linx-parser" },
  "pinned_row_attributes": [],
  "event_type_display": [
    { "name": "retire_uop", "char": "R", "color": "#FF4400" }
  ]
})";
  }

  pipetrace::LinxPtCastOptions options;
  options.input_path = input;
  options.store_path = store;
  options.config_path = config;
  options.force = true;
  pipetrace::cast_linx_pt_to_store(options);

  auto db = pipetrace::create_sqlite_store();
  ASSERT_TRUE(db->open(store));
  const auto types = db->event_types();
  ASSERT_EQ(types.size(), 1U);
  EXPECT_EQ(types[0].color_rgba, 0xFFFF4400U);
}

TEST(LinxPtCast, SkipsWhenStoreMatchesSourceTrace) {
  const std::string input = temp_path("linx_cast_skip.pt");
  const std::string store = temp_path("linx_cast_skip.pt.db");
  const std::string config = temp_path("linx_cast_skip_config.json");

  pipetrace::LinxPtGenerateOptions gen;
  gen.output_path = input;
  gen.object_count = 16;
  gen.events_per_object = 2;
  gen.uops_per_instruction = 4;
  gen.cycle_span = 16;
  gen.seed = 3;
  pipetrace::generate_linx_pt_trace(gen);

  {
    std::ofstream out(config, std::ios::trunc);
    out << R"({
  "cast_tool": { "command": "./build/pipetrace-linx-parser" },
  "pinned_row_attributes": [],
  "event_type_display": []
})";
  }

  pipetrace::LinxPtCastOptions cast;
  cast.input_path = input;
  cast.store_path = store;
  cast.config_path = config;
  const pipetrace::LinxPtCastStats first = pipetrace::cast_linx_pt_to_store(cast);
  EXPECT_FALSE(first.cast_skipped);
  EXPECT_GT(first.objects, 0U);

  const pipetrace::LinxPtCastStats second = pipetrace::cast_linx_pt_to_store(cast);
  EXPECT_TRUE(second.cast_skipped);
}

TEST(LinxPtCast, ForceRecastsDespiteUnchangedSource) {
  const std::string input = temp_path("linx_cast_force.pt");
  const std::string store = temp_path("linx_cast_force.pt.db");
  const std::string config = temp_path("linx_cast_force_config.json");

  pipetrace::LinxPtGenerateOptions gen;
  gen.output_path = input;
  gen.object_count = 16;
  gen.events_per_object = 2;
  gen.uops_per_instruction = 4;
  gen.cycle_span = 16;
  gen.seed = 4;
  pipetrace::generate_linx_pt_trace(gen);

  {
    std::ofstream out(config, std::ios::trunc);
    out << R"({
  "cast_tool": { "command": "./build/pipetrace-linx-parser" },
  "pinned_row_attributes": [],
  "event_type_display": []
})";
  }

  pipetrace::LinxPtCastOptions cast;
  cast.input_path = input;
  cast.store_path = store;
  cast.config_path = config;
  pipetrace::cast_linx_pt_to_store(cast);

  cast.force = true;
  const pipetrace::LinxPtCastStats forced = pipetrace::cast_linx_pt_to_store(cast);
  EXPECT_FALSE(forced.cast_skipped);
  EXPECT_GT(forced.objects, 0U);
}
