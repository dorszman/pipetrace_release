#include <chrono>
#include <filesystem>
#include <fstream>
#include <string>
#include <thread>

#include "gtest/gtest.h"
#include "pipetrace/progress.hpp"

namespace {

std::string temp_path(const std::string& name) {
  return (std::filesystem::temp_directory_path() / name).string();
}

}  // namespace

TEST(Progress, FormatStatusPlainIsCanonical) {
  pipetrace::StatusSnapshot snap;
  snap.tool = "cast";
  snap.phase = "parse";
  snap.done = 12;
  snap.total = 100;
  snap.msg = "lines";
  EXPECT_EQ(pipetrace::format_status_plain(snap),
            "STATUS tool=cast phase=parse done=12 total=100 msg=lines");
}

TEST(Progress, ParsesStatusMode) {
  EXPECT_EQ(pipetrace::parse_status_mode("pretty"), pipetrace::StatusMode::Pretty);
  EXPECT_EQ(pipetrace::parse_status_mode("plain"), pipetrace::StatusMode::Plain);
  EXPECT_THROW(pipetrace::parse_status_mode("nope"), std::runtime_error);
}

TEST(Progress, WritesThrottledPlainStatusAndLog) {
  const std::string log = temp_path("pipetrace_progress_test.log");
  std::filesystem::remove(log);

  pipetrace::ProgressReporter reporter("cast", pipetrace::StatusMode::Plain, log);
  reporter.set_phase("parse", "lines");
  reporter.set_counts(1, 10, "lines");
  reporter.set_counts(2, 10, "lines");  // within 100ms — may be skipped on stdout, still ok
  std::this_thread::sleep_for(std::chrono::milliseconds(120));
  reporter.set_counts(3, 10, "lines");
  reporter.finish("ok");

  std::ifstream in(log);
  ASSERT_TRUE(in);
  std::string contents((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
  EXPECT_NE(contents.find("STATUS tool=cast phase=parse"), std::string::npos);
  EXPECT_NE(contents.find("outcome=ok"), std::string::npos);
}
