#include <filesystem>
#include <string>

#include "gtest/gtest.h"
#include "pipetrace/app_config.hpp"
#include "pipetrace/attributes.hpp"
#include "pipetrace/generator.hpp"
#include "pipetrace/sort_sql.hpp"
#include "pipetrace/storage.hpp"
#include "storage/sqlite_store.hpp"

namespace {

std::string temp_path(const std::string& name) {
  return (std::filesystem::temp_directory_path() / name).string();
}

}  // namespace

TEST(Storage, ViewportQueryReturnsOverlappingObjects) {
  const std::string ptj = temp_path("pipetrace_query.ptj");
  const std::string db = ptj + ".db";
  std::filesystem::remove(ptj);
  std::filesystem::remove(db);

  pipetrace::GeneratorConfig config;
  config.object_count = 100;
  pipetrace::generate_generic_trace(config, ptj);

  auto store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(store->open(db));

  pipetrace::Viewport viewport;
  viewport.time_start = 0;
  viewport.time_end = 1000;
  viewport.row_start = 0;
  viewport.row_end = 20;

  const pipetrace::ColumnarObjects objects = store->query_objects(viewport);
  EXPECT_GT(objects.ids.size(), 0u);
  EXPECT_EQ(objects.ids.front(), 1);
  EXPECT_EQ(objects.row_indices.front(), 0);
  EXPECT_EQ(objects.row_indices.back(),
            static_cast<std::int32_t>(objects.row_indices.front() + objects.ids.size() - 1));

  const pipetrace::ColumnarEvents events = store->query_events(viewport, objects.ids);
  EXPECT_GT(events.object_ids.size(), 0u);
  EXPECT_EQ(events.ids.size(), events.object_ids.size());
  EXPECT_EQ(events.kinds.size(), events.object_ids.size());
  EXPECT_EQ(events.display_chars.size(), events.object_ids.size());
  EXPECT_EQ(events.colors_rgba.size(), events.object_ids.size());
  EXPECT_EQ(events.attributes_json.size(), events.object_ids.size());

  bool found_event_attributes = false;
  for (std::size_t i = 0; i < events.kinds.size(); ++i) {
    if (events.kinds[i] == "work" && events.attributes_json[i] != "{}") {
      const auto attrs = pipetrace::parse_object_attributes(events.attributes_json[i]);
      EXPECT_EQ(pipetrace::attribute_value(attrs, "phase"), "compute");
      found_event_attributes = true;
      break;
    }
  }
  EXPECT_TRUE(found_event_attributes);

  const auto event_types = store->event_types();
  ASSERT_FALSE(event_types.empty());
  EXPECT_NE(event_types.front().display_char, '\0');

  const std::vector<pipetrace::CycleOccurrenceCount> decode_counts =
      store->query_event_cycle_counts(event_types.front().id, viewport.time_start,
                                      viewport.time_end);
  ASSERT_FALSE(decode_counts.empty());
  EXPECT_GT(decode_counts.front().count, 0U);

  const auto first_object = store->find_object(1);
  ASSERT_TRUE(first_object.has_value());
  ASSERT_GE(first_object->attributes.size(), 2U);
  EXPECT_EQ(pipetrace::attribute_value(first_object->attributes, "inst_id"), "0");
  EXPECT_EQ(pipetrace::attribute_value(first_object->attributes, "task_index"), "0");
}

TEST(Storage, ObjectIdZeroAppearsAtRowZero) {
  const std::string db = temp_path("pipetrace_object_zero.db");
  std::filesystem::remove(db);

  pipetrace::SqliteStore store;
  ASSERT_TRUE(store.open(db));
  store.exec_sql("BEGIN IMMEDIATE;");
  store.insert_object_type(1, "object", "Object");
  store.insert_object(0, 1, "inst_0", 0, 10, -1, R"({"type":"Instruction"})");
  store.insert_object(1, 1, "uop_1", 0, 10, 0, R"({"type":"Uop","disasm":"nop"})");
  store.set_meta("object_zero", 0, 10, 2, 0);
  store.commit_transaction();

  auto trace_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store->open(db));

  const std::optional<std::int64_t> row0 = trace_store->object_row_index(0);
  ASSERT_TRUE(row0.has_value());
  EXPECT_EQ(*row0, 0);

  pipetrace::Viewport viewport;
  viewport.time_start = 0;
  viewport.time_end = 100;
  viewport.row_start = 0;
  viewport.row_end = 1;

  const pipetrace::ColumnarObjects objects = trace_store->query_objects(viewport);
  ASSERT_EQ(objects.ids.size(), 2U);
  EXPECT_EQ(objects.ids[0], 0);
  EXPECT_EQ(objects.row_indices[0], 0);
  EXPECT_EQ(objects.ids[1], 1);
  EXPECT_EQ(objects.row_indices[1], 1);
}

TEST(Storage, SparseObjectIdsUseDenseRowIndex) {
  const std::string db = temp_path("pipetrace_sparse_ids.db");
  std::filesystem::remove(db);

  pipetrace::SqliteStore store;
  ASSERT_TRUE(store.open(db));
  store.exec_sql("BEGIN IMMEDIATE;");
  store.insert_object_type(1, "object", "Object");
  store.insert_object(0, 1, "obj_0", 0, 10, -1, R"({"InstID":"100"})");
  store.insert_object(5, 1, "obj_5", 0, 10, -1, R"({"InstID":"200"})");
  store.insert_object(100, 1, "obj_100", 0, 10, -1, R"({"InstID":"3723"})");
  store.set_meta("sparse_test", 0, 10, 3, 0);
  store.commit_transaction();

  auto trace_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store->open(db));

  const std::optional<std::int64_t> row0 = trace_store->object_row_index(0);
  ASSERT_TRUE(row0.has_value());
  EXPECT_EQ(*row0, 0);

  const std::optional<std::int64_t> row5 = trace_store->object_row_index(5);
  ASSERT_TRUE(row5.has_value());
  EXPECT_EQ(*row5, 1);

  const std::optional<std::int64_t> row100 = trace_store->object_row_index(100);
  ASSERT_TRUE(row100.has_value());
  EXPECT_EQ(*row100, 2);

  const std::optional<pipetrace::ObjectId> id_for_row0 = trace_store->object_id_for_row(0);
  ASSERT_TRUE(id_for_row0.has_value());
  EXPECT_EQ(*id_for_row0, 0);

  const std::optional<pipetrace::ObjectId> id_for_row2 = trace_store->object_id_for_row(2);
  ASSERT_TRUE(id_for_row2.has_value());
  EXPECT_EQ(*id_for_row2, 100);

  const std::unordered_map<std::string, std::int64_t> inst_index =
      trace_store->build_attribute_row_index("InstID");
  EXPECT_EQ(inst_index.at("100"), 0);
  EXPECT_EQ(inst_index.at("200"), 1);
  EXPECT_EQ(inst_index.at("3723"), 2);
}

TEST(Storage, ObjectAttributeKeysTable) {
  const std::string db = temp_path("pipetrace_object_attribute_keys.db");
  std::filesystem::remove(db);

  pipetrace::SqliteStore store;
  ASSERT_TRUE(store.open(db));
  store.exec_sql("BEGIN IMMEDIATE;");
  store.insert_object_type(1, "object", "Object");
  store.insert_object(1, 1, "uop_1", 0, 10, -1, R"({"type":"Uop","InstID":"1","disasm":"nop"})");
  store.insert_object(2, 1, "uop_2", 0, 10, -1, R"({"type":"Uop","InstID":"2"})");
  store.set_meta("keys_test", 0, 10, 2, 0);
  store.refresh_object_attribute_keys();
  store.commit_transaction();

  auto trace_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store->open(db));

  const std::vector<std::string> keys = trace_store->object_attribute_keys();
  ASSERT_EQ(keys.size(), 3U);
  EXPECT_EQ(keys[0], "InstID");
  EXPECT_EQ(keys[1], "disasm");
  EXPECT_EQ(keys[2], "type");
}

TEST(Storage, SortsObjectsByAttributeScheme) {
  const std::string db = temp_path("pipetrace_sort_attrs.db");
  std::filesystem::remove(db);

  pipetrace::SqliteStore store;
  ASSERT_TRUE(store.open(db));
  store.exec_sql("BEGIN IMMEDIATE;");
  store.insert_object_type(1, "object", "Object");
  store.insert_object(0, 1, "obj_0", 0, 10, -1,
                      R"({"seqnum":"2","InstID":"10","PC":"0xBBBB"})");
  store.insert_object(1, 1, "obj_1", 0, 10, -1,
                      R"({"seqnum":"1","InstID":"20","PC":"0x10000"})");
  store.insert_object(2, 1, "obj_2", 0, 10, -1,
                      R"({"seqnum":"1","InstID":"5","PC":"0xAAAA"})");
  store.insert_object(3, 1, "obj_3", 0, 10, -1, R"({"InstID":"1"})");
  store.set_meta("sort_test", 0, 10, 4, 0);
  store.commit_transaction();

  pipetrace::SortScheme scheme;
  scheme.name = "seqnum/InstID";
  scheme.columns = {{"seqnum", "asc"}, {"InstID", "asc"}};
  ASSERT_EQ(store.materialize_object_sort_ranks({scheme}, true), 1U);

  auto trace_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store->open(db));

  pipetrace::Viewport viewport;
  viewport.time_start = 0;
  viewport.time_end = 100;
  viewport.row_start = 0;
  viewport.row_end = 3;

  const pipetrace::ColumnarObjects objects = trace_store->query_objects(viewport, 0, &scheme);
  ASSERT_EQ(objects.ids.size(), 4U);
  EXPECT_EQ(objects.ids[0], 2);
  EXPECT_EQ(objects.ids[1], 1);
  EXPECT_EQ(objects.ids[2], 0);
  EXPECT_EQ(objects.ids[3], 3);

  const std::optional<std::int64_t> row2 = trace_store->object_row_index(2, &scheme);
  ASSERT_TRUE(row2.has_value());
  EXPECT_EQ(*row2, 0);

  const std::optional<std::int64_t> row3 = trace_store->object_row_index(3, &scheme);
  ASSERT_TRUE(row3.has_value());
  EXPECT_EQ(*row3, 3);
}

TEST(Storage, SortsHexPcValuesNumerically) {
  const std::string db = temp_path("pipetrace_sort_pc.db");
  std::filesystem::remove(db);

  pipetrace::SqliteStore store;
  ASSERT_TRUE(store.open(db));
  store.exec_sql("BEGIN IMMEDIATE;");
  store.insert_object_type(1, "object", "Object");
  store.insert_object(0, 1, "a", 0, 10, -1, R"({"PC":"0xBBBB"})");
  store.insert_object(1, 1, "b", 0, 10, -1, R"({"PC":"0xAAAA"})");
  store.insert_object(2, 1, "c", 0, 10, -1, R"({"PC":"0x10000"})");
  store.set_meta("pc_sort", 0, 10, 3, 0);
  store.commit_transaction();

  pipetrace::SortScheme scheme;
  scheme.name = "PC";
  scheme.columns = {{"PC", "asc"}};
  ASSERT_EQ(store.materialize_object_sort_ranks({scheme}, true), 1U);

  auto trace_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store->open(db));

  pipetrace::Viewport viewport;
  viewport.time_start = 0;
  viewport.time_end = 100;
  viewport.row_start = 0;
  viewport.row_end = 2;

  const pipetrace::ColumnarObjects objects = trace_store->query_objects(viewport, 0, &scheme);
  ASSERT_EQ(objects.ids.size(), 3U);
  EXPECT_EQ(objects.ids[0], 1);
  EXPECT_EQ(objects.ids[1], 0);
  EXPECT_EQ(objects.ids[2], 2);
}

TEST(Storage, BuildSortOrderIncludesTypedKeys) {
  pipetrace::SortScheme scheme;
  scheme.name = "seqnum/InstID";
  scheme.columns = {{"seqnum", "asc"}, {"InstID", "asc"}};

  const std::string order_by = pipetrace::build_object_sort_order_by_clause(scheme);
  EXPECT_NE(order_by.find("json_extract(attributes, '$.seqnum')"), std::string::npos);
  EXPECT_NE(order_by.find("json_extract(attributes, '$.InstID')"), std::string::npos);
  EXPECT_NE(order_by.find(", id"), std::string::npos);
}

TEST(Storage, RankedViewportReturnsSubset) {
  const std::string db = temp_path("pipetrace_sort_rank_viewport.db");
  std::filesystem::remove(db);

  pipetrace::SqliteStore store;
  ASSERT_TRUE(store.open(db));
  store.exec_sql("BEGIN IMMEDIATE;");
  store.insert_object_type(1, "object", "Object");
  store.insert_object(0, 1, "obj_0", 0, 10, -1, R"({"seqnum":"30"})");
  store.insert_object(1, 1, "obj_1", 0, 10, -1, R"({"seqnum":"10"})");
  store.insert_object(2, 1, "obj_2", 0, 10, -1, R"({"seqnum":"20"})");
  store.insert_object(3, 1, "obj_3", 0, 10, -1, R"({"seqnum":"40"})");
  store.set_meta("rank_viewport", 0, 10, 4, 0);
  store.commit_transaction();

  pipetrace::SortScheme scheme;
  scheme.name = "seqnum";
  scheme.columns = {{"seqnum", "asc"}};
  ASSERT_EQ(store.materialize_object_sort_ranks({scheme}, true), 1U);
  EXPECT_TRUE(store.has_object_sort_ranks("seqnum"));
  EXPECT_EQ(store.materialize_object_sort_ranks({scheme}, false), 0U);

  auto trace_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store->open(db));

  pipetrace::Viewport viewport;
  viewport.time_start = 0;
  viewport.time_end = 10;
  viewport.row_start = 1;
  viewport.row_end = 2;

  const pipetrace::ColumnarObjects objects = trace_store->query_objects(viewport, 0, &scheme);
  ASSERT_EQ(objects.ids.size(), 2U);
  EXPECT_EQ(objects.ids[0], 2);
  EXPECT_EQ(objects.ids[1], 0);
  ASSERT_EQ(objects.row_indices.size(), 2U);
  EXPECT_EQ(objects.row_indices[0], 1);
  EXPECT_EQ(objects.row_indices[1], 2);

  const auto id_at_0 = trace_store->object_id_for_row(0, &scheme);
  ASSERT_TRUE(id_at_0.has_value());
  EXPECT_EQ(*id_at_0, 1);
}

TEST(Storage, MissingRanksFallsBackToIdOrder) {
  const std::string db = temp_path("pipetrace_sort_no_ranks.db");
  std::filesystem::remove(db);

  pipetrace::SqliteStore store;
  ASSERT_TRUE(store.open(db));
  store.exec_sql("BEGIN IMMEDIATE;");
  store.insert_object_type(1, "object", "Object");
  store.insert_object(0, 1, "obj_0", 0, 10, -1, R"({"seqnum":"2"})");
  store.insert_object(1, 1, "obj_1", 0, 10, -1, R"({"seqnum":"1"})");
  store.set_meta("no_ranks", 0, 10, 2, 0);
  store.commit_transaction();

  auto trace_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store->open(db));

  pipetrace::SortScheme scheme;
  scheme.name = "seqnum";
  scheme.columns = {{"seqnum", "asc"}};

  pipetrace::Viewport viewport;
  viewport.time_start = 0;
  viewport.time_end = 10;
  viewport.row_start = 0;
  viewport.row_end = 1;

  const pipetrace::ColumnarObjects objects = trace_store->query_objects(viewport, 0, &scheme);
  ASSERT_EQ(objects.ids.size(), 2U);
  EXPECT_EQ(objects.ids[0], 0);
  EXPECT_EQ(objects.ids[1], 1);
}

TEST(Storage, FindsFirstObjectByAttributePrefix) {
  const std::string db = temp_path("pipetrace_attr_search.db");
  std::filesystem::remove(db);

  pipetrace::SqliteStore store;
  ASSERT_TRUE(store.open(db));
  store.exec_sql("BEGIN IMMEDIATE;");
  store.insert_object_type(1, "object", "Object");
  store.insert_object(0, 1, "obj_0", 0, 10, -1,
                      R"({"seqnum":"42","InstID":"100"})");
  store.insert_object(1, 1, "obj_1", 0, 10, -1,
                      R"({"seqnum":"4","InstID":"200"})");
  store.insert_object(2, 1, "obj_2", 0, 10, -1,
                      R"({"seqnum":"124","InstID":"300"})");
  store.set_meta("search_test", 0, 10, 3, 0);
  store.commit_transaction();

  pipetrace::SortScheme scheme;
  scheme.name = "seqnum/InstID";
  scheme.columns = {{"seqnum", "asc"}, {"InstID", "asc"}};
  ASSERT_EQ(store.materialize_object_sort_ranks({scheme}, true), 1U);

  auto trace_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store->open(db));

  const std::optional<pipetrace::AttributeSearchMatch> match4 =
      trace_store->find_first_object_by_attribute("seqnum", "4", &scheme);
  ASSERT_TRUE(match4.has_value());
  EXPECT_EQ(match4->object_id, 1);
  EXPECT_EQ(match4->row_index, 0);

  const std::optional<pipetrace::AttributeSearchMatch> match42 =
      trace_store->find_first_object_by_attribute("seqnum", "42", &scheme);
  ASSERT_TRUE(match42.has_value());
  EXPECT_EQ(match42->object_id, 0);
  EXPECT_EQ(match42->row_index, 1);

  const std::optional<pipetrace::AttributeSearchMatch> match124 =
      trace_store->find_first_object_by_attribute("seqnum", "24", &scheme);
  EXPECT_FALSE(match124.has_value());
}

TEST(Storage, ViewportEventsRespectTimeWindow) {
  const std::string db = temp_path("pipetrace_event_time_window.db");
  std::filesystem::remove(db);

  pipetrace::SqliteStore store;
  ASSERT_TRUE(store.open(db));
  store.exec_sql("BEGIN IMMEDIATE;");
  store.insert_object_type(1, "object", "Object");
  store.insert_event_type(1, "work", 1, 0xFF888888U);
  store.insert_object(0, 1, "obj_0", 0, 100, -1, "{}");
  store.insert_event(1, 0, 1, "work", 10, "{}");
  store.insert_event(2, 0, 1, "work", 50, "{}");
  store.insert_event(3, 0, 1, "work", 90, "{}");
  store.set_meta("time_window", 0, 100, 1, 3);
  store.commit_transaction();

  auto trace_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store->open(db));

  pipetrace::Viewport viewport;
  viewport.time_start = 40;
  viewport.time_end = 60;
  viewport.row_start = 0;
  viewport.row_end = 0;

  const pipetrace::ColumnarObjects objects = trace_store->query_objects(viewport, 0);
  ASSERT_EQ(objects.ids.size(), 1U);
  const pipetrace::ColumnarEvents events = trace_store->query_events(viewport, objects.ids);
  ASSERT_EQ(events.times.size(), 1U);
  EXPECT_EQ(events.times.front(), 50);

  const auto counts = trace_store->query_event_cycle_counts(1, 40, 60);
  ASSERT_EQ(counts.size(), 1U);
  EXPECT_EQ(counts.front().cycle, 50);
  EXPECT_EQ(counts.front().count, 1U);

  const auto outside = trace_store->query_event_cycle_counts(1, 0, 5);
  EXPECT_TRUE(outside.empty());
}

TEST(Storage, AttributeSortViewportIsStableAcrossQueries) {
  const std::string db = temp_path("pipetrace_sort_cache.db");
  std::filesystem::remove(db);

  pipetrace::SqliteStore store;
  ASSERT_TRUE(store.open(db));
  store.exec_sql("BEGIN IMMEDIATE;");
  store.insert_object_type(1, "object", "Object");
  store.insert_object(0, 1, "obj_0", 0, 10, -1, R"({"seqnum":"2"})");
  store.insert_object(1, 1, "obj_1", 0, 10, -1, R"({"seqnum":"1"})");
  store.insert_object(2, 1, "obj_2", 0, 10, -1, R"({"seqnum":"3"})");
  store.set_meta("sort_cache", 0, 10, 3, 0);
  store.commit_transaction();

  pipetrace::SortScheme scheme;
  scheme.name = "seqnum";
  scheme.columns = {{"seqnum", "asc"}};
  ASSERT_EQ(store.materialize_object_sort_ranks({scheme}, true), 1U);

  auto trace_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store->open(db));

  pipetrace::Viewport viewport;
  viewport.time_start = 0;
  viewport.time_end = 10;
  viewport.row_start = 0;
  viewport.row_end = 1;

  const pipetrace::ColumnarObjects first = trace_store->query_objects(viewport, 0, &scheme);
  const pipetrace::ColumnarObjects second = trace_store->query_objects(viewport, 0, &scheme);
  ASSERT_EQ(first.ids.size(), 2U);
  ASSERT_EQ(second.ids, first.ids);
  EXPECT_EQ(first.ids[0], 1);
  EXPECT_EQ(first.ids[1], 0);

  const auto row1 = trace_store->object_row_index(1, &scheme);
  const auto id_at_0 = trace_store->object_id_for_row(0, &scheme);
  ASSERT_TRUE(row1.has_value());
  ASSERT_TRUE(id_at_0.has_value());
  EXPECT_EQ(*row1, 0);
  EXPECT_EQ(*id_at_0, 1);
}
