#include <gtest/gtest.h>

#include "pipetrace/row_sort_state.hpp"

namespace {

pipetrace::AppConfig make_config() {
  pipetrace::AppConfig config = pipetrace::default_app_config();
  config.sort_schemes = {
      {.name = "seqnum",
       .columns = {{.key = "seqnum", .order = "asc"}}},
      {.name = "PC/seqnum",
       .columns = {{.key = "PC", .order = "asc"}, {.key = "seqnum", .order = "asc"}}},
      {.name = "RetirePushup",
       .columns = {{.key = "RetirePushup", .order = "desc"}}},
  };
  return config;
}

}  // namespace

TEST(RowSortState, StartsInConfigMode) {
  const pipetrace::AppConfig config = make_config();
  pipetrace::RowSortState state;
  EXPECT_FALSE(state.user_mode());
  EXPECT_EQ(state.config_scheme_index(), 0U);
  ASSERT_NE(state.active_sort_scheme(config), nullptr);
  EXPECT_EQ(state.active_sort_scheme(config)->name, "seqnum");
  EXPECT_EQ(state.display_label(config), "seqnum");
}

TEST(RowSortState, HeaderDoubleClickMapsToConfiguredScheme) {
  const pipetrace::AppConfig config = make_config();
  pipetrace::RowSortState state;
  EXPECT_TRUE(state.apply_header_double_click("PC", config));
  EXPECT_FALSE(state.user_mode());
  EXPECT_EQ(state.config_scheme_index(), 1U);
  ASSERT_NE(state.viewport_sort_scheme(config), nullptr);
  EXPECT_EQ(state.viewport_sort_scheme(config)->name, "PC/seqnum");
}

TEST(RowSortState, HeaderDoubleClickUnconfiguredIsTrianglesOnly) {
  const pipetrace::AppConfig config = make_config();
  pipetrace::RowSortState state;
  EXPECT_FALSE(state.apply_header_double_click("disasm", config));
  EXPECT_TRUE(state.user_mode());
  EXPECT_EQ(state.user_column_key(), "disasm");
  EXPECT_TRUE(state.user_ascending());
  // Viewport order stays on the config scheme (seqnum).
  ASSERT_NE(state.viewport_sort_scheme(config), nullptr);
  EXPECT_EQ(state.viewport_sort_scheme(config)->name, "seqnum");
  EXPECT_NE(state.display_label(config).find("User (disasm"), std::string::npos);
}

TEST(RowSortState, HeaderDoubleClickSameConfiguredColumnWithoutReverseIsTrianglesOnly) {
  const pipetrace::AppConfig config = make_config();
  pipetrace::RowSortState state;
  ASSERT_TRUE(state.set_config_scheme_index(2, config));
  EXPECT_FALSE(state.apply_header_double_click("RetirePushup", config));
  EXPECT_TRUE(state.user_mode());
  EXPECT_TRUE(state.user_ascending());
  EXPECT_EQ(state.viewport_sort_scheme(config)->name, "RetirePushup");
}

TEST(RowSortState, ConfigSchemeLeavesUserMode) {
  const pipetrace::AppConfig config = make_config();
  pipetrace::RowSortState state;
  state.apply_header_double_click("disasm", config);
  ASSERT_TRUE(state.set_config_scheme_index(1, config));
  EXPECT_FALSE(state.user_mode());
  EXPECT_EQ(state.config_scheme_index(), 1U);
  ASSERT_NE(state.active_sort_scheme(config), nullptr);
  EXPECT_EQ(state.active_sort_scheme(config)->name, "PC/seqnum");
}

TEST(RowSortState, ActiveSortDirectionForColumn) {
  const pipetrace::AppConfig config = make_config();
  pipetrace::RowSortState state;

  ASSERT_TRUE(state.active_sort_direction_for_column("seqnum", config).has_value());
  EXPECT_TRUE(*state.active_sort_direction_for_column("seqnum", config));
  EXPECT_FALSE(state.active_sort_direction_for_column("InstID", config).has_value());

  ASSERT_TRUE(state.set_config_scheme_index(2, config));
  ASSERT_TRUE(state.active_sort_direction_for_column("RetirePushup", config).has_value());
  EXPECT_FALSE(*state.active_sort_direction_for_column("RetirePushup", config));

  state.apply_header_double_click("disasm", config);
  ASSERT_TRUE(state.active_sort_direction_for_column("disasm", config).has_value());
  EXPECT_TRUE(*state.active_sort_direction_for_column("disasm", config));
  state.apply_header_double_click("disasm", config);
  ASSERT_TRUE(state.active_sort_direction_for_column("disasm", config).has_value());
  EXPECT_FALSE(*state.active_sort_direction_for_column("disasm", config));
}
