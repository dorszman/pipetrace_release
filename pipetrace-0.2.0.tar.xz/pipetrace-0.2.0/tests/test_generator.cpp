#include <filesystem>
#include <string>

#include "gtest/gtest.h"
#include "pipetrace/generator.hpp"
#include "pipetrace/storage.hpp"

namespace {

std::string temp_path(const std::string& name) {
  return (std::filesystem::temp_directory_path() / name).string();
}

}  // namespace

TEST(Generator, CreatesCpuPipelineTrace) {
  const std::string ptj = temp_path("pipetrace_cpu.ptj");
  const std::string db = ptj + ".db";
  std::filesystem::remove(ptj);
  std::filesystem::remove(db);

  pipetrace::CpuPipelineConfig config;
  config.object_count = 25;
  config.time_span = 5000;
  const pipetrace::TraceMeta meta = pipetrace::generate_cpu_pipeline_trace(config, ptj);

  auto store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(store->open(db));

  EXPECT_EQ(meta.object_count, 25);
  EXPECT_GT(meta.event_count, 25 * 6);
  EXPECT_GE(store->event_types().size(), 108U);
  EXPECT_TRUE(std::filesystem::exists(ptj));
  EXPECT_TRUE(std::filesystem::exists(db));

  const auto object = store->find_object(1);
  ASSERT_TRUE(object.has_value());
  ASSERT_GE(object->attributes.size(), 3U);
  bool has_slot = false;
  bool has_uop_index = false;
  bool has_inst_id = false;
  bool has_asm = false;
  for (const auto& [key, value] : object->attributes) {
    if (key == "slot") {
      has_slot = true;
      EXPECT_EQ(value, "0");
    }
    if (key == "uop_index") {
      has_uop_index = true;
      EXPECT_EQ(value, "0");
    }
    if (key == "inst_id") {
      has_inst_id = true;
      EXPECT_EQ(value, "0");
    }
    if (key == "asm") {
      has_asm = true;
      EXPECT_FALSE(value.empty());
    }
  }
  EXPECT_TRUE(has_slot);
  EXPECT_TRUE(has_uop_index);
  EXPECT_TRUE(has_inst_id);
  EXPECT_TRUE(has_asm);
}
