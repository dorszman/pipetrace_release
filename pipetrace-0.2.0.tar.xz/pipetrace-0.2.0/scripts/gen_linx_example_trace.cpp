// Generate a Linx .pt trace in pipetrace_example style: Instruction + Uop
// objects with realistic pipeline event names and attributes.
//
// Usage: gen_linx_example_trace --output PATH.pt [--instructions N] [--uops N]

#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>

namespace {

struct Options {
  const char* output_path = nullptr;
  std::int64_t instruction_count = 1000000;
  std::int64_t uop_count = 1000000;
};

void usage() {
  std::fprintf(stderr,
               "gen_linx_example_trace --output PATH.pt [--instructions N] [--uops N]\n");
}

Options parse_args(int argc, char** argv) {
  Options options;
  for (int i = 1; i < argc; ++i) {
    if (std::strcmp(argv[i], "--output") == 0 && i + 1 < argc) {
      options.output_path = argv[++i];
    } else if (std::strcmp(argv[i], "--instructions") == 0 && i + 1 < argc) {
      options.instruction_count = std::strtoll(argv[++i], nullptr, 10);
    } else if (std::strcmp(argv[i], "--uops") == 0 && i + 1 < argc) {
      options.uop_count = std::strtoll(argv[++i], nullptr, 10);
    } else if (std::strcmp(argv[i], "--help") == 0) {
      usage();
      std::exit(0);
    } else {
      std::fprintf(stderr, "unknown argument: %s\n", argv[i]);
      usage();
      std::exit(1);
    }
  }
  if (options.output_path == nullptr || options.instruction_count <= 0 ||
      options.uop_count <= 0) {
    usage();
    std::exit(1);
  }
  return options;
}

enum class UopKind : int { Addi, Simd, Load, Store, Branch };

UopKind kind_for(std::int64_t serial) {
  switch (serial % 16) {
    case 3:
    case 11:
      return UopKind::Load;
    case 7:
      return UopKind::Store;
    case 15:
      return UopKind::Branch;
    case 1:
    case 5:
    case 9:
    case 13:
      return UopKind::Simd;
    default:
      return UopKind::Addi;
  }
}

struct Writer {
  FILE* file;
  char buf[1 << 20];
  std::size_t used = 0;

  explicit Writer(FILE* f) : file(f) {}

  void flush() {
    if (used == 0) {
      return;
    }
    if (std::fwrite(buf, 1, used, file) != used) {
      std::fprintf(stderr, "write failed\n");
      std::exit(1);
    }
    used = 0;
  }

  void append(const char* data, std::size_t n) {
    if (n > sizeof(buf)) {
      flush();
      if (std::fwrite(data, 1, n, file) != n) {
        std::fprintf(stderr, "write failed\n");
        std::exit(1);
      }
      return;
    }
    if (used + n > sizeof(buf)) {
      flush();
    }
    std::memcpy(buf + used, data, n);
    used += n;
  }

  void print(const char* fmt, ...) {
    char tmp[512];
    va_list args;
    va_start(args, fmt);
    const int n = std::vsnprintf(tmp, sizeof(tmp), fmt, args);
    va_end(args);
    if (n < 0) {
      return;
    }
    append(tmp, static_cast<std::size_t>(n));
  }
};

void write_inst_events(Writer& out, std::int64_t inst_id, std::int64_t inst_serial,
                       std::int64_t fetch_c, std::int64_t decode_c, std::int64_t retire_c) {
  out.print("[%lld] [%lld] f5_valid(5) PC:0x0\n",
            static_cast<long long>(inst_id), static_cast<long long>(fetch_c));
  out.print("[%lld] [%lld] D1_decode_instr(1)\n",
            static_cast<long long>(inst_id), static_cast<long long>(decode_c));
  if (inst_serial % 8 == 3) {
    out.print("[%lld] [%lld] instr_window_break(S) instr_window_break_reason:\"window-limit\"\n",
              static_cast<long long>(inst_id), static_cast<long long>(decode_c));
    out.print("[%lld] [%lld] D1_decode_instr(1)\n",
              static_cast<long long>(inst_id), static_cast<long long>(decode_c + 2));
  }
  out.print("[%lld] [%lld] retire_inst(R) InstID:%lld\n", static_cast<long long>(inst_id),
            static_cast<long long>(retire_c), static_cast<long long>(inst_serial));
}

void write_addi_uop(Writer& out, std::int64_t uop_id, std::int64_t parent, std::int64_t inst_id,
                    std::uint64_t pc, std::int64_t seq, int xn, int ptag, int src_ptag,
                    int robid, std::int64_t c0, std::int64_t retire_c, std::uint64_t val) {
  out.print(
      "[%lld] type:Uop parent:%lld InstID:%lld PC:0x%llx disasm:\"ADDI  D: X%d  S: X%d  "
      "I: 0x10\" seqnum:%lld tid:0\n",
      static_cast<long long>(uop_id), static_cast<long long>(parent),
      static_cast<long long>(inst_id), static_cast<unsigned long long>(pc), xn, xn,
      static_cast<long long>(seq));
  out.print("[%lld] [%lld] replicate_uop_from_Instr(1)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0));
  out.print("[%lld] [%lld] decode_uop(2)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 2));
  out.print(
      "[%lld] [%lld] alloc(A) ROBID:%d dest_ptag1:%d dest_reg1:X%d exe_latency:1 seqnum:%lld "
      "src_ptag1:%d src_ptag2:-1 src_reg1:X%d src_reg2:none\n",
      static_cast<long long>(uop_id), static_cast<long long>(c0 + 4), robid, ptag, xn,
      static_cast<long long>(seq), src_ptag, xn);
  out.print(
      "[%lld] [%lld] alloc_zlc(a) eport:-1 issueq:0 sched:4294967295 zlc_latency:2\n",
      static_cast<long long>(uop_id), static_cast<long long>(c0 + 4));
  out.print("[%lld] [%lld] folding_uop(f)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 4));
  out.print("[%lld] [%lld] writeback(w) dest_ptag:%d dest_val:0x%llx pipe:-1\n",
            static_cast<long long>(uop_id), static_cast<long long>(c0 + 6), ptag,
            static_cast<unsigned long long>(val));
  out.print("[%lld] [%lld] zlc_ex(Z)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 6));
  out.print("[%lld] [%lld] value_feedback(v) state:0\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 7));
  out.print("[%lld] [%lld] zlc_wakeup(S)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 9));
  out.print("[%lld] [%lld] preg_release(^) dest_ptag:%d dest_reg:X%d\n",
            static_cast<long long>(uop_id), static_cast<long long>(retire_c - 2), src_ptag, xn);
  out.print(
      "[%lld] [%lld] retire_uop(R) ROBID:%d dest_ptag1:%d dest_ptag2:~ dest_reg1:X%d "
      "dest_reg2:none\n",
      static_cast<long long>(uop_id), static_cast<long long>(retire_c), robid, ptag, xn);
}

void write_simd_uop(Writer& out, std::int64_t uop_id, std::int64_t parent, std::int64_t inst_id,
                    std::uint64_t pc, std::int64_t seq, int vn, int ptag, int src1, int src2,
                    int robid, std::int64_t c0, std::int64_t retire_c) {
  out.print(
      "[%lld] type:Uop parent:%lld InstID:%lld PC:0x%llx disasm:\"VADDW  D: V%d  S: V0, V%d\" "
      "seqnum:%lld tid:0\n",
      static_cast<long long>(uop_id), static_cast<long long>(parent),
      static_cast<long long>(inst_id), static_cast<unsigned long long>(pc), vn, vn,
      static_cast<long long>(seq));
  out.print("[%lld] [%lld] replicate_uop_from_Instr(1)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0));
  out.print("[%lld] [%lld] decode_uop(2)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 2));
  out.print(
      "[%lld] [%lld] alloc(A) ROBID:%d dest_ptag1:%d dest_reg1:V%d exe_latency:2 seqnum:%lld "
      "src_ptag1:%d src_ptag2:%d src_reg1:V0 src_reg2:V%d\n",
      static_cast<long long>(uop_id), static_cast<long long>(c0 + 3), robid, ptag, vn,
      static_cast<long long>(seq), src1, src2, vn);
  out.print("[%lld] [%lld] zlc_reject(r) state:0\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 3));
  const int pipe = static_cast<int>(uop_id % 4);
  out.print("[%lld] [%lld] fsu_issue(i) issueq:%d pipe:%d\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 17), pipe, pipe);
  out.print(
      "[%lld] [%lld] fsu_ready(r) src_ptag1:%d src_ptag2:%d src_val1:0xff80ff80ff80ff80 "
      "src_val2:0x8888888888888888\n",
      static_cast<long long>(uop_id), static_cast<long long>(c0 + 17), src1, src2);
  out.print("[%lld] [%lld] fsu_Execute(E) pipe:%d\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 22), pipe);
  out.print("[%lld] [%lld] preg_release(^) dest_ptag:%d dest_reg:V%d\n",
            static_cast<long long>(uop_id), static_cast<long long>(retire_c - 2), src2, vn);
  out.print(
      "[%lld] [%lld] retire_uop(R) ROBID:%d dest_ptag1:%d dest_ptag2:~ dest_reg1:V%d "
      "dest_reg2:none\n",
      static_cast<long long>(uop_id), static_cast<long long>(retire_c), robid, ptag, vn);
}

void write_load_uop(Writer& out, std::int64_t uop_id, std::int64_t parent, std::uint64_t pc,
                    std::uint64_t pa, std::int64_t seq, int vn, int xn, int ptag, int src_ptag,
                    int robid, int ldid, std::int64_t c0, std::int64_t retire_c) {
  out.print(
      "[%lld] type:Uop parent:%lld PA:0x%llx PC:0x%llx disasm:\"LDR  D: V%d  S: X%d  I: 0x0, "
      "0x0\" seqnum:%lld tid:0\n",
      static_cast<long long>(uop_id), static_cast<long long>(parent),
      static_cast<unsigned long long>(pa), static_cast<unsigned long long>(pc), vn, xn,
      static_cast<long long>(seq));
  out.print("[%lld] [%lld] replicate_uop_from_Instr(1)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0));
  out.print("[%lld] [%lld] decode_uop(2)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 2));
  out.print(
      "[%lld] [%lld] alloc(A) ROBID:%d dest_ptag1:%d dest_ptag2:-1 dest_reg1:V%d dest_reg2:none "
      "exe_latency:4 ldid:%d seqnum:%lld src_ptag1:%d src_ptag2:-1 src_reg1:X%d src_reg2:none\n",
      static_cast<long long>(uop_id), static_cast<long long>(c0 + 4), robid, ptag, vn, ldid,
      static_cast<long long>(seq), src_ptag, xn);
  out.print(
      "[%lld] [%lld] alloc_zlc(a) eport:17 issueq:0 sched:4294967295 zlc_latency:3\n",
      static_cast<long long>(uop_id), static_cast<long long>(c0 + 4));
  out.print("[%lld] [%lld] write_dispq(d) eport:17 sched:17\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 4));
  out.print("[%lld] [%lld] dispatch(d) issueq:17 pipe:17\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 5));
  out.print("[%lld] [%lld] ready(r) src_ptag1:%d src_ptag2:-1 src_val1:0x%llx src_val2:0xdeadbeef\n",
            static_cast<long long>(uop_id), static_cast<long long>(c0 + 7), src_ptag,
            static_cast<unsigned long long>(pa));
  out.print("[%lld] [%lld] src_ready(r) src_num:0\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 7));
  out.print("[%lld] [%lld] zlc_ex(Z)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 7));
  out.print("[%lld] [%lld] issue(i) issueq:17 pipe:17\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 8));
  out.print("[%lld] [%lld] issue_execute_load(E) pipe:17 zlc_path:1\n",
            static_cast<long long>(uop_id), static_cast<long long>(c0 + 8));
  out.print("[%lld] [%lld] result_pipe_arb_win(R) type:ISSUE_LOAD zlc_path:1\n",
            static_cast<long long>(uop_id), static_cast<long long>(c0 + 8));
  out.print("[%lld] [%lld] send_wakeup(W)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 8));
  out.print("[%lld] [%lld] zlc_fast_load_dealloc_isq(F)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 8));
  out.print("[%lld] [%lld] TLB_lookup_load_hit(h)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 9));
  out.print("[%lld] [%lld] dc_data_arb(d)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 9));
  out.print("[%lld] [%lld] deallocate_issq(d)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 9));
  out.print(
      "[%lld] [%lld] dc_hit($) PA:0x%llx VA:0x%llx entry:0 set:%d state:Exclusive way:0\n",
      static_cast<long long>(uop_id), static_cast<long long>(c0 + 10),
      static_cast<unsigned long long>(pa), static_cast<unsigned long long>(pa),
      static_cast<int>(uop_id % 512));
  out.print("[%lld] [%lld] ld_writeback(w)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 11));
  out.print("[%lld] [%lld] load_complete(c)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 11));
  out.print("[%lld] [%lld] preg_release(^) dest_ptag:%d dest_reg:V%d\n",
            static_cast<long long>(uop_id), static_cast<long long>(retire_c - 2), src_ptag, vn);
  out.print(
      "[%lld] [%lld] retire_uop(R) ROBID:%d dest_ptag1:%d dest_ptag2:~ dest_reg1:V%d "
      "dest_reg2:none\n",
      static_cast<long long>(uop_id), static_cast<long long>(retire_c), robid, ptag, vn);
}

void write_store_uop(Writer& out, std::int64_t uop_id, std::int64_t parent, std::uint64_t pc,
                     std::uint64_t pa, std::int64_t seq, int xn, int src_ptag, int robid,
                     int stid, std::int64_t c0, std::int64_t retire_c) {
  out.print(
      "[%lld] type:Uop parent:%lld PA:0x%llx PC:0x%llx disasm:\"STPA  S: X%d  I: 0x0\" "
      "seqnum:%lld tid:0\n",
      static_cast<long long>(uop_id), static_cast<long long>(parent),
      static_cast<unsigned long long>(pa), static_cast<unsigned long long>(pc), xn,
      static_cast<long long>(seq));
  out.print("[%lld] [%lld] replicate_uop_from_Instr(1)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0));
  out.print("[%lld] [%lld] decode_uop(2)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 2));
  out.print(
      "[%lld] [%lld] alloc(A) ROBID:%d dest_ptag1:-1 dest_ptag2:-1 dest_reg1:none dest_reg2:none "
      "exe_latency:3 seqnum:%lld src_ptag1:%d src_ptag2:-1 src_reg1:X%d src_reg2:none stid:%d\n",
      static_cast<long long>(uop_id), static_cast<long long>(c0 + 4), robid,
      static_cast<long long>(seq), src_ptag, xn, stid);
  out.print(
      "[%lld] [%lld] alloc_zlc(a) eport:17 issueq:0 sched:4294967295 zlc_latency:2\n",
      static_cast<long long>(uop_id), static_cast<long long>(c0 + 4));
  out.print("[%lld] [%lld] src_from_value_feedback(s) src_reg:X%d src_val:0x%llx\n",
            static_cast<long long>(uop_id), static_cast<long long>(c0 + 4), xn,
            static_cast<unsigned long long>(pa));
  out.print("[%lld] [%lld] write_dispq(d) eport:17 sched:17\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 4));
  out.print("[%lld] [%lld] dispatch(d) issueq:17 pipe:17\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 5));
  out.print("[%lld] [%lld] zlc_ex(Z)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 6));
  out.print("[%lld] [%lld] issue(i) issueq:17 pipe:17\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 7));
  out.print("[%lld] [%lld] issue_execute_sta(E) pipe:17 zlc_path:1\n",
            static_cast<long long>(uop_id), static_cast<long long>(c0 + 7));
  out.print("[%lld] [%lld] ready(r) src_ptag1:%d src_ptag2:-1 src_val1:0x%llx src_val2:0xdeadbeef\n",
            static_cast<long long>(uop_id), static_cast<long long>(c0 + 7), src_ptag,
            static_cast<unsigned long long>(pa));
  out.print("[%lld] [%lld] src_ready(r) src_num:0\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 7));
  out.print("[%lld] [%lld] zlc_fast_sta_dealloc_isq(F)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 7));
  out.print("[%lld] [%lld] TLB_lookup_sta_hit(h)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 8));
  out.print("[%lld] [%lld] deallocate_issq(d)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 8));
  out.print(
      "[%lld] [%lld] retire_uop(R) ROBID:%d dest_ptag1:~ dest_ptag2:~ dest_reg1:none "
      "dest_reg2:none\n",
      static_cast<long long>(uop_id), static_cast<long long>(retire_c), robid);
}

void write_branch_uop(Writer& out, std::int64_t uop_id, std::int64_t parent, std::int64_t inst_id,
                      std::uint64_t pc, std::uint64_t target, std::int64_t seq, int robid,
                      std::int64_t c0, std::int64_t retire_c) {
  out.print(
      "[%lld] type:Uop parent:%lld InstID:%lld PC:0x%llx disasm:\"BCOND  S: PS_NZCV  I: 0x%llx, "
      "0x8\" seqnum:%lld tid:0\n",
      static_cast<long long>(uop_id), static_cast<long long>(parent),
      static_cast<long long>(inst_id), static_cast<unsigned long long>(pc),
      static_cast<unsigned long long>(target), static_cast<long long>(seq));
  out.print("[%lld] [%lld] replicate_uop_from_Instr(1)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0));
  out.print("[%lld] [%lld] decode_uop(2)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 2));
  out.print(
      "[%lld] [%lld] alloc(A) ROBID:%d dest_ptag1:-1 dest_reg1:none exe_latency:1 seqnum:%lld "
      "src_ptag1:1536 src_ptag2:-1 src_reg1:PS_NZCV src_reg2:none\n",
      static_cast<long long>(uop_id), static_cast<long long>(c0 + 4), robid,
      static_cast<long long>(seq));
  out.print(
      "[%lld] [%lld] alloc_zlc(a) eport:-1 issueq:0 sched:4294967295 zlc_latency:2\n",
      static_cast<long long>(uop_id), static_cast<long long>(c0 + 4));
  out.print("[%lld] [%lld] src_from_value_feedback(s) src_reg:PS_NZCV src_val:0x20000000\n",
            static_cast<long long>(uop_id), static_cast<long long>(c0 + 4));
  out.print("[%lld] [%lld] zlc_ex(Z)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 6));
  out.print("[%lld] [%lld] branch_bcond_not_fused(n)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 7));
  out.print("[%lld] [%lld] branch_resolution(b) taken:1 target_VA:0x%llx\n",
            static_cast<long long>(uop_id), static_cast<long long>(c0 + 7),
            static_cast<unsigned long long>(target));
  out.print("[%lld] [%lld] zlc_wakeup(S)\n", static_cast<long long>(uop_id),
            static_cast<long long>(c0 + 9));
  out.print("[%lld] [%lld] release_robgroup(^)\n", static_cast<long long>(uop_id),
            static_cast<long long>(retire_c - 2));
  out.print(
      "[%lld] [%lld] retire_uop(R) ROBID:%d dest_ptag1:~ dest_ptag2:~ dest_reg1:none "
      "dest_reg2:none\n",
      static_cast<long long>(uop_id), static_cast<long long>(retire_c), robid);
}

const char* inst_disasm(UopKind kind, int n, char* buf, std::size_t nbuf) {
  switch (kind) {
    case UopKind::Addi:
      std::snprintf(buf, nbuf, "addi x%d, x%d, #16", n, n);
      break;
    case UopKind::Simd:
      std::snprintf(buf, nbuf, "uaddw  q%d, q%d, q20", n, n);
      break;
    case UopKind::Load:
      std::snprintf(buf, nbuf, "ldr q%d, [x%d]", n, n);
      break;
    case UopKind::Store:
      std::snprintf(buf, nbuf, "st1 {v%d.16b}, [x%d]", n, n);
      break;
    case UopKind::Branch:
      std::snprintf(buf, nbuf, "b.ne 0x8");
      break;
  }
  return buf;
}

}  // namespace

int main(int argc, char** argv) {
  const Options options = parse_args(argc, argv);
  FILE* file = std::fopen(options.output_path, "w");
  if (file == nullptr) {
    std::fprintf(stderr, "failed to open %s\n", options.output_path);
    return 1;
  }

  Writer out(file);
  const std::int64_t inst_count = options.instruction_count;
  const std::int64_t uop_count = options.uop_count;

  std::int64_t next_id = 0;
  std::int64_t fetch_id = -1;
  std::int64_t uops_emitted = 0;
  std::int64_t last_retire = 8500;
  std::int64_t seqnum = 0;
  const std::uint64_t base_pc = 0x5657c3da00ULL;
  const std::uint64_t base_pa = 0x565a87fd00ULL;

  for (std::int64_t i = 0; i < inst_count; ++i) {
    if (i % 8 == 0) {
      fetch_id = next_id++;
      out.print("[%lld] type:Fetch parent:-1\n", static_cast<long long>(fetch_id));
      const std::int64_t fetch2_id = next_id++;
      out.print("[%lld] type:Fetch2 parent:%lld\n", static_cast<long long>(fetch2_id),
                static_cast<long long>(fetch_id));
      const std::int64_t fc = 8400 + (i / 4);
      out.print("[%lld] [%lld] fetch_bundle(F) insts:8 PC:0x%llx\n",
                static_cast<long long>(fetch_id), static_cast<long long>(fc),
                static_cast<unsigned long long>(base_pc + static_cast<std::uint64_t>(i) * 4));
    }

    const std::int64_t inst_id = next_id++;
    const UopKind kind = kind_for(i);
    const int n = static_cast<int>(i % 31);
    const std::uint64_t pc = base_pc + static_cast<std::uint64_t>(i) * 4;
    const std::uint32_t opcode = 0x91004100u + static_cast<std::uint32_t>(i * 17);
    char disasm[80];
    inst_disasm(kind, n, disasm, sizeof(disasm));

    out.print(
        "[%lld] type:Instruction parent:%lld InstID:%lld PC:0x%llx disasm:\"%s\" opcode:0x%x "
        "seqnum:%lld tid:0\n",
        static_cast<long long>(inst_id), static_cast<long long>(fetch_id),
        static_cast<long long>(i), static_cast<unsigned long long>(pc), disasm, opcode,
        static_cast<long long>(seqnum));

    const std::int64_t fetch_c = 8400 + (i / 4);
    const std::int64_t decode_c = fetch_c + 13;
    const std::int64_t alloc_c = decode_c + 2;
    const int robid = static_cast<int>(i % 256);
    const int ptag = static_cast<int>((i * 7 + 100) % 1536);
    const int src_ptag = static_cast<int>((i * 3 + 50) % 1536);

    const bool emit_uop = uops_emitted < uop_count;
    std::int64_t retire_c = last_retire + 1;
    if (emit_uop) {
      const std::int64_t uop_id = next_id++;
      const std::int64_t exec_done = alloc_c + (kind == UopKind::Load ? 11 : 22);
      retire_c = exec_done + 70;
      if (retire_c <= last_retire) {
        retire_c = last_retire + 1;
      }
      last_retire = retire_c;

      switch (kind) {
        case UopKind::Addi:
          write_addi_uop(out, uop_id, inst_id, i, pc, seqnum, n, ptag, src_ptag, robid, alloc_c - 4,
                         retire_c, pc + 0x10);
          break;
        case UopKind::Simd:
          write_simd_uop(out, uop_id, inst_id, i, pc, seqnum, n, ptag, src_ptag,
                         (src_ptag + 17) % 1536, robid, alloc_c - 4, retire_c);
          break;
        case UopKind::Load:
          write_load_uop(out, uop_id, inst_id, pc, base_pa + static_cast<std::uint64_t>(i) * 16,
                         seqnum, n, n, ptag, src_ptag, robid, static_cast<int>(600 + (i % 4000)),
                         alloc_c - 4, retire_c);
          break;
        case UopKind::Store:
          write_store_uop(out, uop_id, inst_id, pc, base_pa + static_cast<std::uint64_t>(i) * 16,
                          seqnum, n, src_ptag, robid, static_cast<int>(500 + (i % 2000)),
                          alloc_c - 4, retire_c);
          break;
        case UopKind::Branch:
          write_branch_uop(out, uop_id, inst_id, i, pc, pc + 8, seqnum, robid, alloc_c - 4,
                           retire_c);
          break;
      }
      ++uops_emitted;
      ++seqnum;
    } else {
      last_retire = retire_c;
    }

    write_inst_events(out, inst_id, i, fetch_c, decode_c, retire_c + 6);
    ++seqnum;
  }

  // Remaining uops attach to the last instruction if instruction count < uop count.
  const std::int64_t last_inst = next_id - 1;
  while (uops_emitted < uop_count) {
    const std::int64_t uop_id = next_id++;
    const UopKind kind = kind_for(uops_emitted);
    const int n = static_cast<int>(uops_emitted % 31);
    const std::uint64_t pc = base_pc + static_cast<std::uint64_t>(uops_emitted) * 4;
    const std::int64_t c0 = 8400 + uops_emitted / 4;
    last_retire += 1;
    write_addi_uop(out, uop_id, last_inst, inst_count - 1, pc, seqnum++, n,
                   static_cast<int>((uops_emitted * 7) % 1536),
                   static_cast<int>((uops_emitted * 3) % 1536),
                   static_cast<int>(uops_emitted % 256), c0, last_retire, pc);
    (void)kind;
    ++uops_emitted;
  }

  out.flush();
  std::fclose(file);
  std::printf("generated %s instructions=%lld uops=%lld objects>=%lld\n", options.output_path,
              static_cast<long long>(inst_count), static_cast<long long>(uop_count),
              static_cast<long long>(next_id));
  return 0;
}
