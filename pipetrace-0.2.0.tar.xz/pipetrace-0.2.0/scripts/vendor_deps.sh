#!/usr/bin/env bash
# Populate third_party/ for offline builds. Run on a machine with network access,
# then commit third_party/ (or copy the repo) to air-gapped / low-bandwidth sites.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TP="$ROOT/third_party"

SQLITE_VERSION="3460100"
SQLITE_URL="https://www.sqlite.org/2024/sqlite-amalgamation-${SQLITE_VERSION}.zip"

GLFW_TAG="3.4"
IMGUI_TAG="v1.91.5"
IMPLOT_TAG="v0.16"
GTEST_TAG="v1.15.2"

clone_tag() {
  local name="$1" url="$2" tag="$3"
  local dest="$TP/$name"
  if [[ -f "$dest/.vendor-tag" ]] && grep -qx "$tag" "$dest/.vendor-tag" 2>/dev/null; then
    echo "  $name @ $tag (already vendored)"
    return
  fi
  echo "  $name @ $tag"
  rm -rf "$dest"
  git clone --depth 1 --branch "$tag" "$url" "$dest"
  rm -rf "$dest/.git"
  echo "$tag" > "$dest/.vendor-tag"
}

fetch_sqlite() {
  local dest="$TP/sqlite"
  if [[ -f "$dest/sqlite3.c" ]] && [[ -f "$dest/.vendor-tag" ]] && grep -qx "$SQLITE_VERSION" "$dest/.vendor-tag"; then
    echo "  sqlite @ $SQLITE_VERSION (already vendored)"
    return
  fi
  echo "  sqlite @ $SQLITE_VERSION"
  mkdir -p "$dest"
  local zip="$TP/.sqlite.zip"
  curl -fsSL "$SQLITE_URL" -o "$zip"
  rm -rf "$dest"/*
  unzip -qo "$zip" -d "$dest"
  if [[ -d "$dest/sqlite-amalgamation-${SQLITE_VERSION}" ]]; then
    mv "$dest/sqlite-amalgamation-${SQLITE_VERSION}"/* "$dest/"
    rmdir "$dest/sqlite-amalgamation-${SQLITE_VERSION}"
  fi
  rm -f "$zip"
  echo "$SQLITE_VERSION" > "$dest/.vendor-tag"
}

mkdir -p "$TP"
echo "Vendoring dependencies into $TP ..."

fetch_sqlite
clone_tag glfw https://github.com/glfw/glfw.git "$GLFW_TAG"
clone_tag imgui https://github.com/ocornut/imgui.git "$IMGUI_TAG"
clone_tag implot https://github.com/epezent/implot.git "$IMPLOT_TAG"
clone_tag googletest https://github.com/google/googletest.git "$GTEST_TAG"

rm -rf "$TP/sqlite_tmp" "$TP/.sqlite.zip"

# Drop upstream example prebuilts (Windows .lib/.dll/etc.); pipetrace builds from source.
find "$TP" -type f \( -name '*.lib' -o -name '*.exe' -o -name '*.dll' -o -name '*.dylib' \) -print -delete
# Empty MSVC lib dirs left under imgui examples
find "$TP" -type d \( -name 'lib-vc*' -o -name 'lib-vc2010-*' \) -empty -delete 2>/dev/null || true

echo ""
echo "Done. third_party/ is ready for offline builds."
echo "Commit third_party/ to git, or copy the full repo to the target machine."
du -sh "$TP"/* 2>/dev/null | sort -h
