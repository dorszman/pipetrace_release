#include "pipetrace/importer.hpp"

#include <filesystem>

#include "storage/sqlite_store.hpp"

namespace pipetrace {

TraceMeta import_ptj_trace(const std::string& input_path, const std::string& store_path) {
  std::filesystem::remove(store_path);
  SqliteStore store;
  if (!store.open(store_path)) {
    throw std::runtime_error("failed to create store: " + store_path);
  }
  return import_ptj_into_store(store, input_path);
}

}  // namespace pipetrace
