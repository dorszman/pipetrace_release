#include <iostream>
#include <string>

#include "pipetrace/linx_pt.hpp"

namespace {

pipetrace::LinxPtGenerateOptions parse_args(int argc, char** argv) {
  pipetrace::LinxPtGenerateOptions options;
  for (int i = 1; i < argc; ++i) {
    const std::string arg = argv[i];
    if (arg == "--output" && i + 1 < argc) {
      options.output_path = argv[++i];
    } else if (arg == "--objects" && i + 1 < argc) {
      options.object_count = std::stoll(argv[++i]);
    } else if (arg == "--events-per-object" && i + 1 < argc) {
      options.events_per_object = std::stoll(argv[++i]);
    } else if (arg == "--uops-per-instruction" && i + 1 < argc) {
      options.uops_per_instruction = std::stoll(argv[++i]);
    } else if (arg == "--cycle-span" && i + 1 < argc) {
      options.cycle_span = std::stoll(argv[++i]);
    } else if (arg == "--seed" && i + 1 < argc) {
      options.seed = std::stoll(argv[++i]);
    } else if (arg == "--flat") {
      options.include_tree = false;
    } else if (arg == "--partial-retire") {
      options.partial_retire = true;
    } else if (arg == "--help") {
      std::cout << "pipetrace-linx-synthgen --output PATH.pt [--objects N] [--events-per-object N] "
                   "[--uops-per-instruction N] [--cycle-span N] [--seed N] [--flat] "
                   "[--partial-retire]\n";
      std::cout << "  --partial-retire  skip retire_inst on inst_serial%3==2; skip retire_uop on "
                   "2nd uop per instruction\n";
      std::exit(0);
    } else {
      throw std::runtime_error("unknown argument: " + arg);
    }
  }
  if (options.output_path.empty()) {
    throw std::runtime_error("--output is required");
  }
  return options;
}

}  // namespace

int main(int argc, char** argv) {
  try {
    const pipetrace::LinxPtGenerateOptions options = parse_args(argc, argv);
    pipetrace::generate_linx_pt_trace(options);
    const std::int64_t instruction_count =
        options.include_tree
            ? (options.object_count + options.uops_per_instruction - 1) /
                  options.uops_per_instruction
            : 0;
    const std::int64_t total_objects =
        options.include_tree ? instruction_count + options.object_count : options.object_count;
    std::cout << "generated " << options.output_path << " uops=" << options.object_count
              << " instructions=" << instruction_count << " objects=" << total_objects
              << " events_per_uop=" << options.events_per_object;
    if (options.partial_retire) {
      std::cout << " partial_retire=1";
    }
    std::cout << '\n';
    return 0;
  } catch (const std::exception& ex) {
    std::cerr << "pipetrace-linx-synthgen error: " << ex.what() << '\n';
    return 1;
  }
}
