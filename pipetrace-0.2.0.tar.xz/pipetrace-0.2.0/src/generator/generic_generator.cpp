#include "pipetrace/generator.hpp"

namespace pipetrace {

// Generic generator implementation lives in cpu_pipeline_generator.cpp for v0.1.

}  // namespace pipetrace
