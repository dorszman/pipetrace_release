#include "pipetrace/generator.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

#include "pipetrace/importer.hpp"

namespace pipetrace {
namespace {

class XorShift64 {
 public:
  explicit XorShift64(std::uint64_t seed) : state_(seed ? seed : 1) {}
  std::uint64_t next() {
    std::uint64_t x = state_;
    x ^= x << 13;
    x ^= x >> 7;
    x ^= x << 17;
    state_ = x;
    return x;
  }
  std::int64_t range(std::int64_t lo, std::int64_t hi) {
    return lo + static_cast<std::int64_t>(next() % static_cast<std::uint64_t>(hi - lo + 1));
  }

 private:
  std::uint64_t state_;
};

void write_ptj_header(std::ofstream& out, const std::string& trace_name) {
  out << "{\"type\":\"meta\",\"version\":1,\"name\":\"" << trace_name << "\"}\n";
}

void write_event(std::ofstream& out, ObjectId object_id, const char* kind, Timestamp time,
                 Timestamp& min_time, Timestamp& max_time, std::int64_t& event_count,
                 const std::string& attrs_json = "{}") {
  out << "{\"type\":\"event\",\"object_id\":" << object_id << ",\"kind\":\"" << kind
      << "\",\"time\":" << time;
  if (!attrs_json.empty() && attrs_json != "{}") {
    out << ",\"attrs\":" << attrs_json;
  }
  out << "}\n";
  min_time = std::min(min_time, time);
  max_time = std::max(max_time, time);
  ++event_count;
}

TraceMeta generate_to_ptj(const GeneratorConfig& config,
                          const std::string& output_path,
                          const char* object_type,
                          const char* display_name,
                          const std::vector<const char*>& event_kinds,
                          const std::vector<char>& event_chars,
                          const std::vector<std::uint32_t>& colors) {
  std::filesystem::create_directories(std::filesystem::path(output_path).parent_path());
  std::ofstream out(output_path, std::ios::trunc);
  if (!out) {
    throw std::runtime_error("failed to open trace output: " + output_path);
  }

  write_ptj_header(out, std::filesystem::path(output_path).stem().string());
  out << "{\"type\":\"object_type\",\"name\":\"" << object_type << "\",\"display\":\""
      << display_name << "\"}\n";

  for (std::size_t i = 0; i < event_kinds.size(); ++i) {
    out << "{\"type\":\"event_type\",\"name\":\"" << event_kinds[i] << "\",\"object_type\":\""
        << object_type << "\",\"color\":" << colors[i] << ",\"char\":\""
        << (event_chars.size() > i ? event_chars[i] : '?') << "\"}\n";
  }

  Timestamp min_time = std::numeric_limits<Timestamp>::max();
  Timestamp max_time = std::numeric_limits<Timestamp>::min();
  std::int64_t event_count = 0;

  const std::size_t stage_count = event_kinds.size();
  const Timestamp max_start_cycle =
      config.time_span > stage_count ? config.time_span - (stage_count - 1) : 0;
  const std::int64_t object_count =
      std::min(config.object_count, static_cast<std::int64_t>(max_start_cycle) + 1);

  for (std::int64_t obj = 0; obj < object_count; ++obj) {
    const Timestamp start_cycle = static_cast<Timestamp>(obj);
    std::vector<Timestamp> stage_times;
    stage_times.reserve(stage_count);

    for (std::size_t stage = 0; stage < stage_count; ++stage) {
      stage_times.push_back(start_cycle + static_cast<Timestamp>(stage));
    }

    const Timestamp first = stage_times.front();
    const Timestamp last = stage_times.back();

    out << "{\"type\":\"object\",\"id\":" << (obj + 1) << ",\"object_type\":\"" << object_type
        << "\",\"name\":\"" << object_type << '_' << obj << "\",\"first_time\":" << first
        << ",\"last_time\":" << last << ",\"attrs\":{\"inst_id\":" << obj << ",\"asm\":\"nop\","
        << "\"task_index\":" << obj << ",\"lane\":" << (obj % 4) << ",\"priority\":" << (obj % 3)
        << "}}\n";

    for (std::size_t stage = 0; stage < event_kinds.size(); ++stage) {
      std::string attrs_json = "{}";
      if (std::string(event_kinds[stage]) == "work") {
        attrs_json = "{\"units\":" + std::to_string((obj % 5) + 1) +
                     ",\"phase\":\"compute\",\"batch\":" + std::to_string(obj % 8) + "}";
      }
      write_event(out, obj + 1, event_kinds[stage], stage_times[stage], min_time, max_time,
                  event_count, attrs_json);
    }
  }

  out.close();

  const std::string store_path = output_path + ".db";
  return import_ptj_trace(output_path, store_path);
}

struct GeneratedEventType {
  std::string name;
  char display_char{'?'};
  std::uint32_t color_rgba{0xFF888888};
};

std::uint32_t hsv_color_rgba(float hue, float saturation, float value) {
  const float chroma = value * saturation;
  const float hue_sector = hue * 6.0f;
  const float x = chroma * (1.0f - std::fabs(std::fmod(hue_sector, 2.0f) - 1.0f));
  float red = 0.0f;
  float green = 0.0f;
  float blue = 0.0f;
  switch (static_cast<int>(hue_sector)) {
    case 0:
      red = chroma;
      green = x;
      break;
    case 1:
      red = x;
      green = chroma;
      break;
    case 2:
      green = chroma;
      blue = x;
      break;
    case 3:
      green = x;
      blue = chroma;
      break;
    case 4:
      red = x;
      blue = chroma;
      break;
    default:
      red = chroma;
      blue = x;
      break;
  }
  const float offset = value - chroma;
  red += offset;
  green += offset;
  blue += offset;
  const auto channel = [](float c) {
    return static_cast<std::uint32_t>(std::clamp(c, 0.0f, 1.0f) * 255.0f + 0.5f);
  };
  return 0xFF000000U | (channel(blue) << 16U) | (channel(green) << 8U) | channel(red);
}

char rare_display_char(std::size_t index) {
  static constexpr char kPool[] =
      "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  return kPool[index % (sizeof(kPool) - 1U)];
}

std::vector<GeneratedEventType> build_rare_event_catalog() {
  static constexpr std::array<const char*, 20> kBases = {
      "tlb",    "icache", "dcache", "l2",      "l3",     "branch", "fetch", "decode",
      "rename", "dispatch", "issue", "execute", "retire", "prf",    "rob",   "rs",
      "lq",     "sq",     "bp",     "mem"};
  static constexpr std::array<const char*, 5> kEvents = {"miss",  "stall", "replay",
                                                         "fault", "retry"};

  std::vector<GeneratedEventType> catalog;
  catalog.reserve(kBases.size() * kEvents.size());
  std::size_t index = 0;
  for (const char* base : kBases) {
    for (const char* event : kEvents) {
      GeneratedEventType type;
      type.name = std::string(base) + '_' + event;
      type.display_char = rare_display_char(index);
      type.color_rgba = hsv_color_rgba(static_cast<float>(index) * 0.137f, 0.55f, 0.88f);
      catalog.push_back(std::move(type));
      ++index;
    }
  }
  return catalog;
}

void write_event_type(std::ofstream& out, const GeneratedEventType& event_type,
                      const char* object_type) {
  out << "{\"type\":\"event_type\",\"name\":\"" << event_type.name << "\",\"object_type\":\""
      << object_type << "\",\"color\":" << event_type.color_rgba << ",\"char\":\""
      << event_type.display_char << "\"}\n";
}

std::int64_t clamp_decode_width(std::int64_t decode_width) {
  return std::clamp(decode_width, std::int64_t{1}, std::int64_t{32});
}

Timestamp decode_cycle_for_uop(std::int64_t uop_index, std::int64_t decode_width) {
  return static_cast<Timestamp>(uop_index / decode_width);
}

std::int64_t max_uop_count(Timestamp time_span, std::size_t stage_count,
                           std::int64_t decode_width) {
  if (stage_count == 0 || decode_width <= 0) {
    return 0;
  }
  const Timestamp max_decode_cycle =
      time_span > stage_count ? time_span - static_cast<Timestamp>(stage_count - 1) : 0;
  return (static_cast<std::int64_t>(max_decode_cycle) + 1) * decode_width;
}

TraceMeta generate_cpu_pipeline_to_ptj(const CpuPipelineConfig& config,
                                       const std::string& output_path,
                                       const std::vector<const char*>& stages,
                                       const std::vector<char>& stage_chars,
                                       const std::vector<std::uint32_t>& stage_colors) {
  static const std::vector<GeneratedEventType> kCommonOverlays = {
      {"cancel", 'C', 0xFFD32F2F},
      {"stall", '!', 0xFF757575},
  };
  const std::vector<GeneratedEventType> rare_event_types = build_rare_event_catalog();

  std::filesystem::create_directories(std::filesystem::path(output_path).parent_path());
  std::ofstream out(output_path, std::ios::trunc);
  if (!out) {
    throw std::runtime_error("failed to open trace output: " + output_path);
  }

  write_ptj_header(out, std::filesystem::path(output_path).stem().string());
  out << "{\"type\":\"object_type\",\"name\":\"uop\",\"display\":\"Micro-op\"}\n";

  for (std::size_t i = 0; i < stages.size(); ++i) {
    GeneratedEventType stage_type;
    stage_type.name = stages[i];
    stage_type.display_char = stage_chars[i];
    stage_type.color_rgba = stage_colors[i];
    write_event_type(out, stage_type, "uop");
  }
  for (const GeneratedEventType& overlay : kCommonOverlays) {
    write_event_type(out, overlay, "uop");
  }
  for (const GeneratedEventType& rare_type : rare_event_types) {
    write_event_type(out, rare_type, "uop");
  }

  XorShift64 rng(config.seed);
  Timestamp min_time = std::numeric_limits<Timestamp>::max();
  Timestamp max_time = std::numeric_limits<Timestamp>::min();
  std::int64_t event_count = 0;

  const std::size_t stage_count = stages.size();
  const std::int64_t decode_width = clamp_decode_width(config.decode_width);
  const std::int64_t object_count =
      std::min(config.object_count, max_uop_count(config.time_span, stage_count, decode_width));

constexpr std::int64_t kCancelDenom = 3;
  constexpr std::int64_t kStallDenom = 4;
  constexpr std::int64_t kRareDenom = 24;

  static const char* kAsmSnippets[] = {
      "add x0, x1, x2",
      "sub x3, x4, x5",
      "mul x6, x7, x8",
      "ldr x9, [x10]",
      "str x11, [x12]",
      "b.eq .L0",
      "bl _helper",
      "madd x13, x14, x15, x16",
      "and x17, x18, #0xff",
      "orr x19, x20, x21",
  };
  constexpr std::size_t kAsmSnippetCount =
      sizeof(kAsmSnippets) / sizeof(kAsmSnippets[0]);

  for (std::int64_t obj = 0; obj < object_count; ++obj) {
    const ObjectId object_id = obj + 1;
    const Timestamp decode_cycle = decode_cycle_for_uop(obj, decode_width);
    const std::int64_t slot = obj % decode_width;
    std::vector<Timestamp> stage_times;
    stage_times.reserve(stage_count);

    for (std::size_t stage = 0; stage < stage_count; ++stage) {
      stage_times.push_back(decode_cycle + static_cast<Timestamp>(stage));
    }

    out << "{\"type\":\"object\",\"id\":" << object_id << ",\"object_type\":\"uop\",\"name\":\"uop_"
        << obj << "_s" << slot << "\",\"first_time\":" << stage_times.front()
        << ",\"last_time\":" << stage_times.back() << ",\"attrs\":{\"inst_id\":" << obj
        << ",\"asm\":\"" << kAsmSnippets[static_cast<std::size_t>(obj % kAsmSnippetCount)]
        << "\",\"uop_index\":" << obj << ",\"slot\":" << slot << ",\"decode_cycle\":"
        << decode_cycle << ",\"decode_width\":" << decode_width << "}}\n";

    for (std::size_t stage = 0; stage < stage_count; ++stage) {
      write_event(out, object_id, stages[stage], stage_times[stage], min_time, max_time,
                  event_count);
    }

    if (stage_count > 0) {
      const std::size_t cancel_stage = static_cast<std::size_t>(rng.range(0, stage_count - 1));
      const std::size_t stall_stage = static_cast<std::size_t>(rng.range(0, stage_count - 1));

      if (rng.range(0, kCancelDenom - 1) == 0) {
        const std::int64_t latency = rng.range(1, 4);
        write_event(out, object_id, "cancel", stage_times[cancel_stage], min_time, max_time,
                    event_count,
                    "{\"reason\":\"branch_mispredict\",\"latency\":" +
                        std::to_string(latency) + "}");
      }
      if (rng.range(0, kStallDenom - 1) == 0) {
        const std::int64_t cycles = rng.range(1, 3);
        const char* unit = cycles % 2 == 0 ? "fpu" : "alu";
        write_event(out, object_id, "stall", stage_times[stall_stage], min_time, max_time,
                    event_count,
                    std::string("{\"stall_cycles\":") + std::to_string(cycles) +
                        ",\"unit\":\"" + unit + "\"}");
      }

      for (const GeneratedEventType& rare_type : rare_event_types) {
        if (rng.range(0, kRareDenom - 1) != 0) {
          continue;
        }
        const std::size_t rare_stage = static_cast<std::size_t>(rng.range(0, stage_count - 1));
        write_event(out, object_id, rare_type.name.c_str(), stage_times[rare_stage], min_time,
                    max_time, event_count,
                    "{\"severity\":\"high\",\"code\":" + std::to_string(rng.range(1, 999)) + "}");
      }
    }
  }

  out.close();
  return import_ptj_trace(output_path, output_path + ".db");
}

}  // namespace

TraceMeta generate_cpu_pipeline_trace(const CpuPipelineConfig& config,
                                      const std::string& output_path) {
  static const std::vector<const char*> stages = {"decode", "rename",  "dispatch",
                                                  "issue",  "execute", "retire"};
  static const std::vector<std::uint32_t> colors = {
      0xFF4CAF50, 0xFF2196F3, 0xFFFF9800, 0xFF9C27B0, 0xFFE91E63, 0xFF607D8B};
  static const std::vector<char> chars = {'D', 'R', 'A', 'I', 'E', 'T'};

  const std::size_t stage_count =
      static_cast<std::size_t>(std::clamp(config.stages, std::int64_t{1}, std::int64_t{6}));
  const std::vector<const char*> use_stages(stages.begin(), stages.begin() + stage_count);
  const std::vector<char> use_chars(chars.begin(), chars.begin() + stage_count);
  const std::vector<std::uint32_t> use_colors(colors.begin(), colors.begin() + stage_count);

  return generate_cpu_pipeline_to_ptj(config, output_path, use_stages, use_chars, use_colors);
}

TraceMeta generate_generic_trace(const GeneratorConfig& config,
                                 const std::string& output_path) {
  static const std::vector<const char*> kinds = {"start", "work", "wait", "finish"};
  static const std::vector<std::uint32_t> colors = {0xFF00BCD4, 0xFF8BC34A, 0xFFFFC107,
                                                    0xFF795548};
  static const std::vector<char> chars = {'S', 'W', 'A', 'F'};
  return generate_to_ptj(config, output_path, "task", "Task", kinds, chars, colors);
}

}  // namespace pipetrace
