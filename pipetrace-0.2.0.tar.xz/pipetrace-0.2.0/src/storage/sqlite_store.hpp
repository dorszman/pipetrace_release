#pragma once

#include <functional>
#include <optional>
#include <string>
#include <unordered_map>
#include <vector>

#include "pipetrace/app_config.hpp"
#include "pipetrace/columnar.hpp"
#include "pipetrace/types.hpp"

struct sqlite3;
struct sqlite3_stmt;

namespace pipetrace {

class SqliteStore;

struct AttributeSearchMatch;

TraceMeta import_ptj_into_store(SqliteStore& store, const std::string& input_path);

class SqliteStore {
 public:
  SqliteStore();
  ~SqliteStore();

  SqliteStore(const SqliteStore&) = delete;
  SqliteStore& operator=(const SqliteStore&) = delete;

  bool open(const std::string& path);
  void close();

  TraceMeta meta() const;
  std::vector<ObjectType> object_types() const;
  std::vector<EventType> event_types() const;

  ColumnarObjects query_objects(const Viewport& viewport, std::int64_t prefetch_rows = 8,
                                const SortScheme* sort_scheme = nullptr);
  ColumnarEvents query_events(const Viewport& viewport,
                              const std::vector<ObjectId>& object_ids);

  std::vector<CycleOccurrenceCount> query_event_cycle_counts(
      std::int64_t event_type_id, Timestamp time_start, Timestamp time_end) const;

  std::optional<TraceObject> find_object(ObjectId id) const;

  std::optional<ObjectId> object_id_for_row(std::int64_t row,
                                            const SortScheme* sort_scheme = nullptr) const;
  std::optional<std::int64_t> object_row_index(ObjectId id,
                                               const SortScheme* sort_scheme = nullptr) const;
  std::unordered_map<std::string, std::int64_t> build_attribute_row_index(
      const std::string& attribute_key) const;
  std::optional<AttributeSearchMatch> find_first_object_by_attribute(
      const std::string& attribute_key, const std::string& prefix,
      const SortScheme* sort_scheme = nullptr) const;

  void exec_sql(const char* sql);
  void set_meta(const std::string& name, Timestamp min_time, Timestamp max_time,
                std::int64_t object_count, std::int64_t event_count);
  std::optional<std::string> meta_value(const std::string& key) const;
  void set_meta_value(const std::string& key, const std::string& value);
  void insert_object_type(std::int64_t id, const std::string& name,
                            const std::string& display_name);
  void insert_event_type(std::int64_t id, const std::string& name, std::int64_t object_type_id,
                         std::uint32_t color_rgba);
  void insert_event_type_display(std::int64_t event_type_id, char display_char,
                                 std::uint32_t color_rgba);
  void update_event_type_color(std::int64_t event_type_id, std::uint32_t color_rgba);
  void insert_object(ObjectId id, std::int64_t object_type_id, const std::string& name,
                     Timestamp first_time, Timestamp last_time, ObjectId parent_id = -1,
                     const std::string& attributes_json = "{}");
  void insert_event(EventId id, ObjectId object_id, std::int64_t event_type_id,
                    const std::string& kind, Timestamp time,
                    const std::string& attributes_json = "{}");

  void begin_immediate_transaction();
  void commit_transaction();
  void rollback_transaction();

  void copy_database_file(const std::string& dest_path) const;

  void for_each_event_by_kind(
      const std::string& kind,
      const std::function<void(EventId event_id, ObjectId object_id,
                               const char* attributes_json)>& callback) const;

  void for_each_object(
      const std::function<void(ObjectId id, ObjectId parent_id,
                               const char* attributes_json)>& callback) const;

  void ensure_analysis_indexes();

  struct InstIdPromotionRow {
    ObjectId object_id{};
    ObjectId parent_id{-1};
    const char* object_attributes_json{nullptr};
    const char* retire_event_attributes_json{nullptr};
    std::int64_t retire_event_count{0};
  };

  void for_each_instruction_instid_promotion(
      const std::function<void(const InstIdPromotionRow&)>& callback) const;

  void for_each_uop_instid_promotion(
      const std::function<void(const InstIdPromotionRow&)>& callback) const;

  struct UopRetireUopRow {
    ObjectId object_id{};
    const char* object_attributes_json{nullptr};
    const char* inst_id{nullptr};
    Timestamp retire_uop_cycle{0};
  };

  void for_each_uop_with_retire_uop(
      const std::function<void(const UopRetireUopRow&)>& callback) const;

  struct UopPcPromotionRow {
    ObjectId object_id{};
    ObjectId parent_id{-1};
    const char* object_attributes_json{nullptr};
    const char* parent_pc{nullptr};
  };

  void for_each_uop_pc_promotion(
      const std::function<void(const UopPcPromotionRow&)>& callback) const;

  struct UopInstIdPcRow {
    ObjectId object_id{};
    const char* object_attributes_json{nullptr};
    const char* inst_id{nullptr};
    const char* pc{nullptr};
    const char* retire_pushup{nullptr};
  };

  void for_each_uop_with_instid_and_pc(
      const std::function<void(const UopInstIdPcRow&)>& callback) const;

  struct UopInstIdPushupRow {
    ObjectId object_id{};
    const char* object_attributes_json{nullptr};
    const char* inst_id{nullptr};
    const char* retire_pushup{nullptr};
  };

  void for_each_uop_with_instid(
      const std::function<void(const UopInstIdPushupRow&)>& callback) const;

  void update_object_attributes(ObjectId id, const std::string& attributes_json);

  void refresh_object_attribute_keys();
  std::vector<std::string> object_attribute_keys() const;

  void ensure_object_sort_rank_table();
  bool has_object_sort_ranks(const std::string& scheme_name) const;
  /// Rebuild dense ranks for the given schemes. Skips when fingerprint matches and
  /// all schemes already have ranks, unless force is true. Returns schemes rebuilt.
  std::size_t materialize_object_sort_ranks(const std::vector<SortScheme>& schemes,
                                           bool force = false);
  /// Rebuild only the listed schemes (always). Used after dual analyze for Dual* keys.
  std::size_t rebuild_object_sort_ranks(const std::vector<SortScheme>& schemes);
  std::optional<std::string> object_sort_ranks_fingerprint() const;

 private:
  struct ObjectIdLayout {
    ObjectId min_id{};
    ObjectId max_id{};
    std::int64_t count{};
    bool contiguous{};
  };

  void initialize_schema();
  void migrate_schema();
  void invalidate_object_id_layout();
  const ObjectIdLayout& object_id_layout() const;
  void rebuild_one_object_sort_rank(const SortScheme& scheme);
  bool object_sort_ranks_complete(const std::vector<SortScheme>& schemes) const;

  sqlite3* db_{nullptr};
  std::string path_;
  mutable std::optional<ObjectIdLayout> object_id_layout_;
  mutable std::optional<std::unordered_map<std::string, bool>> object_sort_rank_schemes_;
};

}  // namespace pipetrace
