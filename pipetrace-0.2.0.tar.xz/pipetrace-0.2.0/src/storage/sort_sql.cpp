#include "pipetrace/sort_sql.hpp"

#include <cctype>
#include <sstream>
#include <stdexcept>

namespace pipetrace {
namespace {

std::string sql_escape_json_path_key(const std::string& key) {
  std::string escaped;
  escaped.reserve(key.size() + 4);
  for (const char ch : key) {
    if (ch == '"') {
      escaped += "\\\"";
    } else {
      escaped.push_back(ch);
    }
  }
  return escaped;
}

std::string nibble_case_expr(const std::string& char_expr) {
  std::ostringstream out;
  out << "(CASE lower(" << char_expr << ") "
      << "WHEN '0' THEN 0 WHEN '1' THEN 1 WHEN '2' THEN 2 WHEN '3' THEN 3 "
      << "WHEN '4' THEN 4 WHEN '5' THEN 5 WHEN '6' THEN 6 WHEN '7' THEN 7 "
      << "WHEN '8' THEN 8 WHEN '9' THEN 9 WHEN 'a' THEN 10 WHEN 'b' THEN 11 "
      << "WHEN 'c' THEN 12 WHEN 'd' THEN 13 WHEN 'e' THEN 14 WHEN 'f' THEN 15 "
      << "ELSE NULL END)";
  return out.str();
}

std::string hex_to_integer_sql(const std::string& raw_expr) {
  std::ostringstream out;
  out << "(CASE WHEN " << raw_expr << " GLOB '0[xX][0-9A-Fa-f]*' "
      << "AND length(" << raw_expr << ") > 2 THEN ";
  out << "(0";
  for (int digit = 0; digit < 16; ++digit) {
    const int pos = 3 + digit;
    out << " + (CASE WHEN length(" << raw_expr << ") > " << (pos - 1) << " THEN "
        << nibble_case_expr("substr(" + raw_expr + ", " + std::to_string(pos) + ", 1)")
        << " * CAST(1 AS INTEGER) << (" << (15 - digit) * 4 << ") ELSE 0 END)";
  }
  out << ") ELSE NULL END)";
  return out.str();
}

std::string type_rank_sql(const std::string& raw_expr) {
  std::ostringstream out;
  out << "(CASE "
      << "WHEN " << raw_expr << " IS NULL OR trim(COALESCE(" << raw_expr << ", '')) = '' THEN 4 "
      << "WHEN " << raw_expr << " GLOB '0[xX][0-9A-Fa-f]*' THEN 0 "
      << "WHEN (" << raw_expr << " GLOB '*[0-9]*' AND " << raw_expr << " GLOB '*.*' "
      << "AND " << raw_expr << " NOT GLOB '0[xX]*' "
      << "AND " << raw_expr << " NOT GLOB '*[^0-9.+-eE]*') THEN 2 "
      << "WHEN (" << raw_expr << " GLOB '[0-9]*' OR " << raw_expr << " GLOB '-[0-9]*') "
      << "AND " << raw_expr << " NOT GLOB '*[^0-9-]*' THEN 1 "
      << "ELSE 3 END)";
  return out.str();
}

std::string typed_value_sql(const std::string& raw_expr) {
  const std::string hex = hex_to_integer_sql(raw_expr);
  std::ostringstream out;
  out << "(CASE "
      << "WHEN " << raw_expr << " IS NULL OR trim(COALESCE(" << raw_expr << ", '')) = '' THEN NULL "
      << "WHEN " << raw_expr << " GLOB '0[xX][0-9A-Fa-f]*' THEN " << hex << " "
      << "WHEN (" << raw_expr << " GLOB '*[0-9]*' AND " << raw_expr << " GLOB '*.*' "
      << "AND " << raw_expr << " NOT GLOB '0[xX]*' "
      << "AND " << raw_expr << " NOT GLOB '*[^0-9.+-eE]*') THEN CAST(" << raw_expr << " AS REAL) "
      << "WHEN (" << raw_expr << " GLOB '[0-9]*' OR " << raw_expr << " GLOB '-[0-9]*') "
      << "AND " << raw_expr << " NOT GLOB '*[^0-9-]*' THEN CAST(" << raw_expr << " AS INTEGER) "
      << "ELSE lower(" << raw_expr << ") END)";
  return out.str();
}

std::string missing_flag_sql(const std::string& raw_expr) {
  return "(CASE WHEN " + raw_expr + " IS NULL OR trim(COALESCE(" + raw_expr +
         ", '')) = '' THEN 1 ELSE 0 END)";
}

}  // namespace

bool is_valid_attribute_sort_key(const std::string& key) {
  if (key.empty()) {
    return false;
  }
  for (const char ch : key) {
    if (!(std::isalnum(static_cast<unsigned char>(ch)) || ch == '_')) {
      return false;
    }
  }
  return true;
}

std::string build_attribute_sort_key_sql(const std::string& attribute_key, const bool ascending) {
  if (!is_valid_attribute_sort_key(attribute_key)) {
    throw std::runtime_error("invalid attribute sort key: " + attribute_key);
  }
  const std::string path = "'$." + sql_escape_json_path_key(attribute_key) + "'";
  const std::string raw = "json_extract(attributes, " + path + ")";
  const std::string missing = missing_flag_sql(raw);
  const std::string type_rank = type_rank_sql(raw);
  const std::string value = typed_value_sql(raw);

  const char* value_dir = ascending ? "ASC" : "DESC";
  // Missing values always sort last regardless of column direction.
  std::ostringstream out;
  out << missing << " ASC, " << type_rank << " ASC, " << value << " " << value_dir;
  return out.str();
}

std::string build_object_sort_order_by_clause(const SortScheme& scheme) {
  if (scheme.columns.empty()) {
    return "id";
  }

  std::ostringstream out;
  for (std::size_t i = 0; i < scheme.columns.size(); ++i) {
    const SortColumn& column = scheme.columns[i];
    const bool ascending = column.order != "desc";
    if (i > 0) {
      out << ", ";
    }
    out << build_attribute_sort_key_sql(column.key, ascending);
  }
  out << ", id";
  return out.str();
}

std::string build_sort_schemes_fingerprint(const std::vector<SortScheme>& schemes) {
  std::ostringstream out;
  for (std::size_t i = 0; i < schemes.size(); ++i) {
    if (i > 0) {
      out << '|';
    }
    const SortScheme& scheme = schemes[i];
    out << scheme.name << '{';
    for (std::size_t c = 0; c < scheme.columns.size(); ++c) {
      if (c > 0) {
        out << ',';
      }
      const SortColumn& column = scheme.columns[c];
      const std::string order = column.order == "desc" ? "desc" : "asc";
      out << column.key << ':' << order;
    }
    out << '}';
  }
  return out.str();
}

bool sort_scheme_references_dual_keys(const SortScheme& scheme) {
  for (const SortColumn& column : scheme.columns) {
    if (column.key.size() >= 4 && column.key.compare(0, 4, "Dual") == 0) {
      return true;
    }
  }
  return false;
}

}  // namespace pipetrace
