#include "pipetrace/progress.hpp"

#include <cstdio>
#include <iostream>
#include <stdexcept>

namespace pipetrace {
namespace {

std::string escape_status_token(std::string value) {
  for (char& ch : value) {
    if (ch == ' ' || ch == '\t' || ch == '\n' || ch == '\r') {
      ch = '_';
    }
  }
  return value;
}

}  // namespace

StatusMode parse_status_mode(const std::string& text) {
  if (text == "pretty") {
    return StatusMode::Pretty;
  }
  if (text == "plain") {
    return StatusMode::Plain;
  }
  throw std::runtime_error("status mode must be 'pretty' or 'plain'");
}

std::string status_mode_to_string(StatusMode mode) {
  return mode == StatusMode::Pretty ? "pretty" : "plain";
}

std::string format_status_plain(const StatusSnapshot& snapshot) {
  std::string line = "STATUS";
  if (!snapshot.tool.empty()) {
    line += " tool=";
    line += escape_status_token(snapshot.tool);
  }
  if (!snapshot.phase.empty()) {
    line += " phase=";
    line += escape_status_token(snapshot.phase);
  }
  line += " done=";
  line += std::to_string(snapshot.done);
  line += " total=";
  line += std::to_string(snapshot.total);
  if (!snapshot.msg.empty()) {
    line += " msg=";
    line += escape_status_token(snapshot.msg);
  }
  if (!snapshot.outcome.empty()) {
    line += " outcome=";
    line += escape_status_token(snapshot.outcome);
  }
  return line;
}

ProgressReporter::ProgressReporter(std::string tool_name, StatusMode mode, std::string log_path)
    : tool_(std::move(tool_name)), mode_(mode), log_path_(std::move(log_path)) {
  snapshot_.tool = tool_;
  if (!log_path_.empty()) {
    log_file_.open(log_path_, std::ios::out | std::ios::app);
    if (!log_file_) {
      throw std::runtime_error("failed to open progress log: " + log_path_);
    }
    write_log_line("=== " + tool_ + " log start ===");
    if (mode_ == StatusMode::Pretty) {
      std::cerr << tool_ << ": writing verbose log to " << log_path_ << '\n';
    }
  }
  last_emit_ = std::chrono::steady_clock::now() - kMinEmitInterval;
}

ProgressReporter::~ProgressReporter() {
  if (!finished_ && pretty_line_open_) {
    std::fputc('\n', stdout);
    std::fflush(stdout);
    pretty_line_open_ = false;
  }
}

void ProgressReporter::set_phase(std::string phase, std::string msg) {
  std::lock_guard<std::mutex> lock(mutex_);
  snapshot_.phase = std::move(phase);
  if (!msg.empty()) {
    snapshot_.msg = std::move(msg);
  }
  snapshot_.outcome.clear();
  emit(true);
  // Allow an immediate set_counts() after a phase change without waiting 100ms.
  last_emit_ = std::chrono::steady_clock::now() - kMinEmitInterval;
}

void ProgressReporter::set_counts(std::uint64_t done, std::uint64_t total, std::string msg) {
  std::lock_guard<std::mutex> lock(mutex_);
  snapshot_.done = done;
  snapshot_.total = total;
  if (!msg.empty()) {
    snapshot_.msg = std::move(msg);
  }
  emit(false);
}

void ProgressReporter::warn(const std::string& message) {
  std::lock_guard<std::mutex> lock(mutex_);
  write_log_line("WARN " + message);
  if (pretty_line_open_) {
    std::fputc('\n', stdout);
    pretty_line_open_ = false;
  }
  std::cerr << "WARN: " << message << '\n';
}

void ProgressReporter::log(const std::string& message) {
  std::lock_guard<std::mutex> lock(mutex_);
  write_log_line(message);
}

void ProgressReporter::finish(const std::string& outcome, const std::string& message) {
  std::lock_guard<std::mutex> lock(mutex_);
  snapshot_.outcome = outcome;
  if (!message.empty()) {
    snapshot_.msg = message;
  }
  emit(true);
  finished_ = true;
  write_log_line("=== " + tool_ + " finished outcome=" + outcome + " ===");
}

void ProgressReporter::emit(bool force) {
  const auto now = std::chrono::steady_clock::now();
  if (!force && (now - last_emit_) < kMinEmitInterval) {
    return;
  }
  last_emit_ = now;
  const std::string body = format_status_plain(snapshot_);
  write_log_line(body);
  write_stdout(body, force || !snapshot_.outcome.empty());
}

void ProgressReporter::write_stdout(const std::string& body, bool final_line) {
  if (mode_ == StatusMode::Plain) {
    std::fputs(body.c_str(), stdout);
    std::fputc('\n', stdout);
    std::fflush(stdout);
    pretty_line_open_ = false;
    return;
  }

  // Pretty: decorate the same body (color + single-line update), do not rebuild the facts.
  constexpr const char* kReset = "\033[0m";
  constexpr const char* kCyan = "\033[36m";
  constexpr const char* kGreen = "\033[32m";
  std::string decorated = std::string(kCyan) + body + kReset;
  if (!snapshot_.outcome.empty()) {
    decorated = std::string(kGreen) + body + kReset;
  }

  if (final_line) {
    if (pretty_line_open_) {
      std::fputc('\n', stdout);
      pretty_line_open_ = false;
    }
    std::fputs(decorated.c_str(), stdout);
    std::fputc('\n', stdout);
    std::fflush(stdout);
    return;
  }

  std::fputc('\r', stdout);
  std::fputs(decorated.c_str(), stdout);
  std::fputs("\033[K", stdout);
  std::fflush(stdout);
  pretty_line_open_ = true;
}

void ProgressReporter::write_log_line(const std::string& line) {
  if (!log_file_) {
    return;
  }
  log_file_ << line << '\n';
  log_file_.flush();
}

}  // namespace pipetrace
