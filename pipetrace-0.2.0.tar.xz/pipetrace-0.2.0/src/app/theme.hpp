#pragma once

#include "imgui.h"

namespace pipetrace {

enum class ColorScheme { Night, Day, Gay };

struct MarkerBandColors {
  ImU32 pinned_band{};
  ImU32 pinned_cross{};
  ImU32 active_band{};
  ImU32 active_cross{};
};

struct ViewerTheme {
  ImU32 grid_background{};
  ImU32 cell_fill{};
  ImU32 cell_border{};
  ImU32 row_panel_background{};
  ImU32 row_panel_border{};
  ImU32 row_panel_header_background{};
  ImU32 row_panel_header_text{};
  ImU32 row_panel_column_divider{};
  ImU32 row_panel_row_fill{};
  ImU32 row_panel_row_divider{};
  ImU32 row_panel_value_text{};
  ImU32 axis_background{};
  ImU32 axis_divider{};
  ImU32 axis_inner_divider{};
  ImU32 axis_tick{};
  ImU32 axis_label{};
  ImU32 header_label_background{};
  ImU32 header_label_border{};
  ImU32 header_label_divider{};
  ImU32 occurrence_panel_background{};
  ImU32 occurrence_panel_border{};
  ImU32 occurrence_panel_divider{};
  ImU32 event_text_on_dark{};
  ImU32 event_text_on_light{};
  ImU32 pinned_guide{};
  ImU32 active_guide{};
  MarkerBandColors marker_underlay{};
  MarkerBandColors marker_overlay{};
};

const ViewerTheme& viewer_theme(ColorScheme scheme);
void apply_imgui_theme(ColorScheme scheme);
const char* color_scheme_label(ColorScheme scheme);
ColorScheme cycle_color_scheme(ColorScheme scheme);

}  // namespace pipetrace
