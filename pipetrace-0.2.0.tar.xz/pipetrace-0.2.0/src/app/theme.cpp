#include "app/theme.hpp"

namespace pipetrace {
namespace {

ViewerTheme make_night_theme() {
  ViewerTheme theme;
  theme.grid_background = IM_COL32(18, 18, 22, 255);
  theme.cell_fill = IM_COL32(22, 22, 28, 255);
  theme.cell_border = IM_COL32(40, 40, 48, 255);
  theme.row_panel_background = IM_COL32(24, 24, 30, 255);
  theme.row_panel_border = IM_COL32(50, 50, 60, 255);
  theme.row_panel_header_background = IM_COL32(28, 28, 34, 255);
  theme.row_panel_header_text = IM_COL32(180, 180, 190, 255);
  theme.row_panel_column_divider = IM_COL32(40, 40, 48, 255);
  theme.row_panel_row_fill = IM_COL32(22, 22, 28, 255);
  theme.row_panel_row_divider = IM_COL32(36, 36, 44, 255);
  theme.row_panel_value_text = IM_COL32(220, 220, 228, 255);
  theme.axis_background = IM_COL32(28, 28, 34, 255);
  theme.axis_divider = IM_COL32(60, 60, 72, 255);
  theme.axis_inner_divider = IM_COL32(50, 50, 60, 255);
  theme.axis_tick = IM_COL32(80, 80, 96, 255);
  theme.axis_label = IM_COL32(190, 190, 200, 255);
  theme.header_label_background = IM_COL32(26, 26, 32, 255);
  theme.header_label_border = IM_COL32(50, 50, 60, 255);
  theme.header_label_divider = IM_COL32(40, 40, 48, 255);
  theme.occurrence_panel_background = IM_COL32(24, 24, 30, 255);
  theme.occurrence_panel_border = IM_COL32(60, 60, 72, 255);
  theme.occurrence_panel_divider = IM_COL32(50, 50, 60, 255);
  theme.event_text_on_dark = IM_COL32(240, 240, 245, 255);
  theme.event_text_on_light = IM_COL32(20, 20, 24, 255);
  theme.pinned_guide = IM_COL32(255, 180, 60, 220);
  theme.active_guide = IM_COL32(120, 180, 255, 255);
  theme.marker_underlay = {IM_COL32(255, 170, 50, 40), IM_COL32(255, 170, 50, 65),
                           IM_COL32(70, 110, 180, 45), IM_COL32(70, 110, 180, 70)};
  theme.marker_overlay = {IM_COL32(255, 170, 50, 70), IM_COL32(255, 170, 50, 110),
                          IM_COL32(70, 110, 180, 90), IM_COL32(70, 110, 180, 130)};
  return theme;
}

ViewerTheme make_day_theme() {
  ViewerTheme theme;
  theme.grid_background = IM_COL32(236, 238, 242, 255);
  theme.cell_fill = IM_COL32(248, 249, 251, 255);
  theme.cell_border = IM_COL32(208, 212, 220, 255);
  theme.row_panel_background = IM_COL32(244, 246, 249, 255);
  theme.row_panel_border = IM_COL32(190, 196, 208, 255);
  theme.row_panel_header_background = IM_COL32(232, 235, 240, 255);
  theme.row_panel_header_text = IM_COL32(55, 60, 70, 255);
  theme.row_panel_column_divider = IM_COL32(210, 214, 222, 255);
  theme.row_panel_row_fill = IM_COL32(250, 251, 253, 255);
  theme.row_panel_row_divider = IM_COL32(220, 224, 232, 255);
  theme.row_panel_value_text = IM_COL32(30, 34, 42, 255);
  theme.axis_background = IM_COL32(232, 235, 240, 255);
  theme.axis_divider = IM_COL32(190, 196, 208, 255);
  theme.axis_inner_divider = IM_COL32(200, 206, 216, 255);
  theme.axis_tick = IM_COL32(150, 158, 172, 255);
  theme.axis_label = IM_COL32(55, 60, 70, 255);
  theme.header_label_background = IM_COL32(238, 240, 244, 255);
  theme.header_label_border = IM_COL32(190, 196, 208, 255);
  theme.header_label_divider = IM_COL32(210, 214, 222, 255);
  theme.occurrence_panel_background = IM_COL32(244, 246, 249, 255);
  theme.occurrence_panel_border = IM_COL32(190, 196, 208, 255);
  theme.occurrence_panel_divider = IM_COL32(200, 206, 216, 255);
  theme.event_text_on_dark = IM_COL32(248, 249, 251, 255);
  theme.event_text_on_light = IM_COL32(24, 28, 36, 255);
  theme.pinned_guide = IM_COL32(200, 120, 20, 255);
  theme.active_guide = IM_COL32(30, 100, 220, 255);
  theme.marker_underlay = {IM_COL32(230, 150, 30, 45), IM_COL32(230, 150, 30, 70),
                           IM_COL32(40, 100, 210, 40), IM_COL32(40, 100, 210, 65)};
  theme.marker_overlay = {IM_COL32(230, 150, 30, 75), IM_COL32(230, 150, 30, 110),
                          IM_COL32(40, 100, 210, 70), IM_COL32(40, 100, 210, 105)};
  return theme;
}

ViewerTheme make_gay_theme() {
  ViewerTheme theme;
  theme.grid_background = IM_COL32(255, 220, 235, 255);
  theme.cell_fill = IM_COL32(255, 235, 245, 255);
  theme.cell_border = IM_COL32(255, 170, 210, 255);
  theme.row_panel_background = IM_COL32(255, 210, 230, 255);
  theme.row_panel_border = IM_COL32(255, 130, 190, 255);
  theme.row_panel_header_background = IM_COL32(255, 190, 220, 255);
  theme.row_panel_header_text = IM_COL32(120, 20, 70, 255);
  theme.row_panel_column_divider = IM_COL32(255, 150, 200, 255);
  theme.row_panel_row_fill = IM_COL32(255, 228, 240, 255);
  theme.row_panel_row_divider = IM_COL32(255, 180, 215, 255);
  theme.row_panel_value_text = IM_COL32(90, 10, 55, 255);
  theme.axis_background = IM_COL32(255, 195, 225, 255);
  theme.axis_divider = IM_COL32(255, 120, 185, 255);
  theme.axis_inner_divider = IM_COL32(255, 140, 195, 255);
  theme.axis_tick = IM_COL32(230, 80, 160, 255);
  theme.axis_label = IM_COL32(110, 15, 65, 255);
  theme.header_label_background = IM_COL32(255, 205, 230, 255);
  theme.header_label_border = IM_COL32(255, 130, 190, 255);
  theme.header_label_divider = IM_COL32(255, 160, 205, 255);
  theme.occurrence_panel_background = IM_COL32(255, 215, 235, 255);
  theme.occurrence_panel_border = IM_COL32(255, 120, 185, 255);
  theme.occurrence_panel_divider = IM_COL32(255, 140, 195, 255);
  theme.event_text_on_dark = IM_COL32(255, 245, 250, 255);
  theme.event_text_on_light = IM_COL32(80, 10, 45, 255);
  theme.pinned_guide = IM_COL32(255, 60, 180, 255);
  theme.active_guide = IM_COL32(255, 20, 147, 255);
  theme.marker_underlay = {IM_COL32(255, 100, 200, 50), IM_COL32(255, 100, 200, 80),
                           IM_COL32(255, 40, 160, 45), IM_COL32(255, 40, 160, 75)};
  theme.marker_overlay = {IM_COL32(255, 100, 200, 85), IM_COL32(255, 100, 200, 125),
                          IM_COL32(255, 40, 160, 80), IM_COL32(255, 40, 160, 120)};
  return theme;
}

}  // namespace

const ViewerTheme& viewer_theme(const ColorScheme scheme) {
  static const ViewerTheme kNight = make_night_theme();
  static const ViewerTheme kDay = make_day_theme();
  static const ViewerTheme kGay = make_gay_theme();
  switch (scheme) {
    case ColorScheme::Day:
      return kDay;
    case ColorScheme::Gay:
      return kGay;
    case ColorScheme::Night:
    default:
      return kNight;
  }
}

void apply_imgui_theme(const ColorScheme scheme) {
  if (scheme == ColorScheme::Day) {
    ImGui::StyleColorsLight();
    ImGuiStyle& style = ImGui::GetStyle();
    style.WindowRounding = 4.0f;
    style.FrameRounding = 3.0f;
    style.Colors[ImGuiCol_WindowBg] = ImVec4(0.96f, 0.97f, 0.98f, 1.0f);
    style.Colors[ImGuiCol_ChildBg] = ImVec4(0.98f, 0.98f, 0.99f, 1.0f);
    style.Colors[ImGuiCol_FrameBg] = ImVec4(0.93f, 0.94f, 0.96f, 1.0f);
    return;
  }

  if (scheme == ColorScheme::Gay) {
    ImGui::StyleColorsLight();
    ImGuiStyle& style = ImGui::GetStyle();
    style.WindowRounding = 6.0f;
    style.FrameRounding = 5.0f;
    style.Colors[ImGuiCol_WindowBg] = ImVec4(1.0f, 0.88f, 0.94f, 1.0f);
    style.Colors[ImGuiCol_ChildBg] = ImVec4(1.0f, 0.92f, 0.96f, 1.0f);
    style.Colors[ImGuiCol_FrameBg] = ImVec4(1.0f, 0.82f, 0.91f, 1.0f);
    style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(1.0f, 0.75f, 0.87f, 1.0f);
    style.Colors[ImGuiCol_FrameBgActive] = ImVec4(1.0f, 0.65f, 0.82f, 1.0f);
    style.Colors[ImGuiCol_Button] = ImVec4(1.0f, 0.55f, 0.78f, 1.0f);
    style.Colors[ImGuiCol_ButtonHovered] = ImVec4(1.0f, 0.45f, 0.72f, 1.0f);
    style.Colors[ImGuiCol_ButtonActive] = ImVec4(0.95f, 0.30f, 0.65f, 1.0f);
    style.Colors[ImGuiCol_Header] = ImVec4(1.0f, 0.70f, 0.85f, 1.0f);
    style.Colors[ImGuiCol_HeaderHovered] = ImVec4(1.0f, 0.60f, 0.80f, 1.0f);
    style.Colors[ImGuiCol_HeaderActive] = ImVec4(1.0f, 0.50f, 0.75f, 1.0f);
    style.Colors[ImGuiCol_Text] = ImVec4(0.45f, 0.05f, 0.28f, 1.0f);
    style.Colors[ImGuiCol_Border] = ImVec4(1.0f, 0.55f, 0.78f, 0.8f);
    return;
  }

  ImGui::StyleColorsDark();
}

const char* color_scheme_label(const ColorScheme scheme) {
  switch (scheme) {
    case ColorScheme::Day:
      return "Day";
    case ColorScheme::Gay:
      return "Gay";
    case ColorScheme::Night:
    default:
      return "Night";
  }
}

ColorScheme cycle_color_scheme(const ColorScheme scheme) {
  switch (scheme) {
    case ColorScheme::Night:
      return ColorScheme::Day;
    case ColorScheme::Day:
      return ColorScheme::Gay;
    case ColorScheme::Gay:
      return ColorScheme::Night;
  }
  return ColorScheme::Night;
}

}  // namespace pipetrace
