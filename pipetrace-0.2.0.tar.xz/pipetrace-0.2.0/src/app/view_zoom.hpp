#pragma once

#include <algorithm>
#include <cmath>

namespace pipetrace {

inline bool zoom_preserve_anchor(double& scroll, double& cell_size, double mouse_local,
                                 double zoom_factor, double min_size, double max_size) {
  const double old_size = cell_size;
  const double new_size = std::clamp(old_size * zoom_factor, min_size, max_size);
  if (new_size == old_size) {
    return false;
  }

  scroll += mouse_local * (1.0 / old_size - 1.0 / new_size);
  cell_size = new_size;
  return true;
}

inline bool zoom_preserve_anchor_to_size(double& scroll, double& cell_size, double mouse_local,
                                         double target_size, double min_size, double max_size) {
  const double old_size = cell_size;
  const double new_size = std::clamp(target_size, min_size, max_size);
  if (new_size == old_size) {
    return false;
  }

  scroll += mouse_local * (1.0 / old_size - 1.0 / new_size);
  cell_size = new_size;
  return true;
}

}  // namespace pipetrace
