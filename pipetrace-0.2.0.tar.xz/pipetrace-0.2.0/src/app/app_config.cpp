#include "pipetrace/app_config.hpp"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <optional>
#include <sstream>
#include <stdexcept>
#include <string>
#include <system_error>
#include <unordered_set>

#ifdef _WIN32
#  define WIN32_LEAN_AND_MEAN
#  include <windows.h>
#endif

namespace pipetrace {
namespace {

std::string read_file_or_empty(const std::string& path) {
  std::ifstream in(path);
  if (!in) {
    return {};
  }
  std::ostringstream buffer;
  buffer << in.rdbuf();
  return buffer.str();
}

std::optional<std::string> extract_quoted_value(const std::string& object,
                                                const std::string& key) {
  const std::string needle = "\"" + key + "\":";
  const auto pos = object.find(needle);
  if (pos == std::string::npos) {
    return std::nullopt;
  }
  std::size_t start = pos + needle.size();
  while (start < object.size() && std::isspace(static_cast<unsigned char>(object[start]))) {
    ++start;
  }
  if (start >= object.size() || object[start] != '"') {
    return std::nullopt;
  }
  ++start;
  const auto end = object.find('"', start);
  if (end == std::string::npos) {
    return std::nullopt;
  }
  return object.substr(start, end - start);
}

std::optional<float> extract_number_value(const std::string& object, const std::string& key) {
  const std::string needle = "\"" + key + "\":";
  const auto pos = object.find(needle);
  if (pos == std::string::npos) {
    return std::nullopt;
  }
  std::size_t i = pos + needle.size();
  while (i < object.size() && std::isspace(static_cast<unsigned char>(object[i]))) {
    ++i;
  }
  std::size_t j = i;
  while (j < object.size() && (std::isdigit(static_cast<unsigned char>(object[j])) ||
                               object[j] == '.' || object[j] == '-')) {
    ++j;
  }
  if (j == i) {
    return std::nullopt;
  }
  return std::stof(object.substr(i, j - i));
}

std::optional<std::uint64_t> extract_uint64_value(const std::string& object,
                                                  const std::string& key) {
  const std::string needle = "\"" + key + "\":";
  const auto pos = object.find(needle);
  if (pos == std::string::npos) {
    return std::nullopt;
  }
  std::size_t i = pos + needle.size();
  while (i < object.size() && std::isspace(static_cast<unsigned char>(object[i]))) {
    ++i;
  }
  std::size_t j = i;
  while (j < object.size() && std::isdigit(static_cast<unsigned char>(object[j]))) {
    ++j;
  }
  if (j == i) {
    return std::nullopt;
  }
  return std::stoull(object.substr(i, j - i));
}

std::optional<std::string> extract_top_level_object(const std::string& text,
                                                    const std::string& key) {
  const std::string needle = "\"" + key + "\":";
  const auto key_pos = text.find(needle);
  if (key_pos == std::string::npos) {
    return std::nullopt;
  }

  const auto open = text.find('{', key_pos);
  if (open == std::string::npos) {
    return std::nullopt;
  }

  std::size_t depth = 0;
  for (std::size_t i = open; i < text.size(); ++i) {
    const char ch = text[i];
    if (ch == '{') {
      ++depth;
    } else if (ch == '}') {
      --depth;
      if (depth == 0) {
        return text.substr(open, i - open + 1);
      }
    }
  }
  return std::nullopt;
}

std::vector<std::string> split_top_level_objects(const std::string& text,
                                                 const std::string& array_key) {
  const std::string needle = "\"" + array_key + "\":";
  const auto array_pos = text.find(needle);
  if (array_pos == std::string::npos) {
    return {};
  }

  const auto open = text.find('[', array_pos);
  if (open == std::string::npos) {
    return {};
  }

  std::vector<std::string> objects;
  std::size_t depth = 0;
  std::size_t object_start = std::string::npos;
  for (std::size_t i = open + 1; i < text.size(); ++i) {
    const char ch = text[i];
    if (ch == '{') {
      if (depth == 0) {
        object_start = i;
      }
      ++depth;
    } else if (ch == '}') {
      --depth;
      if (depth == 0 && object_start != std::string::npos) {
        objects.push_back(text.substr(object_start, i - object_start + 1));
        object_start = std::string::npos;
      }
    } else if (ch == ']' && depth == 0) {
      break;
    }
  }
  return objects;
}

std::vector<std::string> split_top_level_strings(const std::string& text,
                                                 const std::string& array_key) {
  const std::string needle = "\"" + array_key + "\":";
  const auto array_pos = text.find(needle);
  if (array_pos == std::string::npos) {
    return {};
  }

  const auto open = text.find('[', array_pos);
  if (open == std::string::npos) {
    return {};
  }

  std::vector<std::string> strings;
  std::size_t i = open + 1;
  while (i < text.size()) {
    while (i < text.size() && std::isspace(static_cast<unsigned char>(text[i]))) {
      ++i;
    }
    if (i >= text.size() || text[i] == ']') {
      break;
    }
    if (text[i] != '"') {
      break;
    }
    ++i;
    std::string value;
    while (i < text.size() && text[i] != '"') {
      if (text[i] == '\\' && i + 1 < text.size()) {
        value.push_back(text[i + 1]);
        i += 2;
      } else {
        value.push_back(text[i++]);
      }
    }
    if (i < text.size() && text[i] == '"') {
      ++i;
    }
    strings.push_back(value);
    while (i < text.size() && std::isspace(static_cast<unsigned char>(text[i]))) {
      ++i;
    }
    if (i < text.size() && text[i] == ',') {
      ++i;
    }
  }
  return strings;
}

PinnedRowAttribute parse_pinned_row_attribute(const std::string& object_text) {
  PinnedRowAttribute column;
  column.key = extract_quoted_value(object_text, "key").value_or("");
  column.label = extract_quoted_value(object_text, "label").value_or(column.key);
  column.width_px = extract_number_value(object_text, "width_px").value_or(80.0f);
  column.scope = extract_quoted_value(object_text, "scope").value_or("Always");
  if (column.key.empty()) {
    throw std::runtime_error("pinned row attribute entry missing key");
  }
  if (column.width_px < 24.0f) {
    column.width_px = 24.0f;
  }
  if (column.scope != "Always" && column.scope != "SingleTrace" && column.scope != "DualTrace") {
    throw std::runtime_error("pinned row attribute scope must be Always, SingleTrace, or DualTrace");
  }
  return column;
}

bool pinned_row_scope_visible(const PinnedRowAttribute& column, bool dual_layout) {
  if (column.scope == "Always") {
    return true;
  }
  if (column.scope == "SingleTrace") {
    return !dual_layout;
  }
  if (column.scope == "DualTrace") {
    return dual_layout;
  }
  return true;
}

bool is_hex_digit(char ch) {
  return std::isdigit(static_cast<unsigned char>(ch)) ||
         (ch >= 'a' && ch <= 'f') || (ch >= 'A' && ch <= 'F');
}

std::optional<std::uint8_t> parse_hex_byte(const std::string& text, std::size_t pos) {
  if (pos + 1 >= text.size() || !is_hex_digit(text[pos]) || !is_hex_digit(text[pos + 1])) {
    return std::nullopt;
  }
  const auto nibble = [](char ch) -> int {
    if (std::isdigit(static_cast<unsigned char>(ch))) {
      return ch - '0';
    }
    return std::tolower(static_cast<unsigned char>(ch)) - 'a' + 10;
  };
  return static_cast<std::uint8_t>((nibble(text[pos]) << 4) | nibble(text[pos + 1]));
}

std::optional<std::uint32_t> parse_color_hex(const std::string& text) {
  if (text.empty() || text[0] != '#') {
    return std::nullopt;
  }
  const std::string hex = text.substr(1);
  if (hex.size() != 6 && hex.size() != 8) {
    return std::nullopt;
  }
  for (char ch : hex) {
    if (!is_hex_digit(ch)) {
      return std::nullopt;
    }
  }

  const std::optional<std::uint8_t> r = parse_hex_byte(hex, 0);
  const std::optional<std::uint8_t> g = parse_hex_byte(hex, 2);
  const std::optional<std::uint8_t> b = parse_hex_byte(hex, 4);
  if (!r || !g || !b) {
    return std::nullopt;
  }

  std::uint8_t a = 0xFF;
  if (hex.size() == 8) {
    const std::optional<std::uint8_t> parsed_a = parse_hex_byte(hex, 6);
    if (!parsed_a) {
      return std::nullopt;
    }
    a = *parsed_a;
  }

  return (static_cast<std::uint32_t>(a) << 24) | (static_cast<std::uint32_t>(*r) << 16) |
         (static_cast<std::uint32_t>(*g) << 8) | static_cast<std::uint32_t>(*b);
}

std::string format_color_hex(std::uint32_t color_rgba) {
  const std::uint8_t a = static_cast<std::uint8_t>((color_rgba >> 24) & 0xFF);
  const std::uint8_t r = static_cast<std::uint8_t>((color_rgba >> 16) & 0xFF);
  const std::uint8_t g = static_cast<std::uint8_t>((color_rgba >> 8) & 0xFF);
  const std::uint8_t b = static_cast<std::uint8_t>(color_rgba & 0xFF);

  char buffer[16];
  if (a == 0xFF) {
    std::snprintf(buffer, sizeof(buffer), "#%02X%02X%02X", r, g, b);
  } else {
    std::snprintf(buffer, sizeof(buffer), "#%02X%02X%02X%02X", r, g, b, a);
  }
  return buffer;
}

ObjectAttributeStrengthRule parse_object_attribute_strength_rule(const std::string& object_text) {
  ObjectAttributeStrengthRule rule;
  rule.key = extract_quoted_value(object_text, "key").value_or("");
  rule.color = extract_quoted_value(object_text, "color").value_or("");
  rule.highlight = extract_quoted_value(object_text, "highlight").value_or("max");
  if (rule.key.empty()) {
    throw std::runtime_error("object_attribute_strength entry missing key");
  }
  if (rule.color.empty()) {
    throw std::runtime_error("object_attribute_strength entry missing color");
  }
  if (!parse_color_hex(rule.color)) {
    throw std::runtime_error("object_attribute_strength entry has invalid color: " + rule.color);
  }
  if (rule.highlight != "max" && rule.highlight != "min") {
    throw std::runtime_error("object_attribute_strength highlight must be max or min");
  }
  return rule;
}

EventTypeDisplay parse_event_type_display(const std::string& object_text) {
  EventTypeDisplay entry;
  entry.name = extract_quoted_value(object_text, "name").value_or("");
  const std::string char_text = extract_quoted_value(object_text, "char").value_or("?");
  entry.display_char = char_text.empty() ? '?' : char_text[0];

  if (const std::optional<std::string> color_text = extract_quoted_value(object_text, "color")) {
    const std::optional<std::uint32_t> parsed = parse_color_hex(*color_text);
    if (!parsed) {
      throw std::runtime_error("event_type_display entry has invalid color: " + *color_text);
    }
    entry.color_rgba = *parsed;
  } else if (const std::optional<std::uint64_t> legacy =
                 extract_uint64_value(object_text, "color_rgba")) {
    entry.color_rgba = static_cast<std::uint32_t>(*legacy);
  } else {
    // Omitted color = unset until analyze invents a palette color.
    entry.color_rgba = kUnassignedEventTypeColor;
  }

  if (entry.name.empty()) {
    throw std::runtime_error("event_type_display entry missing name");
  }
  return entry;
}

CastToolConfig parse_cast_tool_config(const std::string& object_text) {
  CastToolConfig cast_tool;
  cast_tool.command =
      extract_quoted_value(object_text, "command").value_or(cast_tool.command);
  if (cast_tool.command.empty()) {
    throw std::runtime_error("cast_tool.command must not be empty");
  }
  return cast_tool;
}

SortColumn parse_sort_column(const std::string& object_text) {
  SortColumn column;
  column.key = extract_quoted_value(object_text, "key").value_or("");
  column.order = extract_quoted_value(object_text, "order").value_or("asc");
  if (column.key.empty()) {
    throw std::runtime_error("sort column entry missing key");
  }
  if (column.order != "asc" && column.order != "desc") {
    throw std::runtime_error("sort column order must be asc or desc");
  }
  return column;
}

SortScheme parse_sort_scheme(const std::string& object_text) {
  SortScheme scheme;
  scheme.name = extract_quoted_value(object_text, "name").value_or("");
  if (scheme.name.empty()) {
    throw std::runtime_error("sort scheme entry missing name");
  }
  for (const std::string& column_text : split_top_level_objects(object_text, "columns")) {
    scheme.columns.push_back(parse_sort_column(column_text));
  }
  if (scheme.columns.empty()) {
    throw std::runtime_error("sort scheme must include at least one column");
  }
  return scheme;
}

std::string missing_config_message(bool allow_env, bool allow_exe) {
  if (allow_env && allow_exe) {
    return "config is required: pass --config PATH, set PIPETRACE_CONFIG, or place " +
           std::string(kAppConfigFileName) + " next to the executable";
  }
  if (allow_env) {
    return "config is required: set PIPETRACE_CONFIG or pass --config PATH";
  }
  if (allow_exe) {
    return "config is required: pass --config PATH or place " + std::string(kAppConfigFileName) +
           " next to the executable";
  }
  return "config is required: pass --config PATH";
}

void require_config_file(const std::string& path) {
  if (!std::filesystem::exists(path)) {
    throw std::runtime_error("config file not found: " + path);
  }
  if (!std::filesystem::is_regular_file(path)) {
    throw std::runtime_error("config path is not a regular file: " + path);
  }
}

}  // namespace

std::optional<std::uint32_t> parse_hex_color_rgba(const std::string& text) {
  return parse_color_hex(text);
}

std::string format_hex_color_rgba_string(const std::uint8_t r, const std::uint8_t g,
                                         const std::uint8_t b, const std::uint8_t a) {
  char buffer[10];
  std::snprintf(buffer, sizeof(buffer), "#%02X%02X%02X%02X", r, g, b, a);
  return buffer;
}

std::string strength_color_from_base(const std::string& base_color_hex, const double strength) {
  const std::optional<std::uint32_t> rgba = parse_hex_color_rgba(base_color_hex);
  if (!rgba) {
    throw std::runtime_error("invalid strength color base: " + base_color_hex);
  }
  const std::uint8_t r = static_cast<std::uint8_t>((*rgba >> 16) & 0xFFU);
  const std::uint8_t g = static_cast<std::uint8_t>((*rgba >> 8) & 0xFFU);
  const std::uint8_t b = static_cast<std::uint8_t>(*rgba & 0xFFU);
  const double clamped = std::max(0.0, std::min(1.0, strength));
  const std::uint8_t a =
      static_cast<std::uint8_t>(std::lround(clamped * 255.0));
  return format_hex_color_rgba_string(r, g, b, a);
}

float AppConfig::row_panel_width() const {
  float total = 0.0f;
  for (const PinnedRowAttribute& column : pinned_row_attributes) {
    total += column.width_px;
  }
  return total;
}

const EventTypeDisplay* AppConfig::find_event_type_display(const std::string& name) const {
  for (const EventTypeDisplay& entry : event_type_display) {
    if (entry.name == name) {
      return &entry;
    }
  }
  return nullptr;
}

EventTypeDisplay* AppConfig::find_event_type_display(const std::string& name) {
  for (EventTypeDisplay& entry : event_type_display) {
    if (entry.name == name) {
      return &entry;
    }
  }
  return nullptr;
}

AppConfig default_app_config() {
  AppConfig config;
  config.cast_tool.command = "./build/pipetrace-linx-parser";
  config.analysis_tool.command = "./build/pipetrace-linx-analyze";
  config.pinned_row_attributes = {
      {"type", "Type", 88.0f},
      {"InstID", "Inst", 44.0f},
      {"RetirePushup", "Pushup", 56.0f},
      {"disasm", "Disasm", 320.0f},
  };
  config.sort_schemes = {
      SortScheme{"seqnum", {{"seqnum", "asc"}}},
      SortScheme{"InstID/seqnum", {{"InstID", "asc"}, {"seqnum", "asc"}}},
      SortScheme{"PC/seqnum", {{"PC", "asc"}, {"seqnum", "asc"}}},
      SortScheme{"RetirePushup", {{"RetirePushup", "desc"}}},
      SortScheme{"DualRetirePushup", {{"DualRetirePushup", "desc"}}},
      SortScheme{"PcCount", {{"PcCount", "desc"}, {"PC", "asc"}}},
  };
  config.search_attributes = {"seqnum", "InstID"};
  return config;
}

std::string executable_directory(const std::string& argv0) {
  std::filesystem::path exe;

#ifdef _WIN32
  std::wstring buf(32768, L'\0');
  const DWORD n = GetModuleFileNameW(nullptr, buf.data(), static_cast<DWORD>(buf.size()));
  if (n > 0 && n < buf.size()) {
    buf.resize(n);
    exe = std::filesystem::path(buf);
  }
#else
  std::error_code link_ec;
  const std::filesystem::path self = std::filesystem::read_symlink("/proc/self/exe", link_ec);
  if (!link_ec && !self.empty()) {
    exe = self;
  }
#endif

  if (exe.empty() && !argv0.empty()) {
    exe = argv0;
    if (exe.is_relative()) {
      std::error_code abs_ec;
      exe = std::filesystem::absolute(exe, abs_ec);
      if (abs_ec) {
        return {};
      }
    }
  }
  if (exe.empty()) {
    return {};
  }

  std::error_code canon_ec;
  const std::filesystem::path canonical = std::filesystem::weakly_canonical(exe, canon_ec);
  if (!canon_ec && !canonical.empty()) {
    exe = canonical;
  }
  return exe.parent_path().string();
}

std::string resolve_app_config_path(const std::string& flag_path, bool allow_env,
                                    const std::string& exe_dir) {
  std::string path = flag_path;
  if (path.empty() && allow_env) {
    if (const char* env = std::getenv("PIPETRACE_CONFIG")) {
      if (env[0] != '\0') {
        path = env;
      }
    }
  }
  if (!path.empty()) {
    require_config_file(path);
    return path;
  }
  if (!exe_dir.empty()) {
    const std::filesystem::path adjacent =
        std::filesystem::path(exe_dir) / kAppConfigFileName;
    if (std::filesystem::is_regular_file(adjacent)) {
      return adjacent.string();
    }
  }
  throw std::runtime_error(missing_config_message(allow_env, !exe_dir.empty()));
}

AppConfig load_app_config(const std::string& path) {
  const std::string text = read_file_or_empty(path);
  if (text.empty()) {
    return {};
  }

  AppConfig config;
  if (const std::optional<std::string> cast_tool_text = extract_top_level_object(text, "cast_tool")) {
    config.cast_tool = parse_cast_tool_config(*cast_tool_text);
  }
  if (const std::optional<std::string> analysis_tool_text =
          extract_top_level_object(text, "analysis_tool")) {
    config.analysis_tool.command =
        extract_quoted_value(*analysis_tool_text, "command")
            .value_or(config.analysis_tool.command);
    if (config.analysis_tool.command.empty()) {
      throw std::runtime_error("analysis_tool.command must not be empty");
    }
  }
  for (const std::string& object_text :
       split_top_level_objects(text, "pinned_row_attributes")) {
    config.pinned_row_attributes.push_back(parse_pinned_row_attribute(object_text));
  }
  for (const std::string& object_text :
       split_top_level_objects(text, "event_type_display")) {
    config.event_type_display.push_back(parse_event_type_display(object_text));
  }
  for (const std::string& object_text : split_top_level_objects(text, "sort_schemes")) {
    config.sort_schemes.push_back(parse_sort_scheme(object_text));
  }
  for (const std::string& object_text :
       split_top_level_objects(text, "object_attribute_strength")) {
    config.object_attribute_strength.push_back(parse_object_attribute_strength_rule(object_text));
  }
  config.search_attributes = split_top_level_strings(text, "search_attributes");
  if (config.search_attributes.empty()) {
    config.search_attributes = {"seqnum", "InstID"};
  }
  config.sync_attribute = extract_quoted_value(text, "sync_attribute").value_or("");
  return config;
}

std::size_t merge_event_type_display(AppConfig& config,
                                     const std::vector<EventTypeDisplay>& discovered) {
  std::size_t added = 0;
  for (const EventTypeDisplay& entry : discovered) {
    if (config.find_event_type_display(entry.name) != nullptr) {
      continue;
    }
    config.event_type_display.push_back(entry);
    ++added;
  }
  return added;
}

void save_app_config(const std::string& path, const AppConfig& config) {
  std::ofstream out(path, std::ios::trunc);
  if (!out) {
    throw std::runtime_error("failed to write app config: " + path);
  }

  out << "{\n";
  out << "  \"cast_tool\": {\n";
  out << "    \"command\": \"" << config.cast_tool.command << "\"\n";
  out << "  },\n";
  out << "  \"analysis_tool\": {\n";
  out << "    \"command\": \"" << config.analysis_tool.command << "\"\n";
  out << "  },\n";
  out << "  \"pinned_row_attributes\": [\n";
  for (std::size_t i = 0; i < config.pinned_row_attributes.size(); ++i) {
    const PinnedRowAttribute& column = config.pinned_row_attributes[i];
    out << "    { \"key\": \"" << column.key << "\", \"label\": \"" << column.label
        << "\", \"width_px\": " << column.width_px << ", \"scope\": \"" << column.scope << "\" }";
    out << (i + 1 < config.pinned_row_attributes.size() ? ",\n" : "\n");
  }
  out << "  ],\n";
  if (!config.sync_attribute.empty()) {
    out << "  \"sync_attribute\": \"" << config.sync_attribute << "\",\n";
  }
  out << "  \"search_attributes\": [";
  for (std::size_t i = 0; i < config.search_attributes.size(); ++i) {
    out << (i == 0 ? " " : ", ") << "\"" << config.search_attributes[i] << "\"";
  }
  out << " ],\n";
  if (!config.object_attribute_strength.empty()) {
    out << "  \"object_attribute_strength\": [\n";
    for (std::size_t i = 0; i < config.object_attribute_strength.size(); ++i) {
      const ObjectAttributeStrengthRule& rule = config.object_attribute_strength[i];
      out << "    { \"key\": \"" << rule.key << "\", \"color\": \"" << rule.color
          << "\", \"highlight\": \"" << rule.highlight << "\" }";
      out << (i + 1 < config.object_attribute_strength.size() ? ",\n" : "\n");
    }
    out << "  ],\n";
  }
  out << "  \"sort_schemes\": [\n";
  for (std::size_t i = 0; i < config.sort_schemes.size(); ++i) {
    const SortScheme& scheme = config.sort_schemes[i];
    out << "    {\n";
    out << "      \"name\": \"" << scheme.name << "\",\n";
    out << "      \"columns\": [\n";
    for (std::size_t j = 0; j < scheme.columns.size(); ++j) {
      const SortColumn& column = scheme.columns[j];
      out << "        { \"key\": \"" << column.key << "\", \"order\": \"" << column.order << "\" }";
      out << (j + 1 < scheme.columns.size() ? ",\n" : "\n");
    }
    out << "      ]\n";
    out << "    }";
    out << (i + 1 < config.sort_schemes.size() ? ",\n" : "\n");
  }
  out << "  ],\n";
  out << "  \"event_type_display\": [\n";
  for (std::size_t i = 0; i < config.event_type_display.size(); ++i) {
    const EventTypeDisplay& entry = config.event_type_display[i];
    out << "    { \"name\": \"" << entry.name << "\", \"char\": \""
        << (entry.display_char != '\0' ? std::string(1, entry.display_char) : std::string("?"));
    if (!is_unassigned_event_type_color(entry.color_rgba)) {
      out << "\", \"color\": \"" << format_color_hex(entry.color_rgba) << "\" }";
    } else {
      out << "\" }";
    }
    out << (i + 1 < config.event_type_display.size() ? ",\n" : "\n");
  }
  out << "  ]\n";
  out << "}\n";
}

std::unordered_map<std::string, bool> default_pinned_attribute_checks(
    const AppConfig& config, const std::vector<std::string>& available_keys) {
  std::unordered_set<std::string> config_keys;
  for (const PinnedRowAttribute& column : config.pinned_row_attributes) {
    config_keys.insert(column.key);
  }

  std::unordered_map<std::string, bool> checked;
  checked.reserve(available_keys.size());
  for (const std::string& key : available_keys) {
    checked[key] = config_keys.count(key) > 0;
  }
  return checked;
}

std::vector<PinnedRowAttribute> build_active_pinned_row_columns(
    const AppConfig& config, const std::vector<std::string>& available_keys,
    const std::unordered_map<std::string, bool>& checked, bool dual_layout) {
  std::unordered_set<std::string> available_set(available_keys.begin(), available_keys.end());
  std::unordered_map<std::string, PinnedRowAttribute> config_by_key;
  for (const PinnedRowAttribute& column : config.pinned_row_attributes) {
    config_by_key.emplace(column.key, column);
  }

  std::vector<PinnedRowAttribute> active;
  std::unordered_set<std::string> added;

  for (const PinnedRowAttribute& column : config.pinned_row_attributes) {
    if (!pinned_row_scope_visible(column, dual_layout)) {
      continue;
    }
    if (!available_set.count(column.key)) {
      continue;
    }
    const auto checked_it = checked.find(column.key);
    if (checked_it == checked.end() || !checked_it->second) {
      continue;
    }
    active.push_back(column);
    added.insert(column.key);
  }

  for (const std::string& key : available_keys) {
    if (added.count(key)) {
      continue;
    }
    if (config_by_key.count(key)) {
      continue;
    }
    const auto checked_it = checked.find(key);
    if (checked_it == checked.end() || !checked_it->second) {
      continue;
    }
    PinnedRowAttribute column;
    column.key = key;
    column.label = key;
    column.width_px = 80.0f;
    column.scope = "Always";
    if (!pinned_row_scope_visible(column, dual_layout)) {
      continue;
    }
    if (const auto config_it = config_by_key.find(key); config_it != config_by_key.end()) {
      column.label = config_it->second.label;
      column.width_px = config_it->second.width_px;
    }
    active.push_back(column);
  }

  return active;
}

}  // namespace pipetrace
