#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <mutex>
#include <optional>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

#ifdef _WIN32
#  define WIN32_LEAN_AND_MEAN
#  include <windows.h>
#else
#  include <spawn.h>
#  include <sys/wait.h>
#  include <unistd.h>
#endif

#include "pipetrace/app_config.hpp"
#include "pipetrace/progress.hpp"

#ifndef _WIN32
extern char** environ;
#endif

namespace {

struct Options {
  std::vector<std::string> inputs;
  std::string config_path;  // --config; else PIPETRACE_CONFIG (mandatory)
  bool view{true};
  bool force{false};
};

Options parse_args(int argc, char** argv) {
  Options options;
  for (int i = 1; i < argc; ++i) {
    const std::string arg = argv[i];
    if (arg == "--config" && i + 1 < argc) {
      options.config_path = argv[++i];
    } else if (arg == "--no-view") {
      options.view = false;
    } else if (arg == "--force") {
      options.force = true;
    } else if (arg == "--help") {
      std::cout
          << "pipetrace-linx TRACE [TRACE2] [--no-view] [--force] [--config PATH]\n"
             "  TRACE is a linx PT text file or a SQLite store (detected by content).\n"
             "  Two traces must resolve to different stores (duplicate the file for debug).\n"
             "  Config is required: --config PATH (or PIPETRACE_CONFIG; --config wins).\n";
      std::exit(0);
    } else if (!arg.empty() && arg[0] == '-') {
      throw std::runtime_error("unknown argument: " + arg);
    } else {
      options.inputs.push_back(arg);
    }
  }
  if (options.inputs.empty() || options.inputs.size() > 2) {
    throw std::runtime_error("provide one or two trace paths (linx PT text or SQLite store)");
  }
  return options;
}

enum class InputKind { Pt, Db };

constexpr char kSqliteMagic[16] = {'S', 'Q', 'L', 'i', 't', 'e', ' ', 'f',
                                   'o', 'r', 'm', 'a', 't', ' ', '3', '\0'};

bool file_starts_with_sqlite_magic(const std::string& path) {
  std::ifstream in(path, std::ios::binary);
  if (!in) {
    throw std::runtime_error("failed to open input: " + path);
  }
  char header[16] = {};
  in.read(header, 16);
  if (in.gcount() < 16) {
    return false;
  }
  return std::memcmp(header, kSqliteMagic, 16) == 0;
}

InputKind detect_kind(const std::string& path) {
  if (!std::filesystem::exists(path)) {
    throw std::runtime_error("input not found: " + path);
  }
  if (!std::filesystem::is_regular_file(path)) {
    throw std::runtime_error("input is not a regular file: " + path);
  }
  // Content sniff (not extension): SQLite main DB files start with "SQLite format 3\0".
  return file_starts_with_sqlite_magic(path) ? InputKind::Db : InputKind::Pt;
}

std::string default_store_for_pt(const std::string& pt_path) {
  return pt_path + ".db";
}

std::string canonical_path(const std::string& path) {
  std::error_code ec;
  const std::filesystem::path resolved = std::filesystem::weakly_canonical(path, ec);
  if (ec) {
    return std::filesystem::absolute(path).lexically_normal().string();
  }
  return resolved.string();
}

std::string resolve_tool_path(const std::string& configured, const std::string& fallback_name) {
  if (!configured.empty() && std::filesystem::exists(configured)) {
    return configured;
  }
  const std::string local = std::string("./build/") + fallback_name;
  if (std::filesystem::exists(local)) {
    return local;
  }
  if (!configured.empty()) {
    return configured;
  }
  return local;
}

struct SlotState {
  std::string label;
  std::string status_line{"STATUS tool=? phase=starting done=0 total=0"};
  std::string last_warn;
  int exit_code{-1};
  bool finished{false};
};

struct PipelineUi {
  explicit PipelineUi(std::size_t slot_count) : slots(slot_count) {}

  std::vector<SlotState> slots;
  std::mutex mutex;
  bool painted{false};
  bool use_regions{false};

  void set_tty_mode(bool enabled) { use_regions = enabled; }

  void update_status(std::size_t slot, const std::string& line) {
    std::lock_guard<std::mutex> lock(mutex);
    if (slot >= slots.size()) {
      return;
    }
    slots[slot].status_line = line;
    if (use_regions) {
      redraw_locked();
    } else {
      std::cout << '[' << slots[slot].label << "] " << line << '\n';
      std::cout.flush();
    }
  }

  void update_warn(std::size_t slot, const std::string& line) {
    std::lock_guard<std::mutex> lock(mutex);
    if (slot >= slots.size()) {
      return;
    }
    slots[slot].last_warn = line;
    if (use_regions) {
      redraw_locked();
    } else {
      std::cout << '[' << slots[slot].label << "] " << line << '\n';
      std::cout.flush();
    }
  }

  void mark_finished(std::size_t slot, int exit_code) {
    std::lock_guard<std::mutex> lock(mutex);
    if (slot >= slots.size()) {
      return;
    }
    slots[slot].exit_code = exit_code;
    slots[slot].finished = true;
    if (use_regions) {
      redraw_locked();
    } else {
      std::cout << '[' << slots[slot].label << "] finished exit=" << exit_code << '\n';
      std::cout.flush();
    }
  }

  void finish_ui() {
    std::lock_guard<std::mutex> lock(mutex);
    if (use_regions && painted) {
      std::cout << '\n';
      std::cout.flush();
    }
  }

 private:
  void redraw_locked() {
    if (!use_regions) {
      for (const SlotState& slot : slots) {
        std::cout << '[' << slot.label << "] " << slot.status_line << '\n';
      }
      std::cout.flush();
      return;
    }

    const std::size_t rows = slots.size();
    if (painted) {
      std::cout << "\033[" << rows << "A";
    }
    for (const SlotState& slot : slots) {
      std::cout << "\033[2K";
      std::cout << slot.label << "  " << slot.status_line;
      if (!slot.last_warn.empty()) {
        std::cout << "  | " << slot.last_warn;
      }
      if (slot.finished) {
        std::cout << "  exit=" << slot.exit_code;
      }
      std::cout << '\n';
    }
    std::cout.flush();
    painted = true;
  }
};

struct CommandResult {
  int exit_code{1};
};

// ── portable read-line helper (reads from a HANDLE on Win32, fd on POSIX) ──
#ifdef _WIN32
static void pipe_reader_thread(HANDLE h, std::size_t slot, PipelineUi& ui, bool is_stderr) {
  char buf[4096];
  std::string partial;
  DWORD n = 0;
  while (ReadFile(h, buf, sizeof(buf) - 1, &n, nullptr) && n > 0) {
    buf[n] = '\0';
    partial += buf;
    std::size_t pos;
    while ((pos = partial.find('\n')) != std::string::npos) {
      std::string line = partial.substr(0, pos);
      while (!line.empty() && (line.back() == '\r' || line.back() == '\n')) line.pop_back();
      partial.erase(0, pos + 1);
      if (!is_stderr && line.rfind("STATUS ", 0) == 0) {
        ui.update_status(slot, line);
      } else if (is_stderr && !line.empty()) {
        ui.update_warn(slot, line);
      }
    }
  }
  CloseHandle(h);
}
#endif

CommandResult run_command_capture_status(const std::vector<std::string>& args, std::size_t slot,
                                         PipelineUi& ui) {
#ifdef _WIN32
  // Build a single command-line string (naïve quoting — good enough for our paths)
  std::string cmdline;
  for (const auto& a : args) {
    if (!cmdline.empty()) cmdline += ' ';
    bool needs_quote = a.find(' ') != std::string::npos;
    if (needs_quote) cmdline += '"';
    cmdline += a;
    if (needs_quote) cmdline += '"';
  }

  HANDLE out_r, out_w, err_r, err_w;
  SECURITY_ATTRIBUTES sa{sizeof(SECURITY_ATTRIBUTES), nullptr, TRUE};
  if (!CreatePipe(&out_r, &out_w, &sa, 0) || !CreatePipe(&err_r, &err_w, &sa, 0))
    throw std::runtime_error("CreatePipe failed");
  SetHandleInformation(out_r, HANDLE_FLAG_INHERIT, 0);
  SetHandleInformation(err_r, HANDLE_FLAG_INHERIT, 0);

  STARTUPINFOA si{};
  si.cb = sizeof(si);
  si.dwFlags = STARTF_USESTDHANDLES;
  si.hStdOutput = out_w;
  si.hStdError  = err_w;
  si.hStdInput  = GetStdHandle(STD_INPUT_HANDLE);

  PROCESS_INFORMATION pi{};
  std::vector<char> cmdvec(cmdline.begin(), cmdline.end());
  cmdvec.push_back('\0');
  if (!CreateProcessA(nullptr, cmdvec.data(), nullptr, nullptr, TRUE, 0, nullptr, nullptr, &si, &pi)) {
    CloseHandle(out_r); CloseHandle(out_w); CloseHandle(err_r); CloseHandle(err_w);
    throw std::runtime_error("failed to spawn: " + args.front());
  }
  CloseHandle(out_w);
  CloseHandle(err_w);

  std::thread out_reader([&]() { pipe_reader_thread(out_r, slot, ui, false); });
  std::thread err_reader([&]() { pipe_reader_thread(err_r, slot, ui, true); });

  WaitForSingleObject(pi.hProcess, INFINITE);
  DWORD exit_code = 1;
  GetExitCodeProcess(pi.hProcess, &exit_code);
  CloseHandle(pi.hProcess);
  CloseHandle(pi.hThread);
  out_reader.join();
  err_reader.join();

  CommandResult result{static_cast<int>(exit_code)};
  ui.mark_finished(slot, result.exit_code);
  return result;

#else
  int out_pipe[2];
  int err_pipe[2];
  if (pipe(out_pipe) != 0 || pipe(err_pipe) != 0) {
    throw std::runtime_error("pipe failed");
  }

  posix_spawn_file_actions_t actions;
  posix_spawn_file_actions_init(&actions);
  posix_spawn_file_actions_adddup2(&actions, out_pipe[1], STDOUT_FILENO);
  posix_spawn_file_actions_adddup2(&actions, err_pipe[1], STDERR_FILENO);
  posix_spawn_file_actions_addclose(&actions, out_pipe[0]);
  posix_spawn_file_actions_addclose(&actions, err_pipe[0]);
  posix_spawn_file_actions_addclose(&actions, out_pipe[1]);
  posix_spawn_file_actions_addclose(&actions, err_pipe[1]);

  std::vector<char*> argv;
  argv.reserve(args.size() + 1);
  for (const std::string& arg : args) {
    argv.push_back(const_cast<char*>(arg.c_str()));
  }
  argv.push_back(nullptr);

  pid_t pid = 0;
  const int spawn_rc = posix_spawn(&pid, args.front().c_str(), &actions, nullptr, argv.data(), environ);
  posix_spawn_file_actions_destroy(&actions);
  close(out_pipe[1]);
  close(err_pipe[1]);
  if (spawn_rc != 0) {
    close(out_pipe[0]);
    close(err_pipe[0]);
    throw std::runtime_error("failed to spawn: " + args.front() + " (" + std::strerror(spawn_rc) + ")");
  }

  std::atomic<bool> readers_done{false};
  std::thread out_reader([&]() {
    FILE* fp = fdopen(out_pipe[0], "r");
    if (fp == nullptr) { close(out_pipe[0]); return; }
    char* line = nullptr;
    size_t cap = 0;
    while (getline(&line, &cap, fp) >= 0) {
      std::string text(line);
      while (!text.empty() && (text.back() == '\n' || text.back() == '\r')) text.pop_back();
      if (text.rfind("STATUS ", 0) == 0) ui.update_status(slot, text);
    }
    free(line);
    fclose(fp);
  });

  std::thread err_reader([&]() {
    FILE* fp = fdopen(err_pipe[0], "r");
    if (fp == nullptr) { close(err_pipe[0]); return; }
    char* line = nullptr;
    size_t cap = 0;
    while (getline(&line, &cap, fp) >= 0) {
      std::string text(line);
      while (!text.empty() && (text.back() == '\n' || text.back() == '\r')) text.pop_back();
      if (!text.empty()) ui.update_warn(slot, text);
    }
    free(line);
    fclose(fp);
  });

  int status = 0;
  waitpid(pid, &status, 0);
  out_reader.join();
  err_reader.join();
  readers_done = true;

  CommandResult result;
  if (WIFEXITED(status)) result.exit_code = WEXITSTATUS(status);
  else result.exit_code = 1;
  ui.mark_finished(slot, result.exit_code);
  return result;
#endif
}

CommandResult run_single_trace_pipeline(const std::string& input, InputKind kind,
                                        const std::string& store_path,
                                        const std::string& cast_bin, const std::string& analyze_bin,
                                        const std::string& config_path, bool force, std::size_t slot,
                                        PipelineUi& ui) {
  if (kind == InputKind::Pt) {
    std::vector<std::string> cast_args = {
        cast_bin,     "--input", input, "--store", store_path, "--config", config_path,
        "--status",   "plain",   "--log", store_path + ".cast.log"};
    if (force) {
      cast_args.push_back("--force");
    }
    const CommandResult cast_result = run_command_capture_status(cast_args, slot, ui);
    if (cast_result.exit_code != 0) {
      return cast_result;
    }
  }

  std::vector<std::string> analyze_args = {analyze_bin, "--store",  store_path, "--config",
                                           config_path, "--status", "plain",    "--log",
                                           store_path + ".analyze.log"};
  if (force) {
    analyze_args.push_back("--force");
  }
  return run_command_capture_status(analyze_args, slot, ui);
}

}  // namespace

int main(int argc, char** argv) {
  try {
    const Options options = parse_args(argc, argv);
    const std::string config_path =
        pipetrace::resolve_app_config_path(options.config_path, /*allow_env=*/true);
    const pipetrace::AppConfig config = pipetrace::load_app_config(config_path);

    std::vector<InputKind> kinds;
    kinds.reserve(options.inputs.size());
    for (const std::string& input : options.inputs) {
      kinds.push_back(detect_kind(input));
    }

    std::vector<std::string> stores;
    stores.reserve(options.inputs.size());
    for (std::size_t i = 0; i < options.inputs.size(); ++i) {
      if (kinds[i] == InputKind::Pt) {
        stores.push_back(default_store_for_pt(options.inputs[i]));
      } else {
        stores.push_back(options.inputs[i]);
      }
    }

    if (stores.size() == 2 &&
        canonical_path(stores[0]) == canonical_path(stores[1])) {
      throw std::runtime_error(
          "dual mode requires two different traces (both inputs resolve to the same store); "
          "for debug, duplicate the trace");
    }

    const std::string cast_bin =
        resolve_tool_path(config.cast_tool.command, "pipetrace-linx-parser");
    const std::string analyze_bin =
        resolve_tool_path(config.analysis_tool.command, "pipetrace-linx-analyze");
    const std::string viewer_bin = resolve_tool_path("./build/pipetrace-view", "pipetrace-view");

    PipelineUi ui(options.inputs.size() == 2 ? 2 : 1);
    ui.set_tty_mode(isatty(STDOUT_FILENO) != 0);
    for (std::size_t i = 0; i < ui.slots.size(); ++i) {
      ui.slots[i].label = options.inputs.size() == 1 ? "trace" : (i == 0 ? "trace1" : "trace2");
    }

    std::vector<CommandResult> results(options.inputs.size());
    if (options.inputs.size() == 1) {
      results[0] =
          run_single_trace_pipeline(options.inputs[0], kinds[0], stores[0], cast_bin, analyze_bin,
                                    config_path, options.force, 0, ui);
    } else {
      std::thread t0([&]() {
        results[0] =
            run_single_trace_pipeline(options.inputs[0], kinds[0], stores[0], cast_bin, analyze_bin,
                                      config_path, options.force, 0, ui);
      });
      std::thread t1([&]() {
        results[1] =
            run_single_trace_pipeline(options.inputs[1], kinds[1], stores[1], cast_bin, analyze_bin,
                                      config_path, options.force, 1, ui);
      });
      t0.join();
      t1.join();
    }

    ui.finish_ui();

    for (std::size_t i = 0; i < results.size(); ++i) {
      if (results[i].exit_code != 0) {
        std::cerr << "pipetrace-linx error: " << ui.slots[i].label
                  << " failed with exit code " << results[i].exit_code << '\n';
        return results[i].exit_code;
      }
    }

    if (stores.size() == 2) {
      PipelineUi dual_ui(1);
      dual_ui.set_tty_mode(isatty(STDOUT_FILENO) != 0);
      dual_ui.slots[0].label = "dual";
      std::vector<std::string> dual_args = {
          analyze_bin, "--store", stores[0], "--store2", stores[1], "--config", config_path,
          "--status",  "plain",   "--log",   stores[0] + ".dual.log"};
      if (options.force) {
        dual_args.push_back("--force");
      }
      const CommandResult dual_result = run_command_capture_status(dual_args, 0, dual_ui);
      dual_ui.finish_ui();
      if (dual_result.exit_code != 0) {
        std::cerr << "pipetrace-linx error: dual analysis failed\n";
        return dual_result.exit_code;
      }
    }

    std::cout << "pipeline ok";
    for (const std::string& store : stores) {
      std::cout << " store=" << store;
    }
    std::cout << '\n';

    if (options.view) {
      std::vector<std::string> view_args = {viewer_bin, "--config", config_path, stores[0]};
      if (stores.size() == 2) {
        view_args.push_back(stores[1]);
      }
#ifdef _WIN32
      std::string cmdline;
      for (const auto& a : view_args) {
        if (!cmdline.empty()) cmdline += ' ';
        bool needs_quote = a.find(' ') != std::string::npos;
        if (needs_quote) cmdline += '"';
        cmdline += a;
        if (needs_quote) cmdline += '"';
      }
      STARTUPINFOA si{}; si.cb = sizeof(si);
      PROCESS_INFORMATION pi{};
      std::vector<char> cmdvec(cmdline.begin(), cmdline.end());
      cmdvec.push_back('\0');
      if (!CreateProcessA(nullptr, cmdvec.data(), nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si, &pi))
        throw std::runtime_error("failed to launch viewer");
      WaitForSingleObject(pi.hProcess, INFINITE);
      DWORD exit_code = 1;
      GetExitCodeProcess(pi.hProcess, &exit_code);
      CloseHandle(pi.hProcess); CloseHandle(pi.hThread);
      return static_cast<int>(exit_code);
#else
      std::vector<char*> view_argv;
      for (std::string& arg : view_args) {
        view_argv.push_back(arg.data());
      }
      view_argv.push_back(nullptr);
      posix_spawn_file_actions_t actions;
      posix_spawn_file_actions_init(&actions);
      pid_t pid = 0;
      const int rc =
          posix_spawn(&pid, view_args.front().c_str(), &actions, nullptr, view_argv.data(), environ);
      posix_spawn_file_actions_destroy(&actions);
      if (rc != 0) {
        throw std::runtime_error("failed to launch viewer");
      }
      int status = 0;
      waitpid(pid, &status, 0);
      return WIFEXITED(status) ? WEXITSTATUS(status) : 1;
#endif
    }

    return 0;
  } catch (const std::exception& ex) {
    std::cerr << "pipetrace-linx error: " << ex.what() << '\n';
    return 1;
  }
}
