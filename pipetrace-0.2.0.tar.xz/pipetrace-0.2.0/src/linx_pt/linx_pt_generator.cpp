#include "pipetrace/linx_pt.hpp"

#include <algorithm>
#include <fstream>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>

namespace pipetrace {
namespace {

std::string escape_quoted(const std::string& value) {
  std::string out;
  out.reserve(value.size() + 8);
  for (char ch : value) {
    if (ch == '"') {
      out += '\\';
    }
    out += ch;
  }
  return out;
}

void write_uop_attributes(std::ostream& out, ObjectId uop_id) {
  static const char* kDisasmOps[] = {"add", "sub", "mul", "nop", "mov", "and", "or", "xor"};

  const std::string disasm = std::string(kDisasmOps[uop_id % 8]) + " r" +
                             std::to_string(uop_id % 16) + ", r" +
                             std::to_string((uop_id + 3) % 16) + " slot " +
                             std::to_string(uop_id);
  out << '[' << uop_id << "] disasm:\"" << escape_quoted(disasm) << "\"\n";
}

void write_pipeline_events(std::ostream& out, ObjectId object_id, std::int64_t events_per_object,
                           std::int64_t cycle_span, std::mt19937& rng,
                           std::vector<Timestamp>& cycles) {
  static const char* kEventTypes[] = {"fetch", "decode", "execute", "writeback"};
  static const char kEventChars[] = {'f', 'd', 'e', 'w'};

  std::uniform_int_distribution<int> cycle_dist(0, static_cast<int>(cycle_span - 1));
  std::uniform_int_distribution<int> type_dist(0, 3);

  cycles.clear();
  cycles.reserve(static_cast<std::size_t>(events_per_object));
  for (std::int64_t event_index = 0; event_index < events_per_object; ++event_index) {
    const int type_index = type_dist(rng);
    const Timestamp cycle = static_cast<Timestamp>(cycle_dist(rng));
    cycles.push_back(cycle);
    out << '[' << object_id << "] [" << cycle << "] " << kEventTypes[type_index] << '('
        << kEventChars[type_index] << ") stage:" << event_index << " VA:0x"
        << std::hex << (0x50000000U + static_cast<unsigned>(object_id)) << std::dec << '\n';
  }
}

Timestamp retire_cycle_after(const std::vector<Timestamp>& cycles, Timestamp extra) {
  Timestamp cycle = extra;
  if (!cycles.empty()) {
    cycle = std::max(cycle, *std::max_element(cycles.begin(), cycles.end()) + 1);
  }
  return cycle;
}

bool skip_retire_inst(std::int64_t inst_serial, bool partial_retire) {
  return partial_retire && inst_serial % 3 == 2;
}

bool skip_retire_uop(std::int64_t uop_index, bool partial_retire) {
  return partial_retire && uop_index == 1;
}

}  // namespace

void generate_linx_pt_trace(const LinxPtGenerateOptions& options) {
  if (options.output_path.empty()) {
    throw std::runtime_error("output path is required");
  }
  if (options.object_count <= 0) {
    throw std::runtime_error("object_count must be positive");
  }
  if (options.events_per_object <= 0) {
    throw std::runtime_error("events_per_object must be positive");
  }
  if (options.uops_per_instruction <= 0) {
    throw std::runtime_error("uops_per_instruction must be positive");
  }

  std::ofstream out(options.output_path, std::ios::trunc);
  if (!out) {
    throw std::runtime_error("failed to open output: " + options.output_path);
  }

  std::mt19937 rng(static_cast<std::uint32_t>(options.seed));
  std::vector<Timestamp> cycles;

  if (!options.include_tree) {
    for (std::int64_t uop_index = 0; uop_index < options.object_count; ++uop_index) {
      const ObjectId uop_id = static_cast<ObjectId>(uop_index);
      out << '[' << uop_id << "] type:Uop parent:-1\n";
      write_uop_attributes(out, uop_id);
      write_pipeline_events(out, uop_id, options.events_per_object, options.cycle_span, rng,
                            cycles);
      const Timestamp retire_cycle = retire_cycle_after(cycles, static_cast<Timestamp>(uop_index));
      out << '[' << uop_id << "] [" << retire_cycle << "] retire_uop(R)\n";
    }
    return;
  }

  const std::int64_t instruction_count =
      (options.object_count + options.uops_per_instruction - 1) / options.uops_per_instruction;
  ObjectId next_id = 0;

  for (std::int64_t inst_serial = 0; inst_serial < instruction_count; ++inst_serial) {
    const ObjectId inst_id = next_id++;
    out << '[' << inst_id << "] type:Instruction parent:-1\n";

    const std::int64_t uops_remaining = options.object_count - inst_serial * options.uops_per_instruction;
    const std::int64_t uops_this_instruction =
        std::min(options.uops_per_instruction, uops_remaining);

    Timestamp inst_retire_cycle = static_cast<Timestamp>(inst_serial);
    for (std::int64_t uop_index = 0; uop_index < uops_this_instruction; ++uop_index) {
      const ObjectId uop_id = next_id++;
      out << '[' << uop_id << "] type:Uop parent:" << inst_id << '\n';
      write_uop_attributes(out, uop_id);
      write_pipeline_events(out, uop_id, options.events_per_object, options.cycle_span, rng,
                            cycles);
      if (!skip_retire_uop(uop_index, options.partial_retire)) {
        const Timestamp retire_cycle =
            retire_cycle_after(cycles, static_cast<Timestamp>(uop_id + uop_index + 1));
        out << '[' << uop_id << "] [" << retire_cycle << "] retire_uop(R)\n";
        inst_retire_cycle = std::max(inst_retire_cycle, retire_cycle + 1);
      }
    }

    if (!skip_retire_inst(inst_serial, options.partial_retire)) {
      out << '[' << inst_id << "] [" << inst_retire_cycle << "] retire_inst(R) InstID:" << inst_serial
          << '\n';
    }
  }
}

}  // namespace pipetrace
