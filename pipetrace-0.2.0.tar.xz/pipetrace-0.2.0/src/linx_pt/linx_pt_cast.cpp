#include "pipetrace/linx_pt.hpp"

#include "pipetrace/app_config.hpp"
#include "pipetrace/attributes.hpp"
#include "linx_pt/linx_pt_parser.hpp"
#include "storage/sqlite_store.hpp"

#include <algorithm>
#include <cctype>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <sys/stat.h>
#include <unordered_map>
#include <vector>

namespace pipetrace {
namespace {

constexpr ObjectId kNoParent = -1;
constexpr std::size_t kEventBatchSize = 8192;

char normalize_display_char(const char value, const std::string& fallback_name) {
  const unsigned char uchar = static_cast<unsigned char>(value);
  if (value != '\0' && uchar >= 32 && uchar != 127) {
    return value;
  }
  if (!fallback_name.empty()) {
    const char candidate =
        static_cast<char>(std::toupper(static_cast<unsigned char>(fallback_name[0])));
    if (candidate >= 32 && candidate != 127) {
      return candidate;
    }
  }
  return '?';
}

struct ObjectAccum {
  bool seen{false};
  ObjectId parent_id{kNoParent};
  std::vector<std::pair<std::string, std::string>> attributes;
  Timestamp first_time{std::numeric_limits<Timestamp>::max()};
  Timestamp last_time{std::numeric_limits<Timestamp>::min()};
  bool has_events{false};
};

struct PendingEvent {
  ObjectId object_id{};
  Timestamp cycle{};
  std::int64_t event_type_id{};
  std::string kind;
  std::string attributes_json;
};

struct EventTypeInfo {
  std::int64_t id{};
  char display_char{'?'};
  std::uint32_t color_rgba{kUnassignedEventTypeColor};
  bool char_from_trace{false};
};

std::string field_value(const std::vector<std::pair<std::string, std::string>>& fields,
                        const std::string& key) {
  for (const auto& [field_key, value] : fields) {
    if (field_key == key) {
      return value;
    }
  }
  return {};
}

void merge_attribute_fields(ObjectAccum& object,
                            const std::vector<linx_pt::ParsedField>& fields) {
  for (const linx_pt::ParsedField& field : fields) {
    if (field.key == "parent") {
      object.parent_id = static_cast<ObjectId>(std::stoll(field.value));
      continue;
    }
    auto existing = std::find_if(object.attributes.begin(), object.attributes.end(),
                                 [&](const auto& entry) { return entry.first == field.key; });
    if (existing != object.attributes.end()) {
      existing->second = field.value;
    } else {
      object.attributes.emplace_back(field.key, field.value);
    }
  }
}

ObjectAccum& object_for_id(std::unordered_map<ObjectId, ObjectAccum>& objects,
                           ObjectId object_id) {
  ObjectAccum& object = objects[object_id];
  object.seen = true;
  return object;
}

std::string default_trace_name(const std::string& input_path) {
  return std::filesystem::path(input_path).stem().string();
}

std::int64_t file_mtime_seconds(const std::string& path) {
  struct stat st {};
  if (stat(path.c_str(), &st) != 0) {
    throw std::runtime_error("failed to stat input: " + path);
  }
  return static_cast<std::int64_t>(st.st_mtime);
}

}  // namespace

LinxPtCastStats cast_linx_pt_to_store(const LinxPtCastOptions& options) {
  LinxPtCastStats stats;
  if (options.input_path.empty() || options.store_path.empty()) {
    throw std::runtime_error("input and store paths are required");
  }

  const std::string absolute_input =
      std::filesystem::absolute(std::filesystem::path(options.input_path)).string();
  const std::int64_t input_mtime = file_mtime_seconds(options.input_path);

  if (!options.force && std::filesystem::exists(options.store_path)) {
    SqliteStore existing;
    if (existing.open(options.store_path)) {
      const std::optional<std::string> stored_path = existing.meta_value("source_trace_path");
      const std::optional<std::string> stored_mtime = existing.meta_value("source_trace_mtime");
      if (stored_path.has_value() && *stored_path == absolute_input && stored_mtime.has_value() &&
          *stored_mtime == std::to_string(input_mtime)) {
        stats.cast_skipped = true;
        if (options.progress != nullptr) {
          options.progress->set_phase("cast");
          options.progress->finish("skipped", "store_up_to_date");
        } else if (options.verbose) {
          std::cerr << "cast skipped: store up to date\n";
        }
        return stats;
      }
    }
  }

  if (options.progress != nullptr) {
    options.progress->set_phase("parse", "lines");
  }

  std::ifstream input(options.input_path);
  if (!input) {
    throw std::runtime_error("failed to open input: " + options.input_path);
  }

  AppConfig app_config = load_app_config(options.config_path);
  if (app_config.cast_tool.command.empty()) {
    app_config.cast_tool.command = "./build/pipetrace-linx-parser";
  }

  std::unordered_map<ObjectId, ObjectAccum> objects;
  objects.reserve(65536);

  std::unordered_map<std::string, EventTypeInfo> event_types;
  std::unordered_map<std::string, char> trace_char_hints;
  std::vector<PendingEvent> pending_events;
  pending_events.reserve(kEventBatchSize);
  std::int64_t next_event_type_id = 0;

  std::string line;
  std::size_t line_number = 0;
  while (std::getline(input, line)) {
    ++line_number;
    ++stats.lines_read;

    const linx_pt::ParseResult parsed = linx_pt::parse_line(line);
    if (parsed.status == linx_pt::ParseStatus::Skip) {
      ++stats.lines_skipped;
      continue;
    }
    if (parsed.status == linx_pt::ParseStatus::Error) {
      throw std::runtime_error("line " + std::to_string(line_number) + ": " + parsed.message);
    }

    ++stats.lines_parsed;
    if (options.progress != nullptr) {
      options.progress->set_counts(stats.lines_read, 0, "lines");
    }
    if (parsed.attribute.has_value()) {
      const linx_pt::AttributeLine& attribute = *parsed.attribute;
      merge_attribute_fields(object_for_id(objects, attribute.object_id), attribute.fields);
      continue;
    }

    if (!parsed.event.has_value()) {
      continue;
    }

    const linx_pt::EventLine& event = *parsed.event;
    ObjectAccum& object = object_for_id(objects, event.object_id);
    object.has_events = true;
    object.first_time = std::min(object.first_time, event.cycle);
    object.last_time = std::max(object.last_time, event.cycle);

    if (event.display_char_hint.has_value()) {
      const char hint = *event.display_char_hint;
      const auto [it, inserted] = trace_char_hints.try_emplace(event.event_type, hint);
      if (!inserted && it->second != hint) {
        ++stats.warnings;
        const std::string warning =
            "conflicting display char for event type '" + event.event_type + "'; keeping first";
        if (options.progress != nullptr) {
          options.progress->warn(warning);
        } else {
          std::cerr << "warning: " << warning << '\n';
        }
      }
    }

    EventTypeInfo& type_info = event_types[event.event_type];
    if (type_info.id == 0) {
      type_info.id = ++next_event_type_id;
    }

    PendingEvent pending;
    pending.object_id = event.object_id;
    pending.cycle = event.cycle;
    pending.event_type_id = type_info.id;
    pending.kind = event.event_type;
    std::vector<std::pair<std::string, std::string>> attrs;
    attrs.reserve(event.attributes.size());
    for (const linx_pt::ParsedField& field : event.attributes) {
      attrs.emplace_back(field.key, field.value);
    }
    pending.attributes_json = format_object_attributes_json(attrs);
    pending_events.push_back(std::move(pending));
    ++stats.events;
  }

  stats.objects = objects.size();

  std::vector<EventTypeDisplay> discovered_types;
  discovered_types.reserve(event_types.size());
  for (auto& [name, info] : event_types) {
    EventTypeDisplay display;
    display.name = name;
    if (EventTypeDisplay* existing = app_config.find_event_type_display(name)) {
      display.display_char = existing->display_char;
      // Preserve user-set colors from config; leave unset/sentinel for analyze to invent.
      display.color_rgba = existing->color_rgba;
    } else {
      const auto hint_it = trace_char_hints.find(name);
      display.display_char =
          normalize_display_char(hint_it != trace_char_hints.end() ? hint_it->second : '\0', name);
      display.color_rgba = kUnassignedEventTypeColor;
      discovered_types.push_back(display);
    }
    info.display_char = display.display_char;
    info.color_rgba = display.color_rgba;
  }

  stats.config_entries_added = merge_event_type_display(app_config, discovered_types);
  if (stats.config_entries_added > 0 || !options.config_path.empty()) {
    save_app_config(options.config_path, app_config);
  }

  if (std::filesystem::exists(options.store_path)) {
    std::filesystem::remove(options.store_path);
  }

  if (options.progress != nullptr) {
    options.progress->set_phase("write", "store");
    options.progress->set_counts(0, static_cast<std::uint64_t>(objects.size()) +
                                        pending_events.size(),
                                 "rows");
  }

  SqliteStore store;
  if (!store.open(options.store_path)) {
    throw std::runtime_error("failed to open store: " + options.store_path);
  }

  store.exec_sql("PRAGMA synchronous=OFF;");
  store.exec_sql("PRAGMA journal_mode=MEMORY;");
  store.exec_sql("BEGIN IMMEDIATE;");

  const std::string trace_name =
      options.trace_name.empty() ? default_trace_name(options.input_path) : options.trace_name;

  store.insert_object_type(1, "object", "Object");
  for (const auto& [name, info] : event_types) {
    store.insert_event_type(info.id, name, 1, info.color_rgba);
    store.insert_event_type_display(info.id, info.display_char, info.color_rgba);
  }

  Timestamp min_time = std::numeric_limits<Timestamp>::max();
  Timestamp max_time = std::numeric_limits<Timestamp>::min();
  std::int64_t object_count = 0;

  for (const auto& [object_id, object] : objects) {
    if (!object.seen) {
      continue;
    }

    const std::string object_type_name = field_value(object.attributes, "type");
    const std::string object_name =
        field_value(object.attributes, "name");
    const std::string resolved_name =
        object_name.empty() ? ("obj_" + std::to_string(object_id)) : object_name;

    std::vector<std::pair<std::string, std::string>> stored_attrs = object.attributes;
    stored_attrs.erase(std::remove_if(stored_attrs.begin(), stored_attrs.end(),
                                      [](const auto& entry) {
                                        return entry.first == "parent" || entry.first == "name";
                                      }),
                       stored_attrs.end());

    Timestamp first_time = object.has_events ? object.first_time : 0;
    Timestamp last_time = object.has_events ? object.last_time : 0;
    if (object.has_events) {
      min_time = std::min(min_time, first_time);
      max_time = std::max(max_time, last_time);
    }

    store.insert_object(object_id, 1, resolved_name, first_time, last_time, object.parent_id,
                        format_object_attributes_json(stored_attrs));
    ++object_count;
    if (options.progress != nullptr) {
      options.progress->set_counts(static_cast<std::uint64_t>(object_count),
                                   static_cast<std::uint64_t>(objects.size()) +
                                       pending_events.size(),
                                   "objects");
    }
  }

  EventId next_event_id = 0;
  for (const PendingEvent& pending : pending_events) {
    store.insert_event(++next_event_id, pending.object_id, pending.event_type_id, pending.kind,
                       pending.cycle, pending.attributes_json);
    min_time = std::min(min_time, pending.cycle);
    max_time = std::max(max_time, pending.cycle);
    if (options.progress != nullptr) {
      options.progress->set_counts(static_cast<std::uint64_t>(object_count + next_event_id),
                                   static_cast<std::uint64_t>(objects.size()) +
                                       pending_events.size(),
                                   "events");
    }
  }

  if (stats.events == 0) {
    min_time = 0;
    max_time = 0;
  }

  store.set_meta(trace_name, min_time, max_time, object_count,
                 static_cast<std::int64_t>(pending_events.size()));
  store.set_meta_value("source_trace_path", absolute_input);
  store.set_meta_value("source_trace_mtime", std::to_string(input_mtime));
  store.set_meta_value("cast_at", std::to_string(static_cast<std::int64_t>(std::time(nullptr))));
  store.set_meta_value("analysis_state", "Raw");
  store.refresh_object_attribute_keys();
  store.exec_sql("COMMIT;");

  if (options.progress != nullptr) {
    options.progress->log("cast complete objects=" + std::to_string(object_count) +
                          " events=" + std::to_string(pending_events.size()) +
                          " warnings=" + std::to_string(stats.warnings));
    options.progress->set_counts(static_cast<std::uint64_t>(object_count + pending_events.size()),
                                 static_cast<std::uint64_t>(object_count + pending_events.size()),
                                 "done");
    options.progress->finish("ok");
  } else if (options.verbose) {
    std::cerr << "cast complete: objects=" << object_count << " events=" << pending_events.size()
              << " warnings=" << stats.warnings << " config_added=" << stats.config_entries_added
              << '\n';
  }

  return stats;
}

}  // namespace pipetrace
