#include "linx_pt/linx_pt_parser.hpp"

#include <cctype>
#include <cstdint>

namespace pipetrace {
namespace linx_pt {
namespace {

void skip_ws(const std::string& line, std::size_t& i) {
  while (i < line.size() && std::isspace(static_cast<unsigned char>(line[i]))) {
    ++i;
  }
}

bool parse_uint64(const std::string& line, std::size_t& i, std::int64_t& out) {
  skip_ws(line, i);
  if (i >= line.size() || line[i] != '[') {
    return false;
  }
  ++i;
  std::size_t start = i;
  while (i < line.size() && std::isdigit(static_cast<unsigned char>(line[i]))) {
    ++i;
  }
  if (start == i || i >= line.size() || line[i] != ']') {
    return false;
  }
  ++i;
  out = std::stoll(line.substr(start, i - start));
  ++i;
  return true;
}

bool parse_identifier(const std::string& line, std::size_t& i, std::string& out) {
  skip_ws(line, i);
  const std::size_t start = i;
  while (i < line.size() && is_ident_char(line[i])) {
    ++i;
  }
  if (start == i) {
    return false;
  }
  out = line.substr(start, i - start);
  return true;
}

bool parse_value_token(const std::string& line, std::size_t& i, std::string& out) {
  skip_ws(line, i);
  if (i >= line.size()) {
    return false;
  }
  if (line[i] == '"') {
    ++i;
    const std::size_t start = i;
    while (i < line.size()) {
      if (line[i] == '\\' && i + 1 < line.size()) {
        i += 2;
        continue;
      }
      if (line[i] == '"') {
        out = line.substr(start, i - start);
        ++i;
        return true;
      }
      ++i;
    }
    return false;
  }

  const std::size_t start = i;
  while (i < line.size() && !std::isspace(static_cast<unsigned char>(line[i]))) {
    ++i;
  }
  if (start == i) {
    return false;
  }
  out = line.substr(start, i - start);
  return true;
}

bool parse_fields(const std::string& line, std::size_t& i, std::vector<ParsedField>& fields,
                  bool allow_event_type_token, std::string& event_type,
                  std::optional<char>& event_char_hint) {
  while (true) {
    skip_ws(line, i);
    if (i >= line.size()) {
      return true;
    }

    std::string ident;
    if (!parse_identifier(line, i, ident)) {
      return false;
    }

    if (i < line.size() && line[i] == '(') {
      if (!allow_event_type_token) {
        return false;
      }
      ++i;
      if (i >= line.size()) {
        return false;
      }
      const char hint = line[i];
      ++i;
      if (i >= line.size() || line[i] != ')') {
        return false;
      }
      ++i;
      event_type = ident;
      event_char_hint = hint;
      allow_event_type_token = false;
      continue;
    }

    if (i >= line.size() || line[i] != ':') {
      return false;
    }
    ++i;
    ParsedField field;
    field.key = ident;
    if (!parse_value_token(line, i, field.value)) {
      return false;
    }
    fields.push_back(std::move(field));
  }
}

}  // namespace

bool is_ident_char(const char ch) {
  return std::isalnum(static_cast<unsigned char>(ch)) || ch == '_';
}

ParseResult parse_line(const std::string& line) {
  ParseResult result;
  std::size_t i = 0;
  skip_ws(line, i);
  if (i >= line.size()) {
    result.status = ParseStatus::Skip;
    return result;
  }

  std::int64_t object_id = 0;
  if (!parse_uint64(line, i, object_id)) {
    result.status = ParseStatus::Error;
    result.message = "missing object id prefix";
    return result;
  }

  skip_ws(line, i);
  if (i < line.size() && line[i] == '[') {
    EventLine event;
    event.object_id = object_id;
    if (!parse_uint64(line, i, event.cycle)) {
      result.status = ParseStatus::Error;
      result.message = "missing cycle prefix";
      return result;
    }
    if (!parse_fields(line, i, event.attributes, true, event.event_type,
                      event.display_char_hint)) {
      result.status = ParseStatus::Error;
      result.message = "failed to parse event fields";
      return result;
    }
    if (event.event_type.empty()) {
      result.status = ParseStatus::Error;
      result.message = "event line missing event_type";
      return result;
    }

    std::unordered_map<std::string, bool> seen_keys;
    for (const ParsedField& field : event.attributes) {
      if (seen_keys[field.key]) {
        result.status = ParseStatus::Error;
        result.message = "duplicate event attribute key: " + field.key;
        return result;
      }
      seen_keys[field.key] = true;
    }

    result.status = ParseStatus::Ok;
    result.event = std::move(event);
    return result;
  }

  AttributeLine attribute;
  attribute.object_id = object_id;
  std::string unused_type;
  std::optional<char> unused_char;
  if (!parse_fields(line, i, attribute.fields, false, unused_type, unused_char)) {
    result.status = ParseStatus::Error;
    result.message = "failed to parse attribute fields";
    return result;
  }
  if (attribute.fields.empty()) {
    result.status = ParseStatus::Error;
    result.message = "attribute line has no fields";
    return result;
  }

  result.status = ParseStatus::Ok;
  result.attribute = std::move(attribute);
  return result;
}

}  // namespace linx_pt
}  // namespace pipetrace
