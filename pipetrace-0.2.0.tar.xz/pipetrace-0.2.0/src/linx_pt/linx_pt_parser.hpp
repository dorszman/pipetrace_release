#pragma once

#include <cstdint>
#include <optional>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include "pipetrace/types.hpp"

namespace pipetrace {
namespace linx_pt {

struct ParsedField {
  std::string key;
  std::string value;
  std::optional<char> display_char_hint;
};

struct AttributeLine {
  std::int64_t object_id{};
  std::vector<ParsedField> fields;
};

struct EventLine {
  std::int64_t object_id{};
  Timestamp cycle{};
  std::string event_type;
  std::optional<char> display_char_hint;
  std::vector<ParsedField> attributes;
};

enum class ParseStatus { Ok, Skip, Error };

struct ParseResult {
  ParseStatus status{ParseStatus::Skip};
  std::optional<AttributeLine> attribute;
  std::optional<EventLine> event;
  std::string message;
};

bool is_ident_char(char ch);
ParseResult parse_line(const std::string& line);

}  // namespace linx_pt
}  // namespace pipetrace
