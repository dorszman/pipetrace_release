#include <iostream>
#include <string>

#include "pipetrace/generator.hpp"
#include "pipetrace/importer.hpp"
#include "pipetrace/storage.hpp"

namespace {

void print_usage() {
  std::cout << "pipetrace-ptj-synthgen <command> [options]\n"
            << "Commands:\n"
            << "  generate [--generic] [--objects N] [--width W] [--output path.ptj]\n"
            << "  import   --input path.ptj [--store path.db]\n"
            << "  info     --store path.db\n";
}

}  // namespace

int main(int argc, char** argv) {
  if (argc < 2) {
    print_usage();
    return 1;
  }

  const std::string command = argv[1];

  if (command == "generate") {
    bool generic = false;
    std::int64_t object_count = 1000;
    std::int64_t decode_width = 4;
    std::string output = "data/sample.ptj";

    for (int i = 2; i < argc; ++i) {
      const std::string arg = argv[i];
      if (arg == "--generic") {
        generic = true;
      } else if (arg == "--objects" && i + 1 < argc) {
        object_count = std::stoll(argv[++i]);
      } else if (arg == "--width" && i + 1 < argc) {
        decode_width = std::stoll(argv[++i]);
      } else if (arg == "--output" && i + 1 < argc) {
        output = argv[++i];
      }
    }

    pipetrace::GeneratorConfig config;
    config.object_count = object_count;
    config.time_span = 100000;
    config.seed = 42;

    pipetrace::TraceMeta meta;
    if (generic) {
      meta = pipetrace::generate_generic_trace(config, output);
    } else {
      pipetrace::CpuPipelineConfig cpu_config;
      cpu_config.object_count = config.object_count;
      cpu_config.time_span = config.time_span;
      cpu_config.seed = config.seed;
      cpu_config.decode_width = decode_width;
      meta = pipetrace::generate_cpu_pipeline_trace(cpu_config, output);
    }

    std::cout << "trace=" << meta.name << " objects=" << meta.object_count
              << " events=" << meta.event_count << " store=" << output << ".db\n";
    return 0;
  }

  if (command == "import") {
    std::string input;
    std::string store;
    for (int i = 2; i < argc; ++i) {
      const std::string arg = argv[i];
      if (arg == "--input" && i + 1 < argc) {
        input = argv[++i];
      } else if (arg == "--store" && i + 1 < argc) {
        store = argv[++i];
      }
    }
    if (input.empty()) {
      print_usage();
      return 1;
    }
    if (store.empty()) {
      store = input + ".db";
    }

    const pipetrace::TraceMeta meta = pipetrace::import_ptj_trace(input, store);
    std::cout << "imported " << meta.object_count << " objects, " << meta.event_count
              << " events into " << store << '\n';
    return 0;
  }

  if (command == "info") {
    std::string store;
    for (int i = 2; i < argc; ++i) {
      if (std::string(argv[i]) == "--store" && i + 1 < argc) {
        store = argv[++i];
      }
    }
    if (store.empty()) {
      print_usage();
      return 1;
    }

    auto trace_store = pipetrace::create_sqlite_store();
    if (!trace_store->open(store)) {
      std::cerr << "failed to open store: " << store << '\n';
      return 1;
    }

    const pipetrace::TraceMeta meta = trace_store->meta();
    std::cout << "name=" << meta.name << '\n'
              << "objects=" << meta.object_count << '\n'
              << "events=" << meta.event_count << '\n'
              << "time=[" << meta.min_time << ", " << meta.max_time << "]\n";

    for (const auto& event_type : trace_store->event_types()) {
      std::cout << "event_type " << event_type.name << " char='" << event_type.display_char
                << "' color=" << std::hex << event_type.color_rgba << std::dec << '\n';
    }
    return 0;
  }

  print_usage();
  return 1;
}
