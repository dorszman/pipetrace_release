#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <memory>
#include <string>

#include "pipetrace/app_config.hpp"
#include "pipetrace/linx_pt.hpp"
#include "pipetrace/progress.hpp"

namespace {

struct Options {
  std::string input_path;
  std::string store_path;
  std::string config_path;
  std::string trace_name;
  std::string log_path;
  pipetrace::StatusMode status_mode{pipetrace::StatusMode::Pretty};
  bool verbose{false};
  bool force{false};
};

Options parse_args(int argc, char** argv) {
  Options options;
  for (int i = 1; i < argc; ++i) {
    const std::string arg = argv[i];
    if (arg == "--input" && i + 1 < argc) {
      options.input_path = argv[++i];
    } else if (arg == "--store" && i + 1 < argc) {
      options.store_path = argv[++i];
    } else if (arg == "--config" && i + 1 < argc) {
      options.config_path = argv[++i];
    } else if (arg == "--trace-name" && i + 1 < argc) {
      options.trace_name = argv[++i];
    } else if (arg == "--log" && i + 1 < argc) {
      options.log_path = argv[++i];
    } else if (arg == "--status" && i + 1 < argc) {
      options.status_mode = pipetrace::parse_status_mode(argv[++i]);
    } else if (arg == "--verbose") {
      options.verbose = true;
    } else if (arg == "--force") {
      options.force = true;
    } else if (arg == "--help") {
      std::cout << "pipetrace-linx-parser --input PATH --store PATH --config PATH "
                   "[--trace-name NAME] [--log PATH] "
                   "[--status pretty|plain] [--verbose] [--force]\n"
                   "  --config PATH is required.\n";
      std::exit(0);
    } else {
      throw std::runtime_error("unknown argument: " + arg);
    }
  }
  if (options.input_path.empty() || options.store_path.empty()) {
    throw std::runtime_error("--input and --store are required");
  }
  if (options.config_path.empty()) {
    throw std::runtime_error("--config is required");
  }
  if (options.log_path.empty()) {
    options.log_path = options.store_path + ".cast.log";
  }
  return options;
}

}  // namespace

int main(int argc, char** argv) {
  try {
    const Options options = parse_args(argc, argv);
    const std::string config_path =
        pipetrace::resolve_app_config_path(options.config_path, /*allow_env=*/false);
    pipetrace::ProgressReporter progress("cast", options.status_mode, options.log_path);

    pipetrace::LinxPtCastOptions cast_options;
    cast_options.input_path = options.input_path;
    cast_options.store_path = options.store_path;
    cast_options.config_path = config_path;
    cast_options.trace_name = options.trace_name;
    cast_options.log_path = options.log_path;
    cast_options.status_mode = options.status_mode;
    cast_options.verbose = options.verbose;
    cast_options.force = options.force;
    cast_options.progress = &progress;

    (void)pipetrace::cast_linx_pt_to_store(cast_options);
    return 0;
  } catch (const std::exception& ex) {
    std::cerr << "pipetrace-linx-parser error: " << ex.what() << '\n';
    return 1;
  }
}
