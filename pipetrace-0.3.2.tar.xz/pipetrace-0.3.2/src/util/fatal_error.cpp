#include "pipetrace/fatal_error.hpp"

#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <exception>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <mutex>
#include <string>

#if defined(_WIN32)
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#endif

namespace pipetrace {
namespace {

std::mutex& log_mutex() {
  static std::mutex mutex;
  return mutex;
}

#if defined(_WIN32)
std::wstring utf8_to_wide(const std::string& utf8) {
  if (utf8.empty()) {
    return {};
  }
  const int needed =
      MultiByteToWideChar(CP_UTF8, 0, utf8.data(), static_cast<int>(utf8.size()), nullptr, 0);
  if (needed <= 0) {
    return {};
  }
  std::wstring wide(static_cast<std::size_t>(needed), L'\0');
  MultiByteToWideChar(CP_UTF8, 0, utf8.data(), static_cast<int>(utf8.size()), wide.data(), needed);
  return wide;
}

std::filesystem::path executable_log_path() {
  std::wstring buf(32768, L'\0');
  const DWORD n = GetModuleFileNameW(nullptr, buf.data(), static_cast<DWORD>(buf.size()));
  if (n == 0 || n >= buf.size()) {
    return std::filesystem::path("pipetrace-view.log");
  }
  buf.resize(n);
  return std::filesystem::path(buf).parent_path() / "pipetrace-view.log";
}
#else
std::filesystem::path executable_log_path() {
  std::error_code ec;
  const std::filesystem::path self = std::filesystem::read_symlink("/proc/self/exe", ec);
  if (!ec && !self.empty()) {
    return self.parent_path() / "pipetrace-view.log";
  }
  return std::filesystem::path("pipetrace-view.log");
}
#endif

void append_log_line(const std::string& line) {
  try {
    std::lock_guard lock(log_mutex());
    const auto path = executable_log_path();
    std::ofstream out(path, std::ios::app);
    if (!out) {
      return;
    }
    const auto now = std::chrono::system_clock::now();
    const std::time_t t = std::chrono::system_clock::to_time_t(now);
    char time_buf[32] = {};
#if defined(_WIN32)
    ctime_s(time_buf, sizeof(time_buf), &t);
#else
    // ctime_r writes a newline-terminated string into time_buf.
    ctime_r(&t, time_buf);
#endif
    // Strip trailing newline from ctime for a single-line prefix.
    for (char& ch : time_buf) {
      if (ch == '\n' || ch == '\r') {
        ch = '\0';
        break;
      }
    }
    out << time_buf << " | " << line << '\n';
  } catch (...) {
    // Logging must never throw.
  }
}

[[noreturn]] void terminate_handler() {
  std::string message = "std::terminate called";
  try {
    if (const std::exception_ptr ep = std::current_exception()) {
      try {
        std::rethrow_exception(ep);
      } catch (const std::exception& ex) {
        message = std::string("std::terminate: uncaught exception: ") + ex.what();
      } catch (...) {
        message = "std::terminate: uncaught non-std exception";
      }
    }
  } catch (...) {
    message = "std::terminate: failed while inspecting exception";
  }
  append_log_line(message);
  std::cerr << message << '\n';
  std::cerr.flush();
  std::abort();
}

#if defined(_WIN32)
LONG WINAPI unhandled_exception_filter(EXCEPTION_POINTERS* info) {
  std::string message = "Unhandled Win32 exception";
  if (info != nullptr && info->ExceptionRecord != nullptr) {
    char buf[128];
    std::snprintf(buf, sizeof(buf), "Unhandled Win32 exception 0x%08lX at %p",
                  static_cast<unsigned long>(info->ExceptionRecord->ExceptionCode),
                  info->ExceptionRecord->ExceptionAddress);
    message = buf;
  }
  append_log_line(message);
  const std::wstring wide = utf8_to_wide(message + "\n\nDetails were written to pipetrace-view.log "
                                                   "next to pipetrace-view.exe.");
  MessageBoxW(nullptr, wide.c_str(), L"pipetrace-view", MB_OK | MB_ICONERROR | MB_SETFOREGROUND);
  return EXCEPTION_EXECUTE_HANDLER;
}
#endif

}  // namespace

void append_diagnostic_log(const std::string& message) { append_log_line(message); }

void install_crash_handlers() {
  static bool installed = false;
  if (installed) {
    return;
  }
  installed = true;
  std::set_terminate(terminate_handler);
#if defined(_WIN32)
  SetUnhandledExceptionFilter(unhandled_exception_filter);
#endif
  append_log_line("crash handlers installed");
}

void report_fatal_error(const std::string& title, const std::string& message) {
  const std::string line = title + ": " + message;
  std::cerr << line << '\n';
  std::cerr.flush();
  append_log_line(line);

#if defined(_WIN32)
  const std::wstring wide_title = utf8_to_wide(title);
  const std::wstring wide_message = utf8_to_wide(message);
  MessageBoxW(nullptr, wide_message.empty() ? L"(no details)" : wide_message.c_str(),
              wide_title.empty() ? L"pipetrace" : wide_title.c_str(),
              MB_OK | MB_ICONERROR | MB_SETFOREGROUND);
#endif
}

}  // namespace pipetrace
