#include "pipetrace/store_readiness.hpp"

#include <optional>
#include <sstream>

#include "pipetrace/sort_sql.hpp"
#include "storage/sqlite_store.hpp"

namespace pipetrace {
namespace {

constexpr const char* kAnalysisStateKey = "analysis_state";
constexpr const char* kAnalysisAtKey = "analyzed_at";
constexpr const char* kAnalysisStateRaw = "Raw";
constexpr const char* kAnalysisStateAnalyzed = "Analyzed";
constexpr const char* kAnalysisStateDualAnalyzed = "DualAnalyzed";

}  // namespace

bool is_analysis_state_viewable(const std::string& analysis_state) {
  return analysis_state == kAnalysisStateAnalyzed ||
         analysis_state == kAnalysisStateDualAnalyzed;
}

std::string resolve_analysis_state(const SqliteStore& store) {
  if (const std::optional<std::string> state = store.meta_value(kAnalysisStateKey)) {
    if (!state->empty()) {
      return *state;
    }
  }
  // Legacy DBs without analysis_state: analyzed_at ⇒ Analyzed, else Raw.
  if (store.meta_value(kAnalysisAtKey).has_value()) {
    return kAnalysisStateAnalyzed;
  }
  return kAnalysisStateRaw;
}

std::string StoreViewReadiness::message(const std::string& store_path) const {
  if (ready) {
    return "Store is ready for viewing.";
  }

  std::ostringstream out;
  out << "This store is not analyzed (or is missing prep tables required by the "
         "current config). Run pipetrace-linx (or analyze) before opening in the "
         "viewer.";
  if (!store_path.empty()) {
    out << "\n\nStore: " << store_path;
  }
  if (!analysis_state.empty()) {
    out << "\nanalysis_state: " << analysis_state;
  }
  if (!missing.empty()) {
    out << "\n\nMissing:";
    for (const std::string& item : missing) {
      out << "\n- " << item;
    }
  }
  return out.str();
}

StoreViewReadiness check_store_view_readiness(const SqliteStore& store,
                                              const AppConfig& config) {
  StoreViewReadiness result;
  result.analysis_state = resolve_analysis_state(store);

  if (!is_analysis_state_viewable(result.analysis_state)) {
    result.missing.push_back("analysis_state is " + result.analysis_state +
                             " (expected Analyzed or DualAnalyzed)");
  }

  if (!config.search_attributes.empty()) {
    const std::string expected = build_search_attributes_fingerprint(config.search_attributes);
    const std::optional<std::string> existing = store.object_search_values_fingerprint();
    if (!existing.has_value() || existing->empty()) {
      result.missing.push_back(
          "search index missing (object_search_value / object_search_values_fingerprint); "
          "run analyze or --search-index-only");
    } else if (*existing != expected) {
      result.missing.push_back(
          "search index fingerprint mismatch for search_attributes (re-analyze or "
          "--search-index-only)");
    } else {
      for (const std::string& key : config.search_attributes) {
        if (!store.has_object_search_values(key)) {
          result.missing.push_back("search index missing key: " + key);
        }
      }
    }
  }

  if (config.has_sync_attribute()) {
    if (!is_valid_attribute_sort_key(config.sync_attribute)) {
      result.missing.push_back("sync_attribute key is invalid: " + config.sync_attribute);
    } else if (!store.has_object_search_values(config.sync_attribute)) {
      result.missing.push_back(
          "sync_attribute \"" + config.sync_attribute +
          "\" missing from object_search_value (add to search_attributes and re-analyze)");
    }
  }

  bool any_sort_scheme = false;
  for (const SortScheme& scheme : config.sort_schemes) {
    if (!scheme.name.empty() && !scheme.columns.empty()) {
      any_sort_scheme = true;
      break;
    }
  }
  if (any_sort_scheme) {
    const std::string expected = build_sort_schemes_fingerprint(config.sort_schemes);
    const std::optional<std::string> existing = store.object_sort_ranks_fingerprint();
    if (!existing.has_value() || existing->empty()) {
      result.missing.push_back(
          "sort ranks missing (object_sort_rank / object_sort_ranks_fingerprint); run analyze");
    } else if (*existing != expected) {
      result.missing.push_back(
          "sort ranks fingerprint mismatch for sort_schemes (re-analyze with --force)");
    } else {
      for (const SortScheme& scheme : config.sort_schemes) {
        if (scheme.name.empty() || scheme.columns.empty()) {
          continue;
        }
        if (!store.has_object_sort_ranks(scheme.name)) {
          result.missing.push_back("sort ranks missing for scheme: " + scheme.name);
        }
      }
    }
  }

  result.ready = result.missing.empty();
  return result;
}

}  // namespace pipetrace
