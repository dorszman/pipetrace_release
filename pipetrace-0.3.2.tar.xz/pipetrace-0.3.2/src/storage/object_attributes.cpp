#include "pipetrace/attributes.hpp"

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <stdexcept>

namespace pipetrace {
namespace {

void skip_ws(const std::string& s, std::size_t& i) {
  while (i < s.size() && std::isspace(static_cast<unsigned char>(s[i]))) {
    ++i;
  }
}

std::string parse_json_string(const std::string& s, std::size_t& i) {
  if (i >= s.size() || s[i] != '"') {
    throw std::runtime_error("expected JSON string");
  }
  ++i;
  std::string out;
  while (i < s.size()) {
    const char ch = s[i++];
    if (ch == '"') {
      return out;
    }
    if (ch == '\\' && i < s.size()) {
      out.push_back(s[i++]);
      continue;
    }
    out.push_back(ch);
  }
  throw std::runtime_error("unterminated JSON string");
}

std::string parse_json_scalar(const std::string& s, std::size_t& i) {
  skip_ws(s, i);
  if (i < s.size() && s[i] == '"') {
    return parse_json_string(s, i);
  }

  const std::size_t start = i;
  while (i < s.size()) {
    const char ch = s[i];
    if (ch == ',' || ch == '}' || std::isspace(static_cast<unsigned char>(ch))) {
      break;
    }
    ++i;
  }
  if (start == i) {
    throw std::runtime_error("expected JSON value");
  }
  return s.substr(start, i - start);
}

}  // namespace

std::optional<std::string> extract_json_object_field(const std::string& line,
                                                     const std::string& key) {
  const std::string needle = "\"" + key + "\":{";
  const auto pos = line.find(needle);
  if (pos == std::string::npos) {
    return std::nullopt;
  }

  std::size_t depth = 0;
  const std::size_t start = pos + needle.size() - 1;
  for (std::size_t i = start; i < line.size(); ++i) {
    if (line[i] == '{') {
      ++depth;
    } else if (line[i] == '}') {
      --depth;
      if (depth == 0) {
        return line.substr(start, i - start + 1);
      }
    }
  }
  return std::nullopt;
}

std::vector<std::pair<std::string, std::string>> parse_object_attributes(
    const std::string& json_object) {
  std::vector<std::pair<std::string, std::string>> result;
  if (json_object.empty()) {
    return result;
  }

  std::size_t i = 0;
  skip_ws(json_object, i);
  if (i >= json_object.size() || json_object[i] != '{') {
    return result;
  }
  ++i;

  while (true) {
    skip_ws(json_object, i);
    if (i < json_object.size() && json_object[i] == '}') {
      break;
    }

    const std::string key = parse_json_string(json_object, i);
    skip_ws(json_object, i);
    if (i >= json_object.size() || json_object[i] != ':') {
      throw std::runtime_error("expected ':' in object attributes");
    }
    ++i;
    const std::string value = parse_json_scalar(json_object, i);
    result.emplace_back(key, value);

    skip_ws(json_object, i);
    if (i < json_object.size() && json_object[i] == ',') {
      ++i;
      continue;
    }
    if (i < json_object.size() && json_object[i] == '}') {
      break;
    }
  }

  return result;
}

std::string format_object_attributes_json(
    const std::vector<std::pair<std::string, std::string>>& attributes) {
  if (attributes.empty()) {
    return "{}";
  }

  std::string out = "{";
  for (std::size_t i = 0; i < attributes.size(); ++i) {
    if (i > 0) {
      out += ',';
    }
    out += '"';
    out += attributes[i].first;
    out += "\":";
    const std::string& value = attributes[i].second;
    const bool numeric = !value.empty() &&
                         std::all_of(value.begin(), value.end(), [](unsigned char ch) {
                           return std::isdigit(ch) || ch == '-';
                         });
    if (numeric) {
      out += value;
    } else {
      out += '"';
      out += value;
      out += '"';
    }
  }
  out += '}';
  return out;
}

std::string attribute_value(const std::vector<std::pair<std::string, std::string>>& attributes,
                            const std::string& key) {
  for (const auto& [attr_key, value] : attributes) {
    if (attr_key == key) {
      return value;
    }
  }
  return {};
}

std::optional<std::string> format_percentage_attribute(const std::string& key,
                                                       const std::string& raw) {
  if (key != "PcCount" && key != "PcRetirePushup" && key != "DualPcRetirePushup") {
    return std::nullopt;
  }
  if (raw.empty()) {
    return std::nullopt;
  }

  char* end = nullptr;
  const double fraction = std::strtod(raw.c_str(), &end);
  if (end == raw.c_str()) {
    return std::nullopt;
  }
  while (end != nullptr && *end != '\0' &&
         std::isspace(static_cast<unsigned char>(*end))) {
    ++end;
  }
  if (end == nullptr || *end != '\0') {
    return std::nullopt;
  }

  const double pct = fraction * 100.0;
  char buf[32];
  if (pct >= 0.0 && pct < 100.0) {
    std::snprintf(buf, sizeof(buf), "%06.3f%%", pct);
  } else {
    std::snprintf(buf, sizeof(buf), "%.3f%%", pct);
  }
  return std::string(buf);
}

void apply_percentage_display_attributes(
    std::vector<std::pair<std::string, std::string>>& attributes) {
  for (auto& [key, value] : attributes) {
    if (auto formatted = format_percentage_attribute(key, value)) {
      value = std::move(*formatted);
    }
  }
}

}  // namespace pipetrace
