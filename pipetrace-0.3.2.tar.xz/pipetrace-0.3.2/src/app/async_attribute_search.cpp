#include "pipetrace/async_attribute_search.hpp"

#include "storage/sqlite_store.hpp"

namespace pipetrace {

AsyncAttributeSearch::~AsyncAttributeSearch() { stop(); }

void AsyncAttributeSearch::start(std::string db_path) {
  stop();
  {
    std::lock_guard lock(mutex_);
    db_path_ = std::move(db_path);
    stop_ = false;
    pending_.reset();
    ready_.reset();
    started_ = true;
  }
  worker_ = std::thread([this] { worker_main(); });
}

void AsyncAttributeSearch::stop() {
  {
    std::lock_guard lock(mutex_);
    if (!started_ && !worker_.joinable()) {
      return;
    }
    stop_ = true;
    pending_.reset();
    ready_.reset();
  }
  cv_.notify_all();
  if (worker_.joinable()) {
    worker_.join();
  }
  std::lock_guard lock(mutex_);
  started_ = false;
  db_path_.clear();
}

bool AsyncAttributeSearch::running() const {
  std::lock_guard lock(mutex_);
  return started_;
}

std::uint64_t AsyncAttributeSearch::request(std::string attribute_key, std::string prefix,
                                           std::optional<SortScheme> sort_scheme,
                                           bool ranks_ascending) {
  const std::uint64_t generation = ticket_.bump();
  {
    std::lock_guard lock(mutex_);
    pending_ = PendingRequest{generation, std::move(attribute_key), std::move(prefix),
                              std::move(sort_scheme), ranks_ascending};
    ready_.reset();
  }
  cv_.notify_one();
  return generation;
}

std::uint64_t AsyncAttributeSearch::cancel() {
  const std::uint64_t generation = ticket_.bump();
  {
    std::lock_guard lock(mutex_);
    pending_.reset();
    ready_.reset();
  }
  cv_.notify_one();
  return generation;
}

std::optional<AsyncAttributeSearch::ReadyResult> AsyncAttributeSearch::take_if_current() {
  std::lock_guard lock(mutex_);
  if (!ready_.has_value() || !ticket_.is_current(ready_->generation)) {
    return std::nullopt;
  }
  ReadyResult result = std::move(*ready_);
  ready_.reset();
  return result;
}

std::uint64_t AsyncAttributeSearch::current_generation() const { return ticket_.current(); }

void AsyncAttributeSearch::worker_main() {
  SqliteStore store;
  std::string path;
  {
    std::lock_guard lock(mutex_);
    path = db_path_;
  }
  if (path.empty() || !store.open_readonly(path)) {
    return;
  }

  for (;;) {
    PendingRequest job;
    {
      std::unique_lock lock(mutex_);
      cv_.wait(lock, [&] { return stop_ || pending_.has_value(); });
      if (stop_) {
        return;
      }
      job = std::move(*pending_);
      pending_.reset();
    }

    const SortScheme* scheme_ptr = job.sort_scheme.has_value() ? &*job.sort_scheme : nullptr;
    std::optional<AttributeSearchMatch> match = store.find_first_object_by_attribute(
        job.attribute_key, job.prefix, scheme_ptr, job.ranks_ascending);

    ReadyResult result;
    result.generation = job.generation;
    result.attribute_key = std::move(job.attribute_key);
    result.prefix = std::move(job.prefix);
    result.match = std::move(match);

    {
      std::lock_guard lock(mutex_);
      if (stop_) {
        return;
      }
      // Latest-wins: drop if the UI already requested a newer query or cancelled.
      if (!ticket_.is_current(result.generation)) {
        continue;
      }
      ready_ = std::move(result);
    }
  }
}

}  // namespace pipetrace
