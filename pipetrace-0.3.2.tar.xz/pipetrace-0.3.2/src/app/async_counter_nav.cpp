#include "pipetrace/async_counter_nav.hpp"

#include "storage/sqlite_store.hpp"

namespace pipetrace {

AsyncCounterNav::~AsyncCounterNav() { stop(); }

void AsyncCounterNav::start(std::string db_path) {
  stop();
  {
    std::lock_guard lock(mutex_);
    db_path_ = std::move(db_path);
    stop_ = false;
    pending_.reset();
    ready_.reset();
    started_ = true;
  }
  worker_ = std::thread([this] { worker_main(); });
}

void AsyncCounterNav::stop() {
  {
    std::lock_guard lock(mutex_);
    if (!started_ && !worker_.joinable()) {
      return;
    }
    stop_ = true;
    pending_.reset();
    ready_.reset();
  }
  cv_.notify_all();
  if (worker_.joinable()) {
    worker_.join();
  }
  std::lock_guard lock(mutex_);
  started_ = false;
  db_path_.clear();
}

bool AsyncCounterNav::running() const {
  std::lock_guard lock(mutex_);
  return started_;
}

std::uint64_t AsyncCounterNav::request(CounterNavDirection direction, std::int64_t event_type_id,
                                       Timestamp cycle, std::int64_t from_row,
                                       std::optional<SortScheme> sort_scheme) {
  const std::uint64_t generation = ticket_.bump();
  {
    std::lock_guard lock(mutex_);
    pending_ = PendingRequest{generation, direction, event_type_id, cycle, from_row,
                              std::move(sort_scheme)};
    ready_.reset();
  }
  cv_.notify_one();
  return generation;
}

std::uint64_t AsyncCounterNav::cancel() {
  const std::uint64_t generation = ticket_.bump();
  {
    std::lock_guard lock(mutex_);
    pending_.reset();
    ready_.reset();
  }
  cv_.notify_one();
  return generation;
}

std::optional<AsyncCounterNav::ReadyResult> AsyncCounterNav::take_if_current() {
  std::lock_guard lock(mutex_);
  if (!ready_.has_value() || !ticket_.is_current(ready_->generation)) {
    return std::nullopt;
  }
  ReadyResult result = std::move(*ready_);
  ready_.reset();
  return result;
}

std::uint64_t AsyncCounterNav::current_generation() const { return ticket_.current(); }

void AsyncCounterNav::worker_main() {
  SqliteStore store;
  std::string path;
  {
    std::lock_guard lock(mutex_);
    path = db_path_;
  }
  const bool store_ok = !path.empty() && store.open_readonly(path);

  for (;;) {
    PendingRequest job;
    {
      std::unique_lock lock(mutex_);
      cv_.wait(lock, [&] { return stop_ || pending_.has_value(); });
      if (stop_) {
        return;
      }
      job = std::move(*pending_);
      pending_.reset();
    }

    std::optional<CounterNavMatch> match;
    if (store_ok) {
      const SortScheme* scheme_ptr = job.sort_scheme.has_value() ? &*job.sort_scheme : nullptr;
      switch (job.direction) {
        case CounterNavDirection::NextCycle:
          match = store.find_next_cycle_for_event_type(job.event_type_id, job.cycle, scheme_ptr);
          break;
        case CounterNavDirection::PrevCycle:
          match = store.find_prev_cycle_for_event_type(job.event_type_id, job.cycle, scheme_ptr);
          break;
        case CounterNavDirection::NextCell:
          match = store.find_next_object_at_cycle_for_event_type(job.event_type_id, job.cycle,
                                                                job.from_row, scheme_ptr);
          break;
        case CounterNavDirection::PrevCell:
          match = store.find_prev_object_at_cycle_for_event_type(job.event_type_id, job.cycle,
                                                                job.from_row, scheme_ptr);
          break;
      }
    }

    ReadyResult result;
    result.generation = job.generation;
    result.direction = job.direction;
    result.event_type_id = job.event_type_id;
    result.match = std::move(match);

    {
      std::lock_guard lock(mutex_);
      if (stop_) {
        return;
      }
      if (!ticket_.is_current(result.generation)) {
        continue;
      }
      ready_ = std::move(result);
    }
  }
}

}  // namespace pipetrace
