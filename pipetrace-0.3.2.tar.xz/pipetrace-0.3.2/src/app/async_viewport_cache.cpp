#include "pipetrace/async_viewport_cache.hpp"

#include <algorithm>

#include "pipetrace/attributes.hpp"
#include "storage/sqlite_store.hpp"

namespace pipetrace {
namespace {

void build_paint_index(ViewportCacheSnapshot& snap) {
  snap.row_by_object.clear();
  snap.row_by_object.reserve(snap.objects.ids.size());
  for (std::size_t i = 0; i < snap.objects.ids.size(); ++i) {
    snap.row_by_object[snap.objects.ids[i]] = snap.objects.row_indices[i];
  }

  snap.events_by_cell.clear();
  for (std::size_t i = 0; i < snap.events.object_ids.size(); ++i) {
    const auto row_it = snap.row_by_object.find(snap.events.object_ids[i]);
    if (row_it == snap.row_by_object.end()) {
      continue;
    }

    PaintCellEvent event;
    event.id = snap.events.ids[i];
    event.event_type_id = snap.events.event_type_ids[i];
    event.display_char =
        snap.events.display_chars.size() > i ? snap.events.display_chars[i] : '?';
    event.color_rgba = snap.events.colors_rgba[i];
    event.object_id = snap.events.object_ids[i];
    event.kind = snap.events.kinds[i];
    snap.events_by_cell[{row_it->second, snap.events.times[i]}].push_back(std::move(event));
  }

  for (auto& entry : snap.events_by_cell) {
    std::sort(entry.second.begin(), entry.second.end(),
              [](const PaintCellEvent& a, const PaintCellEvent& b) {
                return a.event_type_id < b.event_type_id;
              });
  }
}

ViewportCacheSnapshot build_empty_snapshot(std::uint64_t generation, const Viewport& viewport) {
  ViewportCacheSnapshot snap;
  snap.generation = generation;
  snap.cache_time_start = viewport.time_start;
  snap.cache_time_end = viewport.time_end;
  snap.cache_row_start = viewport.row_start;
  snap.cache_row_end = viewport.row_end;
  return snap;
}

ViewportCacheSnapshot build_snapshot(SqliteStore& store, std::uint64_t generation, bool empty,
                                     const Viewport& viewport,
                                     const std::optional<SortScheme>& sort_scheme,
                                     bool ranks_ascending) {
  if (empty) {
    return build_empty_snapshot(generation, viewport);
  }

  ViewportCacheSnapshot snap;
  snap.generation = generation;
  snap.cache_time_start = viewport.time_start;
  snap.cache_time_end = viewport.time_end;
  snap.cache_row_start = viewport.row_start;
  snap.cache_row_end = viewport.row_end;

  const SortScheme* scheme_ptr = sort_scheme.has_value() ? &*sort_scheme : nullptr;
  snap.objects = store.query_objects(viewport, 0, scheme_ptr, ranks_ascending);
  snap.events = store.query_events(viewport, snap.objects.ids);

  snap.attributes_by_object.clear();
  snap.attributes_by_event.clear();
  snap.object_id_by_row.clear();
  for (std::size_t i = 0; i < snap.objects.ids.size(); ++i) {
    const ObjectId id = snap.objects.ids[i];
    const std::string& attributes_json =
        snap.objects.attributes_json.size() > i ? snap.objects.attributes_json[i] : "{}";
    auto attrs = parse_object_attributes(attributes_json);
    apply_percentage_display_attributes(attrs);
    snap.attributes_by_object[id] = std::move(attrs);
    snap.object_id_by_row[snap.objects.row_indices[i]] = id;
  }
  snap.attributes_by_event.reserve(snap.events.ids.size());
  for (std::size_t i = 0; i < snap.events.ids.size(); ++i) {
    const std::string& attributes_json =
        snap.events.attributes_json.size() > i ? snap.events.attributes_json[i] : "{}";
    snap.attributes_by_event[snap.events.ids[i]] = parse_object_attributes(attributes_json);
  }

  build_paint_index(snap);
  return snap;
}

}  // namespace

AsyncViewportCache::~AsyncViewportCache() { stop(); }

void AsyncViewportCache::start(std::string db_path) {
  stop();
  {
    std::lock_guard lock(mutex_);
    db_path_ = std::move(db_path);
    stop_ = false;
    pending_.reset();
    inflight_.reset();
    ready_.reset();
    started_ = true;
  }
  worker_ = std::thread([this] { worker_main(); });
}

void AsyncViewportCache::stop() {
  {
    std::lock_guard lock(mutex_);
    if (!started_ && !worker_.joinable()) {
      return;
    }
    stop_ = true;
    pending_.reset();
    inflight_.reset();
    ready_.reset();
  }
  cv_.notify_all();
  if (worker_.joinable()) {
    worker_.join();
  }
  std::lock_guard lock(mutex_);
  started_ = false;
  db_path_.clear();
}

bool AsyncViewportCache::running() const {
  std::lock_guard lock(mutex_);
  return started_;
}

std::uint64_t AsyncViewportCache::request(Viewport viewport,
                                          std::optional<SortScheme> sort_scheme,
                                          bool ranks_ascending) {
  const std::uint64_t generation = ticket_.bump();
  PendingRequest job;
  job.generation = generation;
  job.empty = false;
  job.viewport = viewport;
  job.sort_scheme = std::move(sort_scheme);
  job.ranks_ascending = ranks_ascending;
  {
    std::lock_guard lock(mutex_);
    pending_ = job;
    inflight_ = job;
    ready_.reset();
  }
  cv_.notify_one();
  return generation;
}

std::uint64_t AsyncViewportCache::request_empty(Timestamp time_start, Timestamp time_end,
                                                std::int64_t row_start,
                                                std::int64_t row_end) {
  const std::uint64_t generation = ticket_.bump();
  PendingRequest job;
  job.generation = generation;
  job.empty = true;
  job.viewport.time_start = time_start;
  job.viewport.time_end = time_end;
  job.viewport.row_start = row_start;
  job.viewport.row_end = row_end;
  {
    std::lock_guard lock(mutex_);
    pending_ = job;
    inflight_ = job;
    ready_.reset();
  }
  cv_.notify_one();
  return generation;
}

std::uint64_t AsyncViewportCache::cancel() {
  const std::uint64_t generation = ticket_.bump();
  {
    std::lock_guard lock(mutex_);
    pending_.reset();
    inflight_.reset();
    ready_.reset();
  }
  cv_.notify_one();
  return generation;
}

std::optional<ViewportCacheSnapshot> AsyncViewportCache::take_if_current() {
  std::lock_guard lock(mutex_);
  if (!ready_.has_value() || !ticket_.is_current(ready_->generation)) {
    return std::nullopt;
  }
  ViewportCacheSnapshot result = std::move(*ready_);
  ready_.reset();
  if (inflight_.has_value() && inflight_->generation == result.generation) {
    inflight_.reset();
  }
  return result;
}

std::uint64_t AsyncViewportCache::current_generation() const { return ticket_.current(); }

bool AsyncViewportCache::has_inflight_request() const {
  std::lock_guard lock(mutex_);
  return inflight_.has_value();
}

bool AsyncViewportCache::inflight_covers(const double view_scroll_time,
                                         const double view_scroll_row,
                                         const std::int64_t visible_cycles,
                                         const std::int64_t visible_rows,
                                         const std::int64_t row_margin) const {
  std::lock_guard lock(mutex_);
  if (!inflight_.has_value()) {
    return false;
  }
  const Viewport& vp = inflight_->viewport;
  return view_scroll_row >= static_cast<double>(vp.row_start) + static_cast<double>(row_margin) &&
         view_scroll_row + static_cast<double>(visible_rows) <=
             static_cast<double>(vp.row_end) - static_cast<double>(row_margin) &&
         view_scroll_time >= static_cast<double>(vp.time_start) &&
         view_scroll_time + static_cast<double>(visible_cycles) <=
             static_cast<double>(vp.time_end);
}

void AsyncViewportCache::worker_main() {
  SqliteStore store;
  std::string path;
  {
    std::lock_guard lock(mutex_);
    path = db_path_;
  }
  if (path.empty() || !store.open_readonly(path)) {
    return;
  }

  for (;;) {
    PendingRequest job;
    {
      std::unique_lock lock(mutex_);
      cv_.wait(lock, [&] { return stop_ || pending_.has_value(); });
      if (stop_) {
        return;
      }
      job = std::move(*pending_);
      pending_.reset();
      inflight_ = job;
    }

    ViewportCacheSnapshot snap =
        build_snapshot(store, job.generation, job.empty, job.viewport, job.sort_scheme,
                       job.ranks_ascending);

    {
      std::lock_guard lock(mutex_);
      if (stop_) {
        return;
      }
      if (!ticket_.is_current(snap.generation)) {
        if (inflight_.has_value() && inflight_->generation == snap.generation) {
          inflight_.reset();
        }
        continue;
      }
      ready_ = std::move(snap);
    }
  }
}

}  // namespace pipetrace
