#include <cstdlib>
#include <cctype>
#include <cfloat>
#include <cmath>
#include <cstdio>
#include <filesystem>
#include <iostream>
#include <memory>
#include <optional>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "GLFW/glfw3.h"
#include "app/theme.hpp"
#include "app/timeline_view.hpp"
#include "pipetrace/row_sort_state.hpp"
#include "imgui.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"
#include "implot.h"
#include "pipetrace/app_config.hpp"
#include "pipetrace/generator.hpp"
#include "pipetrace/importer.hpp"
#include "pipetrace/attributes.hpp"
#include "pipetrace/fatal_error.hpp"
#include "pipetrace/storage.hpp"
#include "pipetrace/store_readiness.hpp"

namespace {

struct AppOptions {
  std::string trace_path;
  std::string store_path;
  std::string trace2_path;
  std::string store2_path;
  std::string config_path;
  std::string title;  // optional task label for the GLFW window title
  bool generate{false};
  bool generic{false};
  std::int64_t object_count{2000};
};

/// GLFW / task-bar title. Default is "pipetrace". With --title: "pipetrace | {title} | {store}".
std::string make_window_title(const AppOptions& options) {
  if (options.title.empty()) {
    return "pipetrace";
  }
  std::string title = "pipetrace | " + options.title;
  if (!options.store_path.empty()) {
    title += " | ";
    title += std::filesystem::path(options.store_path).filename().string();
  }
  if (!options.store2_path.empty()) {
    title += " + ";
    title += std::filesystem::path(options.store2_path).filename().string();
  }
  return title;
}

AppOptions parse_args(int argc, char** argv) {
  AppOptions options;
  int positional_count = 0;
  for (int i = 1; i < argc; ++i) {
    const std::string arg = argv[i];
    if (arg == "--generate") {
      options.generate = true;
    } else if (arg == "--generic") {
      options.generic = true;
    } else if (arg == "--objects" && i + 1 < argc) {
      options.object_count = std::stoll(argv[++i]);
    } else if (arg == "--trace" && i + 1 < argc) {
      options.trace_path = argv[++i];
    } else if (arg == "--trace2" && i + 1 < argc) {
      options.trace2_path = argv[++i];
    } else if (arg == "--config" && i + 1 < argc) {
      options.config_path = argv[++i];
    } else if (arg == "--title" && i + 1 < argc) {
      options.title = argv[++i];
    } else if (arg == "--help") {
      std::cout << "pipetrace-view [options] [store.db] [store2.db]\n"
                   "  Options: [--generate] [--generic] [--objects N] [--trace path.ptj]\n"
                   "           [--trace2 path.ptj] [--config PATH] [--title TEXT]\n"
                   "  Positional stores: first .db is the primary store; optional second enables\n"
                   "  dual-trace (e.g. Windows Open with / multi-select).\n"
                   "  A store path is required unless --generate is passed.\n"
                   "  Config: store meta app_config_json (from analyze) if present; else\n"
                   "  --config PATH, else PIPETRACE_CONFIG, else pipetrace.app.json\n"
                   "  next to the executable. Dual-trace uses the primary store's embed.\n"
                   "  --title TEXT: optional window label (e.g. feature/task). Window title becomes\n"
                   "  'pipetrace | TEXT | store.db' (default without --title: 'pipetrace').\n"
                   "  Fatals also append to pipetrace-view.log next to the executable.\n";
      std::exit(0);
    } else if (!arg.empty() && arg[0] == '-') {
      throw std::runtime_error("unknown option: " + arg);
    } else {
      if (positional_count == 0) {
        options.store_path = arg;
      } else if (positional_count == 1) {
        options.store2_path = arg;
      } else {
        throw std::runtime_error("too many positional store paths (expected at most 2)");
      }
      ++positional_count;
    }
  }
  return options;
}

void ensure_trace(AppOptions& options) {
  if (options.store_path.empty()) {
    if (!options.generate) {
      throw std::runtime_error(
          "No store specified.\n\n"
          "Pass an analyzed .db (drag-and-drop / Open with / CLI):\n"
          "  pipetrace-view path\\to\\trace.db\n\n"
          "Config: if analyze embedded app_config_json into the DB, no config file "
          "is needed. Otherwise place pipetrace.app.json next to pipetrace-view.exe "
          "(or pass --config / PIPETRACE_CONFIG).\n\n"
          "Double-clicking the exe alone is not enough — it does not know which "
          "trace to open.\n\n"
          "Dev only: --generate creates data/sample.ptj.db (still requires analyze "
          "before viewing).");
    }
    if (options.trace_path.empty()) {
      options.trace_path = "data/sample.ptj";
    }
    options.store_path = options.trace_path + ".db";
  }

  if (options.generate) {
    std::filesystem::create_directories("data");
    if (options.trace_path.empty()) {
      options.trace_path = "data/sample.ptj";
    }
    pipetrace::GeneratorConfig config;
    config.object_count = options.object_count;
    config.time_span = 100000;
    config.seed = 42;

    pipetrace::TraceMeta meta;
    if (options.generic) {
      meta = pipetrace::generate_generic_trace(config, options.trace_path);
    } else {
      pipetrace::CpuPipelineConfig cpu_config;
      cpu_config.object_count = config.object_count;
      cpu_config.time_span = config.time_span;
      cpu_config.seed = config.seed;
      meta = pipetrace::generate_cpu_pipeline_trace(cpu_config, options.trace_path);
    }

    std::cout << "generated trace '" << meta.name << "' with " << meta.object_count
              << " objects and " << meta.event_count << " events\n";
    options.store_path = options.trace_path + ".db";
    return;
  }

  if (!std::filesystem::exists(options.store_path)) {
    throw std::runtime_error("store not found: " + options.store_path);
  }
}

std::string to_lower_ascii(std::string value) {
  for (char& ch : value) {
    ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
  }
  return value;
}

void sidebar_bullet_text(const char* text) {
  ImGui::Bullet();
  ImGui::SameLine();
  ImGui::PushTextWrapPos(0.0f);
  ImGui::TextWrapped("%s", text);
  ImGui::PopTextWrapPos();
}

bool event_type_matches_filter(const pipetrace::EventType& event_type,
                               const std::string& filter) {
  if (filter.empty()) {
    return true;
  }

  const std::string lower_filter = to_lower_ascii(filter);
  if (to_lower_ascii(event_type.name).find(lower_filter) != std::string::npos) {
    return true;
  }

  const std::string char_label(1, event_type.display_char);
  return to_lower_ascii(char_label).find(lower_filter) != std::string::npos;
}

std::vector<const pipetrace::EventType*> filter_event_types(
    const std::vector<pipetrace::EventType>& event_types, const std::string& filter) {
  std::vector<const pipetrace::EventType*> result;
  result.reserve(event_types.size());
  for (const pipetrace::EventType& event_type : event_types) {
    if (event_type_matches_filter(event_type, filter)) {
      result.push_back(&event_type);
    }
  }
  return result;
}

pipetrace::AppConfig load_application_config(const AppOptions& options,
                                             const std::string& argv0,
                                             pipetrace::TraceStore* primary_store) {
  if (primary_store != nullptr) {
    if (const std::optional<std::string> embedded =
            primary_store->meta_value(pipetrace::kAppConfigJsonMetaKey)) {
      if (!embedded->empty()) {
        return pipetrace::load_app_config_from_string(*embedded);
      }
    }
  }
  const std::string exe_dir = pipetrace::executable_directory(argv0);
  const std::string config_path =
      pipetrace::resolve_app_config_path(options.config_path, /*allow_env=*/true, exe_dir);
  return pipetrace::load_app_config(config_path);
}

void ensure_second_trace(AppOptions& options) {
  if (options.store2_path.empty() && options.trace2_path.empty()) {
    return;
  }
  if (options.store2_path.empty()) {
    options.store2_path = options.trace2_path + ".db";
  }
  if (!std::filesystem::exists(options.store2_path)) {
    std::cerr << "second trace store not found: " << options.store2_path << '\n';
  }
}

pipetrace::Timestamp partner_preserving_cycle(const pipetrace::TimelineView& target) {
  if (target.state().has_crosshair) {
    return target.state().crosshair.cycle;
  }
  return static_cast<pipetrace::Timestamp>(std::floor(target.state().view_scroll_time));
}

std::optional<std::string> sync_value_for_row(pipetrace::TraceStore& store,
                                              const std::string& sync_key, std::int64_t row,
                                              const pipetrace::SortScheme* sort_scheme,
                                              bool ranks_ascending) {
  if (sync_key.empty() || row < 0) {
    return std::nullopt;
  }
  const std::optional<pipetrace::ObjectId> object_id =
      store.object_id_for_row(row, sort_scheme, ranks_ascending);
  if (!object_id.has_value()) {
    return std::nullopt;
  }
  return store.indexed_attribute_value(sync_key, *object_id);
}

std::optional<std::int64_t> partner_row_for_sync_value(pipetrace::TraceStore& target_store,
                                                      const std::string& sync_key,
                                                      const std::string& sync_value,
                                                      const pipetrace::SortScheme* sort_scheme,
                                                      bool ranks_ascending) {
  const std::optional<pipetrace::AttributeSearchMatch> match =
      target_store.find_object_by_attribute_value(sync_key, sync_value, sort_scheme,
                                                  ranks_ascending);
  if (!match.has_value()) {
    return std::nullopt;
  }
  return match->row_index;
}

/// Map source viewport so the partner's matched row stays at the same screen offset.
std::optional<double> partner_scroll_for_anchor(const pipetrace::TimelineView& source,
                                                std::int64_t source_anchor_row,
                                                std::int64_t partner_row) {
  const double offset =
      static_cast<double>(source_anchor_row) - source.state().view_scroll_row;
  return static_cast<double>(partner_row) - offset;
}

void sync_partner_crosshair(pipetrace::TimelineView& source, pipetrace::TimelineView& target,
                            const std::string& sync_key, pipetrace::TraceStore& source_store,
                            pipetrace::TraceStore& target_store) {
  if (!source.state().has_crosshair) {
    return;
  }
  const std::int64_t source_row = source.state().crosshair.row;
  const std::optional<std::string> sync_value =
      sync_value_for_row(source_store, sync_key, source_row, source.viewport_sort_scheme(),
                         source.viewport_ranks_ascending());
  if (!sync_value.has_value()) {
    return;
  }
  const std::optional<std::int64_t> partner_row = partner_row_for_sync_value(
      target_store, sync_key, *sync_value, target.viewport_sort_scheme(),
      target.viewport_ranks_ascending());
  if (!partner_row.has_value()) {
    return;
  }

  pipetrace::GridPosition target_cell;
  target_cell.cycle = partner_preserving_cycle(target);
  target_cell.row = *partner_row;
  const std::optional<double> partner_scroll =
      partner_scroll_for_anchor(source, source_row, *partner_row);
  target.sync_crosshair(target_cell, partner_scroll);
}

void sync_partner_view_scroll_row(pipetrace::TimelineView& source,
                                  pipetrace::TimelineView& target, const std::string& sync_key,
                                  pipetrace::TraceStore& source_store,
                                  pipetrace::TraceStore& target_store) {
  const std::int64_t source_anchor =
      source.state().has_crosshair
          ? source.state().crosshair.row
          : static_cast<std::int64_t>(std::floor(source.state().view_scroll_row));
  const std::optional<std::string> sync_value =
      sync_value_for_row(source_store, sync_key, source_anchor, source.viewport_sort_scheme(),
                         source.viewport_ranks_ascending());
  if (!sync_value.has_value()) {
    target.apply_view_scroll_row(source.state().view_scroll_row);
    return;
  }
  const std::optional<std::int64_t> partner_row = partner_row_for_sync_value(
      target_store, sync_key, *sync_value, target.viewport_sort_scheme(),
      target.viewport_ranks_ascending());
  if (!partner_row.has_value()) {
    return;
  }
  const std::optional<double> partner_scroll =
      partner_scroll_for_anchor(source, source_anchor, *partner_row);
  if (partner_scroll.has_value()) {
    target.apply_view_scroll_row(*partner_scroll);
  }
}

struct SyncViewDragSession {
  bool active{false};
  std::int64_t source_anchor_row{0};
  std::int64_t partner_anchor_row{0};
};

void sync_partner_during_view_drag(pipetrace::TimelineView& source,
                                   pipetrace::TimelineView& target, SyncViewDragSession& session,
                                   const std::string& sync_key,
                                   pipetrace::TraceStore& source_store,
                                   pipetrace::TraceStore& target_store) {
  if (!source.is_view_scroll_drag_active()) {
    if (session.active) {
      session.active = false;
      target.clear_sync_partner_highlight();
    }
    return;
  }

  sync_partner_view_scroll_row(source, target, sync_key, source_store, target_store);
  if (!source.state().has_crosshair) {
    return;
  }

  const std::int64_t source_row = source.state().crosshair.row;

  if (!session.active) {
    session.active = true;
    session.source_anchor_row = source_row;
    session.partner_anchor_row =
        target.state().has_crosshair ? target.state().crosshair.row : source_row;
  }

  pipetrace::GridPosition partner_cell;
  partner_cell.cycle = partner_preserving_cycle(target);
  const std::optional<std::string> sync_value =
      sync_value_for_row(source_store, sync_key, source_row, source.viewport_sort_scheme(),
                         source.viewport_ranks_ascending());
  if (sync_value.has_value()) {
    const std::optional<std::int64_t> partner_row = partner_row_for_sync_value(
        target_store, sync_key, *sync_value, target.viewport_sort_scheme(),
        target.viewport_ranks_ascending());
    if (partner_row.has_value()) {
      partner_cell.row = *partner_row;
    } else {
      partner_cell.row =
          session.partner_anchor_row + (source_row - session.source_anchor_row);
    }
  } else {
    partner_cell.row = session.partner_anchor_row + (source_row - session.source_anchor_row);
  }

  target.set_sync_partner_highlight(partner_cell);
}

const pipetrace::EventType* find_matching_event_type(
    const std::vector<pipetrace::EventType>& event_types,
    const pipetrace::EventType& reference) {
  for (const pipetrace::EventType& event_type : event_types) {
    if (event_type.name == reference.name && event_type.display_char == reference.display_char) {
      return &event_type;
    }
  }
  return nullptr;
}

struct TracePinnedAttributes {
  std::vector<std::string> available_keys;
  std::unordered_map<std::string, bool> checked;
};

TracePinnedAttributes load_trace_pinned_attributes(pipetrace::TraceStore& store,
                                                   const pipetrace::AppConfig& config) {
  TracePinnedAttributes state;
  state.available_keys = store.object_attribute_keys();
  state.checked = pipetrace::default_pinned_attribute_checks(config, state.available_keys);
  return state;
}

void apply_trace_pinned_attributes(pipetrace::TimelineView& timeline,
                                   const pipetrace::AppConfig& config,
                                   const TracePinnedAttributes& state, bool dual_layout) {
  timeline.set_pinned_row_columns(pipetrace::build_active_pinned_row_columns(
      config, state.available_keys, state.checked, dual_layout));
}

void apply_pinned_attributes_all_traces(
    const pipetrace::AppConfig& config, bool dual_layout,
    const std::vector<std::pair<pipetrace::TimelineView*, TracePinnedAttributes*>>& targets) {
  for (const auto& [timeline, attr_state] : targets) {
    if (timeline == nullptr || attr_state == nullptr) {
      continue;
    }
    apply_trace_pinned_attributes(*timeline, config, *attr_state, dual_layout);
  }
}

void set_pinned_attribute_checked_all_traces(
    const std::string& key, bool checked,
    const std::vector<std::pair<pipetrace::TimelineView*, TracePinnedAttributes*>>& targets) {
  for (const auto& [timeline, attr_state] : targets) {
    (void)timeline;
    if (attr_state == nullptr) {
      continue;
    }
    attr_state->checked[key] = checked;
  }
}

void set_all_pinned_attributes_checked(
    bool checked,
    const std::vector<std::pair<pipetrace::TimelineView*, TracePinnedAttributes*>>& targets) {
  for (const auto& [timeline, attr_state] : targets) {
    (void)timeline;
    if (attr_state == nullptr) {
      continue;
    }
    for (const std::string& key : attr_state->available_keys) {
      attr_state->checked[key] = checked;
    }
  }
}

void draw_object_attributes_panel(
    TracePinnedAttributes& state, const pipetrace::AppConfig& config, bool dual_layout,
    const std::vector<std::pair<pipetrace::TimelineView*, TracePinnedAttributes*>>& targets) {
  ImGui::Separator();
  ImGui::Text("Row attributes");
  if (state.available_keys.empty()) {
    ImGui::TextDisabled("(none in store)");
    return;
  }

  if (ImGui::SmallButton("Select all")) {
    set_all_pinned_attributes_checked(true, targets);
    apply_pinned_attributes_all_traces(config, dual_layout, targets);
  }
  ImGui::SameLine();
  if (ImGui::SmallButton("Erase all")) {
    set_all_pinned_attributes_checked(false, targets);
    apply_pinned_attributes_all_traces(config, dual_layout, targets);
  }

  const float remaining_height = ImGui::GetContentRegionAvail().y;
  constexpr float kMinRowAttributesHeight = 180.0f;
  const float list_height =
      std::max(kMinRowAttributesHeight, remaining_height * 0.40f);

  ImGui::BeginChild("object_attributes_list", ImVec2(0, list_height), ImGuiChildFlags_Borders);
  ImGuiListClipper clipper;
  clipper.Begin(static_cast<int>(state.available_keys.size()));
  while (clipper.Step()) {
    for (int row = clipper.DisplayStart; row < clipper.DisplayEnd; ++row) {
      const std::string& key = state.available_keys[static_cast<std::size_t>(row)];
      ImGui::PushID(row);
      bool checked = state.checked[key];
      if (ImGui::Checkbox(key.c_str(), &checked)) {
        set_pinned_attribute_checked_all_traces(key, checked, targets);
        apply_pinned_attributes_all_traces(config, dual_layout, targets);
      }
      ImGui::PopID();
    }
  }
  ImGui::EndChild();
}

void toggle_marked_event_type_all_traces(
    const pipetrace::EventType& reference,
    const std::vector<std::pair<pipetrace::TimelineView*,
                                const std::vector<pipetrace::EventType>*>>& targets) {
  for (const auto& [timeline, event_types] : targets) {
    if (timeline == nullptr || event_types == nullptr) {
      continue;
    }
    const pipetrace::EventType* match = find_matching_event_type(*event_types, reference);
    if (match != nullptr) {
      timeline->toggle_marked_event_type(*match);
    }
  }
}

void draw_event_types_panel(
    pipetrace::TimelineView& primary_timeline,
    const std::vector<pipetrace::EventType>& all_event_types,
    char* filter_buf, std::size_t filter_size,
    const std::vector<std::pair<pipetrace::TimelineView*,
                                const std::vector<pipetrace::EventType>*>>& toggle_targets) {
  ImGui::Separator();
  ImGui::Text("Pinned events (click to mark)");
  ImGui::SetNextItemWidth(-FLT_MIN);
  ImGui::InputTextWithHint("##event_type_filter", "Filter name or char...", filter_buf,
                           filter_size);
  ImGui::SameLine();
  if (ImGui::Button("Clear")) {
    filter_buf[0] = '\0';
  }

  const std::vector<const pipetrace::EventType*> filtered_event_types =
      filter_event_types(all_event_types, filter_buf);
  ImGui::Text("%zu / %zu shown", filtered_event_types.size(), all_event_types.size());

  ImGui::BeginChild("event_types_list", ImVec2(0, 0), ImGuiChildFlags_Borders);
  ImGuiListClipper clipper;
  clipper.Begin(static_cast<int>(filtered_event_types.size()));
  while (clipper.Step()) {
    for (int row = clipper.DisplayStart; row < clipper.DisplayEnd; ++row) {
      const pipetrace::EventType& event_type = *filtered_event_types[row];
      ImGui::PushID(static_cast<int>(event_type.id));
      const float r = ((event_type.color_rgba) & 0xFF) / 255.0f;
      const float g = ((event_type.color_rgba >> 8) & 0xFF) / 255.0f;
      const float b = ((event_type.color_rgba >> 16) & 0xFF) / 255.0f;
      ImGui::ColorButton("##c", ImVec4(r, g, b, 1.0f), ImGuiColorEditFlags_NoTooltip,
                         ImVec2(16, 16));
      ImGui::SameLine();
      const std::string label =
          std::string("'") + event_type.display_char + "' " + event_type.name;
      if (ImGui::Selectable(label.c_str(), primary_timeline.is_event_type_marked(event_type.id))) {
        toggle_marked_event_type_all_traces(event_type, toggle_targets);
      }
      ImGui::PopID();
    }
  }
  ImGui::EndChild();
}

void draw_pinned_markers_panel(pipetrace::TimelineView& timeline, const char* child_id,
                               const char* title, float height) {
  ImGui::BeginChild(child_id, ImVec2(0, height), ImGuiChildFlags_Borders);
  ImGui::Text("%s", title);
  ImGui::Separator();
  const std::vector<pipetrace::GridPosition>& pinned_markers = timeline.pinned_markers();
  if (pinned_markers.empty()) {
    ImGui::TextDisabled("Ctrl+click grid to pin");
  } else {
    ImGui::BeginChild("list", ImVec2(0, 0), ImGuiChildFlags_Borders);
    for (std::size_t i = 0; i < pinned_markers.size(); ++i) {
      const pipetrace::GridPosition& marker = pinned_markers[i];
      ImGui::PushID(static_cast<int>(i));
      char label[64];
      std::snprintf(label, sizeof(label), "Cycle %lld, row %lld",
                    static_cast<long long>(marker.cycle), static_cast<long long>(marker.row));
      const float remove_width = ImGui::GetFrameHeight();
      const float row_width = std::max(0.0f, ImGui::GetContentRegionAvail().x - remove_width - 4.0f);
      if (ImGui::Selectable(label, false, 0, ImVec2(row_width, 0))) {
        timeline.navigate_to_grid_cell(marker);
      }
      if (ImGui::IsItemHovered()) {
        ImGui::SetTooltip("Go to marker");
      }
      ImGui::SameLine(0.0f, 4.0f);
      if (ImGui::Button("X", ImVec2(remove_width, 0.0f))) {
        timeline.remove_pinned_marker(i);
        ImGui::PopID();
        break;
      }
      if (ImGui::IsItemHovered()) {
        ImGui::SetTooltip("Remove marker");
      }
      ImGui::PopID();
    }
    ImGui::EndChild();
  }
  ImGui::EndChild();
}

}  // namespace

int main(int argc, char** argv) {
  pipetrace::install_crash_handlers();
  pipetrace::append_diagnostic_log("pipetrace-view starting");

  AppOptions options;
  pipetrace::AppConfig app_config;
  try {
    options = parse_args(argc, argv);
  } catch (const std::exception& ex) {
    pipetrace::report_fatal_error("pipetrace-view", std::string("Configuration error: ") + ex.what());
    return 1;
  }
  try {
    ensure_trace(options);
  } catch (const std::exception& ex) {
    pipetrace::report_fatal_error("pipetrace-view", std::string("Failed to prepare store: ") + ex.what());
    return 1;
  }
  ensure_second_trace(options);
  pipetrace::append_diagnostic_log("store path: " + options.store_path);

  // Open + readiness check before GLFW/ImGui so we never show a viewer window
  // for a store that is not fully analyzed for the loaded config.
  auto store = pipetrace::create_sqlite_store();
  try {
    pipetrace::append_diagnostic_log("opening store");
    if (!store->open(options.store_path)) {
      pipetrace::report_fatal_error(
          "pipetrace-view", "Failed to open store:\n" + options.store_path);
      return 1;
    }
    pipetrace::append_diagnostic_log("store opened");
  } catch (const std::exception& ex) {
    pipetrace::report_fatal_error(
        "pipetrace-view",
        std::string("Failed to open store:\n") + options.store_path + "\n\n" + ex.what());
    return 1;
  }
  try {
    const char* argv0 = (argc > 0 && argv != nullptr) ? argv[0] : "";
    pipetrace::append_diagnostic_log("loading config");
    app_config = load_application_config(options, argv0 != nullptr ? argv0 : "", store.get());
    pipetrace::append_diagnostic_log("config loaded");
  } catch (const std::exception& ex) {
    pipetrace::report_fatal_error("pipetrace-view",
                                  std::string("Configuration error: ") + ex.what());
    return 1;
  }
  {
    pipetrace::append_diagnostic_log("checking store readiness");
    const pipetrace::StoreViewReadiness readiness = store->check_view_readiness(app_config);
    if (!readiness.ready) {
      pipetrace::report_fatal_error("Store not ready",
                                    readiness.message(options.store_path));
      return 1;
    }
    pipetrace::append_diagnostic_log("store ready");
  }

  pipetrace::TraceMeta meta = store->meta();

  std::unique_ptr<pipetrace::TraceStore> store2;
  pipetrace::TraceMeta meta2{};
  bool has_second_trace = false;
  if (!options.store2_path.empty()) {
    if (!std::filesystem::exists(options.store2_path)) {
      pipetrace::report_fatal_error(
          "pipetrace-view", "Second trace store not found:\n" + options.store2_path);
      return 1;
    }
    store2 = pipetrace::create_sqlite_store();
    if (!store2->open(options.store2_path)) {
      pipetrace::report_fatal_error(
          "pipetrace-view", "Failed to open second store:\n" + options.store2_path);
      return 1;
    }
    const pipetrace::StoreViewReadiness readiness2 = store2->check_view_readiness(app_config);
    if (!readiness2.ready) {
      pipetrace::report_fatal_error("Store not ready",
                                    readiness2.message(options.store2_path));
      return 1;
    }
    meta2 = store2->meta();
    has_second_trace = true;
  }

  if (!glfwInit()) {
    pipetrace::report_fatal_error("pipetrace-view", "Failed to initialize GLFW.");
    return 1;
  }
  pipetrace::append_diagnostic_log("glfwInit ok");

  std::string glfw_error_log;
  static std::string* g_glfw_error_sink = nullptr;
  g_glfw_error_sink = &glfw_error_log;
  glfwSetErrorCallback([](int code, const char* description) {
    if (g_glfw_error_sink == nullptr) {
      return;
    }
    if (!g_glfw_error_sink->empty()) {
      *g_glfw_error_sink += "\n";
    }
    *g_glfw_error_sink += "GLFW " + std::to_string(code) + ": ";
    *g_glfw_error_sink += description != nullptr ? description : "(no description)";
  });

  const std::string window_title = make_window_title(options);
  auto try_create_window = [&](int profile_hint, const char* label) -> GLFWwindow* {
    glfwDefaultWindowHints();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    if (profile_hint >= 0) {
      glfwWindowHint(GLFW_OPENGL_PROFILE, profile_hint);
    }
    GLFWwindow* created =
        glfwCreateWindow(1400, 900, window_title.c_str(), nullptr, nullptr);
    if (created == nullptr && !glfw_error_log.empty()) {
      glfw_error_log += std::string("\n(while trying ") + label + ")";
    }
    return created;
  };

  GLFWwindow* window = try_create_window(GLFW_OPENGL_CORE_PROFILE, "OpenGL 3.3 core");
  if (window == nullptr) {
    window = try_create_window(GLFW_OPENGL_COMPAT_PROFILE, "OpenGL 3.3 compat");
  }
  if (window == nullptr) {
    window = try_create_window(-1, "OpenGL 3.3 default profile");
  }
  if (!window) {
    std::string message = "Failed to create window (OpenGL 3.3 context).\n"
                          "This machine may lack a usable OpenGL 3.3 driver.";
    if (!glfw_error_log.empty()) {
      message += "\n\n";
      message += glfw_error_log;
    }
    pipetrace::report_fatal_error("pipetrace-view", message);
    glfwTerminate();
    return 1;
  }
  glfwSetWindowTitle(window, window_title.c_str());
  glfwMakeContextCurrent(window);
  glfwSwapInterval(1);
  pipetrace::append_diagnostic_log("GLFW window created");

  try {
  IMGUI_CHECKVERSION();
  ImGui::CreateContext();
  ImPlot::CreateContext();
  ImGuiIO& io = ImGui::GetIO();
  io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;

  pipetrace::ColorScheme color_scheme = pipetrace::ColorScheme::Night;
  pipetrace::apply_imgui_theme(color_scheme);
  ImGui_ImplGlfw_InitForOpenGL(window, true);
  if (!ImGui_ImplOpenGL3_Init("#version 330")) {
    throw std::runtime_error(
        "ImGui OpenGL3 backend failed to initialize (#version 330). "
        "Check GPU drivers / remote-desktop OpenGL support.");
  }
  pipetrace::append_diagnostic_log("ImGui/OpenGL backend ready");

  pipetrace::append_diagnostic_log("constructing TimelineView");
  pipetrace::TimelineView timeline(*store);
  pipetrace::append_diagnostic_log("TimelineView ready");
  std::optional<pipetrace::TimelineView> timeline2;
  pipetrace::RowSortState row_sort_state;
  timeline.set_row_sort_state(&row_sort_state);
  TracePinnedAttributes pinned_attributes_a =
      load_trace_pinned_attributes(*store, app_config);
  const std::unordered_set<std::string> hidden_object_keys_a =
      store->user_hidden_object_attribute_keys();
  std::optional<TracePinnedAttributes> pinned_attributes_b;
  std::unordered_set<std::string> hidden_object_keys_b;
  if (has_second_trace) {
    timeline2.emplace(*store2);
    timeline2->set_glfw_window(window);
    timeline2->set_row_sort_state(&row_sort_state);
    timeline2->set_dual_layout(true);
    timeline2->set_app_config(app_config);
    timeline2->set_color_scheme(color_scheme);
    timeline2->reset_view(meta2);
    pinned_attributes_b = load_trace_pinned_attributes(*store2, app_config);
    hidden_object_keys_b = store2->user_hidden_object_attribute_keys();
    apply_trace_pinned_attributes(*timeline2, app_config, *pinned_attributes_b, true);
  }

  timeline.set_glfw_window(window);
  timeline.set_app_config(app_config);
  timeline.set_dual_layout(has_second_trace);
  timeline.set_color_scheme(color_scheme);
  timeline.reset_view(meta);
  apply_trace_pinned_attributes(timeline, app_config, pinned_attributes_a, has_second_trace);

  const auto notify_sort_changed = [&](pipetrace::TimelineView& source) {
    if (&source != &timeline) {
      timeline.invalidate_sort_cache();
    }
    if (timeline2.has_value() && &source != &timeline2.value()) {
      timeline2->invalidate_sort_cache();
    }
  };
  timeline.set_sort_change_callback(notify_sort_changed);
  if (timeline2.has_value()) {
    timeline2->set_sort_change_callback(notify_sort_changed);
  }

  bool show_trace1 = true;
  bool show_trace2 = has_second_trace;
  bool sync_enabled = has_second_trace && app_config.has_sync_attribute();

  if (has_second_trace) {
    timeline.set_crosshair_change_callback([&](pipetrace::TimelineView& source) {
      if (!show_trace1 || !show_trace2 || !sync_enabled || !timeline2.has_value()) {
        return;
      }
      sync_partner_crosshair(source, timeline2.value(), app_config.sync_attribute, *store,
                             *store2);
    });
    timeline2->set_crosshair_change_callback([&](pipetrace::TimelineView& source) {
      if (!show_trace1 || !show_trace2 || !sync_enabled) {
        return;
      }
      sync_partner_crosshair(source, timeline, app_config.sync_attribute, *store2, *store);
    });
    timeline.set_view_zoom_change_callback([&](pipetrace::TimelineView& source) {
      if (!show_trace1 || !show_trace2 || !timeline2.has_value()) {
        return;
      }
      timeline2->apply_linked_view_zoom(source.state().cycle_width, source.state().row_height);
    });
    timeline2->set_view_zoom_change_callback([&](pipetrace::TimelineView& source) {
      if (!show_trace1 || !show_trace2) {
        return;
      }
      timeline.apply_linked_view_zoom(source.state().cycle_width, source.state().row_height);
    });
    timeline.set_view_scroll_row_change_callback([&](pipetrace::TimelineView& source) {
      if (!show_trace1 || !show_trace2 || !sync_enabled || !timeline2.has_value()) {
        return;
      }
      sync_partner_view_scroll_row(source, timeline2.value(), app_config.sync_attribute, *store,
                                   *store2);
    });
    timeline2->set_view_scroll_row_change_callback([&](pipetrace::TimelineView& source) {
      if (!show_trace1 || !show_trace2 || !sync_enabled) {
        return;
      }
      sync_partner_view_scroll_row(source, timeline, app_config.sync_attribute, *store2, *store);
    });
  }

  SyncViewDragSession sync_drag_a_to_b;
  SyncViewDragSession sync_drag_b_to_a;

  char event_type_filter[256] = {};
  const float timeline_height = io.DisplaySize.y - 80.0f;
  pipetrace::append_diagnostic_log("entering main loop");
  bool logged_first_frame = false;
  int smoke_frames_remaining = -1;
  if (const char* smoke_env = std::getenv("PIPETRACE_SMOKE_FRAMES")) {
    smoke_frames_remaining = std::atoi(smoke_env);
    if (smoke_frames_remaining < 0) {
      smoke_frames_remaining = 0;
    }
    pipetrace::append_diagnostic_log("smoke mode: exit after " +
                                     std::to_string(smoke_frames_remaining) + " frame(s)");
  }

  while (!glfwWindowShouldClose(window)) {
    glfwPollEvents();
    static bool trace1_search_focus = true;

    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplGlfw_NewFrame();
    ImGui::NewFrame();
    if (!logged_first_frame) {
      pipetrace::append_diagnostic_log("first ImGui frame started");
      logged_first_frame = true;
    }

    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(io.DisplaySize);
    ImGui::Begin("pipetrace", nullptr,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove |
                     ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_MenuBar);

    if (ImGui::BeginMenuBar()) {
      if (ImGui::BeginMenu("Trace")) {
        if (ImGui::MenuItem("Reset view")) {
          timeline.reset_view(meta);
          if (timeline2.has_value()) {
            timeline2->reset_view(meta2);
          }
        }
        ImGui::EndMenu();
      }
      ImGui::Text("  %s", meta.name.c_str());
      if (has_second_trace) {
        ImGui::Text("  |  %s", meta2.name.c_str());
      }
      ImGui::EndMenuBar();
    }

    ImGui::BeginChild("sidebar", ImVec2(260, 0), ImGuiChildFlags_Borders);
    ImGui::Text("Objects: %lld", static_cast<long long>(meta.object_count));
    ImGui::Text("Events: %lld", static_cast<long long>(meta.event_count));
    ImGui::Text("Time span: [%lld, %lld]", static_cast<long long>(meta.min_time),
                static_cast<long long>(meta.max_time));
    ImGui::Text("Theme:");
    ImGui::SameLine();
    if (ImGui::Button(pipetrace::color_scheme_label(color_scheme))) {
      color_scheme = pipetrace::cycle_color_scheme(color_scheme);
      pipetrace::apply_imgui_theme(color_scheme);
      timeline.set_color_scheme(color_scheme);
      if (timeline2.has_value()) {
        timeline2->set_color_scheme(color_scheme);
      }
    }
    if (has_second_trace) {
      ImGui::Separator();
      ImGui::Checkbox("Trace 1", &show_trace1);
      ImGui::Checkbox("Trace 2", &show_trace2);
      if (!show_trace1 && !show_trace2) {
        show_trace1 = true;
      }
      ImGui::Spacing();
      ImGui::Separator();
      ImGui::Spacing();
      const bool both_traces_visible = show_trace1 && show_trace2 && timeline2.has_value();
      if (both_traces_visible && app_config.has_sync_attribute()) {
        ImGui::Checkbox("SYNC", &sync_enabled);
        ImGui::Text("Sync attribute: %s", app_config.sync_attribute.c_str());
      } else if (app_config.has_sync_attribute()) {
        ImGui::BeginDisabled();
        ImGui::Checkbox("SYNC", &sync_enabled);
        ImGui::EndDisabled();
        ImGui::TextDisabled("SYNC requires both traces visible");
      } else {
        ImGui::TextDisabled("Sync attribute not configured");
      }
    }
    if (!app_config.sort_schemes.empty()) {
      ImGui::Separator();
      ImGui::Text("Row sort");
      const bool dual_layout = has_second_trace;
      const std::string sort_label = row_sort_state.display_label(app_config);
      if (ImGui::BeginCombo("##row_sort", sort_label.c_str())) {
        for (std::size_t scheme_index = 0; scheme_index < app_config.sort_schemes.size();
             ++scheme_index) {
          if (!pipetrace::sort_scheme_scope_visible(app_config.sort_schemes[scheme_index],
                                                   dual_layout)) {
            continue;
          }
          const bool selected = row_sort_state.config_scheme_index() == scheme_index;
          if (ImGui::Selectable(app_config.sort_schemes[scheme_index].name.c_str(), selected)) {
            pipetrace::TimelineView* sort_target = &timeline;
            if (show_trace1 && show_trace2 && timeline2.has_value()) {
              if (timeline2->is_plot_hovered()) {
                sort_target = &timeline2.value();
              } else if (!timeline.is_plot_hovered()) {
                sort_target = trace1_search_focus ? &timeline : &timeline2.value();
              }
            } else if (show_trace2 && !show_trace1 && timeline2.has_value()) {
              sort_target = &timeline2.value();
            }
            sort_target->set_sort_scheme_index(scheme_index);
          }
          if (selected) {
            ImGui::SetItemDefaultFocus();
          }
        }
        ImGui::EndCombo();
      }
      ImGui::SameLine();
      const char* direction_label = row_sort_state.direction_label(app_config);
      ImGui::PushID("sort_dir");
      if (ImGui::Button(direction_label)) {
        pipetrace::TimelineView* sort_target = &timeline;
        if (show_trace1 && show_trace2 && timeline2.has_value()) {
          if (timeline2->is_plot_hovered()) {
            sort_target = &timeline2.value();
          } else if (!timeline.is_plot_hovered()) {
            sort_target = trace1_search_focus ? &timeline : &timeline2.value();
          }
        } else if (show_trace2 && !show_trace1 && timeline2.has_value()) {
          sort_target = &timeline2.value();
        }
        sort_target->toggle_sort_direction();
      }
      ImGui::PopID();
      if (ImGui::IsItemHovered(ImGuiHoveredFlags_DelayNormal)) {
        ImGui::SetTooltip(
            "Toggle ascending/descending.\nPrefers a reverse twin scheme when configured;\n"
            "otherwise reverses the active scheme's prep-time ranks.");
      }
    }
    ImGui::Separator();
    ImGui::Text("Controls");
    sidebar_bullet_text("Trace 1 / Trace 2: show each trace");
    sidebar_bullet_text("Both on: stacked view, linked zoom");
    sidebar_bullet_text("Left drag: pan cycles and rows");
    sidebar_bullet_text("Ctrl+wheel on grid: zoom cycle/row cells");
    sidebar_bullet_text("Wheel on grid/row panel: scroll rows");
    sidebar_bullet_text("Double-click scheme-primary header: sort / toggle direction");
    sidebar_bullet_text("Row sort direction button: Asc ↔ Desc");
    sidebar_bullet_text("Left click grid: move crosshair");
    sidebar_bullet_text("Ctrl+click grid: pin marker");
    sidebar_bullet_text("Home/End: first/last event of object");
    sidebar_bullet_text("n/N: next/prev counter cycle; m/M: next/prev row cell");
    sidebar_bullet_text("Click counter strip: set active counter");
    sidebar_bullet_text("/: start or cycle search field; type to match; Enter/Esc quit");
    ImGui::Separator();
    const bool both_traces_visible = show_trace1 && show_trace2 && timeline2.has_value();
    if (show_trace1) {
      ImGui::Text("Crosshair (trace 1)");
      if (timeline.state().has_crosshair) {
        ImGui::Text("Cycle %lld, row %lld",
                    static_cast<long long>(timeline.state().crosshair.cycle),
                    static_cast<long long>(timeline.state().crosshair.row));
      } else {
        ImGui::TextDisabled("Click the timeline grid");
      }
    }
    if (show_trace2 && timeline2.has_value()) {
      ImGui::Text("Crosshair (trace 2)");
      if (timeline2->state().has_crosshair) {
        ImGui::Text("Cycle %lld, row %lld",
                    static_cast<long long>(timeline2->state().crosshair.cycle),
                    static_cast<long long>(timeline2->state().crosshair.row));
      } else {
        ImGui::TextDisabled("Click the timeline grid");
      }
    }
    std::size_t pinned_marker_count = 0;
    if (show_trace1) {
      pinned_marker_count += timeline.pinned_marker_count();
    }
    if (show_trace2 && timeline2.has_value()) {
      pinned_marker_count += timeline2->pinned_marker_count();
    }
    ImGui::Text("Pinned markers: %zu", pinned_marker_count);
    ImGui::BeginDisabled(pinned_marker_count == 0);
    if (ImGui::Button("Clear markers")) {
      if (show_trace1) {
        timeline.clear_pinned_markers();
      }
      if (show_trace2 && timeline2.has_value()) {
        timeline2->clear_pinned_markers();
      }
    }
    ImGui::EndDisabled();
    std::size_t sticky_popup_count = 0;
    if (show_trace1) {
      sticky_popup_count += timeline.sticky_popup_count();
    }
    if (show_trace2 && timeline2.has_value()) {
      sticky_popup_count += timeline2->sticky_popup_count();
    }
    ImGui::Text("Sticky popups: %zu", sticky_popup_count);
    ImGui::BeginDisabled(sticky_popup_count == 0);
    if (ImGui::Button("Clear stickies")) {
      if (show_trace1) {
        timeline.clear_sticky_popups();
      }
      if (show_trace2 && timeline2.has_value()) {
        timeline2->clear_sticky_popups();
      }
    }
    ImGui::EndDisabled();
    ImGui::Separator();
    ImGui::Text("Event chars");
    if (ImGui::Button("Char -")) {
      if (show_trace1) {
        timeline.decrease_event_char_size();
      }
      if (show_trace2 && timeline2.has_value()) {
        timeline2->decrease_event_char_size();
      }
    }
    ImGui::SameLine();
    if (ImGui::Button("Char +")) {
      if (show_trace1) {
        timeline.increase_event_char_size();
      }
      if (show_trace2 && timeline2.has_value()) {
        timeline2->increase_event_char_size();
      }
    }
    ImGui::SameLine();
    if (show_trace1) {
      ImGui::Text("%.0fpx", timeline.state().event_char_font_size);
    } else if (show_trace2 && timeline2.has_value()) {
      ImGui::Text("%.0fpx", timeline2->state().event_char_font_size);
    }

    const auto& trace1_event_types = timeline.event_types();
    const auto& trace2_event_types =
        timeline2.has_value() ? timeline2->event_types() : trace1_event_types;
    const std::vector<std::pair<pipetrace::TimelineView*,
                                const std::vector<pipetrace::EventType>*>> event_type_toggle_targets =
        timeline2.has_value()
            ? std::vector<std::pair<pipetrace::TimelineView*,
                                    const std::vector<pipetrace::EventType>*>>({
                  {&timeline, &trace1_event_types},
                  {&timeline2.value(), &trace2_event_types},
              })
            : std::vector<std::pair<pipetrace::TimelineView*,
                                    const std::vector<pipetrace::EventType>*>>({
                  {&timeline, &trace1_event_types},
              });
    pipetrace::TimelineView& selection_timeline =
        show_trace2 && !show_trace1 && timeline2.has_value() ? timeline2.value() : timeline;
    TracePinnedAttributes& sidebar_pinned_attributes =
        show_trace2 && !show_trace1 && timeline2.has_value() ? pinned_attributes_b.value()
                                                             : pinned_attributes_a;
    const std::vector<std::pair<pipetrace::TimelineView*, TracePinnedAttributes*>>
        pinned_attribute_targets =
            timeline2.has_value() && pinned_attributes_b.has_value()
                ? std::vector<std::pair<pipetrace::TimelineView*, TracePinnedAttributes*>>({
                      {&timeline, &pinned_attributes_a},
                      {&timeline2.value(), &pinned_attributes_b.value()},
                  })
                : std::vector<std::pair<pipetrace::TimelineView*, TracePinnedAttributes*>>({
                      {&timeline, &pinned_attributes_a},
                  });
    draw_object_attributes_panel(sidebar_pinned_attributes, app_config, has_second_trace,
                                 pinned_attribute_targets);
    const std::vector<pipetrace::EventType>& sidebar_event_types =
        show_trace2 && !show_trace1 && timeline2.has_value() ? trace2_event_types
                                                             : trace1_event_types;
    draw_event_types_panel(selection_timeline, sidebar_event_types, event_type_filter,
                           sizeof(event_type_filter), event_type_toggle_targets);
    ImGui::EndChild();

    ImGui::SameLine();
    ImGui::BeginChild("detail_panels", ImVec2(220, 0), ImGuiChildFlags_Borders);
    constexpr float kMarkersPanelHeight = 150.0f;
    const float item_spacing = ImGui::GetStyle().ItemSpacing.y;

    if (both_traces_visible) {
      const float half_markers_height =
          std::max(0.0f, kMarkersPanelHeight * 0.5f - item_spacing * 0.5f);
      draw_pinned_markers_panel(timeline, "pinned_markers_a", "Pinned markers (trace 1)",
                                half_markers_height);
      draw_pinned_markers_panel(timeline2.value(), "pinned_markers_b", "Pinned markers (trace 2)",
                                half_markers_height);
    } else if (show_trace2 && timeline2.has_value()) {
      draw_pinned_markers_panel(timeline2.value(), "pinned_markers_b", "Pinned markers (trace 2)",
                                kMarkersPanelHeight);
    } else {
      draw_pinned_markers_panel(timeline, "pinned_markers", "Pinned markers", kMarkersPanelHeight);
    }

    pipetrace::TimelineView& detail_timeline =
        show_trace2 && !show_trace1 && timeline2.has_value() ? timeline2.value() : timeline;
    pipetrace::TraceStore& detail_store =
        show_trace2 && !show_trace1 && timeline2.has_value() ? *store2 : *store;
    const std::unordered_set<std::string>& detail_hidden_keys =
        show_trace2 && !show_trace1 && timeline2.has_value() ? hidden_object_keys_b
                                                             : hidden_object_keys_a;

    ImGui::BeginChild("object_attrs", ImVec2(0, 0), ImGuiChildFlags_Borders);
    ImGui::Text("Selected object");
    ImGui::Separator();
    if (detail_timeline.state().has_selection) {
      if (const auto object = detail_store.find_object(detail_timeline.state().selected_object)) {
        const std::optional<std::int64_t> row =
            detail_store.object_row_index(object->id, detail_timeline.viewport_sort_scheme(),
                                          detail_timeline.viewport_ranks_ascending());
        if (row.has_value()) {
          ImGui::Text("Row %lld", static_cast<long long>(*row));
        }
        ImGui::Text("Id %lld", static_cast<long long>(object->id));
        ImGui::TextWrapped("%s", object->name.c_str());
        ImGui::Text("Cycles [%lld, %lld]", static_cast<long long>(object->first_time),
                    static_cast<long long>(object->last_time));
        ImGui::Separator();
        ImGui::Text("Attributes");
        bool showed_attr = false;
        for (const auto& [key, value] : object->attributes) {
          if (detail_hidden_keys.contains(key)) {
            continue;
          }
          const std::string display =
              pipetrace::format_percentage_attribute(key, value).value_or(value);
          ImGui::Text("%s: %s", key.c_str(), display.c_str());
          showed_attr = true;
        }
        if (!showed_attr) {
          ImGui::TextDisabled("(none)");
        }

        if (detail_timeline.state().has_selected_cell) {
          ImGui::Separator();
          const pipetrace::GridPosition& cell = detail_timeline.state().selected_cell;
          ImGui::Text("Events at cycle %lld, row %lld",
                      static_cast<long long>(cell.cycle), static_cast<long long>(cell.row));
          if (detail_timeline.state().selected_cell_events.empty()) {
            ImGui::TextDisabled("(no events in cell)");
          } else {
            for (std::size_t event_index = 0;
                 event_index < detail_timeline.state().selected_cell_events.size(); ++event_index) {
              const pipetrace::CellEventInfo& event =
                  detail_timeline.state().selected_cell_events[event_index];
              ImGui::PushID(static_cast<int>(event_index));
              ImGui::Text("'%c' %s (id %lld)", event.display_char, event.kind.c_str(),
                          static_cast<long long>(event.id));
              if (event.attributes.empty()) {
                ImGui::TextDisabled("  (no attributes)");
              } else {
                for (const auto& [key, value] : event.attributes) {
                  ImGui::Text("  %s: %s", key.c_str(), value.c_str());
                }
              }
              ImGui::PopID();
            }
          }
        }
      } else {
        ImGui::TextDisabled("Object not found");
      }
    } else {
      ImGui::TextDisabled("Click a row in the timeline");
    }
    ImGui::EndChild();
    ImGui::EndChild();

    ImGui::SameLine();
    if (both_traces_visible) {
      ImGui::BeginChild("timeline_column", ImVec2(0, 0), ImGuiChildFlags_Borders);
      const float avail_height = ImGui::GetContentRegionAvail().y;
      const float label_height = ImGui::GetTextLineHeightWithSpacing();
      const float half_height = avail_height * 0.5f;
      const float trace_plot_height =
          std::max(0.0f, half_height - label_height - item_spacing);
      ImGui::BeginChild("timeline_a_panel", ImVec2(0, half_height), ImGuiChildFlags_Borders);
      ImGui::Text("Trace 1: %s", meta.name.c_str());
      timeline.draw("timeline_a", trace_plot_height);
      ImGui::EndChild();
      ImGui::BeginChild("timeline_b_panel", ImVec2(0, half_height), ImGuiChildFlags_Borders);
      ImGui::Text("Trace 2: %s", meta2.name.c_str());
      timeline2->draw("timeline_b", trace_plot_height);
      ImGui::EndChild();
      ImGui::EndChild();
    } else if (show_trace2 && timeline2.has_value()) {
      ImGui::BeginChild("timeline_column", ImVec2(0, 0), ImGuiChildFlags_Borders);
      ImGui::Text("Trace 2: %s", meta2.name.c_str());
      timeline2->draw("timeline_b", timeline_height);
      ImGui::EndChild();
    } else {
      ImGui::BeginChild("timeline_column", ImVec2(0, 0), ImGuiChildFlags_Borders);
      ImGui::Text("Trace 1: %s", meta.name.c_str());
      timeline.draw("timeline", timeline_height);
      ImGui::EndChild();
    }
    ImGui::End();

    if (show_trace1) {
      timeline.draw_event_popups();
    }
    if (show_trace2 && timeline2.has_value()) {
      timeline2->draw_event_popups();
    }

    if (both_traces_visible) {
      if (timeline.is_plot_hovered()) {
        trace1_search_focus = true;
      }
      if (timeline2->is_plot_hovered()) {
        trace1_search_focus = false;
      }
      timeline.set_input_focused(trace1_search_focus);
      timeline2->set_input_focused(!trace1_search_focus);
    } else {
      timeline.set_input_focused(show_trace1);
      if (timeline2.has_value()) {
        timeline2->set_input_focused(show_trace2);
      }
    }

    if (show_trace1 && timeline.input_focused()) {
      timeline.handle_search_input();
      timeline.handle_counter_nav_input();
    }
    if (show_trace2 && timeline2.has_value() && timeline2->input_focused()) {
      timeline2->handle_search_input();
      timeline2->handle_counter_nav_input();
    }
    // Apply async search hits even if this frame had no keystrokes.
    if (show_trace1) {
      timeline.poll_search_results();
    }
    if (show_trace2 && timeline2.has_value()) {
      timeline2->poll_search_results();
    }

    if (show_trace1 && timeline.is_search_active()) {
      timeline.draw_search_overlay();
    }
    if (show_trace2 && timeline2.has_value() && timeline2->is_search_active()) {
      timeline2->draw_search_overlay();
    }

    const bool trace1_drag = show_trace1 && timeline.is_view_scroll_drag_active();
    const bool trace2_drag =
        show_trace2 && timeline2.has_value() && timeline2->is_view_scroll_drag_active();

    const bool trace1_drag_before = trace1_drag;
    const bool trace2_drag_before = trace2_drag;

    if (show_trace1) {
      timeline.set_view_drag_input_blocked(both_traces_visible && trace2_drag_before);
      timeline.handle_plot_input();
    }
    if (show_trace2 && timeline2.has_value()) {
      timeline2->set_view_drag_input_blocked(both_traces_visible && trace1_drag_before);
      timeline2->handle_plot_input();
    }
    if (show_trace1) {
      timeline.apply_view_scroll_drag_if_active();
    }
    if (show_trace2 && timeline2.has_value()) {
      timeline2->apply_view_scroll_drag_if_active();
    }

    if (sync_enabled && both_traces_visible) {
      sync_partner_during_view_drag(timeline, timeline2.value(), sync_drag_a_to_b,
                                    app_config.sync_attribute, *store, *store2);
      sync_partner_during_view_drag(timeline2.value(), timeline, sync_drag_b_to_a,
                                    app_config.sync_attribute, *store2, *store);
      if (trace1_drag) {
        timeline2->draw_sync_partner_highlight_overlay();
      }
      if (trace2_drag) {
        timeline.draw_sync_partner_highlight_overlay();
      }
    }

    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    glfwSwapBuffers(window);

    if (smoke_frames_remaining >= 0) {
      if (smoke_frames_remaining == 0) {
        pipetrace::append_diagnostic_log("smoke mode: exiting after frame budget");
        glfwSetWindowShouldClose(window, GLFW_TRUE);
      } else {
        --smoke_frames_remaining;
      }
    }
  }

  ImGui_ImplOpenGL3_Shutdown();
  ImGui_ImplGlfw_Shutdown();
  ImPlot::DestroyContext();
  ImGui::DestroyContext();
  glfwDestroyWindow(window);
  glfwTerminate();
  g_glfw_error_sink = nullptr;
  return 0;
  } catch (const std::exception& ex) {
    pipetrace::report_fatal_error("pipetrace-view",
                                  std::string("Viewer error: ") + ex.what());
    glfwDestroyWindow(window);
    glfwTerminate();
    g_glfw_error_sink = nullptr;
    return 1;
  } catch (...) {
    pipetrace::report_fatal_error("pipetrace-view", "Viewer error: unknown exception.");
    glfwDestroyWindow(window);
    glfwTerminate();
    g_glfw_error_sink = nullptr;
    return 1;
  }
}
