#include "pipetrace/fatal_error.hpp"

#include <iostream>

#if defined(_WIN32)
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#endif

namespace pipetrace {
namespace {

#if defined(_WIN32)
std::wstring utf8_to_wide(const std::string& utf8) {
  if (utf8.empty()) {
    return {};
  }
  const int needed =
      MultiByteToWideChar(CP_UTF8, 0, utf8.data(), static_cast<int>(utf8.size()), nullptr, 0);
  if (needed <= 0) {
    return {};
  }
  std::wstring wide(static_cast<std::size_t>(needed), L'\0');
  MultiByteToWideChar(CP_UTF8, 0, utf8.data(), static_cast<int>(utf8.size()), wide.data(), needed);
  return wide;
}
#endif

}  // namespace

void report_fatal_error(const std::string& title, const std::string& message) {
  std::cerr << title << ": " << message << '\n';
  std::cerr.flush();

#if defined(_WIN32)
  const std::wstring wide_title = utf8_to_wide(title);
  const std::wstring wide_message = utf8_to_wide(message);
  MessageBoxW(nullptr, wide_message.empty() ? L"(no details)" : wide_message.c_str(),
              wide_title.empty() ? L"pipetrace" : wide_title.c_str(),
              MB_OK | MB_ICONERROR | MB_SETFOREGROUND);
#endif
}

}  // namespace pipetrace
