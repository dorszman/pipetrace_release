#pragma once

#include <algorithm>
#include <cstddef>
#include <optional>
#include <string>

#include "pipetrace/app_config.hpp"
#include "pipetrace/sort_sql.hpp"

namespace pipetrace {

class RowSortState {
 public:
  bool user_mode() const { return user_mode_; }
  std::size_t config_scheme_index() const { return config_scheme_index_; }
  const std::string& user_column_key() const { return user_column_key_; }
  bool user_ascending() const { return user_ascending_; }

  bool set_config_scheme_index(std::size_t index, const AppConfig& config) {
    if (config.sort_schemes.empty()) {
      return false;
    }
    const std::size_t clamped = std::min(index, config.sort_schemes.size() - 1);
    bool changed = false;
    if (user_mode_) {
      user_mode_ = false;
      changed = true;
    }
    if (clamped != config_scheme_index_) {
      config_scheme_index_ = clamped;
      changed = true;
    }
    return changed;
  }

  void apply_header_double_click(const std::string& column_key) {
    if (!is_valid_attribute_sort_key(column_key)) {
      return;
    }
    if (user_mode_ && user_column_key_ == column_key) {
      user_ascending_ = !user_ascending_;
    } else {
      user_mode_ = true;
      user_column_key_ = column_key;
      user_ascending_ = true;
    }
    user_scheme_cache_valid_ = false;
  }

  void clamp_config_scheme_index(const AppConfig& config) {
    if (config.sort_schemes.empty()) {
      config_scheme_index_ = 0;
      return;
    }
    config_scheme_index_ = std::min(config_scheme_index_, config.sort_schemes.size() - 1);
  }

  const SortScheme* active_sort_scheme(const AppConfig& config) const {
    if (user_mode_) {
      if (!user_scheme_cache_valid_) {
        user_scheme_cache_.name = "User";
        user_scheme_cache_.columns = {
            {user_column_key_, user_ascending_ ? "asc" : "desc"}};
        user_scheme_cache_valid_ = true;
      }
      return &user_scheme_cache_;
    }
    if (config.sort_schemes.empty()) {
      return nullptr;
    }
    const std::size_t idx = std::min(config_scheme_index_, config.sort_schemes.size() - 1);
    return &config.sort_schemes[idx];
  }

  std::optional<bool> active_sort_direction_for_column(const std::string& column_key,
                                                       const AppConfig& config) const {
    if (user_mode_) {
      if (column_key != user_column_key_) {
        return std::nullopt;
      }
      return user_ascending_;
    }
    const SortScheme* scheme = active_sort_scheme(config);
    if (scheme == nullptr || scheme->columns.empty()) {
      return std::nullopt;
    }
    if (scheme->columns[0].key != column_key) {
      return std::nullopt;
    }
    return scheme->columns[0].order == "asc";
  }

  std::string display_label(const AppConfig& config) const {
    if (user_mode_) {
      const char* order = user_ascending_ ? "asc" : "desc";
      return "User (" + user_column_key_ + " " + order + ")";
    }
    if (config.sort_schemes.empty()) {
      return "Default";
    }
    const std::size_t idx = std::min(config_scheme_index_, config.sort_schemes.size() - 1);
    return config.sort_schemes[idx].name;
  }

 private:
  bool user_mode_{false};
  std::size_t config_scheme_index_{0};
  std::string user_column_key_;
  bool user_ascending_{true};
  mutable SortScheme user_scheme_cache_;
  mutable bool user_scheme_cache_valid_{false};
};

}  // namespace pipetrace
