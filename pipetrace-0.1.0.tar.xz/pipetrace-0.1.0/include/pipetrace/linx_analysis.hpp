#pragma once

#include <cstddef>
#include <string>

#include "pipetrace/progress.hpp"

namespace pipetrace {

struct LinxDbAnalysisOptions {
  std::string store_path;
  std::string output_path;
  std::string config_path;
  std::string log_path;
  StatusMode status_mode{StatusMode::Pretty};
  bool verbose{false};
  bool dry_run{false};
  bool force{false};
  ProgressReporter* progress{nullptr};
};

struct LinxDbDualAnalysisOptions {
  std::string store_path;
  std::string store2_path;
  std::string output_path;
  std::string output2_path;
  std::string log_path;
  StatusMode status_mode{StatusMode::Pretty};
  bool verbose{false};
  bool dry_run{false};
  bool force{false};
  ProgressReporter* progress{nullptr};
};

struct LinxDualTraceAnalysisStats {
  std::size_t dual_matched{0};
  std::size_t dual_missing_trace1{0};
  std::size_t dual_missing_trace2{0};
  std::size_t dual_pushup_updated{0};
  std::size_t dual_pushup_skipped{0};
  std::size_t dual_pc_profiling_updated{0};
  std::size_t warnings{0};
};

struct LinxDbAnalysisStats {
  std::size_t uops_updated{0};
  std::size_t uops_skipped{0};
  std::size_t instructions_updated{0};
  std::size_t instructions_skipped{0};
  std::size_t warnings{0};

  std::size_t uop_no_parent{0};
  std::size_t uop_orphan_parent{0};
  std::size_t uop_parent_not_instruction{0};
  std::size_t uop_no_retire_inst{0};
  std::size_t retire_inst_missing_inst_id{0};
  std::size_t multiple_retire_inst{0};
  std::size_t uop_inst_id_overwritten{0};
  std::size_t instruction_inst_id_overwritten{0};
  std::size_t instruction_no_retire_inst{0};

  std::size_t retire_pushup_updated{0};
  std::size_t retire_pushup_skipped{0};
  std::size_t retire_pushup_first_uop_skipped{0};
  std::size_t retire_pushup_no_inst_id{0};
  std::size_t retire_pushup_overwritten{0};

  std::size_t pc_promoted{0};
  std::size_t pc_skipped{0};
  std::size_t pc_no_parent{0};
  std::size_t pc_parent_missing{0};
  std::size_t pc_overwritten{0};

  std::size_t pc_profiling_updated{0};
  std::size_t pc_profiling_skipped{0};
  std::size_t pc_profiling_overwritten{0};

  std::size_t strength_color_updated{0};
  std::size_t strength_color_skipped{0};
};

enum class LinxDbAnalysisOutcome {
  Analyzed,
  Skipped,
};

struct LinxDbAnalysisRunResult {
  LinxDbAnalysisOutcome outcome{LinxDbAnalysisOutcome::Analyzed};
  LinxDbAnalysisStats stats;
  std::string message;
};

enum class LinxDbDualAnalysisOutcome {
  Analyzed,
  Skipped,
};

struct LinxDbDualAnalysisResult {
  LinxDbDualAnalysisOutcome outcome{LinxDbDualAnalysisOutcome::Analyzed};
  LinxDualTraceAnalysisStats dual;
  std::string message;
};

LinxDbAnalysisStats analyze_linx_store(const LinxDbAnalysisOptions& options);
LinxDbAnalysisRunResult run_linx_db_analysis(const LinxDbAnalysisOptions& options);

LinxDbDualAnalysisResult run_linx_db_dual_analysis(const LinxDbDualAnalysisOptions& options);

}  // namespace pipetrace
