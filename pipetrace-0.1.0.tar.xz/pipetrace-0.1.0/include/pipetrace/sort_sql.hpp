#pragma once

#include <string>
#include <vector>

#include "pipetrace/app_config.hpp"

namespace pipetrace {

bool is_valid_attribute_sort_key(const std::string& key);

// Builds "ORDER BY <exprs>, id" (no leading ORDER BY keyword if empty columns).
std::string build_object_sort_order_by_clause(const SortScheme& scheme);

// SQL expression comparing one attribute value for ORDER BY (missing-last for asc).
std::string build_attribute_sort_key_sql(const std::string& attribute_key, bool ascending);

}  // namespace pipetrace
