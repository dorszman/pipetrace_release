#pragma once

#include <memory>
#include <optional>
#include <string>
#include <unordered_map>
#include <vector>

#include "pipetrace/columnar.hpp"
#include "pipetrace/types.hpp"
#include "pipetrace/app_config.hpp"

namespace pipetrace {

struct AttributeSearchMatch {
  ObjectId object_id{};
  std::int64_t row_index{};
};

class TraceStore {
 public:
  virtual ~TraceStore() = default;

  virtual bool open(const std::string& path) = 0;
  virtual void close() = 0;

  virtual TraceMeta meta() const = 0;
  virtual std::vector<ObjectType> object_types() const = 0;
  virtual std::vector<EventType> event_types() const = 0;

  virtual ColumnarObjects query_objects(const Viewport& viewport,
                                        std::int64_t prefetch_rows = 8,
                                        const SortScheme* sort_scheme = nullptr) = 0;
  virtual ColumnarEvents query_events(const Viewport& viewport,
                                      const std::vector<ObjectId>& object_ids) = 0;

  virtual std::vector<CycleOccurrenceCount> query_event_cycle_counts(
      std::int64_t event_type_id) const = 0;

  virtual std::optional<TraceObject> find_object(ObjectId id) const = 0;
  virtual std::optional<ObjectId> object_id_for_row(std::int64_t row,
                                                    const SortScheme* sort_scheme = nullptr) const = 0;
  virtual std::optional<std::int64_t> object_row_index(ObjectId id,
                                                       const SortScheme* sort_scheme = nullptr) const = 0;
  virtual std::unordered_map<std::string, std::int64_t> build_attribute_row_index(
      const std::string& attribute_key) const = 0;
  virtual std::optional<AttributeSearchMatch> find_first_object_by_attribute(
      const std::string& attribute_key, const std::string& prefix,
      const SortScheme* sort_scheme = nullptr) const = 0;

  virtual std::vector<std::string> object_attribute_keys() const = 0;
};

std::unique_ptr<TraceStore> create_sqlite_store();

}  // namespace pipetrace
