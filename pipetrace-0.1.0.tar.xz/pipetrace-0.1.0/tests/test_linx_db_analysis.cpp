#include <algorithm>
#include <filesystem>
#include <fstream>
#include <string>
#include <sys/stat.h>

// Analysis uses streaming SQL join cursors with O(1) heap (bounded update batch only).
#include "gtest/gtest.h"
#include "pipetrace/attributes.hpp"
#include "pipetrace/linx_analysis.hpp"
#include "pipetrace/linx_pt.hpp"
#include "pipetrace/storage.hpp"
#include "storage/sqlite_store.hpp"

namespace {

std::string temp_path(const std::string& name) {
  return (std::filesystem::temp_directory_path() / name).string();
}

void write_minimal_config(const std::string& path) {
  std::ofstream out(path, std::ios::trunc);
  out << R"({
  "cast_tool": { "command": "./build/pipetrace-linx-parser" },
  "pinned_row_attributes": [],
  "event_type_display": []
})";
}

pipetrace::LinxPtCastStats cast_generated_trace(const std::string& pt_path,
                                                const std::string& db_path,
                                                std::int64_t object_count,
                                                bool include_tree = true) {
  pipetrace::LinxPtGenerateOptions gen;
  gen.output_path = pt_path;
  gen.object_count = object_count;
  gen.events_per_object = 2;
  gen.uops_per_instruction = 4;
  gen.cycle_span = 32;
  gen.seed = 7;
  gen.include_tree = include_tree;
  pipetrace::generate_linx_pt_trace(gen);

  const std::string config = temp_path("linx_analysis_cast_config.json");
  write_minimal_config(config);

  pipetrace::LinxPtCastOptions cast;
  cast.input_path = pt_path;
  cast.store_path = db_path;
  cast.config_path = config;
  return pipetrace::cast_linx_pt_to_store(cast);
}

std::int64_t current_file_mtime_seconds(const std::string& path) {
  struct stat st {};
  if (stat(path.c_str(), &st) != 0) {
    return -1;
  }
  return static_cast<std::int64_t>(st.st_mtime);
}

}  // namespace

TEST(LinxDbAnalysis, PopulatesObjectAttributeKeys) {
  const std::string pt = temp_path("linx_analysis_keys.pt");
  const std::string db = temp_path("linx_analysis_keys.db");
  cast_generated_trace(pt, db, 64);

  auto store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(store->open(db));
  const std::vector<std::string> keys_before = store->object_attribute_keys();
  EXPECT_FALSE(keys_before.empty());
  EXPECT_NE(std::find(keys_before.begin(), keys_before.end(), "type"), keys_before.end());

  pipetrace::LinxDbAnalysisOptions options;
  options.store_path = db;
  pipetrace::analyze_linx_store(options);

  const std::vector<std::string> keys_after = store->object_attribute_keys();
  EXPECT_FALSE(keys_after.empty());
  EXPECT_NE(std::find(keys_after.begin(), keys_after.end(), "InstID"), keys_after.end());
  EXPECT_NE(std::find(keys_after.begin(), keys_after.end(), "id"), keys_after.end());
  EXPECT_NE(std::find(keys_after.begin(), keys_after.end(), "parent_id"), keys_after.end());
}

TEST(LinxDbAnalysis, PromotesInstIdOntoUops) {
  const std::string pt = temp_path("linx_analysis.pt");
  const std::string db = temp_path("linx_analysis.db");
  cast_generated_trace(pt, db, 128);

  pipetrace::LinxDbAnalysisOptions options;
  options.store_path = db;
  const pipetrace::LinxDbAnalysisStats stats = pipetrace::analyze_linx_store(options);
  EXPECT_GT(stats.uops_updated, 0U);
  EXPECT_EQ(stats.uops_skipped, 0U);

  auto trace_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store->open(db));

  const auto uop7 = trace_store->find_object(7);
  ASSERT_TRUE(uop7.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop7->attributes, "type"), "Uop");
  EXPECT_EQ(uop7->parent_id, 5);
  EXPECT_EQ(pipetrace::attribute_value(uop7->attributes, "id"), "7");
  EXPECT_EQ(pipetrace::attribute_value(uop7->attributes, "parent_id"), "5");
  EXPECT_EQ(pipetrace::attribute_value(uop7->attributes, "InstID"), "1");

  const auto instruction5 = trace_store->find_object(5);
  ASSERT_TRUE(instruction5.has_value());
  EXPECT_EQ(pipetrace::attribute_value(instruction5->attributes, "InstID"), "1");
  EXPECT_EQ(pipetrace::attribute_value(instruction5->attributes, "id"), "5");
  EXPECT_EQ(pipetrace::attribute_value(instruction5->attributes, "parent_id"), "");
}

TEST(LinxDbAnalysis, PromotesInstIdOntoInstructions) {
  const std::string pt = temp_path("linx_analysis_inst.pt");
  const std::string db = temp_path("linx_analysis_inst.db");
  cast_generated_trace(pt, db, 128);

  pipetrace::LinxDbAnalysisOptions options;
  options.store_path = db;
  const pipetrace::LinxDbAnalysisStats stats = pipetrace::analyze_linx_store(options);
  EXPECT_GT(stats.instructions_updated, 0U);

  auto trace_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store->open(db));

  const auto instruction0 = trace_store->find_object(0);
  ASSERT_TRUE(instruction0.has_value());
  EXPECT_EQ(pipetrace::attribute_value(instruction0->attributes, "type"), "Instruction");
  EXPECT_EQ(pipetrace::attribute_value(instruction0->attributes, "InstID"), "0");

  const auto instruction5 = trace_store->find_object(5);
  ASSERT_TRUE(instruction5.has_value());
  EXPECT_EQ(pipetrace::attribute_value(instruction5->attributes, "InstID"), "1");
}

TEST(LinxDbAnalysis, PromotesObjectIdentityOntoAllObjects) {
  const std::string pt = temp_path("linx_analysis_identity.pt");
  const std::string db = temp_path("linx_analysis_identity.db");
  cast_generated_trace(pt, db, 32);

  pipetrace::LinxDbAnalysisOptions options;
  options.store_path = db;
  pipetrace::analyze_linx_store(options);

  auto trace_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store->open(db));

  const auto instruction0 = trace_store->find_object(0);
  ASSERT_TRUE(instruction0.has_value());
  EXPECT_EQ(pipetrace::attribute_value(instruction0->attributes, "id"), "0");
  EXPECT_EQ(pipetrace::attribute_value(instruction0->attributes, "parent_id"), "");

  const auto uop1 = trace_store->find_object(1);
  ASSERT_TRUE(uop1.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop1->attributes, "id"), "1");
  EXPECT_EQ(pipetrace::attribute_value(uop1->attributes, "parent_id"), "0");
}

TEST(LinxDbAnalysis, IdempotentRerun) {
  const std::string pt = temp_path("linx_analysis_idempotent.pt");
  const std::string db = temp_path("linx_analysis_idempotent.db");
  cast_generated_trace(pt, db, 64);

  pipetrace::LinxDbAnalysisOptions options;
  options.store_path = db;
  const pipetrace::LinxDbAnalysisStats first = pipetrace::analyze_linx_store(options);
  EXPECT_GT(first.uops_updated, 0U);

  const pipetrace::LinxDbAnalysisStats second = pipetrace::analyze_linx_store(options);
  EXPECT_EQ(second.uops_updated, 0U);
  EXPECT_EQ(second.instructions_updated, 0U);
  EXPECT_EQ(second.pc_promoted, 0U);
  EXPECT_EQ(second.pc_profiling_updated, 0U);
  EXPECT_EQ(second.uop_inst_id_overwritten, 0U);
  EXPECT_EQ(second.instruction_inst_id_overwritten, 0U);
}

TEST(LinxDbAnalysis, FlatTraceSkipsUops) {
  const std::string pt = temp_path("linx_analysis_flat.pt");
  const std::string db = temp_path("linx_analysis_flat.db");
  cast_generated_trace(pt, db, 32, false);

  pipetrace::LinxDbAnalysisOptions options;
  options.store_path = db;
  const pipetrace::LinxDbAnalysisStats stats = pipetrace::analyze_linx_store(options);
  EXPECT_EQ(stats.uops_updated, 0U);
  EXPECT_GT(stats.uop_no_parent, 0U);
}

TEST(LinxDbAnalysis, OutputCopyLeavesInputUnchanged) {
  const std::string pt = temp_path("linx_analysis_copy.pt");
  const std::string input_db = temp_path("linx_analysis_copy_in.db");
  const std::string output_db = temp_path("linx_analysis_copy_out.db");
  cast_generated_trace(pt, input_db, 64);

  pipetrace::LinxDbAnalysisOptions options;
  options.store_path = input_db;
  options.output_path = output_db;
  const pipetrace::LinxDbAnalysisStats stats = pipetrace::analyze_linx_store(options);
  EXPECT_GT(stats.uops_updated, 0U);

  auto input_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(input_store->open(input_db));
  const auto input_uop = input_store->find_object(7);
  ASSERT_TRUE(input_uop.has_value());
  EXPECT_EQ(pipetrace::attribute_value(input_uop->attributes, "InstID"), "");

  auto output_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(output_store->open(output_db));
  const auto output_uop = output_store->find_object(7);
  ASSERT_TRUE(output_uop.has_value());
  EXPECT_EQ(pipetrace::attribute_value(output_uop->attributes, "InstID"), "1");
}

TEST(LinxDbAnalysis, DryRunDoesNotModifyStore) {
  const std::string pt = temp_path("linx_analysis_dry.pt");
  const std::string db = temp_path("linx_analysis_dry.db");
  cast_generated_trace(pt, db, 64);

  pipetrace::LinxDbAnalysisOptions options;
  options.store_path = db;
  options.dry_run = true;
  const pipetrace::LinxDbAnalysisStats stats = pipetrace::analyze_linx_store(options);
  EXPECT_GT(stats.uops_updated, 0U);

  auto trace_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store->open(db));
  const auto uop = trace_store->find_object(7);
  ASSERT_TRUE(uop.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop->attributes, "InstID"), "");
  EXPECT_EQ(pipetrace::attribute_value(uop->attributes, "id"), "");
}

TEST(LinxDbAnalysis, MissingRetireInstSkipsChildUops) {
  const std::string db = temp_path("linx_analysis_missing_retire.db");
  std::filesystem::remove(db);

  pipetrace::SqliteStore store;
  ASSERT_TRUE(store.open(db));
  store.exec_sql("BEGIN IMMEDIATE;");
  store.insert_object_type(1, "object", "Object");
  store.insert_event_type(1, "retire_inst", 1, 0xFF888888U);
  store.insert_object(5, 1, "inst_5", 0, 10, -1, R"({"type":"Instruction"})");
  store.insert_object(7, 1, "uop_7", 0, 10, 5, R"({"type":"Uop","disasm":"nop"})");
  store.set_meta("handcrafted", 0, 10, 2, 0);
  store.commit_transaction();

  pipetrace::LinxDbAnalysisOptions options;
  options.store_path = db;
  const pipetrace::LinxDbAnalysisStats stats = pipetrace::analyze_linx_store(options);
  EXPECT_EQ(stats.uops_updated, 0U);
  EXPECT_EQ(stats.uop_no_retire_inst, 1U);
}

TEST(LinxDbAnalysis, MultipleRetireInstLastWins) {
  const std::string db = temp_path("linx_analysis_multi_retire.db");
  std::filesystem::remove(db);

  pipetrace::SqliteStore store;
  ASSERT_TRUE(store.open(db));
  store.exec_sql("BEGIN IMMEDIATE;");
  store.insert_object_type(1, "object", "Object");
  store.insert_event_type(1, "retire_inst", 1, 0xFF888888U);
  store.insert_object(5, 1, "inst_5", 0, 10, -1, R"({"type":"Instruction"})");
  store.insert_object(7, 1, "uop_7", 0, 10, 5, R"({"type":"Uop","disasm":"nop"})");
  store.insert_event(1, 5, 1, "retire_inst", 8, R"({"InstID":"9"})");
  store.insert_event(2, 5, 1, "retire_inst", 9, R"({"InstID":"42"})");
  store.set_meta("handcrafted", 0, 10, 2, 2);
  store.commit_transaction();

  pipetrace::LinxDbAnalysisOptions options;
  options.store_path = db;
  const pipetrace::LinxDbAnalysisStats stats = pipetrace::analyze_linx_store(options);
  EXPECT_EQ(stats.uops_updated, 1U);
  EXPECT_EQ(stats.instructions_updated, 1U);
  EXPECT_GE(stats.multiple_retire_inst, 1U);

  auto trace_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store->open(db));
  const auto instruction = trace_store->find_object(5);
  ASSERT_TRUE(instruction.has_value());
  EXPECT_EQ(pipetrace::attribute_value(instruction->attributes, "InstID"), "42");
  const auto uop = trace_store->find_object(7);
  ASSERT_TRUE(uop.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop->attributes, "InstID"), "42");
}

TEST(LinxDbAnalysis, RetirePushupSetsDeltaFromPreviousUop) {
  const std::string db = temp_path("linx_analysis_retire_pushup.db");
  std::filesystem::remove(db);

  pipetrace::SqliteStore store;
  ASSERT_TRUE(store.open(db));
  store.exec_sql("BEGIN IMMEDIATE;");
  store.insert_object_type(1, "object", "Object");
  store.insert_event_type(1, "retire_inst", 1, 0xFF888888U);
  store.insert_event_type(2, "retire_uop", 1, 0xFF666666U);
  store.insert_object(0, 1, "inst_0", 0, 10, -1, R"({"type":"Instruction"})");
  store.insert_object(1, 1, "uop_1", 0, 10, 0, R"({"type":"Uop","disasm":"nop"})");
  store.insert_object(2, 1, "uop_2", 0, 10, 0, R"({"type":"Uop","disasm":"add"})");
  store.insert_object(5, 1, "inst_1", 0, 20, -1, R"({"type":"Instruction"})");
  store.insert_object(6, 1, "uop_6", 0, 20, 5, R"({"type":"Uop","disasm":"mul"})");
  store.insert_event(1, 0, 1, "retire_inst", 100, R"({"InstID":"0"})");
  store.insert_event(2, 1, 2, "retire_uop", 10, "{}");
  store.insert_event(3, 2, 2, "retire_uop", 15, "{}");
  store.insert_event(4, 5, 1, "retire_inst", 200, R"({"InstID":"1"})");
  store.insert_event(5, 6, 2, "retire_uop", 25, "{}");
  store.set_meta("handcrafted", 0, 200, 5, 5);
  store.commit_transaction();

  pipetrace::LinxDbAnalysisOptions options;
  options.store_path = db;
  const pipetrace::LinxDbAnalysisStats stats = pipetrace::analyze_linx_store(options);
  EXPECT_EQ(stats.retire_pushup_updated, 2U);
  EXPECT_EQ(stats.retire_pushup_first_uop_skipped, 1U);

  auto trace_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store->open(db));

  const auto uop1 = trace_store->find_object(1);
  ASSERT_TRUE(uop1.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop1->attributes, "InstID"), "0");
  EXPECT_EQ(pipetrace::attribute_value(uop1->attributes, "RetirePushup"), "");

  const auto uop2 = trace_store->find_object(2);
  ASSERT_TRUE(uop2.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop2->attributes, "RetirePushup"), "5");

  const auto uop6 = trace_store->find_object(6);
  ASSERT_TRUE(uop6.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop6->attributes, "InstID"), "1");
  EXPECT_EQ(pipetrace::attribute_value(uop6->attributes, "RetirePushup"), "10");
}

TEST(LinxDbAnalysis, RetirePushupUop4MinusUop3) {
  const std::string db = temp_path("linx_analysis_retire_pushup_uop34.db");
  std::filesystem::remove(db);

  pipetrace::SqliteStore store;
  ASSERT_TRUE(store.open(db));
  store.exec_sql("BEGIN IMMEDIATE;");
  store.insert_object_type(1, "object", "Object");
  store.insert_event_type(1, "retire_inst", 1, 0xFF888888U);
  store.insert_event_type(2, "retire_uop", 1, 0xFF666666U);
  store.insert_object(0, 1, "inst_0", 0, 10, -1, R"({"type":"Instruction"})");
  store.insert_object(1, 1, "uop_1", 0, 10, 0, R"({"type":"Uop"})");
  store.insert_object(2, 1, "uop_2", 0, 10, 0, R"({"type":"Uop"})");
  store.insert_object(3, 1, "uop_3", 0, 10, 0, R"({"type":"Uop"})");
  store.insert_object(4, 1, "uop_4", 0, 10, 0, R"({"type":"Uop"})");
  store.insert_event(1, 0, 1, "retire_inst", 100, R"({"InstID":"0"})");
  store.insert_event(2, 1, 2, "retire_uop", 5, "{}");
  store.insert_event(3, 2, 2, "retire_uop", 8, "{}");
  store.insert_event(4, 3, 2, "retire_uop", 20, "{}");
  store.insert_event(5, 4, 2, "retire_uop", 27, "{}");
  store.set_meta("handcrafted", 0, 100, 5, 5);
  store.commit_transaction();

  pipetrace::LinxDbAnalysisOptions options;
  options.store_path = db;
  pipetrace::analyze_linx_store(options);

  auto trace_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store->open(db));
  const auto uop3 = trace_store->find_object(3);
  ASSERT_TRUE(uop3.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop3->attributes, "RetirePushup"), "12");
  const auto uop4 = trace_store->find_object(4);
  ASSERT_TRUE(uop4.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop4->attributes, "RetirePushup"), "7");
}

TEST(LinxDbAnalysis, RetirePushupUsesMaxRetireUopCyclePerUop) {
  const std::string db = temp_path("linx_analysis_retire_pushup_max.db");
  std::filesystem::remove(db);

  pipetrace::SqliteStore store;
  ASSERT_TRUE(store.open(db));
  store.exec_sql("BEGIN IMMEDIATE;");
  store.insert_object_type(1, "object", "Object");
  store.insert_event_type(1, "retire_inst", 1, 0xFF888888U);
  store.insert_event_type(2, "retire_uop", 1, 0xFF666666U);
  store.insert_object(0, 1, "inst_0", 0, 10, -1, R"({"type":"Instruction"})");
  store.insert_object(1, 1, "uop_1", 0, 10, 0, R"({"type":"Uop"})");
  store.insert_object(2, 1, "uop_2", 0, 10, 0, R"({"type":"Uop"})");
  store.insert_object(5, 1, "inst_1", 0, 20, -1, R"({"type":"Instruction"})");
  store.insert_object(6, 1, "uop_6", 0, 20, 5, R"({"type":"Uop"})");
  store.insert_event(1, 0, 1, "retire_inst", 100, R"({"InstID":"0"})");
  store.insert_event(2, 1, 2, "retire_uop", 10, "{}");
  store.insert_event(3, 2, 2, "retire_uop", 20, "{}");
  store.insert_event(4, 2, 2, "retire_uop", 18, "{}");
  store.insert_event(5, 5, 1, "retire_inst", 200, R"({"InstID":"1"})");
  store.insert_event(6, 6, 2, "retire_uop", 30, "{}");
  store.set_meta("handcrafted", 0, 200, 5, 6);
  store.commit_transaction();

  pipetrace::LinxDbAnalysisOptions options;
  options.store_path = db;
  pipetrace::analyze_linx_store(options);

  auto trace_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store->open(db));
  const auto uop2 = trace_store->find_object(2);
  ASSERT_TRUE(uop2.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop2->attributes, "RetirePushup"), "10");

  const auto uop6 = trace_store->find_object(6);
  ASSERT_TRUE(uop6.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop6->attributes, "RetirePushup"), "10");
}

TEST(LinxDbAnalysis, RetirePushupOnGeneratedTrace) {
  const std::string pt = temp_path("linx_analysis_pushup_gen.pt");
  const std::string db = temp_path("linx_analysis_pushup_gen.db");
  cast_generated_trace(pt, db, 32);

  pipetrace::LinxDbAnalysisOptions options;
  options.store_path = db;
  const pipetrace::LinxDbAnalysisStats stats = pipetrace::analyze_linx_store(options);
  EXPECT_GT(stats.retire_pushup_updated, 0U);
  EXPECT_EQ(stats.retire_pushup_first_uop_skipped, 1U);

  auto trace_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store->open(db));
  const auto uop6 = trace_store->find_object(6);
  ASSERT_TRUE(uop6.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop6->attributes, "InstID"), "1");
  EXPECT_FALSE(pipetrace::attribute_value(uop6->attributes, "RetirePushup").empty());
}

TEST(LinxDbAnalysis, RetirePushupSkipsNonInstIdUopsInChain) {
  const std::string db = temp_path("linx_analysis_pushup_chain.db");
  std::filesystem::remove(db);

  pipetrace::SqliteStore store;
  ASSERT_TRUE(store.open(db));
  store.exec_sql("BEGIN IMMEDIATE;");
  store.insert_object_type(1, "object", "Object");
  store.insert_event_type(1, "retire_inst", 1, 0xFF888888U);
  store.insert_event_type(2, "retire_uop", 1, 0xFF666666U);
  store.insert_object(0, 1, "inst_0", 0, 10, -1, R"({"type":"Instruction"})");
  store.insert_object(1, 1, "uop_1", 0, 10, 0, R"({"type":"Uop"})");
  store.insert_object(5, 1, "inst_1", 0, 20, -1, R"({"type":"Instruction"})");
  store.insert_object(6, 1, "uop_6", 0, 20, 5, R"({"type":"Uop"})");
  store.insert_object(10, 1, "inst_2", 0, 30, -1, R"({"type":"Instruction"})");
  store.insert_object(11, 1, "uop_11", 0, 30, 10, R"({"type":"Uop"})");
  store.insert_object(15, 1, "inst_3", 0, 40, -1, R"({"type":"Instruction"})");
  store.insert_object(16, 1, "uop_16", 0, 40, 15, R"({"type":"Uop"})");
  store.insert_event(1, 0, 1, "retire_inst", 100, R"({"InstID":"0"})");
  store.insert_event(2, 1, 2, "retire_uop", 10, "{}");
  store.insert_event(3, 5, 1, "retire_inst", 200, R"({"InstID":"1"})");
  store.insert_event(4, 6, 2, "retire_uop", 50, "{}");
  store.insert_event(5, 11, 2, "retire_uop", 60, "{}");
  store.insert_event(6, 15, 1, "retire_inst", 300, R"({"InstID":"3"})");
  store.insert_event(7, 16, 2, "retire_uop", 80, "{}");
  store.set_meta("handcrafted", 0, 300, 8, 7);
  store.commit_transaction();

  pipetrace::LinxDbAnalysisOptions options;
  options.store_path = db;
  pipetrace::analyze_linx_store(options);

  auto trace_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store->open(db));

  const auto uop6 = trace_store->find_object(6);
  ASSERT_TRUE(uop6.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop6->attributes, "InstID"), "1");
  EXPECT_EQ(pipetrace::attribute_value(uop6->attributes, "RetirePushup"), "40");

  const auto uop11 = trace_store->find_object(11);
  ASSERT_TRUE(uop11.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop11->attributes, "InstID"), "");
  EXPECT_EQ(pipetrace::attribute_value(uop11->attributes, "RetirePushup"), "");

  const auto uop16 = trace_store->find_object(16);
  ASSERT_TRUE(uop16.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop16->attributes, "InstID"), "3");
  EXPECT_EQ(pipetrace::attribute_value(uop16->attributes, "RetirePushup"), "30");
}

TEST(LinxDbAnalysis, PromotesPcOntoUops) {
  const std::string db = temp_path("linx_analysis_pc_promote.db");
  std::filesystem::remove(db);

  pipetrace::SqliteStore store;
  ASSERT_TRUE(store.open(db));
  store.exec_sql("BEGIN IMMEDIATE;");
  store.insert_object_type(1, "object", "Object");
  store.insert_event_type(1, "retire_inst", 1, 0xFF888888U);
  store.insert_object(5, 1, "inst_5", 0, 10, -1, R"({"type":"Instruction","PC":"0x401000"})");
  store.insert_object(7, 1, "uop_7", 0, 10, 5, R"({"type":"Uop","disasm":"nop"})");
  store.insert_event(1, 5, 1, "retire_inst", 8, R"({"InstID":"1"})");
  store.set_meta("handcrafted", 0, 10, 2, 1);
  store.commit_transaction();

  pipetrace::LinxDbAnalysisOptions options;
  options.store_path = db;
  const pipetrace::LinxDbAnalysisStats stats = pipetrace::analyze_linx_store(options);
  EXPECT_EQ(stats.pc_promoted, 1U);

  auto trace_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store->open(db));
  const auto uop = trace_store->find_object(7);
  ASSERT_TRUE(uop.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop->attributes, "PC"), "0x401000");
}

TEST(LinxDbAnalysis, PcProfilingWritesCountTotalPctAndAverage) {
  const std::string db = temp_path("linx_analysis_pc_profiling.db");
  std::filesystem::remove(db);

  pipetrace::SqliteStore store;
  ASSERT_TRUE(store.open(db));
  store.exec_sql("BEGIN IMMEDIATE;");
  store.insert_object_type(1, "object", "Object");
  store.insert_event_type(1, "retire_inst", 1, 0xFF888888U);
  store.insert_event_type(2, "retire_uop", 1, 0xFF666666U);
  store.insert_object(0, 1, "inst_0", 0, 10, -1, R"({"type":"Instruction","PC":"0x1000"})");
  store.insert_object(1, 1, "uop_1", 0, 10, 0, R"({"type":"Uop"})");
  store.insert_object(2, 1, "uop_2", 0, 10, 0, R"({"type":"Uop"})");
  store.insert_object(5, 1, "inst_1", 0, 20, -1, R"({"type":"Instruction","PC":"0x1000"})");
  store.insert_object(6, 1, "uop_6", 0, 20, 5, R"({"type":"Uop"})");
  store.insert_object(10, 1, "inst_2", 0, 30, -1, R"({"type":"Instruction","PC":"0x2000"})");
  store.insert_object(11, 1, "uop_11", 0, 30, 10, R"({"type":"Uop"})");
  store.insert_event(1, 0, 1, "retire_inst", 100, R"({"InstID":"0"})");
  store.insert_event(2, 1, 2, "retire_uop", 10, "{}");
  store.insert_event(3, 2, 2, "retire_uop", 15, "{}");
  store.insert_event(4, 5, 1, "retire_inst", 200, R"({"InstID":"1"})");
  store.insert_event(5, 6, 2, "retire_uop", 25, "{}");
  store.insert_event(6, 10, 1, "retire_inst", 300, R"({"InstID":"2"})");
  store.insert_event(7, 11, 2, "retire_uop", 40, "{}");
  store.set_meta("handcrafted", 0, 300, 7, 7);
  store.commit_transaction();

  pipetrace::LinxDbAnalysisOptions options;
  options.store_path = db;
  const pipetrace::LinxDbAnalysisStats stats = pipetrace::analyze_linx_store(options);
  EXPECT_EQ(stats.retire_pushup_updated, 3U);
  EXPECT_EQ(stats.pc_profiling_updated, 4U);

  auto trace_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store->open(db));

  const auto uop2 = trace_store->find_object(2);
  ASSERT_TRUE(uop2.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop2->attributes, "RetirePushup"), "5");
  EXPECT_EQ(pipetrace::attribute_value(uop2->attributes, "PcCount"), "0.75");
  EXPECT_EQ(pipetrace::attribute_value(uop2->attributes, "PcRetirePushup"), "0.50");
  EXPECT_EQ(pipetrace::attribute_value(uop2->attributes, "PcRetirePushupAvg"), "5.00");

  const auto uop11 = trace_store->find_object(11);
  ASSERT_TRUE(uop11.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop11->attributes, "RetirePushup"), "15");
  EXPECT_EQ(pipetrace::attribute_value(uop11->attributes, "PcCount"), "0.25");
  EXPECT_EQ(pipetrace::attribute_value(uop11->attributes, "PcRetirePushup"), "0.50");
  EXPECT_EQ(pipetrace::attribute_value(uop11->attributes, "PcRetirePushupAvg"), "15.00");
}

void insert_dual_trace_fixture_db(const std::string& db, bool trace2_cycles) {
  pipetrace::SqliteStore store;
  if (!store.open(db)) {
    throw std::runtime_error("failed to open fixture db: " + db);
  }
  store.exec_sql("BEGIN IMMEDIATE;");
  store.insert_object_type(1, "object", "Object");
  store.insert_event_type(1, "retire_inst", 1, 0xFF888888U);
  store.insert_event_type(2, "retire_uop", 1, 0xFF666666U);
  store.insert_object(0, 1, "inst_0", 0, 10, -1, R"({"type":"Instruction","PC":"0x1000"})");
  store.insert_object(1, 1, "uop_1", 0, 10, 0, R"({"type":"Uop"})");
  store.insert_object(2, 1, "uop_2", 0, 10, 0, R"({"type":"Uop"})");
  store.insert_object(5, 1, "inst_1", 0, 20, -1, R"({"type":"Instruction","PC":"0x1000"})");
  store.insert_object(6, 1, "uop_6", 0, 20, 5, R"({"type":"Uop"})");
  store.insert_object(10, 1, "inst_2", 0, 30, -1, R"({"type":"Instruction","PC":"0x2000"})");
  store.insert_object(11, 1, "uop_11", 0, 30, 10, R"({"type":"Uop"})");
  store.insert_event(1, 0, 1, "retire_inst", 100, R"({"InstID":"0"})");
  store.insert_event(2, 1, 2, "retire_uop", 10, "{}");
  store.insert_event(3, 2, 2, "retire_uop", trace2_cycles ? 18 : 15, "{}");
  store.insert_event(4, 5, 1, "retire_inst", 200, R"({"InstID":"1"})");
  store.insert_event(5, 6, 2, "retire_uop", trace2_cycles ? 22 : 25, "{}");
  store.insert_event(6, 10, 1, "retire_inst", 300, R"({"InstID":"2"})");
  store.insert_event(7, 11, 2, "retire_uop", trace2_cycles ? 37 : 40, "{}");
  store.set_meta("handcrafted", 0, 300, 7, 7);
  store.commit_transaction();
}

TEST(LinxDbAnalysis, DualTraceWritesSeparateDualAttributes) {
  const std::string db1 = temp_path("linx_analysis_dual_trace1.db");
  const std::string db2 = temp_path("linx_analysis_dual_trace2.db");
  std::filesystem::remove(db1);
  std::filesystem::remove(db2);

  insert_dual_trace_fixture_db(db1, false);
  insert_dual_trace_fixture_db(db2, true);

  pipetrace::LinxDbAnalysisOptions single;
  single.store_path = db1;
  pipetrace::analyze_linx_store(single);
  single.store_path = db2;
  pipetrace::analyze_linx_store(single);

  pipetrace::LinxDbDualAnalysisOptions options;
  options.store_path = db1;
  options.store2_path = db2;
  const pipetrace::LinxDbDualAnalysisResult result = pipetrace::run_linx_db_dual_analysis(options);

  EXPECT_EQ(result.outcome, pipetrace::LinxDbDualAnalysisOutcome::Analyzed);
  EXPECT_EQ(result.dual.dual_matched, 3U);
  EXPECT_EQ(result.dual.dual_missing_trace1, 0U);
  EXPECT_EQ(result.dual.dual_missing_trace2, 0U);
  EXPECT_GT(result.dual.dual_pushup_updated, 0U);
  EXPECT_GT(result.dual.dual_pc_profiling_updated, 0U);

  auto trace_store1 = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store1->open(db1));
  const auto uop2_t1 = trace_store1->find_object(2);
  ASSERT_TRUE(uop2_t1.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop2_t1->attributes, "RetirePushup"), "5");
  EXPECT_EQ(pipetrace::attribute_value(uop2_t1->attributes, "DualRetirePushup"), "3");

  const auto uop6_t1 = trace_store1->find_object(6);
  ASSERT_TRUE(uop6_t1.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop6_t1->attributes, "RetirePushup"), "10");
  EXPECT_EQ(pipetrace::attribute_value(uop6_t1->attributes, "DualRetirePushup"), "-6");

  const auto uop11_t1 = trace_store1->find_object(11);
  ASSERT_TRUE(uop11_t1.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop11_t1->attributes, "RetirePushup"), "15");
  EXPECT_EQ(pipetrace::attribute_value(uop11_t1->attributes, "DualRetirePushup"), "0");

  auto trace_store2 = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store2->open(db2));
  const auto uop2_t2 = trace_store2->find_object(2);
  ASSERT_TRUE(uop2_t2.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop2_t2->attributes, "RetirePushup"), "8");
  EXPECT_EQ(pipetrace::attribute_value(uop2_t2->attributes, "DualRetirePushup"), "3");

  pipetrace::SqliteStore meta_store1;
  ASSERT_TRUE(meta_store1.open(db1));
  const std::optional<std::string> state1 = meta_store1.meta_value("analysis_state");
  ASSERT_TRUE(state1.has_value());
  EXPECT_EQ(*state1, "DualAnalyzed");
  const std::optional<std::string> partner1 = meta_store1.meta_value("dual_partner_path");
  ASSERT_TRUE(partner1.has_value());
  EXPECT_EQ(*partner1, std::filesystem::absolute(db2).string());
}

TEST(LinxDbAnalysis, PartialRetireTraceSkipsInstId) {
  const std::string pt = temp_path("linx_analysis_partial_retire.pt");
  const std::string db = temp_path("linx_analysis_partial_retire.db");

  pipetrace::LinxPtGenerateOptions gen;
  gen.output_path = pt;
  gen.object_count = 20;
  gen.events_per_object = 2;
  gen.uops_per_instruction = 4;
  gen.cycle_span = 32;
  gen.seed = 1;
  gen.partial_retire = true;
  pipetrace::generate_linx_pt_trace(gen);

  const std::string config = temp_path("linx_analysis_partial_cast_config.json");
  write_minimal_config(config);
  pipetrace::LinxPtCastOptions cast;
  cast.input_path = pt;
  cast.store_path = db;
  cast.config_path = config;
  pipetrace::cast_linx_pt_to_store(cast);

  pipetrace::LinxDbAnalysisOptions options;
  options.store_path = db;
  pipetrace::analyze_linx_store(options);

  auto trace_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store->open(db));

  const auto uop11 = trace_store->find_object(11);
  ASSERT_TRUE(uop11.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop11->attributes, "InstID"), "");

  const auto uop12 = trace_store->find_object(12);
  ASSERT_TRUE(uop12.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop12->attributes, "InstID"), "");
}

TEST(LinxDbAnalysis, ObjectAttributeStrengthColorsAllRetirePushupRows) {
  const std::string db = temp_path("linx_analysis_strength_color.db");
  std::filesystem::remove(db);

  pipetrace::SqliteStore store;
  ASSERT_TRUE(store.open(db));
  store.exec_sql("BEGIN IMMEDIATE;");
  store.insert_object_type(1, "object", "Object");
  store.insert_event_type(1, "retire_inst", 1, 0xFF888888U);
  store.insert_event_type(2, "retire_uop", 1, 0xFF666666U);
  store.insert_object(0, 1, "inst_0", 0, 10, -1, R"({"type":"Instruction"})");
  store.insert_object(1, 1, "uop_1", 0, 10, 0, R"({"type":"Uop"})");
  store.insert_object(2, 1, "uop_2", 0, 10, 0, R"({"type":"Uop"})");
  store.insert_object(3, 1, "uop_3", 0, 10, 0, R"({"type":"Uop"})");
  store.insert_object(5, 1, "inst_1", 0, 20, -1, R"({"type":"Instruction"})");
  store.insert_object(6, 1, "uop_6", 0, 20, 5, R"({"type":"Uop"})");
  store.insert_event(1, 0, 1, "retire_inst", 100, R"({"InstID":"0"})");
  store.insert_event(2, 1, 2, "retire_uop", 10, "{}");
  store.insert_event(3, 2, 2, "retire_uop", 15, "{}");
  store.insert_event(4, 3, 2, "retire_uop", 30, "{}");
  store.insert_event(5, 5, 1, "retire_inst", 200, R"({"InstID":"1"})");
  store.insert_event(6, 6, 2, "retire_uop", 40, "{}");
  store.set_meta("handcrafted", 0, 200, 5, 6);
  store.commit_transaction();

  const std::string config = temp_path("linx_analysis_strength_color_config.json");
  std::ofstream config_out(config, std::ios::trunc);
  config_out << R"({
  "object_attribute_strength": [
    { "key": "RetirePushup", "color": "#FF4400", "highlight": "max" }
  ]
})";
  config_out.close();

  pipetrace::LinxDbAnalysisOptions options;
  options.store_path = db;
  options.config_path = config;
  const pipetrace::LinxDbAnalysisStats stats = pipetrace::analyze_linx_store(options);
  EXPECT_EQ(stats.retire_pushup_updated, 3U);
  EXPECT_EQ(stats.strength_color_updated, 3U);

  auto trace_store = pipetrace::create_sqlite_store();
  ASSERT_TRUE(trace_store->open(db));

  const auto uop2 = trace_store->find_object(2);
  ASSERT_TRUE(uop2.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop2->attributes, "RetirePushup"), "5");
  EXPECT_EQ(pipetrace::attribute_value(uop2->attributes, "RetirePushup_color"), "#FF440017");

  const auto uop3 = trace_store->find_object(3);
  ASSERT_TRUE(uop3.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop3->attributes, "RetirePushup"), "15");
  EXPECT_EQ(pipetrace::attribute_value(uop3->attributes, "RetirePushup_color"), "#FF4400FF");

  const auto uop6 = trace_store->find_object(6);
  ASSERT_TRUE(uop6.has_value());
  EXPECT_EQ(pipetrace::attribute_value(uop6->attributes, "RetirePushup"), "10");
  EXPECT_EQ(pipetrace::attribute_value(uop6->attributes, "RetirePushup_color"), "#FF44008B");
}

TEST(LinxDbAnalysis, CastWritesSourceTraceMeta) {
  const std::string pt = temp_path("linx_analysis_source_meta.pt");
  const std::string db = temp_path("linx_analysis_source_meta.db");
  cast_generated_trace(pt, db, 16);

  pipetrace::SqliteStore store;
  ASSERT_TRUE(store.open(db));
  const std::optional<std::string> source_path = store.meta_value("source_trace_path");
  const std::optional<std::string> source_mtime = store.meta_value("source_trace_mtime");
  const std::optional<std::string> cast_at = store.meta_value("cast_at");
  ASSERT_TRUE(source_path.has_value());
  EXPECT_EQ(*source_path, std::filesystem::absolute(pt).string());
  ASSERT_TRUE(source_mtime.has_value());
  EXPECT_EQ(*source_mtime, std::to_string(current_file_mtime_seconds(pt)));
  ASSERT_TRUE(cast_at.has_value());
  EXPECT_FALSE(cast_at->empty());
  const std::optional<std::string> analysis_state = store.meta_value("analysis_state");
  ASSERT_TRUE(analysis_state.has_value());
  EXPECT_EQ(*analysis_state, "Raw");
}

TEST(LinxDbAnalysis, SkipsWhenAlreadyAnalyzed) {
  const std::string pt = temp_path("linx_analysis_skip.pt");
  const std::string db = temp_path("linx_analysis_skip.db");
  cast_generated_trace(pt, db, 32);

  pipetrace::LinxDbAnalysisOptions options;
  options.store_path = db;
  const pipetrace::LinxDbAnalysisRunResult first = pipetrace::run_linx_db_analysis(options);
  ASSERT_EQ(first.outcome, pipetrace::LinxDbAnalysisOutcome::Analyzed);
  EXPECT_GT(first.stats.uops_updated, 0U);

  const pipetrace::LinxDbAnalysisRunResult second = pipetrace::run_linx_db_analysis(options);
  EXPECT_EQ(second.outcome, pipetrace::LinxDbAnalysisOutcome::Skipped);
  EXPECT_EQ(second.message, "analysis skipped: already analyzed");
}

TEST(LinxDbAnalysis, ForceReAnalyzesSingleTrace) {
  const std::string pt = temp_path("linx_analysis_force.pt");
  const std::string db = temp_path("linx_analysis_force.db");
  const std::string config = temp_path("linx_analysis_force_config.json");
  write_minimal_config(config);
  cast_generated_trace(pt, db, 32);

  pipetrace::LinxDbAnalysisOptions options;
  options.store_path = db;
  options.config_path = config;
  pipetrace::run_linx_db_analysis(options);

  options.force = true;
  const pipetrace::LinxDbAnalysisRunResult forced = pipetrace::run_linx_db_analysis(options);
  EXPECT_EQ(forced.outcome, pipetrace::LinxDbAnalysisOutcome::Analyzed);
}

TEST(LinxDbAnalysis, DualAnalysisSkipsWhenPartnerAndTimestampsMatch) {
  const std::string db1 = temp_path("linx_analysis_dual_skip1.db");
  const std::string db2 = temp_path("linx_analysis_dual_skip2.db");
  std::filesystem::remove(db1);
  std::filesystem::remove(db2);

  insert_dual_trace_fixture_db(db1, false);
  insert_dual_trace_fixture_db(db2, true);

  pipetrace::LinxDbAnalysisOptions single;
  single.store_path = db1;
  pipetrace::analyze_linx_store(single);
  single.store_path = db2;
  pipetrace::analyze_linx_store(single);

  pipetrace::LinxDbDualAnalysisOptions dual;
  dual.store_path = db1;
  dual.store2_path = db2;
  const pipetrace::LinxDbDualAnalysisResult first = pipetrace::run_linx_db_dual_analysis(dual);
  ASSERT_EQ(first.outcome, pipetrace::LinxDbDualAnalysisOutcome::Analyzed);

  const pipetrace::LinxDbDualAnalysisResult second = pipetrace::run_linx_db_dual_analysis(dual);
  EXPECT_EQ(second.outcome, pipetrace::LinxDbDualAnalysisOutcome::Skipped);
  EXPECT_EQ(second.message, "dual analysis skipped: up to date");
}

TEST(LinxDbAnalysis, DualAnalysisRejectsRawStore) {
  const std::string db1 = temp_path("linx_analysis_dual_raw1.db");
  const std::string db2 = temp_path("linx_analysis_dual_raw2.db");
  std::filesystem::remove(db1);
  std::filesystem::remove(db2);

  insert_dual_trace_fixture_db(db1, false);
  insert_dual_trace_fixture_db(db2, true);

  pipetrace::LinxDbAnalysisOptions single;
  single.store_path = db2;
  pipetrace::analyze_linx_store(single);

  pipetrace::LinxDbDualAnalysisOptions dual;
  dual.store_path = db1;
  dual.store2_path = db2;
  EXPECT_THROW(pipetrace::run_linx_db_dual_analysis(dual), std::runtime_error);
}
