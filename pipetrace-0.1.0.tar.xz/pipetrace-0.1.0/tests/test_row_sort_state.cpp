#include <gtest/gtest.h>

#include "pipetrace/row_sort_state.hpp"

namespace {

pipetrace::AppConfig make_config() {
  pipetrace::AppConfig config = pipetrace::default_app_config();
  config.sort_schemes = {
      {.name = "seqnum/InstID",
       .columns = {{.key = "seqnum", .order = "asc"}, {.key = "InstID", .order = "asc"}}},
      {.name = "PC",
       .columns = {{.key = "PC", .order = "desc"}}},
  };
  return config;
}

}  // namespace

TEST(RowSortState, StartsInConfigMode) {
  const pipetrace::AppConfig config = make_config();
  pipetrace::RowSortState state;
  EXPECT_FALSE(state.user_mode());
  EXPECT_EQ(state.config_scheme_index(), 0U);
  ASSERT_NE(state.active_sort_scheme(config), nullptr);
  EXPECT_EQ(state.active_sort_scheme(config)->name, "seqnum/InstID");
  EXPECT_EQ(state.display_label(config), "seqnum/InstID");
}

TEST(RowSortState, HeaderDoubleClickEntersUserMode) {
  const pipetrace::AppConfig config = make_config();
  pipetrace::RowSortState state;
  state.apply_header_double_click("PC");
  EXPECT_TRUE(state.user_mode());
  EXPECT_EQ(state.user_column_key(), "PC");
  EXPECT_TRUE(state.user_ascending());
  ASSERT_NE(state.active_sort_scheme(config), nullptr);
  ASSERT_EQ(state.active_sort_scheme(config)->columns.size(), 1U);
  EXPECT_EQ(state.active_sort_scheme(config)->columns[0].key, "PC");
  EXPECT_EQ(state.active_sort_scheme(config)->columns[0].order, "asc");
  EXPECT_NE(state.display_label(config).find("User (PC"), std::string::npos);
}

TEST(RowSortState, HeaderDoubleClickSameColumnTogglesDirection) {
  const pipetrace::AppConfig config = make_config();
  pipetrace::RowSortState state;
  state.apply_header_double_click("PC");
  state.apply_header_double_click("PC");
  EXPECT_TRUE(state.user_mode());
  EXPECT_FALSE(state.user_ascending());
  EXPECT_EQ(state.active_sort_scheme(config)->columns[0].order, "desc");
}

TEST(RowSortState, HeaderDoubleClickDifferentColumnResetsAscending) {
  const pipetrace::AppConfig config = make_config();
  pipetrace::RowSortState state;
  state.apply_header_double_click("PC");
  state.apply_header_double_click("PC");
  state.apply_header_double_click("seqnum");
  EXPECT_TRUE(state.user_mode());
  EXPECT_EQ(state.user_column_key(), "seqnum");
  EXPECT_TRUE(state.user_ascending());
  EXPECT_EQ(state.active_sort_scheme(config)->columns[0].key, "seqnum");
}

TEST(RowSortState, ConfigSchemeLeavesUserMode) {
  const pipetrace::AppConfig config = make_config();
  pipetrace::RowSortState state;
  state.apply_header_double_click("PC");
  ASSERT_TRUE(state.set_config_scheme_index(1, config));
  EXPECT_FALSE(state.user_mode());
  EXPECT_EQ(state.config_scheme_index(), 1U);
  ASSERT_NE(state.active_sort_scheme(config), nullptr);
  EXPECT_EQ(state.active_sort_scheme(config)->name, "PC");
}

TEST(RowSortState, ActiveSortDirectionForColumn) {
  const pipetrace::AppConfig config = make_config();
  pipetrace::RowSortState state;

  ASSERT_TRUE(state.active_sort_direction_for_column("seqnum", config).has_value());
  EXPECT_TRUE(*state.active_sort_direction_for_column("seqnum", config));
  EXPECT_FALSE(state.active_sort_direction_for_column("InstID", config).has_value());

  ASSERT_TRUE(state.set_config_scheme_index(1, config));
  ASSERT_TRUE(state.active_sort_direction_for_column("PC", config).has_value());
  EXPECT_FALSE(*state.active_sort_direction_for_column("PC", config));
  EXPECT_FALSE(state.active_sort_direction_for_column("seqnum", config).has_value());

  state.apply_header_double_click("seqnum");
  ASSERT_TRUE(state.active_sort_direction_for_column("seqnum", config).has_value());
  EXPECT_TRUE(*state.active_sort_direction_for_column("seqnum", config));
  EXPECT_FALSE(state.active_sort_direction_for_column("PC", config).has_value());
  state.apply_header_double_click("seqnum");
  ASSERT_TRUE(state.active_sort_direction_for_column("seqnum", config).has_value());
  EXPECT_FALSE(*state.active_sort_direction_for_column("seqnum", config));
}
