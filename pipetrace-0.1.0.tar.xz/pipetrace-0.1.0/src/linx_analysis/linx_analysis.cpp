#include "pipetrace/linx_analysis.hpp"

#include "pipetrace/app_config.hpp"
#include "pipetrace/attributes.hpp"
#include "storage/sqlite_store.hpp"

#include <cmath>
#include <cstdlib>
#include <ctime>
#include <filesystem>
#include <iostream>
#include <optional>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace pipetrace {
namespace {

constexpr const char* kInstIdKey = "InstID";
constexpr const char* kPcKey = "PC";
constexpr const char* kRetirePushupKey = "RetirePushup";
constexpr const char* kObjectIdKey = "id";
constexpr const char* kParentIdKey = "parent_id";
constexpr const char* kPcCountKey = "PcCount";
constexpr const char* kPcRetirePushupKey = "PcRetirePushup";
constexpr const char* kPcRetirePushupAvgKey = "PcRetirePushupAvg";
constexpr const char* kDualRetirePushupKey = "DualRetirePushup";
constexpr const char* kDualPcRetirePushupKey = "DualPcRetirePushup";
constexpr const char* kDualPcRetirePushupAvgKey = "DualPcRetirePushupAvg";
constexpr const char* kAnalysisStateKey = "analysis_state";
constexpr const char* kAnalysisAtKey = "analysis_at";
constexpr const char* kDualAnalysisAtKey = "dual_analyzed_at";
constexpr const char* kDualPartnerPathKey = "dual_partner_path";
constexpr const char* kAnalysisStateRaw = "Raw";
constexpr const char* kAnalysisStateAnalyzed = "Analyzed";
constexpr const char* kAnalysisStateDualAnalyzed = "DualAnalyzed";
constexpr std::size_t kUpdateBatchSize = 4096;

struct PcBucketStats {
  std::size_t count{0};
  Timestamp pushup_sum{0};
};

struct PendingUpdate {
  ObjectId object_id{};
  std::string attributes_json;
};

std::string inst_id_from_event_json(const char* attributes_json) {
  const std::string json = attributes_json ? attributes_json : "{}";
  std::string value = attribute_value(parse_object_attributes(json), kInstIdKey);
  if (value.empty()) {
    value = attribute_value(parse_object_attributes(json), "inst_id");
  }
  return value;
}

bool merge_inst_id(std::vector<std::pair<std::string, std::string>>& attributes,
                   const std::string& inst_id, bool& overwritten) {
  overwritten = false;
  for (auto& [key, value] : attributes) {
    if (key == kInstIdKey) {
      if (value == inst_id) {
        return false;
      }
      overwritten = true;
      value = inst_id;
      return true;
    }
  }
  attributes.emplace_back(kInstIdKey, inst_id);
  return true;
}

bool merge_string_attribute(std::vector<std::pair<std::string, std::string>>& attributes,
                            const std::string& key, const std::string& value, bool& overwritten) {
  overwritten = false;
  for (auto& [attr_key, attr_value] : attributes) {
    if (attr_key == key) {
      if (attr_value == value) {
        return false;
      }
      overwritten = true;
      attr_value = value;
      return true;
    }
  }
  attributes.emplace_back(key, value);
  return true;
}

class TransactionGuard {
 public:
  explicit TransactionGuard(SqliteStore& store) : store_(store) {
    store_.exec_sql("PRAGMA synchronous=OFF;");
    store_.begin_immediate_transaction();
  }

  ~TransactionGuard() {
    if (active_) {
      try {
        store_.rollback_transaction();
      } catch (...) {
      }
    }
  }

  void commit() {
    store_.commit_transaction();
    active_ = false;
  }

 private:
  SqliteStore& store_;
  bool active_{true};
};

void flush_updates(SqliteStore& store, std::vector<PendingUpdate>& batch, std::size_t& updated_count,
                   bool dry_run) {
  if (batch.empty()) {
    return;
  }
  if (!dry_run) {
    for (const PendingUpdate& update : batch) {
      store.update_object_attributes(update.object_id, update.attributes_json);
    }
  }
  updated_count += batch.size();
  batch.clear();
}

std::optional<double> numeric_attribute_value(const char* attributes_json, const std::string& key) {
  const std::string value_text =
      attribute_value(parse_object_attributes(attributes_json ? attributes_json : "{}"), key);
  if (value_text.empty()) {
    return std::nullopt;
  }
  char* end = nullptr;
  const double value = std::strtod(value_text.c_str(), &end);
  if (end == value_text.c_str() || (end != nullptr && *end != '\0')) {
    return std::nullopt;
  }
  return value;
}

void queue_string_attribute_update(ObjectId id, const char* attributes_json, const std::string& key,
                                   const std::string& value,
                                   std::vector<PendingUpdate>& update_batch,
                                   std::size_t& updated_count, std::size_t& skipped_count,
                                   std::size_t& overwritten_count, std::size_t& warnings,
                                   SqliteStore& store, bool dry_run) {
  std::vector<std::pair<std::string, std::string>> attributes =
      parse_object_attributes(attributes_json);
  bool overwritten = false;
  if (!merge_string_attribute(attributes, key, value, overwritten)) {
    ++skipped_count;
    return;
  }
  if (overwritten) {
    ++overwritten_count;
    ++warnings;
  }
  update_batch.push_back(PendingUpdate{id, format_object_attributes_json(attributes)});
  if (update_batch.size() >= kUpdateBatchSize) {
    flush_updates(store, update_batch, updated_count, dry_run);
  }
}

void promote_object_attribute_strength_colors(SqliteStore& store, const AppConfig& config,
                                              LinxDbAnalysisStats& stats, bool dry_run) {
  for (const ObjectAttributeStrengthRule& rule : config.object_attribute_strength) {
    std::optional<double> min_value;
    std::optional<double> max_value;

    store.for_each_object([&](ObjectId id, ObjectId parent_id, const char* attributes_json) {
      (void)id;
      (void)parent_id;
      const std::optional<double> value = numeric_attribute_value(attributes_json, rule.key);
      if (!value.has_value()) {
        return;
      }
      if (!min_value.has_value() || *value < *min_value) {
        min_value = *value;
      }
      if (!max_value.has_value() || *value > *max_value) {
        max_value = *value;
      }
    });

    if (!min_value.has_value() || !max_value.has_value()) {
      continue;
    }

    const std::string color_key = rule.key + "_color";
    const double range = *max_value - *min_value + 1.0;
    std::vector<PendingUpdate> update_batch;
    update_batch.reserve(kUpdateBatchSize);

    store.for_each_object([&](ObjectId id, ObjectId parent_id, const char* attributes_json) {
      (void)parent_id;
      const std::optional<double> value = numeric_attribute_value(attributes_json, rule.key);
      if (!value.has_value()) {
        return;
      }

      double strength = (*value - *min_value + 1.0) / range;
      if (rule.highlight == "min") {
        strength = 1.0 - strength;
      }
      const std::string color_value = strength_color_from_base(rule.color, strength);
      std::size_t overwritten = 0;
      std::size_t warnings = 0;
      queue_string_attribute_update(id, attributes_json, color_key, color_value, update_batch,
                                    stats.strength_color_updated, stats.strength_color_skipped,
                                    overwritten, warnings, store, dry_run);
    });

    flush_updates(store, update_batch, stats.strength_color_updated, dry_run);
  }
}

void queue_retire_pushup_update(ObjectId id, const char* attributes_json,
                                const std::string& retire_pushup,
                                std::vector<PendingUpdate>& update_batch, std::size_t& updated_count,
                                std::size_t& skipped_count, std::size_t& overwritten_count,
                                std::size_t& warnings, SqliteStore& store, bool dry_run) {
  queue_string_attribute_update(id, attributes_json, kRetirePushupKey, retire_pushup, update_batch,
                                updated_count, skipped_count, overwritten_count, warnings, store,
                                dry_run);
}

void promote_retire_pushup(SqliteStore& store, LinxDbAnalysisStats& stats, bool dry_run) {
  std::vector<PendingUpdate> update_batch;
  update_batch.reserve(kUpdateBatchSize);
  std::optional<Timestamp> last_retired_instid_uop_cycle;

  store.for_each_uop_with_retire_uop([&](const SqliteStore::UopRetireUopRow& row) {
    const std::string inst_id = row.inst_id ? row.inst_id : "";
    const bool has_inst_id = !inst_id.empty();

    if (!has_inst_id) {
      ++stats.retire_pushup_no_inst_id;
      ++stats.retire_pushup_skipped;
      return;
    }

    if (!last_retired_instid_uop_cycle.has_value()) {
      ++stats.retire_pushup_first_uop_skipped;
      ++stats.retire_pushup_skipped;
    } else {
      const Timestamp pushup = row.retire_uop_cycle - *last_retired_instid_uop_cycle;
      queue_retire_pushup_update(row.object_id, row.object_attributes_json, std::to_string(pushup),
                                 update_batch, stats.retire_pushup_updated,
                                 stats.retire_pushup_skipped, stats.retire_pushup_overwritten,
                                 stats.warnings, store, dry_run);
    }
    last_retired_instid_uop_cycle = row.retire_uop_cycle;
  });

  flush_updates(store, update_batch, stats.retire_pushup_updated, dry_run);
}

void promote_pc_to_uops(SqliteStore& store, LinxDbAnalysisStats& stats, bool dry_run) {
  std::vector<PendingUpdate> update_batch;
  update_batch.reserve(kUpdateBatchSize);

  store.for_each_uop_pc_promotion([&](const SqliteStore::UopPcPromotionRow& row) {
    if (row.parent_id < 0) {
      ++stats.pc_no_parent;
      ++stats.pc_skipped;
      ++stats.warnings;
      return;
    }

    const std::string pc = row.parent_pc ? row.parent_pc : "";
    if (pc.empty()) {
      ++stats.pc_parent_missing;
      ++stats.pc_skipped;
      return;
    }

    queue_string_attribute_update(row.object_id, row.object_attributes_json, kPcKey, pc,
                                  update_batch, stats.pc_promoted, stats.pc_skipped,
                                  stats.pc_overwritten, stats.warnings, store, dry_run);
  });

  flush_updates(store, update_batch, stats.pc_promoted, dry_run);
}

std::optional<Timestamp> parse_retire_pushup_value(const char* retire_pushup) {
  if (retire_pushup == nullptr || retire_pushup[0] == '\0') {
    return std::nullopt;
  }
  try {
    std::size_t consumed = 0;
    const Timestamp value = static_cast<Timestamp>(std::stoll(retire_pushup, &consumed));
    if (consumed == 0) {
      return std::nullopt;
    }
    return value;
  } catch (...) {
    return std::nullopt;
  }
}

std::string format_ratio(Timestamp part, Timestamp whole) {
  if (whole == 0) {
    return "0";
  }
  const double ratio = static_cast<double>(part) / static_cast<double>(whole);
  char buffer[32];
  std::snprintf(buffer, sizeof(buffer), "%.2f", ratio);
  return buffer;
}

std::string format_ratio(std::size_t part, std::size_t whole) {
  return format_ratio(static_cast<Timestamp>(part), static_cast<Timestamp>(whole));
}

std::string format_average(Timestamp sum, std::size_t count) {
  if (count == 0) {
    return "0";
  }
  const double avg = static_cast<double>(sum) / static_cast<double>(count);
  char buffer[32];
  std::snprintf(buffer, sizeof(buffer), "%.2f", avg);
  return buffer;
}

void apply_pc_profiling(SqliteStore& store, LinxDbAnalysisStats& stats, bool dry_run,
                        const std::string& pushup_read_key, const std::string& pc_count_key,
                        const std::string& pc_retire_pushup_key,
                        const std::string& pc_retire_pushup_avg_key,
                        std::size_t* profiling_updated_out = nullptr) {
  std::unordered_map<std::string, PcBucketStats> pc_buckets;
  std::size_t retired_uop_total = 0;
  Timestamp global_pushup_sum = 0;

  store.for_each_uop_with_instid_and_pc([&](const SqliteStore::UopInstIdPcRow& row) {
    const std::string pc = row.pc ? row.pc : "";
    if (pc.empty()) {
      return;
    }

    PcBucketStats& bucket = pc_buckets[pc];
    ++bucket.count;
    ++retired_uop_total;

    if (const std::optional<double> pushup =
            numeric_attribute_value(row.object_attributes_json, pushup_read_key)) {
      const Timestamp pushup_value = static_cast<Timestamp>(*pushup);
      bucket.pushup_sum += pushup_value;
      global_pushup_sum += pushup_value;
    }
  });

  std::vector<PendingUpdate> update_batch;
  update_batch.reserve(kUpdateBatchSize);
  std::size_t profiling_updated = 0;
  std::size_t profiling_skipped = 0;
  std::size_t profiling_overwritten = 0;

  store.for_each_uop_with_instid_and_pc([&](const SqliteStore::UopInstIdPcRow& row) {
    const std::string pc = row.pc ? row.pc : "";
    if (pc.empty()) {
      return;
    }

    const auto bucket_it = pc_buckets.find(pc);
    if (bucket_it == pc_buckets.end() || bucket_it->second.count == 0) {
      ++profiling_skipped;
      return;
    }

    std::vector<std::pair<std::string, std::string>> attributes =
        parse_object_attributes(row.object_attributes_json);
    bool changed = false;
    bool overwritten = false;

    const auto merge = [&](const std::string& key, const std::string& value) {
      if (key.empty()) {
        return;
      }
      if (merge_string_attribute(attributes, key, value, overwritten)) {
        changed = true;
      }
      if (overwritten) {
        ++profiling_overwritten;
        ++stats.warnings;
        overwritten = false;
      }
    };

    merge(pc_count_key, format_ratio(bucket_it->second.count, retired_uop_total));
    merge(pc_retire_pushup_key, format_ratio(bucket_it->second.pushup_sum, global_pushup_sum));
    merge(pc_retire_pushup_avg_key, format_average(bucket_it->second.pushup_sum, bucket_it->second.count));

    if (!changed) {
      ++profiling_skipped;
      return;
    }

    update_batch.push_back(
        PendingUpdate{row.object_id, format_object_attributes_json(attributes)});
    if (update_batch.size() >= kUpdateBatchSize) {
      flush_updates(store, update_batch, profiling_updated, dry_run);
    }
  });

  flush_updates(store, update_batch, profiling_updated, dry_run);

  if (pushup_read_key == kRetirePushupKey) {
    stats.pc_profiling_updated += profiling_updated;
    stats.pc_profiling_skipped += profiling_skipped;
    stats.pc_profiling_overwritten += profiling_overwritten;
  } else if (profiling_updated_out != nullptr) {
    *profiling_updated_out += profiling_updated;
  }
}

void note_multiple_retire_inst(std::int64_t retire_event_count, std::size_t& multiple_retire_inst,
                               std::size_t& warnings) {
  if (retire_event_count > 1) {
    ++multiple_retire_inst;
    ++warnings;
  }
}

void queue_identity_update(ObjectId id, ObjectId parent_id, const char* attributes_json,
                           std::vector<PendingUpdate>& update_batch, std::size_t& updated_count,
                           std::size_t& skipped_count, SqliteStore& store, bool dry_run) {
  std::vector<std::pair<std::string, std::string>> attributes =
      parse_object_attributes(attributes_json);
  bool changed = false;
  bool overwritten = false;
  if (merge_string_attribute(attributes, kObjectIdKey, std::to_string(id), overwritten)) {
    changed = true;
  }
  if (parent_id >= 0) {
    if (merge_string_attribute(attributes, kParentIdKey, std::to_string(parent_id), overwritten)) {
      changed = true;
    }
  }
  if (!changed) {
    ++skipped_count;
    return;
  }
  update_batch.push_back(PendingUpdate{id, format_object_attributes_json(attributes)});
  if (update_batch.size() >= kUpdateBatchSize) {
    flush_updates(store, update_batch, updated_count, dry_run);
  }
}

void promote_object_identity(SqliteStore& store, bool dry_run) {
  std::vector<PendingUpdate> update_batch;
  update_batch.reserve(kUpdateBatchSize);
  std::size_t updated_count = 0;
  std::size_t skipped_count = 0;
  store.for_each_object([&](ObjectId id, ObjectId parent_id, const char* attributes_json) {
    queue_identity_update(id, parent_id, attributes_json, update_batch, updated_count, skipped_count,
                          store, dry_run);
  });
  flush_updates(store, update_batch, updated_count, dry_run);
}

void queue_inst_id_update(ObjectId id, const char* attributes_json, const std::string& inst_id,
                          std::vector<PendingUpdate>& update_batch, std::size_t& updated_count,
                          std::size_t& skipped_count, std::size_t& overwritten_count,
                          std::size_t& warnings, SqliteStore& store, bool dry_run) {
  std::vector<std::pair<std::string, std::string>> attributes =
      parse_object_attributes(attributes_json);
  bool overwritten = false;
  if (!merge_inst_id(attributes, inst_id, overwritten)) {
    ++skipped_count;
    return;
  }
  if (overwritten) {
    ++overwritten_count;
    ++warnings;
  }
  update_batch.push_back(PendingUpdate{id, format_object_attributes_json(attributes)});
  if (update_batch.size() >= kUpdateBatchSize) {
    flush_updates(store, update_batch, updated_count, dry_run);
  }
}

void process_promotion_row(const SqliteStore::InstIdPromotionRow& row, LinxDbAnalysisStats& stats,
                           std::vector<PendingUpdate>& update_batch, std::size_t& updated_count,
                           std::size_t& skipped_count, std::size_t& overwritten_count,
                           SqliteStore& store, bool dry_run, bool is_uop) {
  if (is_uop && row.parent_id < 0) {
    ++stats.uop_no_parent;
    ++stats.uops_skipped;
    ++stats.warnings;
    return;
  }

  if (row.retire_event_attributes_json == nullptr) {
    if (is_uop) {
      ++stats.uop_no_retire_inst;
      ++stats.uops_skipped;
    } else {
      ++stats.instruction_no_retire_inst;
      ++stats.instructions_skipped;
    }
    ++stats.warnings;
    return;
  }

  note_multiple_retire_inst(row.retire_event_count, stats.multiple_retire_inst, stats.warnings);

  const std::string inst_id = inst_id_from_event_json(row.retire_event_attributes_json);
  if (inst_id.empty()) {
    ++stats.retire_inst_missing_inst_id;
    if (is_uop) {
      ++stats.uops_skipped;
    } else {
      ++stats.instructions_skipped;
    }
    ++stats.warnings;
    return;
  }

  queue_inst_id_update(row.object_id, row.object_attributes_json, inst_id, update_batch,
                       updated_count, skipped_count, overwritten_count, stats.warnings, store,
                       dry_run);
}

std::unordered_map<std::string, Timestamp> build_instid_pushup_map(SqliteStore& store) {
  std::unordered_map<std::string, Timestamp> pushups_by_inst_id;
  store.for_each_uop_with_instid([&](const SqliteStore::UopInstIdPushupRow& row) {
    const std::string inst_id = row.inst_id ? row.inst_id : "";
    if (inst_id.empty()) {
      return;
    }
    const std::optional<Timestamp> pushup = parse_retire_pushup_value(row.retire_pushup);
    if (!pushup.has_value()) {
      return;
    }
    pushups_by_inst_id[inst_id] = *pushup;
  });
  return pushups_by_inst_id;
}

void apply_dual_retire_pushups(
    SqliteStore& store, const std::unordered_map<std::string, Timestamp>& adjusted_by_inst_id,
    LinxDualTraceAnalysisStats& dual_stats, bool dry_run) {
  std::vector<PendingUpdate> update_batch;
  update_batch.reserve(kUpdateBatchSize);
  std::size_t overwritten_count = 0;

  store.for_each_uop_with_instid([&](const SqliteStore::UopInstIdPushupRow& row) {
    const std::string inst_id = row.inst_id ? row.inst_id : "";
    if (inst_id.empty()) {
      return;
    }
    const auto adjusted_it = adjusted_by_inst_id.find(inst_id);
    if (adjusted_it == adjusted_by_inst_id.end()) {
      ++dual_stats.dual_pushup_skipped;
      return;
    }
    queue_string_attribute_update(row.object_id, row.object_attributes_json, kDualRetirePushupKey,
                                std::to_string(adjusted_it->second), update_batch,
                                dual_stats.dual_pushup_updated, dual_stats.dual_pushup_skipped,
                                overwritten_count, dual_stats.warnings, store, dry_run);
  });

  flush_updates(store, update_batch, dual_stats.dual_pushup_updated, dry_run);
}

LinxDualTraceAnalysisStats dual_trace_analyze_open_stores(SqliteStore& store1, SqliteStore& store2,
                                                          bool dry_run, bool verbose) {
  const std::unordered_map<std::string, Timestamp> pushups1 = build_instid_pushup_map(store1);
  const std::unordered_map<std::string, Timestamp> pushups2 = build_instid_pushup_map(store2);

  std::unordered_map<std::string, Timestamp> adjusted_by_inst_id;
  LinxDualTraceAnalysisStats dual_stats;

  for (const auto& [inst_id, pushup2] : pushups2) {
    const auto pushup1_it = pushups1.find(inst_id);
    if (pushup1_it == pushups1.end()) {
      ++dual_stats.dual_missing_trace1;
      ++dual_stats.warnings;
      continue;
    }
    adjusted_by_inst_id.emplace(inst_id, pushup2 - pushup1_it->second);
    ++dual_stats.dual_matched;
  }

  for (const auto& [inst_id, pushup1] : pushups1) {
    if (!pushups2.contains(inst_id)) {
      ++dual_stats.dual_missing_trace2;
      ++dual_stats.warnings;
      (void)pushup1;
    }
  }

  TransactionGuard transaction1(store1);
  TransactionGuard transaction2(store2);

  apply_dual_retire_pushups(store1, adjusted_by_inst_id, dual_stats, dry_run);
  apply_dual_retire_pushups(store2, adjusted_by_inst_id, dual_stats, dry_run);

  LinxDbAnalysisStats profiling_stats1;
  LinxDbAnalysisStats profiling_stats2;
  apply_pc_profiling(store1, profiling_stats1, dry_run, kDualRetirePushupKey, "",
                     kDualPcRetirePushupKey, kDualPcRetirePushupAvgKey,
                     &dual_stats.dual_pc_profiling_updated);
  apply_pc_profiling(store2, profiling_stats2, dry_run, kDualRetirePushupKey, "",
                     kDualPcRetirePushupKey, kDualPcRetirePushupAvgKey,
                     &dual_stats.dual_pc_profiling_updated);

  if (!dry_run) {
    store1.refresh_object_attribute_keys();
    store2.refresh_object_attribute_keys();
    transaction1.commit();
    transaction2.commit();
  }

  if (verbose) {
    std::cerr << "dual analysis: matched=" << dual_stats.dual_matched
              << " missing_trace1=" << dual_stats.dual_missing_trace1
              << " missing_trace2=" << dual_stats.dual_missing_trace2
              << " dual_pushup_updated=" << dual_stats.dual_pushup_updated
              << " dual_pushup_skipped=" << dual_stats.dual_pushup_skipped
              << " dual_pc_profiling_updated=" << dual_stats.dual_pc_profiling_updated
              << " warnings=" << dual_stats.warnings << '\n';
  }

  return dual_stats;
}

std::optional<std::int64_t> parse_meta_i64(const std::optional<std::string>& text) {
  if (!text.has_value() || text->empty()) {
    return std::nullopt;
  }
  try {
    return std::stoll(*text);
  } catch (...) {
    return std::nullopt;
  }
}

struct DbAnalysisMeta {
  std::string analysis_state;
  std::optional<std::int64_t> analyzed_at;
  std::optional<std::int64_t> dual_analyzed_at;
  std::string dual_partner_path;
};

std::string canonical_store_path(const std::string& path) {
  return std::filesystem::absolute(std::filesystem::path(path)).string();
}

DbAnalysisMeta read_db_analysis_meta(SqliteStore& store) {
  DbAnalysisMeta meta;
  if (const std::optional<std::string> state = store.meta_value(kAnalysisStateKey)) {
    meta.analysis_state = *state;
  }
  meta.analyzed_at = parse_meta_i64(store.meta_value(kAnalysisAtKey));
  meta.dual_analyzed_at = parse_meta_i64(store.meta_value(kDualAnalysisAtKey));
  if (const std::optional<std::string> partner = store.meta_value(kDualPartnerPathKey)) {
    meta.dual_partner_path = *partner;
  }

  if (meta.analysis_state.empty()) {
    meta.analysis_state =
        meta.analyzed_at.has_value() ? kAnalysisStateAnalyzed : kAnalysisStateRaw;
  }
  return meta;
}

bool is_analyzed_or_dual(const std::string& state) {
  return state == kAnalysisStateAnalyzed || state == kAnalysisStateDualAnalyzed;
}

void write_single_analysis_meta(SqliteStore& store) {
  store.set_meta_value(kAnalysisStateKey, kAnalysisStateAnalyzed);
  store.set_meta_value(kAnalysisAtKey,
                       std::to_string(static_cast<std::int64_t>(std::time(nullptr))));
}

void write_dual_analysis_meta(SqliteStore& store, const std::string& partner_path) {
  store.set_meta_value(kAnalysisStateKey, kAnalysisStateDualAnalyzed);
  store.set_meta_value(kDualAnalysisAtKey,
                       std::to_string(static_cast<std::int64_t>(std::time(nullptr))));
  store.set_meta_value(kDualPartnerPathKey, partner_path);
}

bool dual_analysis_up_to_date(const DbAnalysisMeta& meta, const std::string& expected_partner) {
  if (meta.analysis_state != kAnalysisStateDualAnalyzed) {
    return false;
  }
  if (!meta.dual_analyzed_at.has_value() || !meta.analyzed_at.has_value()) {
    return false;
  }
  if (*meta.dual_analyzed_at < *meta.analyzed_at) {
    return false;
  }
  if (meta.dual_partner_path.empty()) {
    return false;
  }
  return meta.dual_partner_path == expected_partner;
}

}  // namespace

LinxDbAnalysisStats analyze_linx_store(const LinxDbAnalysisOptions& options) {
  if (options.store_path.empty()) {
    throw std::runtime_error("store path is required");
  }
  if (!std::filesystem::exists(options.store_path)) {
    throw std::runtime_error("store not found: " + options.store_path);
  }

  const std::string work_path =
      options.output_path.empty() ? options.store_path : options.output_path;

  if (!options.output_path.empty() && !options.dry_run) {
    if (options.output_path == options.store_path) {
      throw std::runtime_error("--output must differ from --store");
    }
    SqliteStore copier;
    if (!copier.open(options.store_path)) {
      throw std::runtime_error("failed to open store for copy: " + options.store_path);
    }
    copier.copy_database_file(options.output_path);
    copier.close();
  }

  SqliteStore store;
  if (!store.open(work_path)) {
    throw std::runtime_error("failed to open store: " + work_path);
  }

  LinxDbAnalysisStats stats;
  store.ensure_analysis_indexes();
  TransactionGuard transaction(store);

  std::vector<PendingUpdate> update_batch;
  update_batch.reserve(kUpdateBatchSize);

  auto progress_phase = [&](const char* phase, std::uint64_t done = 0, std::uint64_t total = 0) {
    if (options.progress == nullptr) {
      return;
    }
    options.progress->set_phase(phase);
    options.progress->set_counts(done, total, phase);
  };

  progress_phase("instid_instructions");
  store.for_each_instruction_instid_promotion([&](const SqliteStore::InstIdPromotionRow& row) {
    process_promotion_row(row, stats, update_batch, stats.instructions_updated,
                          stats.instructions_skipped, stats.instruction_inst_id_overwritten, store,
                          options.dry_run, false);
    if (options.progress != nullptr) {
      options.progress->set_counts(stats.instructions_updated + stats.instructions_skipped, 0,
                                   "instructions");
    }
  });
  flush_updates(store, update_batch, stats.instructions_updated, options.dry_run);

  progress_phase("instid_uops");
  store.for_each_uop_instid_promotion([&](const SqliteStore::InstIdPromotionRow& row) {
    process_promotion_row(row, stats, update_batch, stats.uops_updated, stats.uops_skipped,
                          stats.uop_inst_id_overwritten, store, options.dry_run, true);
    if (options.progress != nullptr) {
      options.progress->set_counts(stats.uops_updated + stats.uops_skipped, 0, "uops");
    }
  });
  flush_updates(store, update_batch, stats.uops_updated, options.dry_run);

  progress_phase("pc_promote");
  promote_pc_to_uops(store, stats, options.dry_run);

  progress_phase("retire_pushup");
  promote_retire_pushup(store, stats, options.dry_run);

  progress_phase("pc_profiling");
  apply_pc_profiling(store, stats, options.dry_run, kRetirePushupKey, kPcCountKey,
                     kPcRetirePushupKey, kPcRetirePushupAvgKey);

  progress_phase("strength_color");
  const AppConfig app_config = load_app_config(options.config_path);
  promote_object_attribute_strength_colors(store, app_config, stats, options.dry_run);

  progress_phase("identity");
  promote_object_identity(store, options.dry_run);

  if (!options.dry_run) {
    store.refresh_object_attribute_keys();
    write_single_analysis_meta(store);
    transaction.commit();
  }

  if (options.progress != nullptr) {
    options.progress->log(
        "analysis instructions_updated=" + std::to_string(stats.instructions_updated) +
        " uops_updated=" + std::to_string(stats.uops_updated) +
        " retire_pushup_updated=" + std::to_string(stats.retire_pushup_updated) +
        " pc_profiling_updated=" + std::to_string(stats.pc_profiling_updated) +
        " warnings=" + std::to_string(stats.warnings));
    options.progress->set_counts(1, 1, "done");
    options.progress->finish("ok");
  } else if (options.verbose) {
    std::cerr << "analysis: instructions_updated=" << stats.instructions_updated
              << " uops_updated=" << stats.uops_updated
              << " pc_promoted=" << stats.pc_promoted
              << " retire_pushup_updated=" << stats.retire_pushup_updated
              << " pc_profiling_updated=" << stats.pc_profiling_updated
              << " strength_color_updated=" << stats.strength_color_updated
              << " instructions_skipped=" << stats.instructions_skipped
              << " uops_skipped=" << stats.uops_skipped << " warnings=" << stats.warnings << '\n';
  }

  return stats;
}

LinxDbAnalysisRunResult run_linx_db_analysis(const LinxDbAnalysisOptions& options) {
  if (options.store_path.empty()) {
    throw std::runtime_error("store path is required");
  }
  if (!std::filesystem::exists(options.store_path)) {
    throw std::runtime_error("store not found: " + options.store_path);
  }

  LinxDbAnalysisRunResult result;

  SqliteStore meta_store;
  if (!meta_store.open(options.store_path)) {
    throw std::runtime_error("failed to open store: " + options.store_path);
  }
  const DbAnalysisMeta meta = read_db_analysis_meta(meta_store);
  meta_store.close();

  if (!options.force && meta.analysis_state != kAnalysisStateRaw) {
    result.outcome = LinxDbAnalysisOutcome::Skipped;
    result.message = "analysis skipped: already analyzed";
    if (options.progress != nullptr) {
      options.progress->set_phase("analyze");
      options.progress->finish("skipped", "already_analyzed");
    }
    return result;
  }

  result.stats = analyze_linx_store(options);
  result.outcome = LinxDbAnalysisOutcome::Analyzed;
  return result;
}

LinxDbDualAnalysisResult run_linx_db_dual_analysis(const LinxDbDualAnalysisOptions& options) {
  if (options.store_path.empty()) {
    throw std::runtime_error("--store is required");
  }
  if (options.store2_path.empty()) {
    throw std::runtime_error("--store2 is required for dual trace analysis");
  }
  if (!std::filesystem::exists(options.store_path)) {
    throw std::runtime_error("store not found: " + options.store_path);
  }
  if (!std::filesystem::exists(options.store2_path)) {
    throw std::runtime_error("store2 not found: " + options.store2_path);
  }

  LinxDbDualAnalysisResult result;
  const std::string partner1 = canonical_store_path(options.store2_path);
  const std::string partner2 = canonical_store_path(options.store_path);

  SqliteStore meta_store1;
  if (!meta_store1.open(options.store_path)) {
    throw std::runtime_error("failed to open store: " + options.store_path);
  }
  const DbAnalysisMeta meta1 = read_db_analysis_meta(meta_store1);
  meta_store1.close();

  SqliteStore meta_store2;
  if (!meta_store2.open(options.store2_path)) {
    throw std::runtime_error("failed to open store2: " + options.store2_path);
  }
  const DbAnalysisMeta meta2 = read_db_analysis_meta(meta_store2);
  meta_store2.close();

  if (!is_analyzed_or_dual(meta1.analysis_state)) {
    throw std::runtime_error("store is not analyzed: " + options.store_path +
                             " (state=" + meta1.analysis_state + ")");
  }
  if (!is_analyzed_or_dual(meta2.analysis_state)) {
    throw std::runtime_error("store2 is not analyzed: " + options.store2_path +
                             " (state=" + meta2.analysis_state + ")");
  }

  if (!options.force && dual_analysis_up_to_date(meta1, partner1) &&
      dual_analysis_up_to_date(meta2, partner2)) {
    result.outcome = LinxDbDualAnalysisOutcome::Skipped;
    result.message = "dual analysis skipped: up to date";
    if (options.progress != nullptr) {
      options.progress->set_phase("dual");
      options.progress->finish("skipped", "up_to_date");
    }
    return result;
  }

  if (options.progress != nullptr) {
    options.progress->set_phase("dual", "compare");
  }

  if (!options.output_path.empty() && !options.dry_run) {
    if (options.output_path == options.store_path) {
      throw std::runtime_error("--output must differ from --store");
    }
    SqliteStore copier;
    if (!copier.open(options.store_path)) {
      throw std::runtime_error("failed to open store for copy: " + options.store_path);
    }
    copier.copy_database_file(options.output_path);
    copier.close();
  }
  if (!options.output2_path.empty() && !options.dry_run) {
    if (options.output2_path == options.store2_path) {
      throw std::runtime_error("--output2 must differ from --store2");
    }
    SqliteStore copier;
    if (!copier.open(options.store2_path)) {
      throw std::runtime_error("failed to open store2 for copy: " + options.store2_path);
    }
    copier.copy_database_file(options.output2_path);
    copier.close();
  }

  const std::string work_path1 =
      options.output_path.empty() ? options.store_path : options.output_path;
  const std::string work_path2 =
      options.output2_path.empty() ? options.store2_path : options.output2_path;

  SqliteStore store1;
  if (!store1.open(work_path1)) {
    throw std::runtime_error("failed to open store: " + work_path1);
  }
  SqliteStore store2;
  if (!store2.open(work_path2)) {
    throw std::runtime_error("failed to open store2: " + work_path2);
  }

  result.dual =
      dual_trace_analyze_open_stores(store1, store2, options.dry_run, options.verbose);

  if (!options.dry_run) {
    write_dual_analysis_meta(store1, partner1);
    write_dual_analysis_meta(store2, partner2);
  }

  result.outcome = LinxDbDualAnalysisOutcome::Analyzed;
  if (options.progress != nullptr) {
    options.progress->set_counts(result.dual.dual_matched, result.dual.dual_matched, "matched");
    options.progress->finish("ok");
  }
  return result;
}

}  // namespace pipetrace
