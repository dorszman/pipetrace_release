#include <cstdlib>
#include <iostream>
#include <string>

#include "pipetrace/app_config.hpp"
#include "pipetrace/linx_analysis.hpp"
#include "pipetrace/progress.hpp"

namespace {

struct Options {
  std::string store_path;
  std::string store2_path;
  std::string output_path;
  std::string output2_path;
  std::string config_path;
  std::string log_path;
  pipetrace::StatusMode status_mode{pipetrace::StatusMode::Pretty};
  bool verbose{false};
  bool dry_run{false};
  bool force{false};
};

Options parse_args(int argc, char** argv) {
  Options options;
  for (int i = 1; i < argc; ++i) {
    const std::string arg = argv[i];
    if (arg == "--store" && i + 1 < argc) {
      options.store_path = argv[++i];
    } else if (arg == "--store2" && i + 1 < argc) {
      options.store2_path = argv[++i];
    } else if (arg == "--output" && i + 1 < argc) {
      options.output_path = argv[++i];
    } else if (arg == "--output2" && i + 1 < argc) {
      options.output2_path = argv[++i];
    } else if (arg == "--config" && i + 1 < argc) {
      options.config_path = argv[++i];
    } else if (arg == "--log" && i + 1 < argc) {
      options.log_path = argv[++i];
    } else if (arg == "--status" && i + 1 < argc) {
      options.status_mode = pipetrace::parse_status_mode(argv[++i]);
    } else if (arg == "--verbose") {
      options.verbose = true;
    } else if (arg == "--dry-run") {
      options.dry_run = true;
    } else if (arg == "--force") {
      options.force = true;
    } else if (arg == "--help") {
      std::cout << "pipetrace-linx-analyze --store PATH --config PATH [--store2 PATH] [--output PATH] "
                   "[--output2 PATH] [--log PATH] "
                   "[--status pretty|plain] [--verbose] [--dry-run] [--force]\n"
                   "  --config PATH is required.\n";
      std::exit(0);
    } else {
      throw std::runtime_error("unknown argument: " + arg);
    }
  }
  if (options.store_path.empty()) {
    throw std::runtime_error("--store is required");
  }
  if (options.config_path.empty()) {
    throw std::runtime_error("--config is required");
  }
  if (options.log_path.empty()) {
    options.log_path = options.store2_path.empty() ? options.store_path + ".analyze.log"
                                                   : options.store_path + ".dual.log";
  }
  return options;
}

}  // namespace

int main(int argc, char** argv) {
  try {
    const Options options = parse_args(argc, argv);
    const std::string config_path =
        pipetrace::resolve_app_config_path(options.config_path, /*allow_env=*/false);
    const std::string tool_name = options.store2_path.empty() ? "analyze" : "analyze_dual";
    pipetrace::ProgressReporter progress(tool_name, options.status_mode, options.log_path);

    if (!options.store2_path.empty()) {
      pipetrace::LinxDbDualAnalysisOptions dual_options;
      dual_options.store_path = options.store_path;
      dual_options.store2_path = options.store2_path;
      dual_options.output_path = options.output_path;
      dual_options.output2_path = options.output2_path;
      dual_options.log_path = options.log_path;
      dual_options.status_mode = options.status_mode;
      dual_options.verbose = options.verbose;
      dual_options.dry_run = options.dry_run;
      dual_options.force = options.force;
      dual_options.progress = &progress;

      (void)pipetrace::run_linx_db_dual_analysis(dual_options);
      return 0;
    }

    pipetrace::LinxDbAnalysisOptions analysis_options;
    analysis_options.store_path = options.store_path;
    analysis_options.output_path = options.output_path;
    analysis_options.config_path = config_path;
    analysis_options.log_path = options.log_path;
    analysis_options.status_mode = options.status_mode;
    analysis_options.verbose = options.verbose;
    analysis_options.dry_run = options.dry_run;
    analysis_options.force = options.force;
    analysis_options.progress = &progress;

    (void)pipetrace::run_linx_db_analysis(analysis_options);
    return 0;
  } catch (const std::exception& ex) {
    std::cerr << "pipetrace-linx-analyze error: " << ex.what() << '\n';
    return 1;
  }
}
