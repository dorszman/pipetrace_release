#pragma once

#include <functional>
#include <memory>
#include <optional>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include "imgui.h"
#include "pipetrace/app_config.hpp"
#include "pipetrace/row_sort_state.hpp"
#include "pipetrace/storage.hpp"
#include "pipetrace/types.hpp"

#include "app/theme.hpp"

struct GLFWwindow;

namespace pipetrace {

struct GridPosition {
  Timestamp cycle{};
  std::int64_t row{};
};

struct CellEventInfo {
  EventId id{};
  std::int64_t event_type_id{};
  std::string kind;
  char display_char{'?'};
  std::vector<std::pair<std::string, std::string>> attributes;
};

struct StickyEventPopup {
  std::uint64_t id{};
  GridPosition cell{};
  ImVec2 position{};
  ImVec2 size{};
  float content_height{0.0f};
  float scroll_y{0.0f};
  std::vector<CellEventInfo> events;
};

struct TimelineState {
  double view_scroll_time{};
  double view_scroll_row{};
  double cycle_width{18.0};
  double row_height{22.0};
  std::int64_t visible_rows{40};
  std::int64_t visible_cycles{40};
  float event_char_font_size{13.0f};
  ObjectId selected_object{};
  bool has_selection{false};
  bool has_selected_cell{false};
  GridPosition selected_cell{};
  std::vector<CellEventInfo> selected_cell_events;
  bool has_crosshair{false};
  bool crosshair_cycle_highlight{true};
  GridPosition crosshair{};
  bool has_hover_cell{false};
  GridPosition hover_cell{};
  ImVec2 hover_popup_anchor{};
  std::vector<CellEventInfo> hover_cell_events;
  std::string hover_text;
};

struct MarkedEventType {
  std::int64_t id{};
  std::string name;
  char display_char{'?'};
  std::uint32_t color_rgba{0xFF888888};
  std::vector<CycleOccurrenceCount> occurrence_counts;
};

class TimelineView {
 public:
  explicit TimelineView(TraceStore& store);

  void set_store(TraceStore& store);
  void set_app_config(const AppConfig& config);
  void set_row_sort_state(RowSortState* state);
  void set_sort_scheme_index(std::size_t index);
  std::size_t sort_scheme_index() const;
  bool user_sort_active() const;
  const SortScheme* active_sort_scheme() const;
  void invalidate_sort_cache();
  void set_pinned_row_columns(const std::vector<PinnedRowAttribute>& columns);
  const std::vector<PinnedRowAttribute>& pinned_row_columns() const { return pinned_row_columns_; }
  bool has_row_panel() const { return !pinned_row_columns_.empty(); }
  void set_color_scheme(ColorScheme scheme);
  void reset_view(const TraceMeta& meta);
  void draw(const char* label, float height);
  void draw_event_popups();
  void handle_plot_input();

  void increase_event_char_size();
  void decrease_event_char_size();
  void toggle_marked_event_type(const EventType& event_type);
  bool is_event_type_marked(std::int64_t event_type_id) const;
  void clear_pinned_markers();
  void clear_sticky_popups();
  void remove_pinned_marker(std::size_t index);
  void navigate_to_grid_cell(const GridPosition& cell);
  void move_crosshair_to_row(std::int64_t row);
  void sync_crosshair(const GridPosition& cell, std::optional<double> scroll_row = std::nullopt,
                      std::optional<double> scroll_time = std::nullopt,
                      std::optional<bool> highlight_cycle = std::nullopt);
  void apply_view_zoom(double cycle_width, double row_height);
  void apply_linked_view_zoom(double cycle_width, double row_height);
  void apply_view_scroll(double scroll_time, double scroll_row);
  void apply_view_scroll_row(double scroll_row);
  void navigate_to_object_event_boundary(bool to_first);
  void set_crosshair_change_callback(std::function<void(TimelineView&)> callback);
  void set_sort_change_callback(std::function<void(TimelineView&)> callback);
  void set_view_zoom_change_callback(std::function<void(TimelineView&)> callback);
  void set_view_scroll_row_change_callback(std::function<void(TimelineView&)> callback);
  void set_glfw_window(GLFWwindow* window);
  bool is_view_scroll_drag_active() const;
  void update_view_drag_tracking();
  std::optional<GridPosition> view_drag_cursor_cell() const;
  void set_view_drag_input_blocked(bool blocked);
  void apply_view_scroll_drag_if_active();
  void set_crosshair_silent(const GridPosition& cell,
                            std::optional<bool> highlight_cycle = std::nullopt);
  void set_sync_partner_highlight(const std::optional<GridPosition>& cell);
  void clear_sync_partner_highlight();
  void draw_sync_partner_highlight_overlay();
  void handle_search_input();
  void draw_search_overlay();
  bool is_search_active() const { return search_.active; }
  bool is_plot_hovered() const { return plot_hovered_; }
  void set_input_focused(bool focused) { input_focused_ = focused; }
  bool input_focused() const { return input_focused_; }
  std::size_t pinned_marker_count() const { return pinned_markers_.size(); }
  std::size_t sticky_popup_count() const { return sticky_event_popups_.size(); }
  const std::vector<GridPosition>& pinned_markers() const { return pinned_markers_; }
  const std::vector<MarkedEventType>& marked_event_types() const { return marked_event_types_; }

  const TimelineState& state() const { return state_; }

 private:
  void refresh_cache();
  bool view_outside_cache() const;
  float plot_header_height() const;
  float row_attributes_panel_width() const;
  ImU32 event_color(std::uint32_t rgba) const;
  ImU32 text_color_for_background(ImU32 background) const;
  void draw_cell_label(ImDrawList* draw_list, const std::string& label, ImU32 background,
                       const ImVec2& cell_min, const ImVec2& cell_max, float font_size) const;
  std::optional<GridPosition> grid_cell_at(const ImVec2& mouse, const ImVec2& grid_origin,
                                           float cycle_width, float row_height) const;
  void select_grid_cell(const GridPosition& cell, bool notify_sync = true);
  void select_row(std::int64_t row, bool notify_sync = true);
  void ensure_row_visible(std::int64_t row);
  void notify_view_scroll_row_changed();
  void handle_row_scroll_in_draw(bool grid_wheel_scroll);
  void handle_row_axis_input();
  void handle_row_panel_header_input();
  bool defer_row_cache_refresh() const;
  void draw_row_scrollbar(ImDrawList* draw_list, const ImVec2& origin, float width,
                          float header_height, float body_height, const ViewerTheme& theme);
  std::optional<ObjectId> active_object_id() const;
  std::vector<CellEventInfo> cell_events_at(const GridPosition& cell) const;
  void pin_hover_popup();
  void layout_sticky_popup(StickyEventPopup& popup) const;
  void draw_sticky_popup_overlay(ImDrawList* draw_list, const StickyEventPopup& popup) const;
  void draw_sticky_cell_connector(ImDrawList* draw_list, const StickyEventPopup& popup) const;
  void draw_sync_partner_cell_highlight(ImDrawList* draw_list) const;
  ImVec2 mouse_pos_for_view_drag() const;
  ImVec2 glfw_cursor_pos_for_drag() const;
  bool view_drag_left_button_held() const;
  void refresh_view_drag_mouse();
  void update_pan_scroll_from_drag_mouse();
  ImVec2 grid_cell_screen_center(const GridPosition& cell) const;
  void handle_sticky_popups_input();
  bool mouse_over_sticky_popup(const ImVec2& mouse) const;
  void update_search_match();
  void draw_search_row_highlight(ImDrawList* draw_list) const;

  RowSortState& row_sort_state();
  const RowSortState& row_sort_state() const;
  std::optional<ObjectId> crosshair_object_id() const;
  void reanchor_view_after_sort_change(const std::optional<ObjectId>& anchor_object_id,
                                       Timestamp anchor_cycle);
  void notify_sort_changed();

  struct SearchState {
    bool active{false};
    std::size_t field_index{0};
    std::string query;
    std::optional<std::int64_t> match_row;
    double highlight_start_time{0.0};
  };

  SearchState search_{};
  bool input_focused_{true};
  GLFWwindow* glfw_window_{nullptr};
  TraceStore* store_{nullptr};
  AppConfig app_config_{};
  RowSortState* row_sort_state_{nullptr};
  RowSortState local_row_sort_state_{};
  std::vector<PinnedRowAttribute> pinned_row_columns_{};
  ColorScheme color_scheme_{ColorScheme::Night};
  TraceMeta meta_{};
  TimelineState state_{};
  bool panning_{false};
  ImVec2 pan_anchor_mouse_{};
  double pan_anchor_time_scroll_{};
  double pan_anchor_row_scroll_{};
  bool cache_valid_{false};
  Timestamp cache_time_start_{};
  Timestamp cache_time_end_{};
  std::int64_t cache_row_start_{};
  std::int64_t cache_row_end_{};
  ColumnarObjects cached_objects_{};
  ColumnarEvents cached_events_{};
  std::unordered_map<ObjectId, std::vector<std::pair<std::string, std::string>>>
      cached_attributes_by_object_{};
  std::unordered_map<std::int64_t, ObjectId> object_id_by_row_{};
  std::vector<EventType> event_types_{};
  std::vector<MarkedEventType> marked_event_types_{};
  std::vector<GridPosition> pinned_markers_{};
  std::vector<StickyEventPopup> sticky_event_popups_{};
  std::uint64_t next_sticky_popup_id_{1};
  std::optional<std::uint64_t> dragging_sticky_id_{};
  ImVec2 sticky_drag_anchor_{};
  bool plot_hovered_{false};
  bool plot_layout_valid_{false};
  ImVec2 plot_origin_{};
  ImVec2 plot_max_{};
  ImVec2 grid_origin_{};
  ImVec2 grid_size_{};
  float plot_cycle_width_{0.0f};
  float plot_row_height_{0.0f};
  float row_scrollbar_width_{0.0f};
  ImVec2 row_scrollbar_origin_{};
  ImVec2 row_panel_origin_{};
  float row_panel_width_{0.0f};
  float plot_header_height_{0.0f};
  bool needs_refresh_{true};
  std::int64_t axis_label_step_{1};
  bool row_scrollbar_dragging_{false};
  float row_scrollbar_drag_anchor_{0.0f};
  bool row_wheel_this_frame_{false};
  bool row_panel_selecting_{false};
  ImVec2 row_panel_select_anchor_{};
  std::function<void(TimelineView&)> crosshair_change_callback_{};
  std::function<void(TimelineView&)> sort_change_callback_{};
  bool suppress_crosshair_callback_{false};
  std::function<void(TimelineView&)> view_zoom_change_callback_{};
  bool suppress_view_callback_{false};
  std::function<void(TimelineView&)> view_scroll_row_change_callback_{};
  bool suppress_scroll_row_callback_{false};
  bool view_drag_tracking_{false};
  bool view_drag_mouse_was_usable_{false};
  GridPosition view_drag_anchor_cell_{};
  double view_drag_anchor_scroll_row_{0.0};
  double view_drag_anchor_scroll_time_{0.0};
  bool view_drag_input_blocked_{false};
  ImVec2 view_drag_mouse_{};
  bool view_drag_mouse_valid_{false};
  std::optional<GridPosition> sync_partner_highlight_cell_{};
};

}  // namespace pipetrace
