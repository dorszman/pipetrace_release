#include "app/timeline_view.hpp"

#include <algorithm>
#include <cfloat>
#include <cmath>
#include <cstdio>
#include <map>
#include <unordered_map>
#include <utility>
#include <vector>

#include "app/theme.hpp"
#include "app/view_zoom.hpp"
#include "imgui.h"
#include "pipetrace/attributes.hpp"

#include <GLFW/glfw3.h>

namespace pipetrace {
namespace {

bool mouse_left_button_clicked() {
  return ImGui::GetIO().MouseClicked[ImGuiMouseButton_Left];
}

bool mouse_pos_usable(const ImVec2& mouse) {
  return std::isfinite(mouse.x) && std::isfinite(mouse.y) && mouse.x > -1.0e8f && mouse.y > -1.0e8f;
}

constexpr float kCycleAxisHeight = 24.0f;
constexpr float kOccurrencePanelHeight = 22.0f;
constexpr float kTimelineFooterHeight = 40.0f;
constexpr float kStickyPopupMinWidth = 220.0f;
constexpr float kStickyPopupMaxWidth = 520.0f;
constexpr float kStickyPopupMaxHeight = 420.0f;
constexpr float kStickyPopupPad = 8.0f;

struct StickyPopupLayout {
  float header_row_h{};
  float close_w{};
  float body_top{};
  float body_height{};
  float max_scroll{};
};

struct ScreenRect {
  ImVec2 min{};
  ImVec2 max{};
  float GetWidth() const { return max.x - min.x; }
  float GetHeight() const { return max.y - min.y; }
};

ImU32 imgui_color_u32(ImGuiCol idx, float alpha_mul = 1.0f) {
  const ImVec4 color = ImGui::GetStyleColorVec4(idx);
  return ImGui::ColorConvertFloat4ToU32(
      ImVec4(color.x, color.y, color.z, color.w * alpha_mul));
}

ImVec2 nearest_rect_point(const ImVec2& from, const ImVec2& rect_min, const ImVec2& rect_max) {
  const float cx = std::clamp(from.x, rect_min.x, rect_max.x);
  const float cy = std::clamp(from.y, rect_min.y, rect_max.y);
  if (cx > rect_min.x && cx < rect_max.x && cy > rect_min.y && cy < rect_max.y) {
    const float dl = from.x - rect_min.x;
    const float dr = rect_max.x - from.x;
    const float dt = from.y - rect_min.y;
    const float db = rect_max.y - from.y;
    const float min_d = std::min({dl, dr, dt, db});
    if (min_d == dl) {
      return ImVec2(rect_min.x, cy);
    }
    if (min_d == dr) {
      return ImVec2(rect_max.x, cy);
    }
    if (min_d == dt) {
      return ImVec2(cx, rect_min.y);
    }
    return ImVec2(cx, rect_max.y);
  }
  return ImVec2(cx, cy);
}

StickyPopupLayout sticky_popup_layout(const StickyEventPopup& popup) {
  const float header_row_h = ImGui::GetFrameHeight();
  const float sep_gap = ImGui::GetStyle().ItemSpacing.y;
  const float body_top = kStickyPopupPad + header_row_h + sep_gap + 1.0f + sep_gap;
  const float body_height = std::max(0.0f, popup.size.y - body_top - kStickyPopupPad);
  const float max_scroll = std::max(0.0f, popup.content_height - body_height);
  return StickyPopupLayout{header_row_h, header_row_h, body_top, body_height, max_scroll};
}

ImVec2 sticky_popup_min(const StickyEventPopup& popup) { return popup.position; }

ImVec2 sticky_popup_max(const StickyEventPopup& popup) {
  return ImVec2(popup.position.x + popup.size.x, popup.position.y + popup.size.y);
}

ScreenRect sticky_popup_drag_rect(const StickyEventPopup& popup, const StickyPopupLayout& layout) {
  return ScreenRect{
      ImVec2(popup.position.x + kStickyPopupPad, popup.position.y + kStickyPopupPad),
      ImVec2(popup.position.x + popup.size.x - kStickyPopupPad - layout.close_w - 4.0f,
             popup.position.y + kStickyPopupPad + layout.header_row_h)};
}

ScreenRect sticky_popup_close_rect(const StickyEventPopup& popup, const StickyPopupLayout& layout) {
  return ScreenRect{
      ImVec2(popup.position.x + popup.size.x - kStickyPopupPad - layout.close_w,
             popup.position.y + kStickyPopupPad),
      ImVec2(popup.position.x + popup.size.x - kStickyPopupPad,
             popup.position.y + kStickyPopupPad + layout.close_w)};
}

ScreenRect sticky_popup_body_rect(const StickyEventPopup& popup, const StickyPopupLayout& layout) {
  return ScreenRect{
      ImVec2(popup.position.x + kStickyPopupPad, popup.position.y + layout.body_top),
      ImVec2(popup.position.x + popup.size.x - kStickyPopupPad,
             popup.position.y + layout.body_top + layout.body_height)};
}

void clamp_sticky_popup_position(StickyEventPopup& popup) {
  const ImVec2 display = ImGui::GetIO().DisplaySize;
  popup.position.x =
      std::clamp(popup.position.x, 0.0f, std::max(0.0f, display.x - popup.size.x));
  popup.position.y =
      std::clamp(popup.position.y, 0.0f, std::max(0.0f, display.y - popup.size.y));
}

void clamp_sticky_popup_scroll(StickyEventPopup& popup, const StickyPopupLayout& layout) {
  popup.scroll_y = std::clamp(popup.scroll_y, 0.0f, layout.max_scroll);
}

void draw_sticky_popup_lines(ImDrawList* draw_list, const StickyEventPopup& popup,
                             const StickyPopupLayout& layout, const ScreenRect& body_rect) {
  const float line_h = ImGui::GetTextLineHeightWithSpacing();
  const ImU32 text_color = imgui_color_u32(ImGuiCol_Text);
  const ImU32 disabled_color = imgui_color_u32(ImGuiCol_TextDisabled);
  float y = body_rect.min.y - popup.scroll_y;

  for (std::size_t i = 0; i < popup.events.size(); ++i) {
    const CellEventInfo& event = popup.events[i];
    if (i > 0) {
      if (y + 1.0f >= body_rect.min.y && y <= body_rect.max.y) {
        draw_list->AddLine(ImVec2(body_rect.min.x, y + line_h * 0.5f),
                           ImVec2(body_rect.max.x, y + line_h * 0.5f),
                           imgui_color_u32(ImGuiCol_Separator));
      }
      y += line_h;
    }

    char line[128];
    std::snprintf(line, sizeof(line), "'%c' %s (id %lld)", event.display_char, event.kind.c_str(),
                  static_cast<long long>(event.id));
    if (y + line_h >= body_rect.min.y && y <= body_rect.max.y) {
      draw_list->AddText(ImGui::GetFont(), ImGui::GetFontSize(), ImVec2(body_rect.min.x, y),
                         text_color, line);
    }
    y += line_h;

    if (event.attributes.empty()) {
      if (y + line_h >= body_rect.min.y && y <= body_rect.max.y) {
        draw_list->AddText(ImGui::GetFont(), ImGui::GetFontSize(), ImVec2(body_rect.min.x, y),
                           disabled_color, "(no attributes)");
      }
      y += line_h;
      continue;
    }

    for (const auto& [key, value] : event.attributes) {
      char attr_line[256];
      std::snprintf(attr_line, sizeof(attr_line), "%s: %s", key.c_str(), value.c_str());
      if (y + line_h >= body_rect.min.y && y <= body_rect.max.y) {
        draw_list->AddText(ImGui::GetFont(), ImGui::GetFontSize(), ImVec2(body_rect.min.x, y),
                           text_color, attr_line);
      }
      y += line_h;
    }
  }
}

}  // namespace

float cycle_x(const ImVec2& grid_origin, double view_scroll_time, float cycle_width,
              Timestamp cycle) {
  return grid_origin.x +
         static_cast<float>((static_cast<double>(cycle) - view_scroll_time) * cycle_width);
}

namespace {

std::int64_t cycle_label_step(double cycle_width, Timestamp min_cycle, Timestamp max_cycle) {
  char label_min[32];
  char label_max[32];
  std::snprintf(label_min, sizeof(label_min), "%lld", static_cast<long long>(min_cycle));
  std::snprintf(label_max, sizeof(label_max), "%lld", static_cast<long long>(max_cycle));
  const double min_spacing =
      static_cast<double>(
          std::max(ImGui::CalcTextSize(label_min).x, ImGui::CalcTextSize(label_max).x)) +
      10.0;

  if (cycle_width >= min_spacing) {
    return 1;
  }

  const double raw = min_spacing / cycle_width;
  const double magnitude = std::pow(10.0, std::floor(std::log10(raw)));
  const double normalized = raw / magnitude;
  double nice = 10.0;
  if (normalized <= 1.0) {
    nice = 1.0;
  } else if (normalized <= 2.0) {
    nice = 2.0;
  } else if (normalized <= 5.0) {
    nice = 5.0;
  }
  return static_cast<std::int64_t>(nice * magnitude);
}

std::int64_t stable_cycle_label_step(double cycle_width, Timestamp min_cycle, Timestamp max_cycle,
                                     std::int64_t& cached_step) {
  const std::int64_t desired = cycle_label_step(cycle_width, min_cycle, max_cycle);
  if (cached_step <= 0) {
    cached_step = desired;
    return cached_step;
  }
  if (desired == cached_step) {
    return cached_step;
  }

  char label_min[32];
  char label_max[32];
  std::snprintf(label_min, sizeof(label_min), "%lld", static_cast<long long>(min_cycle));
  std::snprintf(label_max, sizeof(label_max), "%lld", static_cast<long long>(max_cycle));
  const double min_spacing =
      static_cast<double>(
          std::max(ImGui::CalcTextSize(label_min).x, ImGui::CalcTextSize(label_max).x)) +
      10.0;

  if (desired > cached_step) {
    const double shrink_threshold = min_spacing * 0.85 / static_cast<double>(desired);
    if (cycle_width <= shrink_threshold) {
      cached_step = desired;
    }
  } else {
    const double grow_threshold = min_spacing * 1.15 / static_cast<double>(cached_step);
    if (cycle_width >= grow_threshold) {
      cached_step = desired;
    }
  }
  return cached_step;
}

constexpr float kMinOccurrenceLabelWidth = 72.0f;

ImU32 event_color_from_rgba(std::uint32_t rgba) {
  const float a = ((rgba >> 24) & 0xFF) / 255.0f;
  const float b = ((rgba >> 16) & 0xFF) / 255.0f;
  const float g = ((rgba >> 8) & 0xFF) / 255.0f;
  const float r = (rgba & 0xFF) / 255.0f;
  return ImGui::ColorConvertFloat4ToU32(ImVec4(r, g, b, a));
}

ImU32 hex_color_rgba_to_imu32(std::uint32_t rgba) {
  const std::uint8_t a = static_cast<std::uint8_t>((rgba >> 24) & 0xFF);
  const std::uint8_t r = static_cast<std::uint8_t>((rgba >> 16) & 0xFF);
  const std::uint8_t g = static_cast<std::uint8_t>((rgba >> 8) & 0xFF);
  const std::uint8_t b = static_cast<std::uint8_t>(rgba & 0xFF);
  return IM_COL32(r, g, b, a);
}

std::string format_event_type_label(char display_char, const std::string& name) {
  return std::string("'") + display_char + "' " + name;
}

float occurrence_label_width(const std::vector<MarkedEventType>& marked_types) {
  if (marked_types.empty()) {
    return 0.0f;
  }

  float width = kMinOccurrenceLabelWidth;
  for (const MarkedEventType& marked : marked_types) {
    const std::string label = format_event_type_label(marked.display_char, marked.name);
    width = std::max(width, ImGui::CalcTextSize(label.c_str()).x + 12.0f);
  }
  return width;
}

void draw_fitted_left_text(ImDrawList* draw_list, const char* text, ImU32 color,
                           const ImVec2& cell_min, const ImVec2& cell_max);

void draw_column_sort_indicator(ImDrawList* draw_list, const ImVec2& header_min,
                                const ImVec2& header_max, bool ascending, ImU32 color) {
  constexpr float kHalfWidth = 4.0f;
  constexpr float kHalfHeight = 3.0f;
  const float center_x = header_max.x - 8.0f;
  const float center_y = (header_min.y + header_max.y) * 0.5f;
  const ImVec2 half_sz(kHalfWidth, kHalfHeight);
  if (ascending) {
    const ImVec2 apex(center_x, center_y - kHalfHeight);
    draw_list->AddTriangleFilled(ImVec2(apex.x + half_sz.x, apex.y + half_sz.y),
                                   ImVec2(apex.x - half_sz.x, apex.y + half_sz.y), apex, color);
  } else {
    const ImVec2 apex(center_x, center_y + kHalfHeight);
    draw_list->AddTriangleFilled(ImVec2(apex.x - half_sz.x, apex.y - half_sz.y),
                                   ImVec2(apex.x + half_sz.x, apex.y - half_sz.y), apex, color);
  }
}

ImU32 theme_text_color_for_background(ImU32 background, const ViewerTheme& theme);

void draw_row_attributes_panel(ImDrawList* draw_list, const ImVec2& panel_origin, float panel_width,
                               float header_height, float grid_height, double view_scroll_row,
                               float row_height, std::int64_t first_row, std::int64_t last_row,
                               const std::vector<PinnedRowAttribute>& pinned_columns,
                               const ViewerTheme& theme,
                               const std::unordered_map<std::int64_t, ObjectId>& object_id_by_row,
                               const std::unordered_map<
                                   ObjectId, std::vector<std::pair<std::string, std::string>>>&
                                   attributes_by_object,
                               const RowSortState* row_sort_state, const AppConfig* app_config) {
  if (panel_width <= 0.0f || pinned_columns.empty()) {
    return;
  }

  const ImVec2 panel_max(panel_origin.x + panel_width, panel_origin.y + header_height + grid_height);
  draw_list->PushClipRect(panel_origin, panel_max, true);
  draw_list->AddRectFilled(panel_origin, panel_max, theme.row_panel_background);
  draw_list->AddLine(ImVec2(panel_max.x, panel_origin.y), ImVec2(panel_max.x, panel_max.y),
                     theme.row_panel_border);

  float column_x = panel_origin.x;
  for (const PinnedRowAttribute& column : pinned_columns) {
    const ImVec2 header_min(column_x, panel_origin.y);
    const ImVec2 header_max(column_x + column.width_px, panel_origin.y + header_height);
    draw_list->AddRectFilled(header_min, header_max, theme.row_panel_header_background);
    draw_list->AddText(ImVec2(column_x + 6.0f, panel_origin.y + 6.0f), theme.row_panel_header_text,
                       column.label.c_str());
    if (row_sort_state != nullptr && app_config != nullptr) {
      if (const std::optional<bool> ascending =
              row_sort_state->active_sort_direction_for_column(column.key, *app_config)) {
        draw_column_sort_indicator(draw_list, header_min, header_max, *ascending,
                                   theme.row_panel_header_text);
      }
    }
    draw_list->AddLine(ImVec2(header_max.x, panel_origin.y), ImVec2(header_max.x, panel_max.y),
                       theme.row_panel_column_divider);
    column_x += column.width_px;
  }

  const ImVec2 grid_origin(panel_origin.x, panel_origin.y + header_height);
  draw_list->PushClipRect(grid_origin, panel_max, true);

  for (std::int64_t row = first_row; row <= last_row; ++row) {
    const float y =
        grid_origin.y + static_cast<float>(static_cast<double>(row) - view_scroll_row) * row_height;
    if (y + row_height < grid_origin.y || y > panel_max.y) {
      continue;
    }

    const ImVec2 row_min(panel_origin.x, y);
    const ImVec2 row_max(panel_max.x, y + row_height);
    draw_list->AddRectFilled(row_min, row_max, theme.row_panel_row_fill);
    draw_list->AddLine(row_min, ImVec2(row_max.x, row_min.y), theme.row_panel_row_divider);

    const auto row_it = object_id_by_row.find(row);
    if (row_it == object_id_by_row.end()) {
      continue;
    }

    const auto attrs_it = attributes_by_object.find(row_it->second);
    if (attrs_it == attributes_by_object.end()) {
      continue;
    }

    float value_x = panel_origin.x;
    for (const PinnedRowAttribute& column : pinned_columns) {
      const std::string value = attribute_value(attrs_it->second, column.key);
      const ImVec2 fill_min(value_x, y);
      const ImVec2 fill_max(value_x + column.width_px, y + row_height);
      const ImVec2 cell_min(value_x + 4.0f, y + 2.0f);
      const ImVec2 cell_max(value_x + column.width_px - 4.0f, y + row_height - 2.0f);

      ImU32 text_color = theme.row_panel_value_text;
      if (app_config != nullptr) {
        for (const ObjectAttributeStrengthRule& rule : app_config->object_attribute_strength) {
          if (rule.key != column.key) {
            continue;
          }
          const std::string color_key = column.key + "_color";
          const std::string color_text = attribute_value(attrs_it->second, color_key);
          if (const std::optional<std::uint32_t> rgba = parse_hex_color_rgba(color_text)) {
            const ImU32 background = hex_color_rgba_to_imu32(*rgba);
            draw_list->PushClipRect(fill_min, fill_max, true);
            draw_list->AddRectFilled(fill_min, fill_max, background);
            draw_list->PopClipRect();
            text_color = theme_text_color_for_background(background, theme);
          }
          break;
        }
      }

      draw_list->PushClipRect(cell_min, cell_max, true);
      draw_fitted_left_text(draw_list, value.c_str(), text_color, cell_min, cell_max);
      draw_list->PopClipRect();
      value_x += column.width_px;
    }
  }

  draw_list->PopClipRect();
  draw_list->PopClipRect();
}

void draw_cycle_axis(ImDrawList* draw_list, const ImVec2& axis_origin, float axis_width,
                     float label_width, Timestamp first_cycle, Timestamp last_cycle,
                     double view_scroll_time, float cycle_width, std::int64_t label_step,
                     const ViewerTheme& theme) {
  const ImVec2 axis_max(axis_origin.x + axis_width, axis_origin.y + kCycleAxisHeight);
  const ImVec2 full_axis_origin(axis_origin.x - label_width, axis_origin.y);
  const ImVec2 full_axis_max(axis_max.x, axis_max.y);
  draw_list->PushClipRect(full_axis_origin, full_axis_max, true);
  draw_list->AddRectFilled(full_axis_origin, full_axis_max, theme.axis_background);
  if (label_width > 0.0f) {
    draw_list->AddLine(ImVec2(axis_origin.x, axis_origin.y), ImVec2(axis_origin.x, axis_max.y),
                       theme.axis_inner_divider);
  }
  draw_list->AddLine(ImVec2(full_axis_origin.x, axis_max.y), full_axis_max, theme.axis_divider);

  draw_list->PushClipRect(axis_origin, axis_max, true);
  Timestamp cycle = first_cycle;
  if (label_step > 1) {
    const Timestamp remainder = ((cycle % label_step) + label_step) % label_step;
    cycle -= remainder;
  }

  const float label_span = cycle_width * static_cast<float>(label_step);
  float last_label_right = axis_origin.x - 1.0f;

  for (; cycle <= last_cycle + label_step; cycle += label_step) {
    const float x = cycle_x(axis_origin, view_scroll_time, cycle_width, cycle);
    if (x + label_span < axis_origin.x || x > axis_origin.x + axis_width) {
      continue;
    }

    draw_list->AddLine(ImVec2(x, axis_max.y - 6.0f), ImVec2(x, axis_max.y), theme.axis_tick);

    char label[32];
    std::snprintf(label, sizeof(label), "%lld", static_cast<long long>(cycle));
    const ImVec2 text_size = ImGui::CalcTextSize(label);
    const float text_x = x + (label_span - text_size.x) * 0.5f;
    const float text_y = axis_origin.y + (kCycleAxisHeight - text_size.y) * 0.5f;
    const float text_right = text_x + text_size.x;
    if (text_x <= last_label_right + 4.0f) {
      continue;
    }
    if (text_x < axis_origin.x || text_right > axis_origin.x + axis_width) {
      continue;
    }

    draw_list->AddText(ImVec2(text_x, text_y), theme.axis_label, label);
    last_label_right = text_right;
  }

  draw_list->PopClipRect();
  draw_list->PopClipRect();
}

void draw_header_label_column(ImDrawList* draw_list, const ImVec2& plot_origin,
                              float label_width, float header_height,
                              const std::vector<MarkedEventType>& marked_types,
                              const ViewerTheme& theme) {
  if (label_width <= 0.0f || marked_types.empty()) {
    return;
  }

  const ImVec2 col_max(plot_origin.x + label_width, plot_origin.y + header_height);
  draw_list->PushClipRect(plot_origin, col_max, true);
  draw_list->AddRectFilled(plot_origin, col_max, theme.header_label_background);
  draw_list->AddLine(ImVec2(col_max.x, plot_origin.y), ImVec2(col_max.x, col_max.y),
                     theme.header_label_border);

  for (std::size_t i = 0; i < marked_types.size(); ++i) {
    const float row_y =
        plot_origin.y + kCycleAxisHeight + static_cast<float>(i) * kOccurrencePanelHeight;
    const std::string label =
        format_event_type_label(marked_types[i].display_char, marked_types[i].name);
    const ImVec2 text_size = ImGui::CalcTextSize(label.c_str());
    const float text_x = plot_origin.x + 6.0f;
    const float text_y = row_y + (kOccurrencePanelHeight - text_size.y) * 0.5f;
    draw_list->AddText(ImVec2(text_x, text_y), event_color_from_rgba(marked_types[i].color_rgba),
                       label.c_str());

    if (i + 1 < marked_types.size()) {
      const float divider_y = row_y + kOccurrencePanelHeight;
      draw_list->AddLine(ImVec2(plot_origin.x, divider_y), ImVec2(col_max.x, divider_y),
                         theme.header_label_divider);
    }
  }

  draw_list->PopClipRect();
}

ImU32 theme_text_color_for_background(ImU32 background, const ViewerTheme& theme) {
  const float r = static_cast<float>((background >> IM_COL32_R_SHIFT) & 0xFF) / 255.0f;
  const float g = static_cast<float>((background >> IM_COL32_G_SHIFT) & 0xFF) / 255.0f;
  const float b = static_cast<float>((background >> IM_COL32_B_SHIFT) & 0xFF) / 255.0f;
  const float luminance = 0.2126f * r + 0.7152f * g + 0.0722f * b;
  return luminance > 0.62f ? theme.event_text_on_light : theme.event_text_on_dark;
}

std::size_t total_occurrence_count(const std::vector<CycleOccurrenceCount>& occurrences) {
  std::size_t total = 0;
  for (const CycleOccurrenceCount& occurrence : occurrences) {
    total += occurrence.count;
  }
  return total;
}

ImVec2 text_size_at(float font_size, const char* text) {
  return ImGui::GetFont()->CalcTextSizeA(font_size, FLT_MAX, 0.0f, text);
}

void draw_fitted_count_text(ImDrawList* draw_list, const char* text, ImU32 background,
                            const ImVec2& cell_min, const ImVec2& cell_max,
                            const ViewerTheme& theme) {
  const float cell_w = cell_max.x - cell_min.x;
  const float cell_h = cell_max.y - cell_min.y;
  if (cell_w < 4.0f || cell_h < 6.0f) {
    return;
  }

  for (float font_size = 12.0f; font_size >= 7.0f; font_size -= 1.0f) {
    const ImVec2 text_size = text_size_at(font_size, text);
    if (text_size.x > cell_w - 1.0f || text_size.y > cell_h - 1.0f) {
      continue;
    }
    const float text_x = cell_min.x + (cell_w - text_size.x) * 0.5f;
    const float text_y = cell_min.y + (cell_h - text_size.y) * 0.5f;
    draw_list->AddText(ImGui::GetFont(), font_size, ImVec2(text_x, text_y),
                       theme_text_color_for_background(background, theme), text);
    return;
  }
}

void draw_fitted_left_text(ImDrawList* draw_list, const char* text, ImU32 color,
                           const ImVec2& cell_min, const ImVec2& cell_max) {
  const float cell_w = cell_max.x - cell_min.x;
  const float cell_h = cell_max.y - cell_min.y;
  if (cell_w < 4.0f || cell_h < 6.0f || text == nullptr || text[0] == '\0') {
    return;
  }

  const float max_font = std::clamp(cell_h - 4.0f, 7.0f, 28.0f);
  for (float font_size = max_font; font_size >= 7.0f; font_size -= 0.5f) {
    const ImVec2 text_size = text_size_at(font_size, text);
    if (text_size.x > cell_w - 1.0f || text_size.y > cell_h - 1.0f) {
      continue;
    }
    const float text_y = cell_min.y + (cell_h - text_size.y) * 0.5f;
    draw_list->AddText(ImGui::GetFont(), font_size, ImVec2(cell_min.x, text_y), color, text);
    return;
  }
}

void draw_occurrence_panel_bars(ImDrawList* draw_list, const ImVec2& panel_origin, float panel_width,
                                float label_width, Timestamp first_cycle, Timestamp last_cycle,
                                double view_scroll_time, float cycle_width,
                                const std::vector<CycleOccurrenceCount>& occurrences,
                                ImU32 marker_color, const ViewerTheme& theme) {
  const ImVec2 panel_max(panel_origin.x + panel_width, panel_origin.y + kOccurrencePanelHeight);
  const ImVec2 full_panel_origin(panel_origin.x - label_width, panel_origin.y);
  draw_list->PushClipRect(full_panel_origin, panel_max, true);
  draw_list->AddRectFilled(full_panel_origin, panel_max, theme.occurrence_panel_background);
  draw_list->AddLine(ImVec2(full_panel_origin.x, panel_max.y), panel_max, theme.occurrence_panel_border);
  if (label_width > 0.0f) {
    draw_list->AddLine(ImVec2(panel_origin.x, panel_origin.y), ImVec2(panel_origin.x, panel_max.y),
                       theme.occurrence_panel_divider);
  }
  draw_list->PopClipRect();

  draw_list->PushClipRect(panel_origin, panel_max, true);
  const auto begin = std::lower_bound(
      occurrences.begin(), occurrences.end(), first_cycle,
      [](const CycleOccurrenceCount& entry, Timestamp cycle) { return entry.cycle < cycle; });
  const auto end = std::upper_bound(
      occurrences.begin(), occurrences.end(), last_cycle,
      [](Timestamp cycle, const CycleOccurrenceCount& entry) { return cycle < entry.cycle; });
  for (auto it = begin; it != end; ++it) {
    const float x = cycle_x(panel_origin, view_scroll_time, cycle_width, it->cycle);
    if (x + cycle_width < panel_origin.x || x > panel_max.x) {
      continue;
    }
    const float tick_min_x = std::max(x + 1.0f, panel_origin.x + 1.0f);
    const float tick_max_x = std::min(x + cycle_width - 1.0f, panel_max.x - 1.0f);
    if (tick_max_x <= tick_min_x) {
      continue;
    }

    const ImVec2 cell_min(tick_min_x, panel_origin.y + 2.0f);
    const ImVec2 cell_max(tick_max_x, panel_max.y - 2.0f);
    draw_list->AddRectFilled(cell_min, cell_max, marker_color);
  }
  draw_list->PopClipRect();
}

void draw_occurrence_panel_counts(ImDrawList* draw_list, const ImVec2& panel_origin,
                                  float panel_width, Timestamp first_cycle, Timestamp last_cycle,
                                  double view_scroll_time, float cycle_width,
                                  const std::vector<CycleOccurrenceCount>& occurrences,
                                  ImU32 marker_color, const ViewerTheme& theme) {
  const ImVec2 panel_max(panel_origin.x + panel_width, panel_origin.y + kOccurrencePanelHeight);
  draw_list->PushClipRect(panel_origin, panel_max, true);
  const auto begin = std::lower_bound(
      occurrences.begin(), occurrences.end(), first_cycle,
      [](const CycleOccurrenceCount& entry, Timestamp cycle) { return entry.cycle < cycle; });
  const auto end = std::upper_bound(
      occurrences.begin(), occurrences.end(), last_cycle,
      [](Timestamp cycle, const CycleOccurrenceCount& entry) { return cycle < entry.cycle; });
  for (auto it = begin; it != end; ++it) {
    const float x = cycle_x(panel_origin, view_scroll_time, cycle_width, it->cycle);
    if (x + cycle_width < panel_origin.x || x > panel_max.x) {
      continue;
    }
    const float tick_min_x = std::max(x + 1.0f, panel_origin.x + 1.0f);
    const float tick_max_x = std::min(x + cycle_width - 1.0f, panel_max.x - 1.0f);
    if (tick_max_x <= tick_min_x) {
      continue;
    }

    char count_label[16];
    std::snprintf(count_label, sizeof(count_label), "%zu", it->count);
    const ImVec2 cell_min(tick_min_x, panel_origin.y + 2.0f);
    const ImVec2 cell_max(tick_max_x, panel_max.y - 2.0f);
    draw_fitted_count_text(draw_list, count_label, marker_color, cell_min, cell_max, theme);
  }
  draw_list->PopClipRect();
}

struct CellEvent {
  EventId id{};
  std::int64_t event_type_id{};
  char display_char{'?'};
  std::uint32_t color_rgba{};
  ObjectId object_id{};
  std::string kind;
  std::vector<std::pair<std::string, std::string>> attributes;
};

using CellKey = std::pair<std::int64_t, Timestamp>;

std::string label_for_cell_events(const std::vector<CellEvent>& events, float max_width,
                                  float font_size) {
  std::string label;
  for (const CellEvent& event : events) {
    const std::string candidate = label + event.display_char;
    if (text_size_at(font_size, candidate.c_str()).x > max_width) {
      break;
    }
    label = candidate;
  }
  return label;
}

bool is_pinned_row(const std::vector<GridPosition>& markers, std::int64_t row) {
  for (const GridPosition& marker : markers) {
    if (marker.row == row) {
      return true;
    }
  }
  return false;
}

bool is_pinned_cycle(const std::vector<GridPosition>& markers, Timestamp cycle) {
  for (const GridPosition& marker : markers) {
    if (marker.cycle == cycle) {
      return true;
    }
  }
  return false;
}

struct MarkerBandStyle {
  ImU32 pinned_band{};
  ImU32 pinned_cross{};
  ImU32 active_band{};
  ImU32 active_cross{};
};

MarkerBandStyle marker_style_from_theme(const MarkerBandColors& colors) {
  return {colors.pinned_band, colors.pinned_cross, colors.active_band, colors.active_cross};
}

void draw_grid_marker_fills(ImDrawList* draw_list, const ImVec2& grid_origin, const ImVec2& grid_max,
                            Timestamp first_cycle, Timestamp last_cycle, std::int64_t first_row,
                            std::int64_t last_row, double view_scroll_time, double view_scroll_row,
                            float cycle_width, float row_height, bool has_crosshair,
                            const GridPosition& crosshair, bool crosshair_cycle_highlight,
                            const std::vector<GridPosition>& pinned_markers,
                            const MarkerBandStyle& style) {
  for (Timestamp cycle = first_cycle; cycle <= last_cycle; ++cycle) {
    const float x = cycle_x(grid_origin, view_scroll_time, cycle_width, cycle);
    if (x + cycle_width < grid_origin.x || x > grid_max.x) {
      continue;
    }

    for (std::int64_t row = first_row; row <= last_row; ++row) {
      const float y =
          grid_origin.y +
          static_cast<float>(static_cast<double>(row) - view_scroll_row) * row_height;
      if (y + row_height < grid_origin.y || y > grid_max.y) {
        continue;
      }

      const ImVec2 cell_min(std::max(x, grid_origin.x), y);
      const ImVec2 cell_max(std::min(x + cycle_width, grid_max.x), y + row_height);
      if (cell_max.x <= cell_min.x) {
        continue;
      }

      const bool pinned_row = is_pinned_row(pinned_markers, row);
      const bool pinned_col = is_pinned_cycle(pinned_markers, cycle);
      const bool active_row = has_crosshair && crosshair.row == row;
      const bool active_col =
          has_crosshair && crosshair_cycle_highlight && crosshair.cycle == cycle;

      if (pinned_row || pinned_col) {
        draw_list->AddRectFilled(cell_min, cell_max,
                                 pinned_row && pinned_col ? style.pinned_cross : style.pinned_band);
      }
      if (active_row || active_col) {
        draw_list->AddRectFilled(cell_min, cell_max,
                                 active_row && active_col ? style.active_cross : style.active_band);
      }
    }
  }
}

void draw_row_panel_marker_fills(ImDrawList* draw_list, const ImVec2& panel_origin,
                                 const ImVec2& panel_max, float header_height,
                                 double view_scroll_row, float row_height,
                                 std::int64_t first_row, std::int64_t last_row,
                                 bool has_crosshair, const GridPosition& crosshair,
                                 const std::vector<GridPosition>& pinned_markers,
                                 const MarkerBandStyle& style) {
  if (panel_max.x <= panel_origin.x) {
    return;
  }

  const ImVec2 grid_origin(panel_origin.x, panel_origin.y + header_height);
  draw_list->PushClipRect(grid_origin, panel_max, true);

  for (std::int64_t row = first_row; row <= last_row; ++row) {
    const float y =
        grid_origin.y +
        static_cast<float>(static_cast<double>(row) - view_scroll_row) * row_height;
    if (y + row_height < grid_origin.y || y > panel_max.y) {
      continue;
    }

    const ImVec2 row_min(panel_origin.x, y);
    const ImVec2 row_max(panel_max.x, y + row_height);
    const bool pinned_row = is_pinned_row(pinned_markers, row);
    const bool active_row = has_crosshair && crosshair.row == row;

    if (pinned_row) {
      draw_list->AddRectFilled(row_min, row_max, style.pinned_band);
    }
    if (active_row) {
      draw_list->AddRectFilled(row_min, row_max, style.active_band);
    }
  }

  draw_list->PopClipRect();
}

void draw_row_guide(ImDrawList* draw_list, const ImVec2& grid_origin, const ImVec2& grid_max,
                    std::int64_t row, double view_scroll_row, float row_height, ImU32 color,
                    float thickness, float left_x) {
  const float y =
      grid_origin.y + static_cast<float>(static_cast<double>(row) - view_scroll_row) * row_height;
  const float y_bottom = y + row_height;
  if (y_bottom < grid_origin.y || y > grid_max.y) {
    return;
  }
  draw_list->AddLine(ImVec2(left_x, y), ImVec2(grid_max.x, y), color, thickness);
  draw_list->AddLine(ImVec2(left_x, y_bottom), ImVec2(grid_max.x, y_bottom), color, thickness);
}

void draw_cycle_guide(ImDrawList* draw_list, const ImVec2& grid_origin, const ImVec2& grid_max,
                      Timestamp cycle, double view_scroll_time, float cycle_width, ImU32 color,
                      float thickness) {
  const float x = cycle_x(grid_origin, view_scroll_time, cycle_width, cycle);
  const float x_right = x + cycle_width;
  if (x_right < grid_origin.x || x > grid_max.x) {
    return;
  }
  draw_list->AddLine(ImVec2(x, grid_origin.y), ImVec2(x, grid_max.y), color, thickness);
  draw_list->AddLine(ImVec2(x_right, grid_origin.y), ImVec2(x_right, grid_max.y), color, thickness);
}

void draw_grid_marker_guides(ImDrawList* draw_list, const ImVec2& grid_origin, const ImVec2& grid_max,
                             double view_scroll_time, double view_scroll_row, float cycle_width,
                             float row_height, bool has_crosshair, const GridPosition& crosshair,
                             bool crosshair_cycle_highlight,
                             const std::vector<GridPosition>& pinned_markers,
                             const ViewerTheme& theme, float row_guide_left_x) {
  for (const GridPosition& marker : pinned_markers) {
    draw_row_guide(draw_list, grid_origin, grid_max, marker.row, view_scroll_row, row_height,
                   theme.pinned_guide, 1.5f, row_guide_left_x);
    draw_cycle_guide(draw_list, grid_origin, grid_max, marker.cycle, view_scroll_time, cycle_width,
                     theme.pinned_guide, 1.5f);
  }
  if (has_crosshair) {
    draw_row_guide(draw_list, grid_origin, grid_max, crosshair.row, view_scroll_row, row_height,
                   theme.active_guide, 2.0f, row_guide_left_x);
    if (crosshair_cycle_highlight) {
      draw_cycle_guide(draw_list, grid_origin, grid_max, crosshair.cycle, view_scroll_time,
                       cycle_width, theme.active_guide, 2.0f);
    }
  }
}

bool key_just_pressed(const ImGuiKey key) {
  if (key < ImGuiKey_NamedKey_BEGIN || key >= ImGuiKey_NamedKey_END) {
    return false;
  }
  const int key_index = key - ImGuiKey_NamedKey_BEGIN;
  if (key_index < 0 || key_index >= ImGuiKey_NamedKey_COUNT) {
    return false;
  }
  const ImGuiKeyData& key_data = ImGui::GetIO().KeysData[key_index];
  return key_data.Down && key_data.DownDuration == 0.0f;
}

bool pin_hotkey_pressed() {
  return key_just_pressed(ImGuiKey_X);
}

bool mouse_in_rect(const ImVec2& point, const ImVec2& min, const ImVec2& max) {
  return point.x >= min.x && point.x <= max.x && point.y >= min.y && point.y <= max.y;
}

}  // namespace

TimelineView::TimelineView(TraceStore& store) : store_(&store) {
  event_types_ = store.event_types();
}

void TimelineView::set_store(TraceStore& store) {
  store_ = &store;
  event_types_ = store.event_types();
  needs_refresh_ = true;
}

void TimelineView::set_app_config(const AppConfig& config) {
  app_config_ = config;
  row_sort_state().clamp_config_scheme_index(app_config_);
}

void TimelineView::set_row_sort_state(RowSortState* state) {
  row_sort_state_ = state;
}

RowSortState& TimelineView::row_sort_state() {
  return row_sort_state_ != nullptr ? *row_sort_state_ : local_row_sort_state_;
}

const RowSortState& TimelineView::row_sort_state() const {
  return row_sort_state_ != nullptr ? *row_sort_state_ : local_row_sort_state_;
}

void TimelineView::set_sort_scheme_index(const std::size_t index) {
  std::optional<ObjectId> anchor_object_id;
  Timestamp anchor_cycle{};
  if (state_.has_crosshair) {
    anchor_cycle = state_.crosshair.cycle;
    anchor_object_id = crosshair_object_id();
  }
  if (!row_sort_state().set_config_scheme_index(index, app_config_)) {
    return;
  }
  invalidate_sort_cache();
  reanchor_view_after_sort_change(anchor_object_id, anchor_cycle);
  notify_sort_changed();
}

std::size_t TimelineView::sort_scheme_index() const {
  return row_sort_state().config_scheme_index();
}

bool TimelineView::user_sort_active() const {
  return row_sort_state().user_mode();
}

void TimelineView::invalidate_sort_cache() {
  needs_refresh_ = true;
  cache_valid_ = false;
}

const SortScheme* TimelineView::active_sort_scheme() const {
  return row_sort_state().active_sort_scheme(app_config_);
}

void TimelineView::set_pinned_row_columns(const std::vector<PinnedRowAttribute>& columns) {
  pinned_row_columns_ = columns;
}

void TimelineView::set_color_scheme(const ColorScheme scheme) {
  color_scheme_ = scheme;
}

void TimelineView::reset_view(const TraceMeta& meta) {
  meta_ = meta;
  state_.view_scroll_time = static_cast<double>(meta.min_time);
  state_.view_scroll_row = 0.0;
  state_.has_selection = false;
  state_.has_selected_cell = false;
  state_.selected_cell_events.clear();
  state_.has_crosshair = false;
  state_.crosshair_cycle_highlight = true;
  state_.has_hover_cell = false;
  state_.hover_cell_events.clear();
  sticky_event_popups_.clear();
  next_sticky_popup_id_ = 1;
  dragging_sticky_id_.reset();
  marked_event_types_.clear();
  pinned_markers_.clear();
  axis_label_step_ = 1;
  panning_ = false;
  row_scrollbar_dragging_ = false;
  row_wheel_this_frame_ = false;
  view_drag_mouse_valid_ = false;
  view_drag_mouse_was_usable_ = false;
  view_drag_tracking_ = false;
  cache_valid_ = false;
  needs_refresh_ = true;
}

bool TimelineView::defer_row_cache_refresh() const {
  if (panning_) {
    return true;
  }
  if (!row_scrollbar_dragging_ && !row_wheel_this_frame_) {
    return false;
  }
  return !view_outside_cache();
}

bool TimelineView::view_outside_cache() const {
  if (!cache_valid_) {
    return true;
  }

  const std::int64_t row_margin = 24;

  return state_.view_scroll_row < static_cast<double>(cache_row_start_) + row_margin ||
         state_.view_scroll_row + static_cast<double>(state_.visible_rows) >
             static_cast<double>(cache_row_end_) - row_margin ||
         state_.view_scroll_time < static_cast<double>(cache_time_start_) ||
         state_.view_scroll_time + static_cast<double>(state_.visible_cycles) >
             static_cast<double>(cache_time_end_);
}

float TimelineView::plot_header_height() const {
  return kCycleAxisHeight +
         static_cast<float>(marked_event_types_.size()) * kOccurrencePanelHeight;
}

float TimelineView::row_attributes_panel_width() const {
  float total = 0.0f;
  for (const PinnedRowAttribute& column : pinned_row_columns_) {
    total += column.width_px;
  }
  return total;
}

bool TimelineView::is_event_type_marked(std::int64_t event_type_id) const {
  for (const MarkedEventType& marked : marked_event_types_) {
    if (marked.id == event_type_id) {
      return true;
    }
  }
  return false;
}

void TimelineView::toggle_marked_event_type(const EventType& event_type) {
  const auto existing = std::find_if(
      marked_event_types_.begin(), marked_event_types_.end(),
      [&](const MarkedEventType& marked) { return marked.id == event_type.id; });
  if (existing != marked_event_types_.end()) {
    marked_event_types_.erase(existing);
    return;
  }

  MarkedEventType marked;
  marked.id = event_type.id;
  marked.name = event_type.name;
  marked.display_char = event_type.display_char;
  marked.color_rgba = event_type.color_rgba;
  if (store_) {
    marked.occurrence_counts = store_->query_event_cycle_counts(event_type.id);
  }
  marked_event_types_.push_back(std::move(marked));
}

ImU32 TimelineView::event_color(std::uint32_t rgba) const {
  return event_color_from_rgba(rgba);
}

ImU32 TimelineView::text_color_for_background(ImU32 background) const {
  return theme_text_color_for_background(background, viewer_theme(color_scheme_));
}

void TimelineView::increase_event_char_size() {
  state_.event_char_font_size = std::min(32.0f, state_.event_char_font_size + 2.0f);
}

void TimelineView::decrease_event_char_size() {
  state_.event_char_font_size = std::max(8.0f, state_.event_char_font_size - 2.0f);
}

void TimelineView::clear_pinned_markers() {
  pinned_markers_.clear();
}

void TimelineView::clear_sticky_popups() {
  sticky_event_popups_.clear();
  dragging_sticky_id_.reset();
}

void TimelineView::remove_pinned_marker(const std::size_t index) {
  if (index < pinned_markers_.size()) {
    pinned_markers_.erase(pinned_markers_.begin() + static_cast<std::ptrdiff_t>(index));
  }
}

void TimelineView::navigate_to_grid_cell(const GridPosition& cell) {
  state_.view_scroll_time =
      static_cast<double>(cell.cycle) - static_cast<double>(state_.visible_cycles) * 0.5;
  state_.view_scroll_row =
      static_cast<double>(cell.row) - static_cast<double>(state_.visible_rows) * 0.5;
  state_.view_scroll_time =
      std::max(static_cast<double>(meta_.min_time), state_.view_scroll_time);
  state_.view_scroll_row = std::max(0.0, state_.view_scroll_row);

  needs_refresh_ = true;
  refresh_cache();
  select_grid_cell(cell);
}

void TimelineView::move_crosshair_to_row(const std::int64_t row) {
  if (!store_) {
    return;
  }

  state_.crosshair.row = row;
  state_.has_crosshair = true;
  if (state_.has_selected_cell) {
    state_.selected_cell.row = row;
    state_.selected_cell_events = cell_events_at(state_.selected_cell);
  }

  state_.has_selection = false;
  if (const std::optional<ObjectId> object_id =
          store_->object_id_for_row(row, active_sort_scheme())) {
    if (const std::optional<TraceObject> object = store_->find_object(*object_id)) {
      state_.selected_object = object->id;
      state_.has_selection = true;
    }
  }
}

void TimelineView::sync_crosshair(const GridPosition& cell, const std::optional<double> scroll_row,
                                  const std::optional<double> scroll_time,
                                  const std::optional<bool> highlight_cycle) {
  suppress_crosshair_callback_ = true;
  suppress_scroll_row_callback_ = true;
  select_grid_cell(cell, false);
  if (highlight_cycle.has_value()) {
    state_.crosshair_cycle_highlight = highlight_cycle.value();
  }
  // SYNC copies row scroll only; scroll_time is omitted by partner sync paths.
  if (scroll_time.has_value()) {
    state_.view_scroll_time = scroll_time.value();
    needs_refresh_ = true;
  }
  if (scroll_row.has_value()) {
    state_.view_scroll_row = scroll_row.value();
    needs_refresh_ = true;
  } else if (!scroll_time.has_value()) {
    ensure_row_visible(cell.row);
  }
  suppress_scroll_row_callback_ = false;
  suppress_crosshair_callback_ = false;
}

void TimelineView::apply_view_scroll(const double scroll_time, const double scroll_row) {
  suppress_scroll_row_callback_ = true;
  state_.view_scroll_time = scroll_time;
  state_.view_scroll_row = scroll_row;
  needs_refresh_ = true;
  suppress_scroll_row_callback_ = false;
}

void TimelineView::apply_view_zoom(const double cycle_width, const double row_height) {
  suppress_view_callback_ = true;
  state_.cycle_width = cycle_width;
  state_.row_height = row_height;
  needs_refresh_ = true;
  suppress_view_callback_ = false;
}

void TimelineView::apply_linked_view_zoom(const double cycle_width, const double row_height) {
  Timestamp anchor_cycle{};
  std::int64_t anchor_row{};
  if (state_.has_crosshair) {
    anchor_cycle = state_.crosshair.cycle;
    anchor_row = state_.crosshair.row;
  } else if (state_.has_hover_cell) {
    anchor_cycle = state_.hover_cell.cycle;
    anchor_row = state_.hover_cell.row;
  } else if (plot_layout_valid_ && grid_size_.x > 0.0f && grid_size_.y > 0.0f) {
    anchor_cycle = static_cast<Timestamp>(std::floor(
        state_.view_scroll_time +
        static_cast<double>(grid_size_.x * 0.5f) / state_.cycle_width));
    anchor_row = static_cast<std::int64_t>(std::floor(
        state_.view_scroll_row +
        static_cast<double>(grid_size_.y * 0.5f) / state_.row_height));
  } else {
    anchor_cycle = static_cast<Timestamp>(std::floor(
        state_.view_scroll_time + static_cast<double>(state_.visible_cycles) * 0.5));
    anchor_row = static_cast<std::int64_t>(std::floor(
        state_.view_scroll_row + static_cast<double>(state_.visible_rows) * 0.5));
  }

  const double mouse_x =
      (static_cast<double>(anchor_cycle) - state_.view_scroll_time) * state_.cycle_width;
  const double mouse_y =
      (static_cast<double>(anchor_row) - state_.view_scroll_row) * state_.row_height;

  suppress_view_callback_ = true;
  zoom_preserve_anchor_to_size(state_.view_scroll_time, state_.cycle_width, mouse_x, cycle_width,
                               4.0, 80.0);
  zoom_preserve_anchor_to_size(state_.view_scroll_row, state_.row_height, mouse_y, row_height, 8.0,
                               80.0);
  needs_refresh_ = true;
  suppress_view_callback_ = false;
}

void TimelineView::apply_view_scroll_row(const double scroll_row) {
  suppress_scroll_row_callback_ = true;
  state_.view_scroll_row = scroll_row;
  needs_refresh_ = true;
  suppress_scroll_row_callback_ = false;
}

void TimelineView::set_crosshair_change_callback(std::function<void(TimelineView&)> callback) {
  crosshair_change_callback_ = std::move(callback);
}

void TimelineView::set_sort_change_callback(std::function<void(TimelineView&)> callback) {
  sort_change_callback_ = std::move(callback);
}

void TimelineView::set_view_zoom_change_callback(std::function<void(TimelineView&)> callback) {
  view_zoom_change_callback_ = std::move(callback);
}

void TimelineView::set_view_scroll_row_change_callback(
    std::function<void(TimelineView&)> callback) {
  view_scroll_row_change_callback_ = std::move(callback);
}

void TimelineView::notify_view_scroll_row_changed() {
  if (!suppress_scroll_row_callback_ && view_scroll_row_change_callback_) {
    view_scroll_row_change_callback_(*this);
  }
}

void TimelineView::set_glfw_window(GLFWwindow* window) {
  glfw_window_ = window;
}

bool TimelineView::view_drag_left_button_held() const {
  if (glfw_window_ != nullptr) {
    return glfwGetMouseButton(glfw_window_, GLFW_MOUSE_BUTTON_LEFT) == GLFW_PRESS;
  }
  return ImGui::GetIO().MouseDown[ImGuiMouseButton_Left];
}

ImVec2 TimelineView::glfw_cursor_pos_for_drag() const {
  if (glfw_window_ == nullptr) {
    return ImVec2(-FLT_MAX, -FLT_MAX);
  }
  double x = 0.0;
  double y = 0.0;
  glfwGetCursorPos(glfw_window_, &x, &y);
  return ImVec2(static_cast<float>(x), static_cast<float>(y));
}

bool TimelineView::is_view_scroll_drag_active() const {
  if (row_scrollbar_dragging_ || row_wheel_this_frame_) {
    return true;
  }
  return panning_;
}

ImVec2 TimelineView::mouse_pos_for_view_drag() const {
  const ImVec2 io_mouse = ImGui::GetIO().MousePos;
  if (mouse_pos_usable(io_mouse)) {
    return io_mouse;
  }
  const ImVec2 glfw_mouse = glfw_cursor_pos_for_drag();
  if (mouse_pos_usable(glfw_mouse)) {
    return glfw_mouse;
  }
  if (view_drag_mouse_valid_) {
    return view_drag_mouse_;
  }
  return pan_anchor_mouse_;
}

void TimelineView::refresh_view_drag_mouse() {
  const ImVec2 drag_mouse = mouse_pos_for_view_drag();
  if (is_view_scroll_drag_active() && mouse_pos_usable(drag_mouse)) {
    view_drag_mouse_ = drag_mouse;
    view_drag_mouse_valid_ = true;
    return;
  }
  if (!is_view_scroll_drag_active()) {
    view_drag_mouse_valid_ = false;
    view_drag_mouse_was_usable_ = false;
  }
}

void TimelineView::update_pan_scroll_from_drag_mouse() {
  if (!panning_) {
    return;
  }

  if (!view_drag_left_button_held()) {
    // Keep panning_ true until handle_plot_input() handles the release (click vs drag).
    return;
  }

  refresh_view_drag_mouse();
  const ImVec2 mouse = mouse_pos_for_view_drag();
  if (!mouse_pos_usable(mouse) || mouse_over_sticky_popup(mouse)) {
    view_drag_mouse_was_usable_ = false;
    return;
  }

  if (!view_drag_mouse_was_usable_) {
    pan_anchor_mouse_ = mouse;
    pan_anchor_time_scroll_ = state_.view_scroll_time;
    pan_anchor_row_scroll_ = state_.view_scroll_row;
  }
  view_drag_mouse_was_usable_ = true;

  const float dx = mouse.x - pan_anchor_mouse_.x;
  const float dy = mouse.y - pan_anchor_mouse_.y;
  state_.view_scroll_time =
      pan_anchor_time_scroll_ - static_cast<double>(dx) / state_.cycle_width;
  state_.view_scroll_row =
      pan_anchor_row_scroll_ - static_cast<double>(dy) / state_.row_height;
  notify_view_scroll_row_changed();
  needs_refresh_ = true;
}

void TimelineView::update_view_drag_tracking() {
  const bool active = is_view_scroll_drag_active();
  if (active && !view_drag_tracking_) {
    view_drag_tracking_ = true;
    view_drag_anchor_scroll_row_ = state_.view_scroll_row;
    view_drag_anchor_scroll_time_ = state_.view_scroll_time;
    if (plot_layout_valid_) {
      const ImVec2 mouse = mouse_pos_for_view_drag();
      const ImVec2 grid_max(grid_origin_.x + grid_size_.x, grid_origin_.y + grid_size_.y);
      if (mouse_in_rect(mouse, grid_origin_, grid_max)) {
        view_drag_anchor_cell_ =
            grid_cell_at(mouse, grid_origin_, plot_cycle_width_, plot_row_height_).value();
      } else {
        view_drag_anchor_cell_.cycle =
            state_.has_crosshair
                ? state_.crosshair.cycle
                : static_cast<Timestamp>(std::floor(state_.view_scroll_time));
        view_drag_anchor_cell_.row =
            state_.has_crosshair
                ? state_.crosshair.row
                : static_cast<std::int64_t>(std::floor(state_.view_scroll_row));
      }
    }
  } else if (!active && view_drag_tracking_) {
    view_drag_tracking_ = false;
  }
}

std::optional<GridPosition> TimelineView::view_drag_cursor_cell() const {
  if (!plot_layout_valid_ || !is_view_scroll_drag_active()) {
    return std::nullopt;
  }

  if (view_drag_tracking_) {
    const std::int64_t row_scroll_delta = static_cast<std::int64_t>(std::floor(
        state_.view_scroll_row - view_drag_anchor_scroll_row_));
    const Timestamp time_scroll_delta = static_cast<Timestamp>(std::floor(
        state_.view_scroll_time - view_drag_anchor_scroll_time_));
    GridPosition cell = view_drag_anchor_cell_;
    cell.cycle = view_drag_anchor_cell_.cycle + time_scroll_delta;
    cell.row = view_drag_anchor_cell_.row + row_scroll_delta;
    return cell;
  }

  if (state_.has_crosshair) {
    return state_.crosshair;
  }

  GridPosition cell;
  cell.cycle = static_cast<Timestamp>(std::floor(state_.view_scroll_time));
  cell.row = static_cast<std::int64_t>(std::floor(state_.view_scroll_row));
  return cell;
}

void TimelineView::set_view_drag_input_blocked(const bool blocked) {
  view_drag_input_blocked_ = blocked;
}

void TimelineView::apply_view_scroll_drag_if_active() {
  if (!plot_layout_valid_) {
    return;
  }

  refresh_view_drag_mouse();
  const ImVec2 mouse = mouse_pos_for_view_drag();

  if (row_scrollbar_dragging_) {
    const float row_scrollbar_width = row_scrollbar_width_;
    if (row_scrollbar_width <= 0.0f) {
      row_scrollbar_dragging_ = false;
      return;
    }

    const float body_top = row_panel_origin_.y + plot_header_height_;
    const ImVec2 row_panel_max(row_panel_origin_.x + row_panel_width_,
                               row_panel_origin_.y + plot_header_height_ + grid_size_.y);
    const ImVec2 scrollbar_track_min(row_scrollbar_origin_.x, body_top);
    const double total_rows = std::max(1.0, static_cast<double>(meta_.object_count));
    const double max_scroll =
        std::max(0.0, total_rows - static_cast<double>(state_.visible_rows));
    const float track_height = row_panel_max.y - body_top;
    const float thumb_height =
        max_scroll > 0.0
            ? std::max(16.0f, track_height * static_cast<float>(
                                     static_cast<double>(state_.visible_rows) / total_rows))
            : track_height;
    const float thumb_travel = std::max(1.0f, track_height - thumb_height);

    if (view_drag_left_button_held()) {
      const float thumb_y =
          std::clamp(mouse.y - row_scrollbar_drag_anchor_, scrollbar_track_min.y,
                     scrollbar_track_min.y + thumb_travel);
      const float ratio = (thumb_y - scrollbar_track_min.y) / thumb_travel;
      state_.view_scroll_row = static_cast<double>(ratio) * max_scroll;
      needs_refresh_ = true;
      notify_view_scroll_row_changed();
    } else {
      row_scrollbar_dragging_ = false;
      view_drag_mouse_valid_ = false;
      needs_refresh_ = true;
    }
  }
}

void TimelineView::set_crosshair_silent(const GridPosition& cell,
                                        const std::optional<bool> highlight_cycle) {
  const bool same_cell = state_.has_crosshair && state_.crosshair.row == cell.row &&
                         state_.crosshair.cycle == cell.cycle;
  if (same_cell) {
    if (highlight_cycle.has_value()) {
      state_.crosshair_cycle_highlight = highlight_cycle.value();
    }
    return;
  }

  if (is_view_scroll_drag_active()) {
    return;
  }

  suppress_crosshair_callback_ = true;
  select_grid_cell(cell, false);
  if (highlight_cycle.has_value()) {
    state_.crosshair_cycle_highlight = highlight_cycle.value();
  }
  suppress_crosshair_callback_ = false;
}

void TimelineView::set_sync_partner_highlight(const std::optional<GridPosition>& cell) {
  sync_partner_highlight_cell_ = cell;
}

void TimelineView::clear_sync_partner_highlight() {
  sync_partner_highlight_cell_.reset();
}

void TimelineView::draw_sync_partner_cell_highlight(ImDrawList* draw_list) const {
  if (!sync_partner_highlight_cell_.has_value() || !plot_layout_valid_) {
    return;
  }

  const GridPosition& cell = sync_partner_highlight_cell_.value();
  const float x = cycle_x(grid_origin_, state_.view_scroll_time, plot_cycle_width_, cell.cycle);
  const float y = grid_origin_.y +
                  static_cast<float>(static_cast<double>(cell.row) - state_.view_scroll_row) *
                      plot_row_height_;
  const ImVec2 grid_max(grid_origin_.x + grid_size_.x, grid_origin_.y + grid_size_.y);
  const ImVec2 cell_min(std::max(x, grid_origin_.x), y);
  const ImVec2 cell_max(std::min(x + plot_cycle_width_, grid_max.x), y + plot_row_height_);
  if (cell_max.x <= cell_min.x || cell_max.y <= grid_origin_.y || y > grid_max.y) {
    return;
  }

  const float t = static_cast<float>(ImGui::GetTime());
  const float pulse_fast = 0.5f + 0.5f * std::sin(t * 8.0f);
  const float pulse_slow = 0.5f + 0.5f * std::sin(t * 3.2f);
  const float shimmer = 0.5f + 0.5f * std::sin(t * 11.0f + 1.4f);

  const ImVec2 center((cell_min.x + cell_max.x) * 0.5f, (cell_min.y + cell_max.y) * 0.5f);
  const float cell_w = cell_max.x - cell_min.x;
  const float cell_h = cell_max.y - cell_min.y;
  const float base_radius = std::max(cell_w, cell_h) * 0.72f;

  const ImU32 fill_cyan = IM_COL32(0, 210, 255, static_cast<int>(55 + 45 * pulse_slow));
  const ImU32 fill_magenta = IM_COL32(255, 30, 180, static_cast<int>(40 + 35 * pulse_fast));
  draw_list->AddRectFilledMultiColor(cell_min, cell_max, fill_cyan, fill_magenta, fill_magenta,
                                     fill_cyan);

  const ImU32 border_cyan = IM_COL32(0, 255, 255, static_cast<int>(140 + 90 * pulse_fast));
  const ImU32 border_gold = IM_COL32(255, 210, 40, static_cast<int>(120 + 80 * shimmer));
  draw_list->AddRect(cell_min, cell_max, border_cyan, 0.0f, 0, 3.0f);
  draw_list->AddRect(ImVec2(cell_min.x + 2.0f, cell_min.y + 2.0f),
                     ImVec2(cell_max.x - 2.0f, cell_max.y - 2.0f), border_gold, 0.0f, 0, 1.5f);

  const float cross_extent = base_radius * 1.5f;
  const ImU32 cross_color = IM_COL32(255, 230, 80, static_cast<int>(100 + 70 * pulse_fast));
  draw_list->AddLine(ImVec2(center.x - cross_extent, center.y),
                     ImVec2(center.x + cross_extent, center.y), cross_color, 2.0f);
  draw_list->AddLine(ImVec2(center.x, center.y - cross_extent),
                     ImVec2(center.x, center.y + cross_extent), cross_color, 2.0f);

  for (int i = 4; i >= 0; --i) {
    const float glow_r = base_radius * (2.1f + static_cast<float>(i) * 0.28f);
    const int glow_alpha = static_cast<int>((10 + 14 * pulse_slow) * (5 - i) / 5);
    draw_list->AddCircleFilled(center, glow_r, IM_COL32(0, 220, 255, glow_alpha), 56);
  }

  struct RingSpec {
    float scale;
    float phase;
    float thickness;
    int r;
    int g;
    int b;
  };
  const RingSpec rings[] = {
      {2.05f, 0.0f, 3.5f, 255, 190, 0},
      {1.55f, 1.1f, 3.0f, 255, 50, 210},
      {1.05f, 2.3f, 2.5f, 0, 255, 255},
      {0.55f, 3.5f, 2.0f, 255, 255, 255},
  };
  for (const RingSpec& ring : rings) {
    const float ring_pulse = 0.3f + 0.7f * std::sin(t * 6.5f + ring.phase);
    const float radius = base_radius * ring.scale * (0.88f + 0.12f * ring_pulse);
    const int alpha = static_cast<int>((50 + 140 * ring_pulse) * (0.65f + 0.35f * shimmer));
    draw_list->AddCircle(center, radius, IM_COL32(ring.r, ring.g, ring.b, alpha), 0, ring.thickness);
  }

  const float dot_r = base_radius * 0.22f * (0.8f + 0.2f * pulse_fast);
  draw_list->AddCircleFilled(center, dot_r * 2.2f,
                             IM_COL32(255, 200, 0, static_cast<int>(60 + 50 * pulse_fast)), 28);
  draw_list->AddCircleFilled(center, dot_r,
                             IM_COL32(255, 255, 255, static_cast<int>(210 + 45 * shimmer)), 20);
}

void TimelineView::draw_sync_partner_highlight_overlay() {
  if (!plot_layout_valid_) {
    return;
  }
  draw_sync_partner_cell_highlight(ImGui::GetForegroundDrawList());
}

void TimelineView::ensure_row_visible(const std::int64_t row) {
  if (row < static_cast<std::int64_t>(std::floor(state_.view_scroll_row))) {
    state_.view_scroll_row = static_cast<double>(row);
    needs_refresh_ = true;
    return;
  }

  const double visible_end = state_.view_scroll_row + static_cast<double>(state_.visible_rows);
  if (row >= static_cast<std::int64_t>(std::ceil(visible_end))) {
    state_.view_scroll_row =
        static_cast<double>(row) - static_cast<double>(state_.visible_rows) + 1.0;
    state_.view_scroll_row = std::max(0.0, state_.view_scroll_row);
    needs_refresh_ = true;
  }
}

void TimelineView::navigate_to_object_event_boundary(const bool to_first) {
  if (!store_) {
    return;
  }

  const std::optional<ObjectId> object_id = active_object_id();
  if (!object_id.has_value()) {
    return;
  }

  const std::optional<TraceObject> object = store_->find_object(object_id.value());
  if (!object.has_value()) {
    return;
  }

  GridPosition cell;
  const std::optional<std::int64_t> row =
      store_->object_row_index(object->id, active_sort_scheme());
  if (!row.has_value()) {
    return;
  }
  cell.row = *row;
  cell.cycle = to_first ? object->first_time : object->last_time;
  navigate_to_grid_cell(cell);
}

std::optional<ObjectId> TimelineView::active_object_id() const {
  if (state_.has_selection) {
    return state_.selected_object;
  }
  if (state_.has_crosshair) {
    const auto row_it = object_id_by_row_.find(state_.crosshair.row);
    if (row_it != object_id_by_row_.end()) {
      return row_it->second;
    }
  }
  return std::nullopt;
}

std::vector<CellEventInfo> TimelineView::cell_events_at(const GridPosition& cell) const {
  std::vector<CellEventInfo> result;
  std::unordered_map<ObjectId, std::int32_t> row_by_object;
  row_by_object.reserve(cached_objects_.ids.size());
  for (std::size_t i = 0; i < cached_objects_.ids.size(); ++i) {
    row_by_object[cached_objects_.ids[i]] = cached_objects_.row_indices[i];
  }

  for (std::size_t i = 0; i < cached_events_.object_ids.size(); ++i) {
    const auto row_it = row_by_object.find(cached_events_.object_ids[i]);
    if (row_it == row_by_object.end() || row_it->second != cell.row ||
        cached_events_.times[i] != cell.cycle) {
      continue;
    }

    CellEventInfo info;
    info.id = cached_events_.ids[i];
    info.event_type_id = cached_events_.event_type_ids[i];
    info.kind = cached_events_.kinds[i];
    info.display_char = cached_events_.display_chars[i];
    info.attributes = parse_object_attributes(cached_events_.attributes_json[i]);
    result.push_back(std::move(info));
  }

  std::sort(result.begin(), result.end(),
            [](const CellEventInfo& a, const CellEventInfo& b) {
              if (a.event_type_id != b.event_type_id) {
                return a.event_type_id < b.event_type_id;
              }
              return a.id < b.id;
            });
  return result;
}

void TimelineView::select_grid_cell(const GridPosition& cell, const bool notify_sync) {
  state_.selected_cell = cell;
  state_.has_selected_cell = true;
  state_.crosshair = cell;
  state_.has_crosshair = true;
  state_.crosshair_cycle_highlight = true;

  state_.has_selection = false;
  const auto row_it = object_id_by_row_.find(cell.row);
  if (row_it != object_id_by_row_.end()) {
    state_.selected_object = row_it->second;
    state_.has_selection = true;
  }

  state_.selected_cell_events = cell_events_at(cell);

  if (notify_sync && !suppress_crosshair_callback_ && crosshair_change_callback_) {
    crosshair_change_callback_(*this);
  }
}

void TimelineView::select_row(const std::int64_t row, const bool notify_sync) {
  GridPosition cell;
  cell.row = row;
  if (state_.has_crosshair) {
    cell.cycle = state_.crosshair.cycle;
  } else if (state_.has_selected_cell) {
    cell.cycle = state_.selected_cell.cycle;
  } else {
    cell.cycle = static_cast<Timestamp>(std::floor(state_.view_scroll_time));
  }
  select_grid_cell(cell, notify_sync);
}

void TimelineView::layout_sticky_popup(StickyEventPopup& popup) const {
  char header_label[48];
  std::snprintf(header_label, sizeof(header_label), "Cycle %lld, row %lld",
                static_cast<long long>(popup.cell.cycle),
                static_cast<long long>(popup.cell.row));

  const float line_h = ImGui::GetTextLineHeightWithSpacing();
  const float header_row_h = ImGui::GetFrameHeight();
  const float sep_gap = ImGui::GetStyle().ItemSpacing.y;
  const float body_top = kStickyPopupPad + header_row_h + sep_gap + 1.0f + sep_gap;

  float max_text_w = ImGui::CalcTextSize(header_label).x;
  float content_h = 0.0f;

  for (std::size_t i = 0; i < popup.events.size(); ++i) {
    const CellEventInfo& event = popup.events[i];
    if (i > 0) {
      content_h += line_h;
    }

    char event_line[128];
    std::snprintf(event_line, sizeof(event_line), "'%c' %s (id %lld)", event.display_char,
                  event.kind.c_str(), static_cast<long long>(event.id));
    max_text_w = std::max(max_text_w, ImGui::CalcTextSize(event_line).x);
    content_h += line_h;

    if (event.attributes.empty()) {
      max_text_w = std::max(max_text_w, ImGui::CalcTextSize("(no attributes)").x);
      content_h += line_h;
      continue;
    }

    for (const auto& [key, value] : event.attributes) {
      char attr_line[256];
      std::snprintf(attr_line, sizeof(attr_line), "%s: %s", key.c_str(), value.c_str());
      max_text_w = std::max(max_text_w, ImGui::CalcTextSize(attr_line).x);
      content_h += line_h;
    }
  }

  popup.content_height = content_h;
  popup.size.x = std::clamp(max_text_w + 2.0f * kStickyPopupPad + header_row_h + 8.0f,
                            kStickyPopupMinWidth, kStickyPopupMaxWidth);
  const float natural_h = body_top + content_h + kStickyPopupPad;
  popup.size.y = std::min(natural_h, kStickyPopupMaxHeight);

  const StickyPopupLayout layout = sticky_popup_layout(popup);
  clamp_sticky_popup_scroll(popup, layout);
}

void TimelineView::pin_hover_popup() {
  if (!state_.has_hover_cell || state_.hover_cell_events.empty()) {
    return;
  }

  for (StickyEventPopup& popup : sticky_event_popups_) {
    if (popup.cell.cycle == state_.hover_cell.cycle && popup.cell.row == state_.hover_cell.row) {
      popup.events = state_.hover_cell_events;
      layout_sticky_popup(popup);
      return;
    }
  }

  StickyEventPopup popup;
  popup.id = next_sticky_popup_id_++;
  popup.cell = state_.hover_cell;
  popup.position = state_.hover_popup_anchor;
  popup.events = state_.hover_cell_events;
  layout_sticky_popup(popup);
  clamp_sticky_popup_position(popup);
  sticky_event_popups_.push_back(std::move(popup));
}

ImVec2 TimelineView::grid_cell_screen_center(const GridPosition& cell) const {
  const float x =
      cycle_x(grid_origin_, state_.view_scroll_time, plot_cycle_width_, cell.cycle);
  const float y = grid_origin_.y +
                  static_cast<float>(static_cast<double>(cell.row) - state_.view_scroll_row) *
                      plot_row_height_;
  return ImVec2(x + plot_cycle_width_ * 0.5f, y + plot_row_height_ * 0.5f);
}

void TimelineView::draw_sticky_cell_connector(ImDrawList* draw_list,
                                              const StickyEventPopup& popup) const {
  if (!plot_layout_valid_ || popup.size.x <= 0.0f || popup.size.y <= 0.0f) {
    return;
  }

  const ImVec2 cell_center = grid_cell_screen_center(popup.cell);
  const ImVec2 popup_min = sticky_popup_min(popup);
  const ImVec2 popup_max = sticky_popup_max(popup);
  const ImVec2 popup_anchor = nearest_rect_point(cell_center, popup_min, popup_max);
  draw_list->AddLine(cell_center, popup_anchor, imgui_color_u32(ImGuiCol_PlotLines, 0.75f), 2.0f);
}

void TimelineView::draw_sticky_popup_overlay(ImDrawList* draw_list,
                                             const StickyEventPopup& popup) const {
  if (popup.size.x <= 0.0f || popup.size.y <= 0.0f) {
    return;
  }

  const StickyPopupLayout layout = sticky_popup_layout(popup);
  const ImVec2 min = sticky_popup_min(popup);
  const ImVec2 max = sticky_popup_max(popup);
  const ScreenRect drag_rect = sticky_popup_drag_rect(popup, layout);
  const ScreenRect close_rect = sticky_popup_close_rect(popup, layout);
  const ScreenRect body_rect = sticky_popup_body_rect(popup, layout);
  const ImVec2 mouse = ImGui::GetIO().MousePos;

  draw_list->AddRectFilled(min, max, imgui_color_u32(ImGuiCol_WindowBg, 0.96f), 4.0f);
  draw_list->AddRect(min, max, imgui_color_u32(ImGuiCol_Border), 4.0f);

  const ImU32 header_color =
      mouse_in_rect(mouse, drag_rect.min, drag_rect.max)
          ? imgui_color_u32(ImGuiCol_HeaderHovered)
          : imgui_color_u32(ImGuiCol_Header);
  draw_list->AddRectFilled(drag_rect.min, drag_rect.max, header_color, 2.0f);

  char header_label[48];
  std::snprintf(header_label, sizeof(header_label), "Cycle %lld, row %lld",
                static_cast<long long>(popup.cell.cycle),
                static_cast<long long>(popup.cell.row));
  const ImVec2 header_text_size = ImGui::CalcTextSize(header_label);
  draw_list->AddText(
      ImGui::GetFont(), ImGui::GetFontSize(),
      ImVec2(drag_rect.min.x + 4.0f,
             drag_rect.min.y + (drag_rect.GetHeight() - header_text_size.y) * 0.5f),
      imgui_color_u32(ImGuiCol_Text), header_label);

  const ImU32 close_color =
      mouse_in_rect(mouse, close_rect.min, close_rect.max)
          ? imgui_color_u32(ImGuiCol_ButtonHovered)
          : imgui_color_u32(ImGuiCol_Header);
  draw_list->AddRectFilled(close_rect.min, close_rect.max, close_color, 2.0f);
  const ImVec2 close_text_size = ImGui::CalcTextSize("X");
  draw_list->AddText(
      ImGui::GetFont(), ImGui::GetFontSize(),
      ImVec2(close_rect.min.x + (close_rect.GetWidth() - close_text_size.x) * 0.5f,
             close_rect.min.y + (close_rect.GetHeight() - close_text_size.y) * 0.5f),
      imgui_color_u32(ImGuiCol_Text), "X");

  const float sep_gap = ImGui::GetStyle().ItemSpacing.y;
  const float sep_y = popup.position.y + layout.body_top - sep_gap;
  draw_list->AddLine(ImVec2(min.x + kStickyPopupPad, sep_y),
                     ImVec2(max.x - kStickyPopupPad, sep_y), imgui_color_u32(ImGuiCol_Separator));

  draw_list->PushClipRect(body_rect.min, body_rect.max, true);
  draw_sticky_popup_lines(draw_list, popup, layout, body_rect);
  draw_list->PopClipRect();

  if (layout.max_scroll > 0.5f) {
    const float track_x = max.x - 3.0f;
    const float track_h = body_rect.GetHeight();
    const float thumb_h =
        std::max(16.0f, track_h * (layout.body_height / std::max(popup.content_height, 1.0f)));
    const float thumb_travel = std::max(1.0f, track_h - thumb_h);
    const float thumb_y =
        body_rect.min.y + (popup.scroll_y / layout.max_scroll) * thumb_travel;
    draw_list->AddRectFilled(ImVec2(track_x - 2.0f, body_rect.min.y),
                             ImVec2(track_x + 2.0f, body_rect.max.y),
                             imgui_color_u32(ImGuiCol_ScrollbarBg));
    draw_list->AddRectFilled(ImVec2(track_x - 2.0f, thumb_y),
                             ImVec2(track_x + 2.0f, thumb_y + thumb_h),
                             imgui_color_u32(ImGuiCol_ScrollbarGrab));
  }
}

void TimelineView::handle_sticky_popups_input() {
  ImGuiIO& io = ImGui::GetIO();
  const ImVec2 mouse = io.MousePos;

  if (dragging_sticky_id_.has_value()) {
    for (StickyEventPopup& popup : sticky_event_popups_) {
      if (popup.id != dragging_sticky_id_.value()) {
        continue;
      }
      if (io.MouseDown[ImGuiMouseButton_Left]) {
        popup.position =
            ImVec2(mouse.x - sticky_drag_anchor_.x, mouse.y - sticky_drag_anchor_.y);
        clamp_sticky_popup_position(popup);
      } else {
        dragging_sticky_id_.reset();
      }
      return;
    }
    dragging_sticky_id_.reset();
  }

  for (StickyEventPopup& popup : sticky_event_popups_) {
    const StickyPopupLayout layout = sticky_popup_layout(popup);
    const ScreenRect body_rect = sticky_popup_body_rect(popup, layout);
    if (layout.max_scroll > 0.0f && mouse_in_rect(mouse, body_rect.min, body_rect.max) &&
        io.MouseWheel != 0.0f) {
      popup.scroll_y -= io.MouseWheel * ImGui::GetTextLineHeightWithSpacing() * 3.0f;
      clamp_sticky_popup_scroll(popup, layout);
      return;
    }
  }

  if (!ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
    return;
  }

  for (std::size_t index = sticky_event_popups_.size(); index > 0; --index) {
    StickyEventPopup& popup = sticky_event_popups_[index - 1];
    const StickyPopupLayout layout = sticky_popup_layout(popup);
    const ScreenRect close_rect = sticky_popup_close_rect(popup, layout);
    if (mouse_in_rect(mouse, close_rect.min, close_rect.max)) {
      sticky_event_popups_.erase(sticky_event_popups_.begin() +
                                 static_cast<std::ptrdiff_t>(index - 1));
      dragging_sticky_id_.reset();
      return;
    }

    const ScreenRect drag_rect = sticky_popup_drag_rect(popup, layout);
    if (mouse_in_rect(mouse, drag_rect.min, drag_rect.max)) {
      dragging_sticky_id_ = popup.id;
      sticky_drag_anchor_ = ImVec2(mouse.x - popup.position.x, mouse.y - popup.position.y);
      return;
    }
  }
}

bool TimelineView::mouse_over_sticky_popup(const ImVec2& mouse) const {
  for (const StickyEventPopup& popup : sticky_event_popups_) {
    if (popup.size.x <= 0.0f || popup.size.y <= 0.0f) {
      continue;
    }
    const ImVec2 max = sticky_popup_max(popup);
    if (mouse_in_rect(mouse, popup.position, max)) {
      return true;
    }
  }
  return false;
}

void TimelineView::draw_event_popups() {
  ImDrawList* draw_list = ImGui::GetForegroundDrawList();
  for (const StickyEventPopup& popup : sticky_event_popups_) {
    draw_sticky_cell_connector(draw_list, popup);
  }
  for (const StickyEventPopup& popup : sticky_event_popups_) {
    draw_sticky_popup_overlay(draw_list, popup);
  }

  if (!state_.has_hover_cell || state_.hover_cell_events.empty() ||
      mouse_over_sticky_popup(ImGui::GetIO().MousePos) || dragging_sticky_id_.has_value()) {
    return;
  }

  ImGui::SetNextWindowPos(state_.hover_popup_anchor, ImGuiCond_Always, ImVec2(0.0f, 0.0f));
  ImGui::SetNextWindowBgAlpha(0.96f);
  ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(8.0f, 8.0f));
  if (ImGui::Begin("##event_hover_popup", nullptr,
                   ImGuiWindowFlags_Tooltip | ImGuiWindowFlags_NoDecoration |
                       ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings |
                       ImGuiWindowFlags_NoFocusOnAppearing | ImGuiWindowFlags_NoNav)) {
    ImGui::Text("Events in cell");
    ImGui::Separator();
    for (std::size_t i = 0; i < state_.hover_cell_events.size(); ++i) {
      const CellEventInfo& event = state_.hover_cell_events[i];
      if (i > 0) {
        ImGui::Separator();
      }
      ImGui::Text("'%c' %s (id %lld)", event.display_char, event.kind.c_str(),
                  static_cast<long long>(event.id));
      if (event.attributes.empty()) {
        ImGui::TextDisabled("(no attributes)");
      } else {
        for (const auto& [key, value] : event.attributes) {
          ImGui::Text("%s: %s", key.c_str(), value.c_str());
        }
      }
    }
    ImGui::Separator();
    ImGui::TextDisabled("Press X to pin");
    ImGui::End();
  }
  ImGui::PopStyleVar();
}

void TimelineView::draw_row_scrollbar(ImDrawList* draw_list, const ImVec2& origin, float width,
                                      float header_height, float body_height,
                                      const ViewerTheme& theme) {
  if (width <= 0.0f || body_height <= 0.0f) {
    return;
  }

  const ImVec2 track_min(origin.x, origin.y + header_height);
  const ImVec2 track_max(origin.x + width, origin.y + header_height + body_height);
  draw_list->AddRectFilled(origin, ImVec2(track_max.x, origin.y + header_height),
                           theme.row_panel_header_background);
  draw_list->AddRectFilled(track_min, track_max, imgui_color_u32(ImGuiCol_ScrollbarBg));
  draw_list->AddLine(ImVec2(track_max.x, origin.y), ImVec2(track_max.x, track_max.y),
                     theme.row_panel_border);

  const double total_rows = std::max(1.0, static_cast<double>(meta_.object_count));
  const double max_scroll = std::max(0.0, total_rows - static_cast<double>(state_.visible_rows));
  const float track_height = track_max.y - track_min.y;
  const float thumb_height =
      max_scroll > 0.0
          ? std::max(16.0f, track_height * static_cast<float>(
                                   static_cast<double>(state_.visible_rows) / total_rows))
          : track_height;
  const float thumb_travel = std::max(1.0f, track_height - thumb_height);
  const float scroll_ratio =
      max_scroll > 0.0 ? static_cast<float>(state_.view_scroll_row / max_scroll) : 0.0f;
  const float thumb_y = track_min.y + scroll_ratio * thumb_travel;
  const ImVec2 thumb_min(track_min.x + 2.0f, thumb_y);
  const ImVec2 thumb_max(track_max.x - 2.0f, thumb_y + thumb_height);

  const ImVec2 mouse = ImGui::GetIO().MousePos;
  const bool hovered = mouse_in_rect(mouse, track_min, track_max);
  const ImU32 thumb_color =
      row_scrollbar_dragging_ || hovered ? imgui_color_u32(ImGuiCol_ScrollbarGrabHovered)
                                         : imgui_color_u32(ImGuiCol_ScrollbarGrab);
  draw_list->AddRectFilled(thumb_min, thumb_max, thumb_color, 2.0f);
}

void TimelineView::handle_row_scroll_in_draw(const bool grid_wheel_scroll) {
  row_wheel_this_frame_ = false;

  const float row_scrollbar_width = row_scrollbar_width_;
  if (row_scrollbar_width <= 0.0f && row_panel_width_ <= 0.0f) {
    return;
  }

  const ImVec2 mouse = ImGui::GetIO().MousePos;
  const float body_top = row_panel_origin_.y + plot_header_height_;
  const ImVec2 row_panel_max(row_panel_origin_.x + row_panel_width_,
                             row_panel_origin_.y + plot_header_height_ + grid_size_.y);
  const ImVec2 scrollbar_max(row_scrollbar_origin_.x + row_scrollbar_width, row_panel_max.y);
  const ImVec2 scrollbar_track_min(row_scrollbar_origin_.x, body_top);
  const bool over_row_panel =
      row_panel_width_ > 0.0f && mouse_in_rect(mouse, row_panel_origin_, row_panel_max) &&
      mouse.y >= body_top;
  const bool over_scrollbar =
      row_scrollbar_width > 0.0f &&
      mouse_in_rect(mouse, row_scrollbar_origin_, scrollbar_max) && mouse.y >= body_top;

  const double total_rows = std::max(1.0, static_cast<double>(meta_.object_count));
  const double max_scroll = std::max(0.0, total_rows - static_cast<double>(state_.visible_rows));

  if (over_scrollbar || row_scrollbar_dragging_) {
    const float track_height = row_panel_max.y - body_top;
    const float thumb_height =
        max_scroll > 0.0
            ? std::max(16.0f, track_height * static_cast<float>(
                                     static_cast<double>(state_.visible_rows) / total_rows))
            : track_height;
    const float thumb_travel = std::max(1.0f, track_height - thumb_height);

    if (ImGui::IsMouseClicked(ImGuiMouseButton_Left) && over_scrollbar && !view_drag_input_blocked_) {
      if (max_scroll > 0.0) {
        row_scrollbar_dragging_ = true;
        row_scrollbar_drag_anchor_ = mouse.y - scrollbar_track_min.y -
                                     static_cast<float>(state_.view_scroll_row / max_scroll) *
                                         thumb_travel;
      }
    }

    if (row_scrollbar_dragging_) {
      if (view_drag_left_button_held()) {
        const float thumb_y =
            std::clamp(mouse.y - row_scrollbar_drag_anchor_, scrollbar_track_min.y,
                       scrollbar_track_min.y + thumb_travel);
        const float ratio = (thumb_y - scrollbar_track_min.y) / thumb_travel;
        state_.view_scroll_row = static_cast<double>(ratio) * max_scroll;
        needs_refresh_ = true;
        notify_view_scroll_row_changed();
      } else {
        row_scrollbar_dragging_ = false;
        needs_refresh_ = true;
      }
    } else if (ImGui::IsMouseClicked(ImGuiMouseButton_Left) && over_scrollbar &&
               !view_drag_input_blocked_) {
      const float ratio =
          std::clamp((mouse.y - scrollbar_track_min.y) / std::max(1.0f, track_height), 0.0f, 1.0f);
      state_.view_scroll_row = static_cast<double>(ratio) * max_scroll;
      needs_refresh_ = true;
      notify_view_scroll_row_changed();
    }
  } else if (!view_drag_left_button_held()) {
    row_scrollbar_dragging_ = false;
  }

  const bool wheel_scroll_target =
      (over_row_panel || over_scrollbar || grid_wheel_scroll) && !row_scrollbar_dragging_;
  if (wheel_scroll_target && ImGui::GetIO().MouseWheel != 0.0f &&
      !(grid_wheel_scroll && ImGui::GetIO().KeyCtrl)) {
    state_.view_scroll_row -= static_cast<double>(ImGui::GetIO().MouseWheel) * 3.0;
    state_.view_scroll_row = std::clamp(state_.view_scroll_row, 0.0, max_scroll);
    row_wheel_this_frame_ = true;
    needs_refresh_ = true;
    notify_view_scroll_row_changed();
  }
}

void TimelineView::handle_row_panel_header_input() {
  if (!plot_layout_valid_ || !has_row_panel() || row_scrollbar_dragging_) {
    return;
  }

  const ImVec2 mouse = ImGui::GetIO().MousePos;
  const float header_bottom = row_panel_origin_.y + plot_header_height_;
  const ImVec2 header_max(row_panel_origin_.x + row_panel_width_, header_bottom);
  const bool over_header =
      row_panel_width_ > 0.0f && mouse_in_rect(mouse, row_panel_origin_, header_max);
  if (!over_header || !ImGui::IsMouseDoubleClicked(ImGuiMouseButton_Left)) {
    return;
  }

  float column_x = row_panel_origin_.x;
  for (const PinnedRowAttribute& column : pinned_row_columns_) {
    if (mouse.x >= column_x && mouse.x < column_x + column.width_px) {
      std::optional<ObjectId> anchor_object_id;
      Timestamp anchor_cycle{};
      if (state_.has_crosshair) {
        anchor_cycle = state_.crosshair.cycle;
        anchor_object_id = crosshair_object_id();
      }
      row_sort_state().apply_header_double_click(column.key);
      invalidate_sort_cache();
      reanchor_view_after_sort_change(anchor_object_id, anchor_cycle);
      notify_sort_changed();
      break;
    }
    column_x += column.width_px;
  }
}

std::optional<ObjectId> TimelineView::crosshair_object_id() const {
  if (!state_.has_crosshair) {
    return std::nullopt;
  }
  if (state_.has_selection) {
    return state_.selected_object;
  }
  if (store_) {
    if (const std::optional<ObjectId> object_id =
            store_->object_id_for_row(state_.crosshair.row, active_sort_scheme())) {
      return object_id;
    }
  }
  const auto row_it = object_id_by_row_.find(state_.crosshair.row);
  if (row_it != object_id_by_row_.end()) {
    return row_it->second;
  }
  return std::nullopt;
}

void TimelineView::reanchor_view_after_sort_change(const std::optional<ObjectId>& anchor_object_id,
                                                   const Timestamp anchor_cycle) {
  if (!store_ || !state_.has_crosshair || !anchor_object_id.has_value()) {
    return;
  }

  const std::optional<std::int64_t> new_row =
      store_->object_row_index(*anchor_object_id, active_sort_scheme());
  if (!new_row.has_value()) {
    return;
  }

  GridPosition cell;
  cell.cycle = anchor_cycle;
  cell.row = *new_row;
  suppress_crosshair_callback_ = true;
  suppress_scroll_row_callback_ = true;
  select_grid_cell(cell, false);
  const double total_rows = std::max(1.0, static_cast<double>(meta_.object_count));
  const double max_scroll = std::max(0.0, total_rows - static_cast<double>(state_.visible_rows));
  state_.view_scroll_row =
      static_cast<double>(*new_row) - static_cast<double>(state_.visible_rows) * 0.5;
  state_.view_scroll_row = std::clamp(state_.view_scroll_row, 0.0, max_scroll);
  needs_refresh_ = true;
  suppress_scroll_row_callback_ = false;
  suppress_crosshair_callback_ = false;
}

void TimelineView::notify_sort_changed() {
  if (sort_change_callback_) {
    sort_change_callback_(*this);
  }
}

void TimelineView::handle_row_axis_input() {
  if (!plot_layout_valid_) {
    return;
  }

  const ImVec2 mouse = ImGui::GetIO().MousePos;
  const float body_top = row_panel_origin_.y + plot_header_height_;
  const ImVec2 row_panel_max(row_panel_origin_.x + row_panel_width_,
                             row_panel_origin_.y + plot_header_height_ + grid_size_.y);
  const bool over_row_panel =
      row_panel_width_ > 0.0f && mouse_in_rect(mouse, row_panel_origin_, row_panel_max) &&
      mouse.y >= body_top;

  if (over_row_panel && ImGui::IsMouseClicked(ImGuiMouseButton_Left) && !row_scrollbar_dragging_) {
    row_panel_selecting_ = true;
    row_panel_select_anchor_ = mouse;
  }

  if (over_row_panel && ImGui::IsMouseReleased(ImGuiMouseButton_Left) && row_panel_selecting_) {
    const float dx = mouse.x - row_panel_select_anchor_.x;
    const float dy = mouse.y - row_panel_select_anchor_.y;
    if (dx * dx + dy * dy < 25.0f) {
      const std::int64_t row = static_cast<std::int64_t>(std::floor(
          state_.view_scroll_row +
          static_cast<double>((mouse.y - body_top) / plot_row_height_)));
      if (row >= 0 && row < meta_.object_count) {
        select_row(row);
      }
    }
    row_panel_selecting_ = false;
  } else if (!ImGui::IsMouseDown(ImGuiMouseButton_Left)) {
    row_panel_selecting_ = false;
  }
}

void TimelineView::update_search_match() {
  if (!store_ || app_config_.search_attributes.empty()) {
    search_.match_row.reset();
    return;
  }

  if (search_.field_index >= app_config_.search_attributes.size()) {
    search_.field_index = 0;
  }

  if (search_.query.empty()) {
    search_.match_row.reset();
    return;
  }

  const std::string& key = app_config_.search_attributes[search_.field_index];
  const std::optional<AttributeSearchMatch> match =
      store_->find_first_object_by_attribute(key, search_.query, active_sort_scheme());
  if (!match.has_value()) {
    search_.match_row.reset();
    return;
  }

  search_.match_row = match->row_index;
  search_.highlight_start_time = ImGui::GetTime();
  {
    const double total_rows = std::max(1.0, static_cast<double>(meta_.object_count));
    const double max_scroll =
        std::max(0.0, total_rows - static_cast<double>(state_.visible_rows));
    state_.view_scroll_row =
        static_cast<double>(match->row_index) - static_cast<double>(state_.visible_rows) * 0.5;
    state_.view_scroll_row = std::clamp(state_.view_scroll_row, 0.0, max_scroll);
    needs_refresh_ = true;
  }
  select_row(match->row_index);
}

void TimelineView::handle_search_input() {
  if (!input_focused_ || !store_ || app_config_.search_attributes.empty()) {
    return;
  }

  ImGuiIO& io = ImGui::GetIO();
  if (io.WantTextInput) {
    return;
  }

  const auto exit_search = [&]() {
    search_.active = false;
    search_.query.clear();
    search_.match_row.reset();
  };

  if (key_just_pressed(ImGuiKey_Escape)) {
    if (search_.active) {
      exit_search();
    }
    return;
  }

  if (search_.active &&
      (key_just_pressed(ImGuiKey_Enter) || key_just_pressed(ImGuiKey_KeypadEnter))) {
    exit_search();
    return;
  }

  if (key_just_pressed(ImGuiKey_Slash)) {
    if (!search_.active) {
      search_.active = true;
      search_.field_index = 0;
      search_.query.clear();
      search_.match_row.reset();
    } else {
      search_.field_index =
          (search_.field_index + 1) % app_config_.search_attributes.size();
      update_search_match();
    }
    return;
  }

  if (!search_.active) {
    return;
  }

  if (key_just_pressed(ImGuiKey_Backspace)) {
    if (!search_.query.empty()) {
      search_.query.pop_back();
      update_search_match();
    }
    return;
  }

  for (const ImWchar ch : io.InputQueueCharacters) {
    if (ch >= 32 && ch < 127 && ch != '/') {
      search_.query.push_back(static_cast<char>(ch));
      update_search_match();
    }
  }
}

void TimelineView::draw_search_row_highlight(ImDrawList* draw_list) const {
  if (!search_.match_row.has_value() || !plot_layout_valid_) {
    return;
  }

  const double elapsed = ImGui::GetTime() - search_.highlight_start_time;
  if (!search_.active && elapsed > 2.0) {
    return;
  }

  const float alpha_scale =
      search_.active ? 1.0f : static_cast<float>(std::max(0.0, 1.0 - elapsed / 2.0));
  const std::int64_t row = search_.match_row.value();
  const float row_height = plot_row_height_;
  const float y =
      grid_origin_.y +
      static_cast<float>(static_cast<double>(row) - state_.view_scroll_row) * row_height;
  const ImVec2 grid_max(grid_origin_.x + grid_size_.x, grid_origin_.y + grid_size_.y);
  if (y + row_height < grid_origin_.y || y > grid_max.y) {
    return;
  }

  const float left_x = row_scrollbar_width_ > 0.0f
                           ? row_scrollbar_origin_.x
                       : row_panel_width_ > 0.0f && has_row_panel() ? row_panel_origin_.x
                                                                    : grid_origin_.x;
  const ImVec2 band_min(left_x, y);
  const ImVec2 band_max(grid_max.x, y + row_height);
  const int alpha = static_cast<int>(90 * alpha_scale);
  draw_list->AddRectFilled(band_min, band_max, IM_COL32(255, 220, 60, alpha));
  draw_list->AddRect(band_min, band_max, IM_COL32(255, 200, 0, static_cast<int>(180 * alpha_scale)),
                     0.0f, 0, 2.0f);
}

void TimelineView::draw_search_overlay() {
  if (!search_.active || app_config_.search_attributes.empty()) {
    return;
  }

  if (search_.field_index >= app_config_.search_attributes.size()) {
    return;
  }

  const std::string& key = app_config_.search_attributes[search_.field_index];
  char label[256];
  std::snprintf(label, sizeof(label), "Search [%s]: %s|", key.c_str(), search_.query.c_str());

  ImDrawList* draw_list = ImGui::GetForegroundDrawList();
  const ImVec2 text_size = ImGui::CalcTextSize(label);
  const ImVec2 pad(8.0f, 4.0f);
  const ImVec2 pos(plot_origin_.x + 8.0f, plot_origin_.y + 8.0f);
  const ImVec2 rect_max(pos.x + text_size.x + pad.x * 2.0f, pos.y + text_size.y + pad.y * 2.0f);
  draw_list->AddRectFilled(pos, rect_max, IM_COL32(20, 20, 28, 220), 4.0f);
  draw_list->AddRect(pos, rect_max, IM_COL32(255, 200, 0, 200), 4.0f);
  draw_list->AddText(ImVec2(pos.x + pad.x, pos.y + pad.y), IM_COL32(255, 240, 200, 255), label);
}

void TimelineView::handle_plot_input() {
  handle_row_panel_header_input();
  handle_row_axis_input();
  handle_sticky_popups_input();

  if (!ImGui::GetIO().WantTextInput) {
    if (key_just_pressed(ImGuiKey_Home)) {
      navigate_to_object_event_boundary(true);
    } else if (key_just_pressed(ImGuiKey_End)) {
      navigate_to_object_event_boundary(false);
    }
  }

  if (!plot_layout_valid_) {
    return;
  }

  refresh_view_drag_mouse();

  const ImVec2 io_mouse = ImGui::GetIO().MousePos;
  const bool over_plot = mouse_in_rect(io_mouse, plot_origin_, plot_max_);
  const bool over_grid = over_plot && io_mouse.y >= grid_origin_.y;
  const bool over_sticky = mouse_over_sticky_popup(io_mouse);
  const bool scrollbar_drag_active = row_scrollbar_dragging_;

  if (panning_ && !view_drag_left_button_held()) {
    const ImVec2 mouse = mouse_pos_for_view_drag();
    const bool release_over_grid = mouse_pos_usable(io_mouse) &&
                                   mouse_in_rect(io_mouse, plot_origin_, plot_max_) &&
                                   io_mouse.y >= grid_origin_.y;
    if (!over_sticky && release_over_grid) {
      const float dx = mouse.x - pan_anchor_mouse_.x;
      const float dy = mouse.y - pan_anchor_mouse_.y;
      const float drag_dist_sq = dx * dx + dy * dy;
      if (drag_dist_sq < 25.0f) {
        if (const auto cell =
                grid_cell_at(mouse, grid_origin_, plot_cycle_width_, plot_row_height_)) {
          if (ImGui::GetIO().KeyCtrl) {
            pinned_markers_.push_back(*cell);
          }
          select_grid_cell(*cell);
        }
      }
    }
    panning_ = false;
    view_drag_mouse_valid_ = false;
    needs_refresh_ = true;
    if (plot_layout_valid_) {
      refresh_cache();
    }
    return;
  }

  if (panning_ || scrollbar_drag_active) {
    return;
  }

  if (over_sticky || !over_plot || dragging_sticky_id_.has_value()) {
    return;
  }

  plot_hovered_ = over_plot;

  if (!view_drag_input_blocked_ && mouse_left_button_clicked() &&
      (over_grid || io_mouse.x >= grid_origin_.x)) {
    panning_ = true;
    pan_anchor_mouse_ = mouse_pos_usable(io_mouse) ? io_mouse : pan_anchor_mouse_;
    pan_anchor_time_scroll_ = state_.view_scroll_time;
    pan_anchor_row_scroll_ = state_.view_scroll_row;
    if (mouse_pos_usable(io_mouse)) {
      view_drag_mouse_ = io_mouse;
      view_drag_mouse_valid_ = true;
      view_drag_mouse_was_usable_ = true;
    }
  }
}

std::optional<GridPosition> TimelineView::grid_cell_at(const ImVec2& mouse,
                                                       const ImVec2& grid_origin,
                                                       float cycle_width,
                                                       float row_height) const {
  GridPosition cell;
  cell.cycle = static_cast<Timestamp>(std::floor(
      state_.view_scroll_time + static_cast<double>((mouse.x - grid_origin.x) / cycle_width)));
  cell.row = static_cast<std::int64_t>(std::floor(
      state_.view_scroll_row + static_cast<double>((mouse.y - grid_origin.y) / row_height)));
  return cell;
}

void TimelineView::draw_cell_label(ImDrawList* draw_list, const std::string& label,
                                   ImU32 background, const ImVec2& cell_min,
                                   const ImVec2& cell_max, float font_size) const {
  const float cell_w = cell_max.x - cell_min.x;
  const float cell_h = cell_max.y - cell_min.y;
  if (label.empty() || cell_w < 6.0f || cell_h < 8.0f) {
    return;
  }

  const ImVec2 text_size = text_size_at(font_size, label.c_str());
  if (text_size.x > cell_w - 1.0f || text_size.y > cell_h - 1.0f) {
    return;
  }

  const float text_x = cell_min.x + (cell_w - text_size.x) * 0.5f;
  const float text_y = cell_min.y + (cell_h - text_size.y) * 0.5f;
  draw_list->AddText(ImGui::GetFont(), font_size, ImVec2(text_x, text_y),
                     text_color_for_background(background), label.c_str());
}

void TimelineView::refresh_cache() {
  if (!store_) {
    return;
  }

  const std::int64_t row_margin = 48;
  const Timestamp time_margin = 64;
  const Timestamp view_start_cycle =
      static_cast<Timestamp>(std::floor(state_.view_scroll_time));
  const Timestamp visible_cycles = static_cast<Timestamp>(state_.visible_cycles);

  const std::int64_t first_visible_row =
      static_cast<std::int64_t>(std::floor(state_.view_scroll_row));
  const std::int64_t last_visible_row = first_visible_row + state_.visible_rows;

  Viewport viewport;
  viewport.time_start = view_start_cycle - time_margin;
  viewport.time_end = view_start_cycle + visible_cycles + time_margin;

  if (last_visible_row < 0) {
    cached_objects_ = {};
    cached_events_ = {};
    cached_attributes_by_object_.clear();
    object_id_by_row_.clear();
    cache_time_start_ = viewport.time_start;
    cache_time_end_ = viewport.time_end;
    cache_row_start_ = first_visible_row;
    cache_row_end_ = last_visible_row;
    cache_valid_ = true;
    needs_refresh_ = false;
    return;
  }

  viewport.row_start = std::max<std::int64_t>(0, first_visible_row - row_margin);
  viewport.row_end = last_visible_row + row_margin;

  cached_objects_ = store_->query_objects(viewport, row_margin, active_sort_scheme());
  cached_events_ = store_->query_events(viewport, cached_objects_.ids);

  cached_attributes_by_object_.clear();
  object_id_by_row_.clear();
  for (std::size_t i = 0; i < cached_objects_.ids.size(); ++i) {
    const ObjectId id = cached_objects_.ids[i];
    const std::string& attributes_json =
        cached_objects_.attributes_json.size() > i ? cached_objects_.attributes_json[i] : "{}";
    cached_attributes_by_object_[id] = parse_object_attributes(attributes_json);
    object_id_by_row_[cached_objects_.row_indices[i]] = id;
  }

  cache_time_start_ = viewport.time_start;
  cache_time_end_ = viewport.time_end;
  cache_row_start_ = viewport.row_start;
  cache_row_end_ = viewport.row_end;
  cache_valid_ = true;
  needs_refresh_ = false;
}

void TimelineView::draw(const char* label, float height) {
  if (!store_) {
    return;
  }

  plot_layout_valid_ = false;

  ImGui::BeginChild(label, ImVec2(0, height), ImGuiChildFlags_Borders,
                    ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoScrollbar);

  const ImVec2 inner_avail = ImGui::GetContentRegionAvail();
  const float plot_height =
      std::max(0.0f, inner_avail.y - kTimelineFooterHeight);
  const ImVec2 plot_origin = ImGui::GetCursorScreenPos();
  const ImVec2 plot_size(inner_avail.x, plot_height);

  ImDrawList* draw_list = ImGui::GetWindowDrawList();

  const float header_height = plot_header_height();
  const float row_panel_width = row_attributes_panel_width();
  const float label_width = occurrence_label_width(marked_event_types_);
  const float row_scrollbar_width =
      has_row_panel() ? ImGui::GetStyle().ScrollbarSize : 0.0f;
  const float left_gutter_width = row_scrollbar_width + row_panel_width + label_width;
  const ImVec2 row_scrollbar_origin = plot_origin;
  const ImVec2 row_panel_origin(plot_origin.x + row_scrollbar_width, plot_origin.y);
  const ImVec2 occurrence_label_origin(row_panel_origin.x + row_panel_width, plot_origin.y);
  const ImVec2 cycle_origin(plot_origin.x + left_gutter_width, plot_origin.y);
  const float cycle_width_px = plot_size.x - left_gutter_width;
  const ImVec2 grid_origin(plot_origin.x + left_gutter_width, plot_origin.y + header_height);
  const ImVec2 grid_size(std::max(0.0f, cycle_width_px),
                         std::max(0.0f, plot_height - header_height));

  state_.visible_rows =
      static_cast<std::int64_t>(grid_size.y / state_.row_height) + 2;
  state_.visible_cycles =
      static_cast<std::int64_t>(std::ceil(grid_size.x / state_.cycle_width)) + 2;

  const float cycle_width = static_cast<float>(state_.cycle_width);
  const float row_height = static_cast<float>(state_.row_height);
  const Timestamp first_cycle =
      static_cast<Timestamp>(std::floor(state_.view_scroll_time));
  const Timestamp last_cycle =
      first_cycle + static_cast<Timestamp>(std::ceil(grid_size.x / cycle_width)) + 1;
  const std::int64_t first_row =
      static_cast<std::int64_t>(std::floor(state_.view_scroll_row));
  const std::int64_t last_row =
      first_row + static_cast<std::int64_t>(std::ceil(grid_size.y / row_height)) + 1;

  const ImVec2 mouse = ImGui::GetIO().MousePos;
  const ImVec2 plot_max(plot_origin.x + plot_size.x, plot_origin.y + plot_size.y);
  plot_origin_ = plot_origin;
  plot_max_ = plot_max;
  grid_origin_ = grid_origin;
  grid_size_ = grid_size;
  plot_cycle_width_ = cycle_width;
  plot_row_height_ = row_height;
  row_scrollbar_width_ = row_scrollbar_width;
  row_scrollbar_origin_ = row_scrollbar_origin;
  row_panel_origin_ = row_panel_origin;
  row_panel_width_ = row_panel_width;
  plot_header_height_ = header_height;
  plot_layout_valid_ = true;

  refresh_view_drag_mouse();

  const ImVec2 row_panel_max(row_panel_origin.x + row_panel_width,
                             row_panel_origin.y + header_height + grid_size.y);
  const bool over_row_axis =
      (row_scrollbar_width > 0.0f &&
       mouse_in_rect(mouse, row_scrollbar_origin,
                     ImVec2(row_scrollbar_origin.x + row_scrollbar_width, row_panel_max.y)) &&
       mouse.y >= row_panel_origin.y + header_height) ||
      (row_panel_width > 0.0f && mouse_in_rect(mouse, row_panel_origin, row_panel_max) &&
       mouse.y >= row_panel_origin.y + header_height);

  plot_hovered_ =
      mouse_in_rect(mouse, plot_origin, plot_max) && !mouse_over_sticky_popup(mouse);
  const bool grid_hovered = plot_hovered_ && mouse.y >= grid_origin.y && !over_row_axis;

  update_pan_scroll_from_drag_mouse();
  update_view_drag_tracking();

  const bool grid_wheel_scroll = grid_hovered && !mouse_over_sticky_popup(mouse);
  handle_row_scroll_in_draw(grid_wheel_scroll);

  if (grid_wheel_scroll && ImGui::GetIO().MouseWheel != 0.0f && ImGui::GetIO().KeyCtrl) {
    const double zoom_factor =
        ImGui::GetIO().MouseWheel > 0.0f ? 1.12 : 1.0 / 1.12;
    const double mouse_x = static_cast<double>(mouse.x - grid_origin.x);
    const double mouse_y =
        static_cast<double>(std::max(0.0f, mouse.y - grid_origin.y));
    bool changed = false;

    changed |= zoom_preserve_anchor(state_.view_scroll_time, state_.cycle_width, mouse_x,
                                    zoom_factor, 4.0, 80.0);
    changed |= zoom_preserve_anchor(state_.view_scroll_row, state_.row_height, mouse_y,
                                    zoom_factor, 8.0, 80.0);
    if (changed) {
      needs_refresh_ = true;
      if (!suppress_view_callback_ && view_zoom_change_callback_) {
        view_zoom_change_callback_(*this);
      }
    }
  }

  if ((needs_refresh_ || view_outside_cache()) && !defer_row_cache_refresh()) {
    refresh_cache();
  }

  const double draw_row_scroll = state_.view_scroll_row;
  const std::int64_t label_step = stable_cycle_label_step(
      state_.cycle_width, first_cycle, last_cycle, axis_label_step_);
  const ViewerTheme& theme = viewer_theme(color_scheme_);

  const ImVec2 grid_max(grid_origin.x + grid_size.x, grid_origin.y + grid_size.y);
  draw_list->PushClipRect(grid_origin, grid_max, true);

  draw_list->AddRectFilled(grid_origin, grid_max, theme.grid_background);

  std::unordered_map<ObjectId, std::int32_t> row_by_object;
  for (std::size_t i = 0; i < cached_objects_.ids.size(); ++i) {
    row_by_object[cached_objects_.ids[i]] = cached_objects_.row_indices[i];
  }

  for (Timestamp cycle = first_cycle; cycle <= last_cycle; ++cycle) {
    const float x = cycle_x(grid_origin, state_.view_scroll_time, cycle_width, cycle);
    if (x + cycle_width < grid_origin.x || x > grid_origin.x + grid_size.x) {
      continue;
    }

    for (std::int64_t row = first_row; row <= last_row; ++row) {
      const float y =
          grid_origin.y + static_cast<float>(static_cast<double>(row) - draw_row_scroll) *
              row_height;
      if (y + row_height < grid_origin.y || y > grid_origin.y + grid_size.y) {
        continue;
      }

      const ImVec2 cell_min(std::max(x, grid_origin.x), y);
      const ImVec2 cell_max(std::min(x + cycle_width, grid_max.x), y + row_height);
      if (cell_max.x <= cell_min.x) {
        continue;
      }
      draw_list->AddRectFilled(cell_min, cell_max, theme.cell_fill);
      draw_list->AddRect(cell_min, cell_max, theme.cell_border);
    }
  }

  draw_grid_marker_fills(draw_list, grid_origin, grid_max, first_cycle, last_cycle, first_row,
                         last_row, state_.view_scroll_time, state_.view_scroll_row, cycle_width,
                         row_height, state_.has_crosshair, state_.crosshair,
                         state_.crosshair_cycle_highlight, pinned_markers_,
                         marker_style_from_theme(theme.marker_underlay));

  state_.has_hover_cell = false;
  state_.hover_cell_events.clear();
  state_.hover_text.clear();

  std::map<CellKey, std::vector<CellEvent>> events_by_cell;
  for (std::size_t i = 0; i < cached_events_.object_ids.size(); ++i) {
    const auto row_it = row_by_object.find(cached_events_.object_ids[i]);
    if (row_it == row_by_object.end()) {
      continue;
    }

    CellEvent event;
    event.id = cached_events_.ids[i];
    event.event_type_id = cached_events_.event_type_ids[i];
    event.display_char =
        cached_events_.display_chars.size() > i ? cached_events_.display_chars[i] : '?';
    event.color_rgba = cached_events_.colors_rgba[i];
    event.object_id = cached_events_.object_ids[i];
    event.kind = cached_events_.kinds[i];
    event.attributes = parse_object_attributes(cached_events_.attributes_json[i]);
    events_by_cell[{row_it->second, cached_events_.times[i]}].push_back(event);
  }

  for (auto& [cell, events] : events_by_cell) {
    std::sort(events.begin(), events.end(),
              [](const CellEvent& a, const CellEvent& b) {
                return a.event_type_id < b.event_type_id;
              });

    const std::int64_t row = cell.first;
    const Timestamp cycle = cell.second;
    const float x = cycle_x(grid_origin, state_.view_scroll_time, cycle_width, cycle);
    const float y =
        grid_origin.y + static_cast<float>(row - draw_row_scroll) * row_height;
    if (x + cycle_width < grid_origin.x || x > grid_origin.x + grid_size.x ||
        y + row_height < grid_origin.y || y > grid_origin.y + grid_size.y) {
      continue;
    }

    const ImVec2 cell_min(std::max(x + 1.0f, grid_origin.x + 1.0f), y + 1.0f);
    const ImVec2 cell_max(std::min(x + cycle_width - 1.0f, grid_max.x - 1.0f), y + row_height - 1.0f);
    if (cell_max.x <= cell_min.x || cell_max.y <= cell_min.y) {
      continue;
    }
    const ImU32 color = event_color(events.front().color_rgba);
    draw_list->AddRectFilled(cell_min, cell_max, color);

    const std::string label = label_for_cell_events(
        events, cell_max.x - cell_min.x - 1.0f, state_.event_char_font_size);
    draw_cell_label(draw_list, label, color, cell_min, cell_max, state_.event_char_font_size);

    if (grid_hovered && !mouse_over_sticky_popup(mouse) && mouse.x >= x &&
        mouse.x <= x + cycle_width && mouse.y >= y && mouse.y <= y + row_height) {
      state_.has_hover_cell = true;
      state_.hover_cell = {cycle, row};
      state_.hover_popup_anchor = mouse;
      state_.hover_cell_events.clear();
      state_.hover_cell_events.reserve(events.size());
      for (const CellEvent& cell_event : events) {
        CellEventInfo info;
        info.id = cell_event.id;
        info.event_type_id = cell_event.event_type_id;
        info.kind = cell_event.kind;
        info.display_char = cell_event.display_char;
        info.attributes = cell_event.attributes;
        state_.hover_cell_events.push_back(std::move(info));
      }

      state_.hover_text = label + " object " + std::to_string(events.front().object_id) +
                          " cycle " + std::to_string(cycle);
      if (events.size() > 1) {
        state_.hover_text += " (" + std::to_string(events.size()) + " events)";
      }
    }
  }

  if (state_.has_hover_cell && !state_.hover_cell_events.empty() && pin_hotkey_pressed() &&
      !mouse_over_sticky_popup(mouse)) {
    pin_hover_popup();
  }

  draw_grid_marker_fills(draw_list, grid_origin, grid_max, first_cycle, last_cycle, first_row,
                         last_row, state_.view_scroll_time, state_.view_scroll_row, cycle_width,
                         row_height, state_.has_crosshair, state_.crosshair,
                         state_.crosshair_cycle_highlight, pinned_markers_,
                         marker_style_from_theme(theme.marker_overlay));
  draw_list->PopClipRect();

  draw_cycle_axis(draw_list, cycle_origin, cycle_width_px, left_gutter_width, first_cycle,
                  last_cycle, state_.view_scroll_time, cycle_width, label_step, theme);

  for (std::size_t i = 0; i < marked_event_types_.size(); ++i) {
    const ImVec2 panel_origin(
        cycle_origin.x,
        plot_origin.y + kCycleAxisHeight + static_cast<float>(i) * kOccurrencePanelHeight);
    const ImU32 marker_color = event_color(marked_event_types_[i].color_rgba);
    draw_occurrence_panel_bars(draw_list, panel_origin, cycle_width_px, left_gutter_width,
                               first_cycle, last_cycle, state_.view_scroll_time, cycle_width,
                               marked_event_types_[i].occurrence_counts, marker_color, theme);
  }

  if (row_panel_width > 0.0f && has_row_panel()) {
    draw_row_panel_marker_fills(draw_list, row_panel_origin, row_panel_max, header_height,
                                state_.view_scroll_row, row_height, first_row, last_row,
                                state_.has_crosshair, state_.crosshair, pinned_markers_,
                                marker_style_from_theme(theme.marker_underlay));
  }

  draw_row_attributes_panel(draw_list, row_panel_origin, row_panel_width, header_height,
                            grid_size.y, state_.view_scroll_row, row_height, first_row, last_row,
                            pinned_row_columns_, theme, object_id_by_row_,
                            cached_attributes_by_object_, &row_sort_state(), &app_config_);

  if (row_scrollbar_width > 0.0f) {
    draw_row_scrollbar(draw_list, row_scrollbar_origin, row_scrollbar_width, header_height,
                       grid_size.y, theme);
  }

  if (row_panel_width > 0.0f && has_row_panel()) {
    draw_row_panel_marker_fills(draw_list, row_panel_origin, row_panel_max, header_height,
                                state_.view_scroll_row, row_height, first_row, last_row,
                                state_.has_crosshair, state_.crosshair, pinned_markers_,
                                marker_style_from_theme(theme.marker_overlay));
  }

  draw_header_label_column(draw_list, occurrence_label_origin, label_width, header_height,
                           marked_event_types_, theme);

  for (std::size_t i = 0; i < marked_event_types_.size(); ++i) {
    const ImVec2 panel_origin(
        cycle_origin.x,
        plot_origin.y + kCycleAxisHeight + static_cast<float>(i) * kOccurrencePanelHeight);
    draw_occurrence_panel_counts(draw_list, panel_origin, cycle_width_px, first_cycle, last_cycle,
                                 state_.view_scroll_time, cycle_width,
                                 marked_event_types_[i].occurrence_counts,
                                 event_color(marked_event_types_[i].color_rgba), theme);
  }

  const float row_guide_left_x =
      row_scrollbar_width > 0.0f ? row_scrollbar_origin.x
      : row_panel_width > 0.0f && has_row_panel()
          ? row_panel_origin.x
          : grid_origin.x;
  draw_grid_marker_guides(draw_list, grid_origin, grid_max, state_.view_scroll_time,
                          state_.view_scroll_row, cycle_width, row_height, state_.has_crosshair,
                          state_.crosshair, state_.crosshair_cycle_highlight, pinned_markers_,
                          theme, row_guide_left_x);

  draw_search_row_highlight(draw_list);

  ImGui::Dummy(plot_size);

  ImGui::Separator();
  ImGui::Text("cycles: %lld..%lld  rows: %.0f+  cell: %.0fx%.0fpx  events: %zu",
              static_cast<long long>(first_cycle), static_cast<long long>(last_cycle),
              state_.view_scroll_row, state_.cycle_width, state_.row_height,
              cached_events_.object_ids.size());
  if (state_.has_crosshair) {
    ImGui::Text("crosshair: cycle %lld, row %lld  pinned: %zu",
                static_cast<long long>(state_.crosshair.cycle),
                static_cast<long long>(state_.crosshair.row), pinned_markers_.size());
  }
  if (search_.active && !app_config_.search_attributes.empty() &&
      search_.field_index < app_config_.search_attributes.size()) {
    ImGui::Text("Search [%s]: %s|", app_config_.search_attributes[search_.field_index].c_str(),
                search_.query.c_str());
  }
  if (!state_.hover_text.empty()) {
    ImGui::Text("hover: %s", state_.hover_text.c_str());
  }
  for (const MarkedEventType& marked : marked_event_types_) {
    ImGui::Text("marked: '%c' %s (%zu events, %zu cycles)", marked.display_char,
                marked.name.c_str(), total_occurrence_count(marked.occurrence_counts),
                marked.occurrence_counts.size());
  }

  ImGui::EndChild();
}

}  // namespace pipetrace
