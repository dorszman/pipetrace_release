#include "pipetrace/storage.hpp"

#include <algorithm>
#include <cctype>
#include <filesystem>
#include <fstream>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <unordered_map>

#include "pipetrace/attributes.hpp"
#include "pipetrace/sort_sql.hpp"
#include "sqlite3.h"
#include "storage/sqlite_store.hpp"

namespace pipetrace {
namespace {

void check_sqlite(int rc, sqlite3* db, const char* context) {
  if (rc != SQLITE_OK && rc != SQLITE_DONE && rc != SQLITE_ROW) {
    throw std::runtime_error(std::string(context) + ": " + sqlite3_errmsg(db));
  }
}

std::string trim(const std::string& s) {
  std::size_t start = 0;
  while (start < s.size() && std::isspace(static_cast<unsigned char>(s[start]))) {
    ++start;
  }
  std::size_t end = s.size();
  while (end > start && std::isspace(static_cast<unsigned char>(s[end - 1]))) {
    --end;
  }
  return s.substr(start, end - start);
}

std::optional<std::string> extract_string_field(const std::string& line,
                                                const std::string& key) {
  const std::string needle = "\"" + key + "\":\"";
  const auto pos = line.find(needle);
  if (pos == std::string::npos) {
    return std::nullopt;
  }
  const auto start = pos + needle.size();
  const auto end = line.find('"', start);
  if (end == std::string::npos) {
    return std::nullopt;
  }
  return line.substr(start, end - start);
}

std::optional<std::int64_t> extract_int_field(const std::string& line, const std::string& key) {
  const std::string needle = "\"" + key + "\":";
  const auto pos = line.find(needle);
  if (pos == std::string::npos) {
    return std::nullopt;
  }
  const auto start = pos + needle.size();
  return std::stoll(line.substr(start));
}

std::optional<std::uint32_t> extract_uint_field(const std::string& line, const std::string& key) {
  const auto value = extract_int_field(line, key);
  if (!value) {
    return std::nullopt;
  }
  return static_cast<std::uint32_t>(*value);
}

bool is_presentable_display_char(unsigned char value) {
  return value >= 32 && value != 127;
}

char normalize_display_char(char value, const std::string& fallback_name) {
  if (is_presentable_display_char(static_cast<unsigned char>(value))) {
    return value;
  }
  if (!fallback_name.empty()) {
    const char candidate =
        static_cast<char>(std::toupper(static_cast<unsigned char>(fallback_name[0])));
    if (is_presentable_display_char(static_cast<unsigned char>(candidate))) {
      return candidate;
    }
  }
  return '?';
}

char parse_display_char_field(const std::string& line, const std::string& fallback_name) {
  if (const auto text = extract_string_field(line, "char")) {
    if (!text->empty()) {
      return normalize_display_char((*text)[0], fallback_name);
    }
  }
  if (const auto code = extract_int_field(line, "char_code")) {
    return normalize_display_char(static_cast<char>(*code), fallback_name);
  }
  return normalize_display_char('\0', fallback_name);
}

}  // namespace

SqliteStore::SqliteStore() = default;

SqliteStore::~SqliteStore() { close(); }

bool SqliteStore::open(const std::string& path) {
  close();
  path_ = path;
  check_sqlite(sqlite3_open(path.c_str(), &db_), db_, "sqlite3_open");
  initialize_schema();
  return true;
}

void SqliteStore::close() {
  if (db_) {
    sqlite3_close(db_);
    db_ = nullptr;
  }
}

void SqliteStore::initialize_schema() {
  exec_sql(R"(
    CREATE TABLE IF NOT EXISTS meta (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS object_types (
      id INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      display_name TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS event_types (
      id INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      object_type_id INTEGER NOT NULL,
      color_rgba INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS event_type_display (
      event_type_id INTEGER PRIMARY KEY,
      display_char TEXT NOT NULL,
      color_rgba INTEGER NOT NULL,
      FOREIGN KEY(event_type_id) REFERENCES event_types(id)
    );
    CREATE TABLE IF NOT EXISTS objects (
      id INTEGER PRIMARY KEY,
      object_type_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      first_time INTEGER NOT NULL,
      last_time INTEGER NOT NULL,
      parent_id INTEGER NOT NULL DEFAULT -1,
      attributes TEXT NOT NULL DEFAULT '{}'
    );
    CREATE INDEX IF NOT EXISTS idx_objects_time ON objects(first_time, last_time);
    CREATE TABLE IF NOT EXISTS events (
      id INTEGER PRIMARY KEY,
      object_id INTEGER NOT NULL,
      event_type_id INTEGER NOT NULL,
      kind TEXT NOT NULL,
      start_time INTEGER NOT NULL,
      end_time INTEGER NOT NULL,
      attributes TEXT NOT NULL DEFAULT '{}'
    );
    CREATE INDEX IF NOT EXISTS idx_events_object_time ON events(object_id, start_time, end_time);
    CREATE TABLE IF NOT EXISTS object_attribute_keys (
      key TEXT PRIMARY KEY
    );
  )");
  migrate_schema();
}

void SqliteStore::migrate_schema() {
  auto table_has_column = [&](const char* table, const char* column) {
    bool found = false;
    sqlite3_stmt* stmt = nullptr;
    const std::string sql = std::string("PRAGMA table_info(") + table + ");";
    check_sqlite(sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr), db_,
                 "prepare table_info");
    while (sqlite3_step(stmt) == SQLITE_ROW) {
      const char* name = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
      if (name && std::string(name) == column) {
        found = true;
        break;
      }
    }
    sqlite3_finalize(stmt);
    return found;
  };

  if (!table_has_column("objects", "attributes")) {
    exec_sql("ALTER TABLE objects ADD COLUMN attributes TEXT NOT NULL DEFAULT '{}';");
  }
  if (!table_has_column("events", "attributes")) {
    exec_sql("ALTER TABLE events ADD COLUMN attributes TEXT NOT NULL DEFAULT '{}';");
  }
  if (!table_has_column("objects", "parent_id")) {
    exec_sql("ALTER TABLE objects ADD COLUMN parent_id INTEGER NOT NULL DEFAULT -1;");
  }
}

void SqliteStore::exec_sql(const char* sql) {
  char* err = nullptr;
  const int rc = sqlite3_exec(db_, sql, nullptr, nullptr, &err);
  if (rc != SQLITE_OK) {
    std::string message = err ? err : "unknown sqlite error";
    sqlite3_free(err);
    throw std::runtime_error(message);
  }
}

void SqliteStore::set_meta(const std::string& name, Timestamp min_time, Timestamp max_time,
                           std::int64_t object_count, std::int64_t event_count) {
  exec_sql("DELETE FROM meta;");
  auto insert = [&](const char* key, const std::string& value) {
    sqlite3_stmt* stmt = nullptr;
    check_sqlite(
        sqlite3_prepare_v2(db_, "INSERT INTO meta(key, value) VALUES(?, ?);", -1, &stmt, nullptr),
        db_, "prepare meta insert");
    sqlite3_bind_text(stmt, 1, key, -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, value.c_str(), -1, SQLITE_TRANSIENT);
    check_sqlite(sqlite3_step(stmt), db_, "meta insert");
    sqlite3_finalize(stmt);
  };
  insert("name", name);
  insert("min_time", std::to_string(min_time));
  insert("max_time", std::to_string(max_time));
  insert("object_count", std::to_string(object_count));
  insert("event_count", std::to_string(event_count));
}

std::optional<std::string> SqliteStore::meta_value(const std::string& key) const {
  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_, "SELECT value FROM meta WHERE key = ?;", -1, &stmt, nullptr),
               db_, "prepare meta value select");
  sqlite3_bind_text(stmt, 1, key.c_str(), -1, SQLITE_TRANSIENT);
  std::optional<std::string> result;
  if (sqlite3_step(stmt) == SQLITE_ROW) {
    const char* value = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0));
    if (value != nullptr) {
      result = value;
    }
  }
  sqlite3_finalize(stmt);
  return result;
}

void SqliteStore::set_meta_value(const std::string& key, const std::string& value) {
  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_,
                                  "INSERT INTO meta(key, value) VALUES(?, ?) "
                                  "ON CONFLICT(key) DO UPDATE SET value = excluded.value;",
                                  -1, &stmt, nullptr),
               db_, "prepare meta value upsert");
  sqlite3_bind_text(stmt, 1, key.c_str(), -1, SQLITE_TRANSIENT);
  sqlite3_bind_text(stmt, 2, value.c_str(), -1, SQLITE_TRANSIENT);
  check_sqlite(sqlite3_step(stmt), db_, "meta value upsert");
  sqlite3_finalize(stmt);
}

void SqliteStore::insert_object_type(std::int64_t id, const std::string& name,
                                     const std::string& display_name) {
  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_,
                                  "INSERT INTO object_types(id, name, display_name) VALUES(?, ?, ?);",
                                  -1, &stmt, nullptr),
               db_, "prepare object_type insert");
  sqlite3_bind_int64(stmt, 1, id);
  sqlite3_bind_text(stmt, 2, name.c_str(), -1, SQLITE_TRANSIENT);
  sqlite3_bind_text(stmt, 3, display_name.c_str(), -1, SQLITE_TRANSIENT);
  check_sqlite(sqlite3_step(stmt), db_, "object_type insert");
  sqlite3_finalize(stmt);
}

void SqliteStore::insert_event_type(std::int64_t id, const std::string& name,
                                    std::int64_t object_type_id, std::uint32_t color_rgba) {
  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_,
                                  "INSERT INTO event_types(id, name, object_type_id, color_rgba) "
                                  "VALUES(?, ?, ?, ?);",
                                  -1, &stmt, nullptr),
               db_, "prepare event_type insert");
  sqlite3_bind_int64(stmt, 1, id);
  sqlite3_bind_text(stmt, 2, name.c_str(), -1, SQLITE_TRANSIENT);
  sqlite3_bind_int64(stmt, 3, object_type_id);
  sqlite3_bind_int64(stmt, 4, static_cast<std::int64_t>(color_rgba));
  check_sqlite(sqlite3_step(stmt), db_, "event_type insert");
  sqlite3_finalize(stmt);
}

void SqliteStore::insert_event_type_display(std::int64_t event_type_id, char display_char,
                                            std::uint32_t color_rgba) {
  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_,
                                  "INSERT INTO event_type_display(event_type_id, display_char, "
                                  "color_rgba) VALUES(?, ?, ?);",
                                  -1, &stmt, nullptr),
               db_, "prepare event_type_display insert");
  sqlite3_bind_int64(stmt, 1, event_type_id);
  const char text[2] = {display_char, '\0'};
  sqlite3_bind_text(stmt, 2, text, 1, SQLITE_TRANSIENT);
  sqlite3_bind_int64(stmt, 3, static_cast<std::int64_t>(color_rgba));
  check_sqlite(sqlite3_step(stmt), db_, "event_type_display insert");
  sqlite3_finalize(stmt);
}

void SqliteStore::insert_object(ObjectId id, std::int64_t object_type_id, const std::string& name,
                                Timestamp first_time, Timestamp last_time, ObjectId parent_id,
                                const std::string& attributes_json) {
  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_,
                                  "INSERT INTO objects(id, object_type_id, name, first_time, "
                                  "last_time, parent_id, attributes) VALUES(?, ?, ?, ?, ?, ?, ?);",
                                  -1, &stmt, nullptr),
               db_, "prepare object insert");
  sqlite3_bind_int64(stmt, 1, id);
  sqlite3_bind_int64(stmt, 2, object_type_id);
  sqlite3_bind_text(stmt, 3, name.c_str(), -1, SQLITE_TRANSIENT);
  sqlite3_bind_int64(stmt, 4, first_time);
  sqlite3_bind_int64(stmt, 5, last_time);
  sqlite3_bind_int64(stmt, 6, parent_id);
  sqlite3_bind_text(stmt, 7, attributes_json.c_str(), -1, SQLITE_TRANSIENT);
  check_sqlite(sqlite3_step(stmt), db_, "object insert");
  sqlite3_finalize(stmt);
}

void SqliteStore::insert_event(EventId id, ObjectId object_id, std::int64_t event_type_id,
                               const std::string& kind, Timestamp time,
                               const std::string& attributes_json) {
  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_,
                                  "INSERT INTO events(id, object_id, event_type_id, kind, "
                                  "start_time, end_time, attributes) VALUES(?, ?, ?, ?, ?, ?, ?);",
                                  -1, &stmt, nullptr),
               db_, "prepare event insert");
  sqlite3_bind_int64(stmt, 1, id);
  sqlite3_bind_int64(stmt, 2, object_id);
  sqlite3_bind_int64(stmt, 3, event_type_id);
  sqlite3_bind_text(stmt, 4, kind.c_str(), -1, SQLITE_TRANSIENT);
  sqlite3_bind_int64(stmt, 5, time);
  sqlite3_bind_int64(stmt, 6, time);
  sqlite3_bind_text(stmt, 7, attributes_json.c_str(), -1, SQLITE_TRANSIENT);
  check_sqlite(sqlite3_step(stmt), db_, "event insert");
  sqlite3_finalize(stmt);
}

TraceMeta SqliteStore::meta() const {
  TraceMeta result;
  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_, "SELECT key, value FROM meta;", -1, &stmt, nullptr), db_,
               "prepare meta select");
  while (sqlite3_step(stmt) == SQLITE_ROW) {
    const char* key = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0));
    const char* value = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
    if (!key || !value) {
      continue;
    }
    if (std::string(key) == "name") {
      result.name = value;
    } else if (std::string(key) == "min_time") {
      result.min_time = std::stoll(value);
    } else if (std::string(key) == "max_time") {
      result.max_time = std::stoll(value);
    } else if (std::string(key) == "object_count") {
      result.object_count = std::stoll(value);
    } else if (std::string(key) == "event_count") {
      result.event_count = std::stoll(value);
    }
  }
  sqlite3_finalize(stmt);
  return result;
}

std::vector<ObjectType> SqliteStore::object_types() const {
  std::vector<ObjectType> result;
  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_, "SELECT id, name, display_name FROM object_types ORDER BY id;",
                                  -1, &stmt, nullptr),
               db_, "prepare object_types select");
  while (sqlite3_step(stmt) == SQLITE_ROW) {
    ObjectType type;
    type.id = sqlite3_column_int64(stmt, 0);
    type.name = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
    type.display_name = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
    result.push_back(type);
  }
  sqlite3_finalize(stmt);
  return result;
}

std::vector<EventType> SqliteStore::event_types() const {
  std::vector<EventType> result;
  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_,
                                  "SELECT et.id, et.name, et.object_type_id, "
                                  "COALESCE(ed.display_char, substr(et.name, 1, 1)), "
                                  "COALESCE(ed.color_rgba, et.color_rgba) "
                                  "FROM event_types et "
                                  "LEFT JOIN event_type_display ed ON ed.event_type_id = et.id "
                                  "ORDER BY et.id;",
                                  -1, &stmt, nullptr),
               db_, "prepare event_types select");
  while (sqlite3_step(stmt) == SQLITE_ROW) {
    EventType type;
    type.id = sqlite3_column_int64(stmt, 0);
    type.name = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
    type.object_type_id = sqlite3_column_int64(stmt, 2);
    const char* display_char = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
    type.display_char =
        normalize_display_char(display_char ? display_char[0] : '\0', type.name);
    type.color_rgba = static_cast<std::uint32_t>(sqlite3_column_int64(stmt, 4));
    result.push_back(type);
  }
  sqlite3_finalize(stmt);
  return result;
}

ColumnarObjects SqliteStore::query_objects(const Viewport& viewport, std::int64_t prefetch_rows,
                                           const SortScheme* sort_scheme) {
  ColumnarObjects result;
  const std::int64_t first_row = std::max<std::int64_t>(0, viewport.row_start - prefetch_rows);
  const std::int64_t last_row = viewport.row_end + prefetch_rows;
  const std::int64_t row_count = last_row - first_row + 1;
  if (row_count <= 0) {
    return result;
  }

  const std::string order_by =
      sort_scheme != nullptr && !sort_scheme->columns.empty()
          ? build_object_sort_order_by_clause(*sort_scheme)
          : "id";

  std::ostringstream sql;
  sql << "SELECT id, object_type_id, first_time, last_time, attributes "
      << "FROM objects ORDER BY " << order_by << " LIMIT ? OFFSET ?;";

  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_, sql.str().c_str(), -1, &stmt, nullptr), db_,
               "prepare object viewport query");

  sqlite3_bind_int64(stmt, 1, row_count);
  sqlite3_bind_int64(stmt, 2, first_row);

  std::int64_t row = first_row;
  while (sqlite3_step(stmt) == SQLITE_ROW) {
    const ObjectId id = sqlite3_column_int64(stmt, 0);
    result.ids.push_back(id);
    result.object_type_ids.push_back(sqlite3_column_int64(stmt, 1));
    result.first_times.push_back(sqlite3_column_int64(stmt, 2));
    result.last_times.push_back(sqlite3_column_int64(stmt, 3));
    result.row_indices.push_back(static_cast<std::int32_t>(row));
    ++row;
    const char* attributes_json = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4));
    result.attributes_json.push_back(attributes_json ? attributes_json : "{}");
  }
  sqlite3_finalize(stmt);
  return result;
}

ColumnarEvents SqliteStore::query_events(const Viewport& viewport,
                                         const std::vector<ObjectId>& object_ids) {
  ColumnarEvents result;
  if (object_ids.empty()) {
    return result;
  }

  std::ostringstream in_clause;
  in_clause << "SELECT e.id, e.object_id, e.start_time, e.event_type_id, e.kind, "
            << "COALESCE(ed.display_char, substr(et.name, 1, 1)), "
            << "COALESCE(ed.color_rgba, et.color_rgba), e.attributes "
            << "FROM events e "
            << "LEFT JOIN event_types et ON e.event_type_id = et.id "
            << "LEFT JOIN event_type_display ed ON ed.event_type_id = et.id "
            << "WHERE e.object_id IN (";
  for (std::size_t i = 0; i < object_ids.size(); ++i) {
    if (i > 0) {
      in_clause << ',';
    }
    in_clause << '?';
  }
  in_clause << ") ORDER BY e.object_id, e.start_time;";

  sqlite3_stmt* stmt = nullptr;
  const std::string sql = in_clause.str();
  check_sqlite(sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr), db_,
               "prepare event viewport query");
  for (std::size_t i = 0; i < object_ids.size(); ++i) {
    sqlite3_bind_int64(stmt, static_cast<int>(1 + i), object_ids[i]);
  }

  while (sqlite3_step(stmt) == SQLITE_ROW) {
    result.ids.push_back(sqlite3_column_int64(stmt, 0));
    result.object_ids.push_back(sqlite3_column_int64(stmt, 1));
    result.times.push_back(sqlite3_column_int64(stmt, 2));
    result.event_type_ids.push_back(sqlite3_column_int64(stmt, 3));
    const char* kind = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4));
    result.kinds.push_back(kind ? kind : "");
    const char* display_char = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 5));
    result.display_chars.push_back(
        normalize_display_char(display_char ? display_char[0] : '\0', kind ? kind : ""));
    result.colors_rgba.push_back(
        static_cast<std::uint32_t>(sqlite3_column_int64(stmt, 6)));
    const char* attributes_json = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 7));
    result.attributes_json.push_back(attributes_json ? attributes_json : "{}");
  }
  sqlite3_finalize(stmt);
  return result;
}

std::vector<CycleOccurrenceCount> SqliteStore::query_event_cycle_counts(
    std::int64_t event_type_id) const {
  std::vector<CycleOccurrenceCount> result;
  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_,
                                  "SELECT start_time, COUNT(*) FROM events "
                                  "WHERE event_type_id = ? GROUP BY start_time "
                                  "ORDER BY start_time;",
                                  -1, &stmt, nullptr),
               db_, "prepare event cycle count query");
  sqlite3_bind_int64(stmt, 1, event_type_id);

  while (sqlite3_step(stmt) == SQLITE_ROW) {
    CycleOccurrenceCount entry;
    entry.cycle = sqlite3_column_int64(stmt, 0);
    entry.count = static_cast<std::size_t>(sqlite3_column_int64(stmt, 1));
    result.push_back(entry);
  }
  sqlite3_finalize(stmt);
  return result;
}

void SqliteStore::begin_immediate_transaction() { exec_sql("BEGIN IMMEDIATE;"); }

void SqliteStore::commit_transaction() { exec_sql("COMMIT;"); }

void SqliteStore::rollback_transaction() { exec_sql("ROLLBACK;"); }

void SqliteStore::copy_database_file(const std::string& dest_path) const {
  if (dest_path == path_) {
    throw std::runtime_error("copy destination must differ from source");
  }
  if (std::filesystem::exists(dest_path)) {
    std::filesystem::remove(dest_path);
  }

  sqlite3* dest_db = nullptr;
  check_sqlite(sqlite3_open(dest_path.c_str(), &dest_db), dest_db, "sqlite3_open copy dest");
  sqlite3_backup* backup = sqlite3_backup_init(dest_db, "main", db_, "main");
  if (!backup) {
    const std::string message = sqlite3_errmsg(dest_db);
    sqlite3_close(dest_db);
    throw std::runtime_error("sqlite3_backup_init: " + message);
  }
  check_sqlite(sqlite3_backup_step(backup, -1), db_, "sqlite3_backup_step");
  check_sqlite(sqlite3_backup_finish(backup), db_, "sqlite3_backup_finish");
  check_sqlite(sqlite3_close(dest_db), dest_db, "sqlite3_close copy dest");
}

void SqliteStore::for_each_event_by_kind(
    const std::string& kind,
    const std::function<void(EventId event_id, ObjectId object_id,
                             const char* attributes_json)>& callback) const {
  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_,
                                  "SELECT id, object_id, attributes FROM events "
                                  "WHERE kind = ? ORDER BY id;",
                                  -1, &stmt, nullptr),
               db_, "prepare for_each_event_by_kind");
  sqlite3_bind_text(stmt, 1, kind.c_str(), -1, SQLITE_TRANSIENT);

  while (sqlite3_step(stmt) == SQLITE_ROW) {
    const EventId event_id = sqlite3_column_int64(stmt, 0);
    const ObjectId object_id = sqlite3_column_int64(stmt, 1);
    const char* attributes_json = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
    callback(event_id, object_id, attributes_json ? attributes_json : "{}");
  }
  sqlite3_finalize(stmt);
}

void SqliteStore::for_each_object(
    const std::function<void(ObjectId id, ObjectId parent_id,
                             const char* attributes_json)>& callback) const {
  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_,
                                  "SELECT id, parent_id, attributes FROM objects ORDER BY id;",
                                  -1, &stmt, nullptr),
               db_, "prepare for_each_object");

  while (sqlite3_step(stmt) == SQLITE_ROW) {
    const ObjectId id = sqlite3_column_int64(stmt, 0);
    const ObjectId parent_id = sqlite3_column_int64(stmt, 1);
    const char* attributes_json = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
    callback(id, parent_id, attributes_json ? attributes_json : "{}");
  }
  sqlite3_finalize(stmt);
}

void SqliteStore::ensure_analysis_indexes() {
  exec_sql("CREATE INDEX IF NOT EXISTS idx_events_kind_object_id ON events(kind, object_id);");
}

namespace {

void stream_instid_promotion(
    sqlite3* db,
    const char* prepare_label,
    const char* sql,
    const std::function<void(const SqliteStore::InstIdPromotionRow&)>& callback) {
  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr), db, prepare_label);

  while (sqlite3_step(stmt) == SQLITE_ROW) {
    SqliteStore::InstIdPromotionRow row;
    row.object_id = sqlite3_column_int64(stmt, 0);
    row.parent_id = sqlite3_column_type(stmt, 2) == SQLITE_NULL ? -1 : sqlite3_column_int64(stmt, 2);
    row.object_attributes_json = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
    row.retire_event_attributes_json =
        sqlite3_column_type(stmt, 3) == SQLITE_NULL
            ? nullptr
            : reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
    row.retire_event_count = sqlite3_column_int64(stmt, 4);
    callback(row);
  }
  sqlite3_finalize(stmt);
}

}  // namespace

void SqliteStore::for_each_instruction_instid_promotion(
    const std::function<void(const InstIdPromotionRow&)>& callback) const {
  static constexpr const char* kSql =
      "SELECT o.id, o.attributes, NULL, e.attributes, "
      "(SELECT COUNT(*) FROM events WHERE object_id = o.id AND kind = 'retire_inst') "
      "FROM objects o "
      "LEFT JOIN events e ON e.id = ("
      "SELECT id FROM events "
      "WHERE object_id = o.id AND kind = 'retire_inst' "
      "ORDER BY id DESC LIMIT 1) "
      "WHERE json_extract(o.attributes, '$.type') = 'Instruction' "
      "ORDER BY o.id;";
  stream_instid_promotion(db_, "prepare for_each_instruction_instid_promotion", kSql, callback);
}

void SqliteStore::for_each_uop_instid_promotion(
    const std::function<void(const InstIdPromotionRow&)>& callback) const {
  static constexpr const char* kSql =
      "SELECT u.id, u.attributes, u.parent_id, e.attributes, "
      "(SELECT COUNT(*) FROM events WHERE object_id = u.parent_id AND kind = 'retire_inst') "
      "FROM objects u "
      "LEFT JOIN events e ON e.id = ("
      "SELECT id FROM events "
      "WHERE object_id = u.parent_id AND kind = 'retire_inst' "
      "ORDER BY id DESC LIMIT 1) "
      "WHERE json_extract(u.attributes, '$.type') = 'Uop' "
      "ORDER BY u.id;";
  stream_instid_promotion(db_, "prepare for_each_uop_instid_promotion", kSql, callback);
}

void SqliteStore::for_each_uop_with_retire_uop(
    const std::function<void(const UopRetireUopRow&)>& callback) const {
  static constexpr const char* kSql =
      "SELECT u.id, u.attributes, json_extract(u.attributes, '$.InstID'), "
      "(SELECT MAX(start_time) FROM events "
      "WHERE object_id = u.id AND kind = 'retire_uop') "
      "FROM objects u "
      "WHERE json_extract(u.attributes, '$.type') = 'Uop' "
      "AND EXISTS (SELECT 1 FROM events "
      "WHERE object_id = u.id AND kind = 'retire_uop') "
      "ORDER BY u.id;";
  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_, kSql, -1, &stmt, nullptr), db_,
               "prepare for_each_uop_with_retire_uop");

  while (sqlite3_step(stmt) == SQLITE_ROW) {
    UopRetireUopRow row;
    row.object_id = sqlite3_column_int64(stmt, 0);
    row.object_attributes_json = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
    row.inst_id = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
    row.retire_uop_cycle = sqlite3_column_int64(stmt, 3);
    callback(row);
  }
  sqlite3_finalize(stmt);
}

void SqliteStore::for_each_uop_pc_promotion(
    const std::function<void(const UopPcPromotionRow&)>& callback) const {
  static constexpr const char* kSql =
      "SELECT u.id, u.parent_id, u.attributes, json_extract(i.attributes, '$.PC') "
      "FROM objects u "
      "JOIN objects i ON i.id = u.parent_id "
      "WHERE json_extract(u.attributes, '$.type') = 'Uop' "
      "AND json_extract(i.attributes, '$.type') = 'Instruction' "
      "ORDER BY u.id;";
  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_, kSql, -1, &stmt, nullptr), db_,
               "prepare for_each_uop_pc_promotion");

  while (sqlite3_step(stmt) == SQLITE_ROW) {
    UopPcPromotionRow row;
    row.object_id = sqlite3_column_int64(stmt, 0);
    row.parent_id = sqlite3_column_int64(stmt, 1);
    row.object_attributes_json = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
    row.parent_pc = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
    callback(row);
  }
  sqlite3_finalize(stmt);
}

void SqliteStore::for_each_uop_with_instid_and_pc(
    const std::function<void(const UopInstIdPcRow&)>& callback) const {
  static constexpr const char* kSql =
      "SELECT u.id, u.attributes, json_extract(u.attributes, '$.InstID'), "
      "json_extract(u.attributes, '$.PC'), json_extract(u.attributes, '$.RetirePushup') "
      "FROM objects u "
      "WHERE json_extract(u.attributes, '$.type') = 'Uop' "
      "AND json_extract(u.attributes, '$.InstID') IS NOT NULL "
      "AND json_extract(u.attributes, '$.InstID') != '' "
      "AND json_extract(u.attributes, '$.PC') IS NOT NULL "
      "AND json_extract(u.attributes, '$.PC') != '' "
      "ORDER BY u.id;";
  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_, kSql, -1, &stmt, nullptr), db_,
               "prepare for_each_uop_with_instid_and_pc");

  while (sqlite3_step(stmt) == SQLITE_ROW) {
    UopInstIdPcRow row;
    row.object_id = sqlite3_column_int64(stmt, 0);
    row.object_attributes_json = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
    row.inst_id = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
    row.pc = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
    row.retire_pushup = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4));
    callback(row);
  }
  sqlite3_finalize(stmt);
}

void SqliteStore::for_each_uop_with_instid(
    const std::function<void(const UopInstIdPushupRow&)>& callback) const {
  static constexpr const char* kSql =
      "SELECT u.id, u.attributes, json_extract(u.attributes, '$.InstID'), "
      "json_extract(u.attributes, '$.RetirePushup') "
      "FROM objects u "
      "WHERE json_extract(u.attributes, '$.type') = 'Uop' "
      "AND json_extract(u.attributes, '$.InstID') IS NOT NULL "
      "AND json_extract(u.attributes, '$.InstID') != '' "
      "ORDER BY u.id;";
  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_, kSql, -1, &stmt, nullptr), db_,
               "prepare for_each_uop_with_instid");

  while (sqlite3_step(stmt) == SQLITE_ROW) {
    UopInstIdPushupRow row;
    row.object_id = sqlite3_column_int64(stmt, 0);
    row.object_attributes_json = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
    row.inst_id = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
    row.retire_pushup = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
    callback(row);
  }
  sqlite3_finalize(stmt);
}

void SqliteStore::update_object_attributes(ObjectId id, const std::string& attributes_json) {
  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_, "UPDATE objects SET attributes = ? WHERE id = ?;", -1, &stmt,
                                  nullptr),
               db_, "prepare update_object_attributes");
  sqlite3_bind_text(stmt, 1, attributes_json.c_str(), -1, SQLITE_TRANSIENT);
  sqlite3_bind_int64(stmt, 2, id);
  check_sqlite(sqlite3_step(stmt), db_, "update_object_attributes");
  sqlite3_finalize(stmt);
}

std::optional<TraceObject> SqliteStore::find_object(ObjectId id) const {
  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_,
                                  "SELECT id, object_type_id, name, first_time, last_time, "
                                  "parent_id, attributes FROM objects WHERE id = ?;",
                                  -1, &stmt, nullptr),
               db_, "prepare find object");
  sqlite3_bind_int64(stmt, 1, id);
  if (sqlite3_step(stmt) != SQLITE_ROW) {
    sqlite3_finalize(stmt);
    return std::nullopt;
  }
  TraceObject object;
  object.id = sqlite3_column_int64(stmt, 0);
  object.object_type_id = sqlite3_column_int64(stmt, 1);
  object.name = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
  object.first_time = sqlite3_column_int64(stmt, 3);
  object.last_time = sqlite3_column_int64(stmt, 4);
  object.parent_id = sqlite3_column_int64(stmt, 5);
  const char* attributes_json = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 6));
  object.attributes =
      parse_object_attributes(attributes_json ? attributes_json : "{}");
  sqlite3_finalize(stmt);
  return object;
}

std::unordered_map<std::string, std::int64_t> SqliteStore::build_attribute_row_index(
    const std::string& attribute_key) const {
  std::unordered_map<std::string, std::int64_t> index;
  if (attribute_key.empty() || !db_) {
    return index;
  }

  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_, "SELECT id, attributes FROM objects ORDER BY id;", -1, &stmt,
                                  nullptr),
               db_, "prepare attribute row index");
  std::int64_t row = 0;
  while (sqlite3_step(stmt) == SQLITE_ROW) {
    const char* attributes_json = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
    const std::string value =
        attribute_value(parse_object_attributes(attributes_json ? attributes_json : "{}"),
                        attribute_key);
    if (!value.empty()) {
      index.emplace(value, row);
    }
    ++row;
  }
  sqlite3_finalize(stmt);
  return index;
}

std::optional<ObjectId> SqliteStore::object_id_for_row(std::int64_t row,
                                                       const SortScheme* sort_scheme) const {
  if (row < 0 || !db_) {
    return std::nullopt;
  }

  const std::string order_by =
      sort_scheme != nullptr && !sort_scheme->columns.empty()
          ? build_object_sort_order_by_clause(*sort_scheme)
          : "id";

  std::ostringstream sql;
  sql << "SELECT id FROM objects ORDER BY " << order_by << " LIMIT 1 OFFSET ?;";

  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_, sql.str().c_str(), -1, &stmt, nullptr), db_,
               "prepare object_id_for_row");
  sqlite3_bind_int64(stmt, 1, row);
  if (sqlite3_step(stmt) != SQLITE_ROW) {
    sqlite3_finalize(stmt);
    return std::nullopt;
  }
  const ObjectId id = sqlite3_column_int64(stmt, 0);
  sqlite3_finalize(stmt);
  return id;
}

std::optional<std::int64_t> SqliteStore::object_row_index(ObjectId id,
                                                          const SortScheme* sort_scheme) const {
  sqlite3_stmt* exists_stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_, "SELECT 1 FROM objects WHERE id = ? LIMIT 1;", -1,
                                  &exists_stmt, nullptr),
               db_, "prepare object exists");
  sqlite3_bind_int64(exists_stmt, 1, id);
  const bool exists = sqlite3_step(exists_stmt) == SQLITE_ROW;
  sqlite3_finalize(exists_stmt);
  if (!exists) {
    return std::nullopt;
  }

  if (sort_scheme == nullptr || sort_scheme->columns.empty()) {
    sqlite3_stmt* stmt = nullptr;
    check_sqlite(sqlite3_prepare_v2(db_, "SELECT COUNT(*) FROM objects WHERE id < ?;", -1, &stmt,
                                    nullptr),
                 db_, "prepare object_row_index");
    sqlite3_bind_int64(stmt, 1, id);
    if (sqlite3_step(stmt) != SQLITE_ROW) {
      sqlite3_finalize(stmt);
      return std::nullopt;
    }
    const std::int64_t row = sqlite3_column_int64(stmt, 0);
    sqlite3_finalize(stmt);
    return row;
  }

  const std::string order_by = build_object_sort_order_by_clause(*sort_scheme);
  std::ostringstream sql;
  sql << "SELECT row_num FROM ("
      << "SELECT id, ROW_NUMBER() OVER (ORDER BY " << order_by << ") - 1 AS row_num "
      << "FROM objects"
      << ") WHERE id = ?;";

  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_, sql.str().c_str(), -1, &stmt, nullptr), db_,
               "prepare sorted object_row_index");
  sqlite3_bind_int64(stmt, 1, id);
  if (sqlite3_step(stmt) != SQLITE_ROW) {
    sqlite3_finalize(stmt);
    return std::nullopt;
  }
  const std::int64_t row = sqlite3_column_int64(stmt, 0);
  sqlite3_finalize(stmt);
  return row;
}

bool is_valid_attribute_search_prefix(const std::string& prefix) {
  if (prefix.empty()) {
    return false;
  }
  for (const char ch : prefix) {
    if (std::isalnum(static_cast<unsigned char>(ch)) || ch == '-' || ch == '.' || ch == '+') {
      continue;
    }
    return false;
  }
  return true;
}

std::string escape_like_prefix(const std::string& prefix) {
  std::string escaped;
  escaped.reserve(prefix.size() * 2);
  for (const char ch : prefix) {
    if (ch == '\\' || ch == '%' || ch == '_') {
      escaped.push_back('\\');
    }
    escaped.push_back(ch);
  }
  return escaped;
}

std::optional<AttributeSearchMatch> SqliteStore::find_first_object_by_attribute(
    const std::string& attribute_key, const std::string& prefix,
    const SortScheme* sort_scheme) const {
  if (!db_ || prefix.empty() || !is_valid_attribute_sort_key(attribute_key) ||
      !is_valid_attribute_search_prefix(prefix)) {
    return std::nullopt;
  }

  const std::string order_by =
      sort_scheme != nullptr && !sort_scheme->columns.empty()
          ? build_object_sort_order_by_clause(*sort_scheme)
          : "id";
  const std::string raw = "json_extract(attributes, '$." + attribute_key + "')";

  std::ostringstream sql;
  sql << "SELECT id FROM objects WHERE " << raw << " LIKE ? ESCAPE '\\' "
      << "ORDER BY " << order_by << " LIMIT 1;";

  const std::string like_pattern = escape_like_prefix(prefix) + '%';

  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_, sql.str().c_str(), -1, &stmt, nullptr), db_,
               "prepare find_first_object_by_attribute");
  sqlite3_bind_text(stmt, 1, like_pattern.c_str(), -1, SQLITE_TRANSIENT);
  if (sqlite3_step(stmt) != SQLITE_ROW) {
    sqlite3_finalize(stmt);
    return std::nullopt;
  }
  const ObjectId id = sqlite3_column_int64(stmt, 0);
  sqlite3_finalize(stmt);

  const std::optional<std::int64_t> row = object_row_index(id, sort_scheme);
  if (!row.has_value()) {
    return std::nullopt;
  }

  AttributeSearchMatch match;
  match.object_id = id;
  match.row_index = *row;
  return match;
}

void SqliteStore::refresh_object_attribute_keys() {
  exec_sql("DELETE FROM object_attribute_keys;");
  exec_sql(R"(
    INSERT INTO object_attribute_keys(key)
    SELECT DISTINCT je.key
    FROM objects, json_each(objects.attributes) AS je
    ORDER BY je.key;
  )");
}

std::vector<std::string> SqliteStore::object_attribute_keys() const {
  std::vector<std::string> keys;
  sqlite3_stmt* stmt = nullptr;
  check_sqlite(sqlite3_prepare_v2(db_,
                                  "SELECT key FROM object_attribute_keys ORDER BY key;",
                                  -1, &stmt, nullptr),
               db_, "prepare object_attribute_keys");
  while (sqlite3_step(stmt) == SQLITE_ROW) {
    const char* key = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0));
    if (key) {
      keys.emplace_back(key);
    }
  }
  sqlite3_finalize(stmt);

  if (keys.empty()) {
    sqlite3_stmt* count_stmt = nullptr;
    check_sqlite(sqlite3_prepare_v2(db_, "SELECT COUNT(*) FROM objects;", -1, &count_stmt, nullptr),
                 db_, "prepare object count");
    const bool has_objects =
        sqlite3_step(count_stmt) == SQLITE_ROW && sqlite3_column_int64(count_stmt, 0) > 0;
    sqlite3_finalize(count_stmt);
    if (has_objects) {
      const_cast<SqliteStore*>(this)->refresh_object_attribute_keys();
      return object_attribute_keys();
    }
  }

  return keys;
}

TraceMeta import_ptj_into_store(SqliteStore& store, const std::string& input_path) {
  std::ifstream in(input_path);
  if (!in) {
    throw std::runtime_error("failed to open trace input: " + input_path);
  }

  std::string line;
  Timestamp min_time = std::numeric_limits<Timestamp>::max();
  Timestamp max_time = std::numeric_limits<Timestamp>::min();
  std::int64_t object_count = 0;
  std::int64_t event_count = 0;
  std::string trace_name = "trace";
  std::int64_t next_object_type_id = 0;
  std::int64_t next_event_type_id = 0;
  EventId next_event_id = 0;
  std::unordered_map<std::string, std::int64_t> object_type_ids;
  std::unordered_map<std::string, std::int64_t> event_type_ids;

  store.exec_sql("BEGIN IMMEDIATE;");

  while (std::getline(in, line)) {
    line = trim(line);
    if (line.empty()) {
      continue;
    }

    const std::string type = extract_string_field(line, "type").value_or("");
    if (type == "meta") {
      trace_name = extract_string_field(line, "name").value_or(trace_name);
    } else if (type == "object_type") {
      const auto name = extract_string_field(line, "name").value_or("object");
      const auto display = extract_string_field(line, "display").value_or(name);
      const std::int64_t id = ++next_object_type_id;
      object_type_ids[name] = id;
      store.insert_object_type(id, name, display);
    } else if (type == "event_type") {
      const auto name = extract_string_field(line, "name").value_or("event");
      const auto object_type = extract_string_field(line, "object_type").value_or("object");
      const auto color = extract_uint_field(line, "color").value_or(0xFF888888);
      const auto it = object_type_ids.find(object_type);
      if (it == object_type_ids.end()) {
        throw std::runtime_error("unknown object type for event_type: " + object_type);
      }
      const std::int64_t id = ++next_event_type_id;
      event_type_ids[name] = id;
      const char display_char = parse_display_char_field(line, name);
      store.insert_event_type(id, name, it->second, color);
      store.insert_event_type_display(id, display_char, color);
    } else if (type == "object") {
      const ObjectId id = extract_int_field(line, "id").value_or(0);
      const auto object_type = extract_string_field(line, "object_type").value_or("object");
      const auto name = extract_string_field(line, "name").value_or("object");
      const Timestamp first = extract_int_field(line, "first_time").value_or(0);
      const Timestamp last = extract_int_field(line, "last_time").value_or(first);
      const auto it = object_type_ids.find(object_type);
      if (it == object_type_ids.end()) {
        throw std::runtime_error("unknown object type: " + object_type);
      }
      const std::string attributes_json =
          extract_json_object_field(line, "attrs").value_or("{}");
      store.insert_object(id, it->second, name, first, last, -1, attributes_json);
      min_time = std::min(min_time, first);
      max_time = std::max(max_time, last);
      ++object_count;
    } else if (type == "event") {
      const ObjectId object_id = extract_int_field(line, "object_id").value_or(0);
      const auto kind = extract_string_field(line, "kind").value_or("event");
      Timestamp time = 0;
      if (const auto t = extract_int_field(line, "time")) {
        time = *t;
      } else if (const auto t = extract_int_field(line, "start")) {
        time = *t;
      }
      const auto it = event_type_ids.find(kind);
      const std::int64_t event_type_id = it == event_type_ids.end() ? 0 : it->second;
      const std::string attributes_json =
          extract_json_object_field(line, "attrs").value_or("{}");
      store.insert_event(++next_event_id, object_id, event_type_id, kind, time, attributes_json);
      min_time = std::min(min_time, time);
      max_time = std::max(max_time, time);
      ++event_count;
    }
  }

  store.set_meta(trace_name, min_time, max_time, object_count, event_count);
  store.refresh_object_attribute_keys();
  store.exec_sql("COMMIT;");

  TraceMeta meta;
  meta.name = trace_name;
  meta.min_time = min_time;
  meta.max_time = max_time;
  meta.object_count = object_count;
  meta.event_count = event_count;
  return meta;
}

class SqliteStoreAdapter : public TraceStore {
 public:
  bool open(const std::string& path) override { return store_.open(path); }
  void close() override { store_.close(); }
  TraceMeta meta() const override { return store_.meta(); }
  std::vector<ObjectType> object_types() const override { return store_.object_types(); }
  std::vector<EventType> event_types() const override { return store_.event_types(); }
  ColumnarObjects query_objects(const Viewport& viewport, std::int64_t prefetch_rows,
                                const SortScheme* sort_scheme = nullptr) override {
    return store_.query_objects(viewport, prefetch_rows, sort_scheme);
  }
  ColumnarEvents query_events(const Viewport& viewport,
                              const std::vector<ObjectId>& object_ids) override {
    return store_.query_events(viewport, object_ids);
  }
  std::vector<CycleOccurrenceCount> query_event_cycle_counts(
      std::int64_t event_type_id) const override {
    return store_.query_event_cycle_counts(event_type_id);
  }
  std::optional<TraceObject> find_object(ObjectId id) const override {
    return store_.find_object(id);
  }
  std::optional<ObjectId> object_id_for_row(std::int64_t row,
                                            const SortScheme* sort_scheme = nullptr) const override {
    return store_.object_id_for_row(row, sort_scheme);
  }
  std::optional<std::int64_t> object_row_index(ObjectId id,
                                               const SortScheme* sort_scheme = nullptr) const override {
    return store_.object_row_index(id, sort_scheme);
  }
  std::unordered_map<std::string, std::int64_t> build_attribute_row_index(
      const std::string& attribute_key) const override {
    return store_.build_attribute_row_index(attribute_key);
  }
  std::optional<AttributeSearchMatch> find_first_object_by_attribute(
      const std::string& attribute_key, const std::string& prefix,
      const SortScheme* sort_scheme = nullptr) const override {
    return store_.find_first_object_by_attribute(attribute_key, prefix, sort_scheme);
  }
  std::vector<std::string> object_attribute_keys() const override {
    return store_.object_attribute_keys();
  }

  SqliteStore& native() { return store_; }

 private:
  SqliteStore store_;
};

std::unique_ptr<TraceStore> create_sqlite_store() {
  return std::make_unique<SqliteStoreAdapter>();
}

}  // namespace pipetrace
