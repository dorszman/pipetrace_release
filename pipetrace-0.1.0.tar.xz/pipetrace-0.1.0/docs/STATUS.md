# Status

Last updated: 2026-09-03 (MIT LICENSE added).

## Tool binaries

| Binary | Role |
|--------|------|
| `pipetrace-view` | GUI viewer |
| `pipetrace-linx` | Orchestrator / main Linx entry |
| `pipetrace-linx-parser` | Linx `.pt` → DB |
| `pipetrace-linx-analyze` | Single/dual DB analysis |
| `pipetrace-linx-synthgen` | Synthetic Linx `.pt` |
| `pipetrace-ptj-synthgen` | Synthetic PTJ (main); also `import` / `info` |

Notes:
- **PTJ** = Pipetrace Trace JSON (JSON Lines), not Linx `.pt`.
- Only `pipetrace-linx` may resolve config from `PIPETRACE_CONFIG`; other tools take `--config` only.

## Implemented

### Storage and format
- [x] PTJ JSON Lines import
- [x] SQLite store with viewport object/event queries
- [x] Columnar query results
- [x] Event type display chars and colors (`event_type_display`)
- [x] `query_event_cycle_counts()` — per-cycle global occurrence totals

### Generator
- [x] Generic task trace generator
- [x] CPU pipeline generator (6 stages)
- [x] Wide decode (`decode_width`, default 4)
- [x] Common overlays: cancel, stall
- [x] 100 rare event types with low individual probability
- [x] CLI: `generate`, `import`, `info`; flags `--objects`, `--width`, `--output`

### Timeline viewer
- [x] Cycle × row grid (instant events as chars in cells)
- [x] Stable cycle-number x-axis with adaptive label spacing
- [x] Zoom anchoring (pan/zoom without drift)
- [x] Row virtualization + query cache with prefetch margin
- [x] Multi-event same cell (concat chars, priority by event type id)
- [x] Adjustable event char size (sidebar)
- [x] Event type marking (multi-select)
- [x] Occurrence header strips with per-cycle **counts**
- [x] Header label column (full event name); clipping at high zoom
- [x] Filterable virtualized event-type sidebar list
- [x] Per-object attributes (PTJ/SQLite); pinned row columns via app config
- [x] Per-event attributes (PTJ `attrs`, SQLite `events.attributes`); hover tooltip, sidebar, sticky popups
- [x] Sticky attribute popups (**X** to pin, drag header, close, scroll); foreground draw-list overlay
- [x] Crosshair on grid click; pinned markers on Ctrl+click; clear markers button
- [x] Marker bands extend across pinned row columns (not just grid)
- [x] Color schemes: Night, Day, Gay (sidebar theme button)
- [x] User guide: `docs/USAGE.md`

### Tooling
- [x] `build.sh`, CMake, unit tests
- [x] Sample trace: `data/sample.ptj` / `data/sample.ptj.db`
- [x] Migration and AI onboarding docs: `docs/MIGRATION.md`, `AGENTS.md`
- [x] Installation guide: `docs/INSTALLATION.md`
- [x] Vendored `third_party/` deps for offline builds (`scripts/vendor_deps.sh`)
- [x] Linx import pipeline: `pipetrace-linx-parser` (PT → Raw DB), `pipetrace-linx-analyze` (single/dual on DB), `pipetrace-linx` orchestrator, status `--status pretty|plain` — see `docs/LINX_DB_ANALYSIS.md`

## Not yet implemented

- [ ] Density aggregation when zoomed out (bucket/heatmap instead of per-cell chars)
- [ ] Background query workers and cancellable loads
- [ ] UI non-blocking during DB access
- [ ] Minimap / overview strip for 10M+ rows
- [ ] Perfetto and custom GPU renderer benchmarks (per original README plan)
- [ ] Object grouping by type in the row axis
- [ ] Zoom-to-selection, search beyond event-type filter

## Known limitations

- Entire event-type list loaded from DB on open (fine for hundreds/thousands; may need pagination later).
- Occurrence counts computed globally per type (full table scan grouped by cycle — OK for MVP sizes).
- `README.md` MVP spec describes interval events and multi-renderer benchmarks; current code is cycle-grid instant events with ImGui only.

## Recent history (git)

```
7409eae Replace sticky popups with foreground draw-list overlays.
8962285 Add per-event attributes and sticky cell attribute popups.
d3929af Extend marker bands across pinned row columns and expand layout docs.
bb4c46c Add Night, Day, and Gay viewer color schemes.
b432ce9 Add wide decode generation and per-cycle occurrence counts.
```

## Sample trace stats (100 objects, default generator)

- ~108 event types (6 stages + 2 common + 100 rare)
- ~1000+ events (pipeline + overlays + rare)
- Wide decode: 4 uops per decode cycle

Regenerate after generator changes:

```bash
./build/pipetrace-ptj-synthgen generate --objects 100 --output data/sample.ptj
```
