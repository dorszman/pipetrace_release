# Linx SQLite analysis tool — requirements

Status: **implemented**.

## Pipeline model

Two tools, strict input boundaries:

| Tool | Input | Never accepts |
|------|--------|---------------|
| **`pipetrace-linx-parser`** | **One** `.pt` file | DB |
| **`pipetrace-linx-analyze`** | **One or two** `.db` stores | PT |

```text
PT ──cast──► D ("Raw")
D  ──analyze (1 DB)──► Da ("Analyzed")
Da + Da' ──analyze (2 DBs)──► Ddual + Ddual' ("DualAnalyzed" on both)
```

- **Cast** is the only step that reads pipetrace text.
- **Analyze** never reads PT; it only opens SQLite stores.
- **Dual analyze** requires both stores to be **at least single-analyzed** (`Analyzed` or `DualAnalyzed`).

### DB analysis state (string meta)

Stored in the SQLite **`meta`** table as **`analysis_state`**:

| Value | Meaning |
|-------|---------|
| **`Raw`** | Cast only — parser output, no analysis |
| **`Analyzed`** | Single-trace analysis done |
| **`DualAnalyzed`** | Dual-trace derivatives written |

Other meta keys:

| Key | Writer | Meaning |
|-----|--------|---------|
| **`source_trace_path`** | cast | Absolute PT path |
| **`source_trace_mtime`** | cast | PT mtime at cast |
| **`cast_at`** | cast | Cast completion time |
| **`analyzed_at`** | analyze (single) | Last single-analyze time |
| **`dual_analyzed_at`** | analyze (dual) | Last dual-analyze time |
| **`dual_partner_path`** | analyze (dual) | Absolute path of the other DB in the last dual pair |

Legacy DBs without **`analysis_state`**: treat as **`Analyzed`** if **`analyzed_at`** is set, else **`Raw`**.

---

## Pipeline orchestrator

Binary: **`pipetrace-linx`**

Runs cast / single analyze / dual analyze by spawning the existing tools (skip logic stays in those tools).

```bash
./build/pipetrace-linx data/a.pt
./build/pipetrace-linx data/a.db
./build/pipetrace-linx data/a.pt data/b.pt
./build/pipetrace-linx data/a.db data/b.db --no-view
```

- One or two inputs; each is detected by **content** (SQLite header → store; otherwise → PT text). Extension is ignored.
- For a PT input, store defaults to `PATH` + `.db` (e.g. `a.pt` → `a.pt.db`). For a store input, analyze only.
- Two traces: per-trace cast/analyze runs **in parallel**, then dual analyze. The two inputs must resolve to **different** store paths (same path / `a.pt` + `a.pt.db` is rejected). For debug with identical content, **duplicate** the file first.
- Tools are invoked with **`--status plain`**; verbose detail goes to `*.cast.log` / `*.analyze.log` / `*.dual.log`.
- Opens the viewer by default after success; pass **`--no-view`** to skip.
- **Config is mandatory** for the orchestrator: `--config PATH` or env **`PIPETRACE_CONFIG`** (`--config` wins). Pipeline then passes `--config <resolved>` to every spawned tool. Other tools (`pipetrace-linx-parser`, `pipetrace-linx-analyze`, viewer) take **`--config` only** (no env).
- Status mode on tools: **`--status pretty`** (default) or **`plain`**. Pretty only decorates the same `STATUS …` line (color / `\r`); it does not duplicate the message content.

See also [`LINX_DB_ANALYSIS.md`](LINX_DB_ANALYSIS.md) for DB state machine.

---

## Decisions (locked)

| # | Topic | Decision |
|---|--------|----------|
| 1 | Binary name | **`pipetrace-linx-analyze`** |
| 2 | Pipeline placement | After **`pipetrace-linx-parser`**, before **`pipetrace-view --store`** |
| 3 | Attribute key | **`InstID`** (PascalCase) on both Instruction and Uop objects |
| 4 | DB write mode | **Default in-place** update of `--store`; optional **`--output`** copy-out |
| 5 | Dual attributes | **Separate keys** — dual never overwrites single-trace **`RetirePushup`** |
| 6 | Implementation | **C++20**; reuse **`pipetrace_core`**; **no GUI** |

## Purpose

Standalone CLI that reads a **pipetrace-compatible SQLite store** produced by **`pipetrace-linx-parser`** and **enhances** it before the viewer loads it.

**Task 1:** promote `InstID` onto Instruction and Uop objects.

**Task 2:** promote **`RetirePushup`** (within-trace chain pushup).

**Task 3:** promote **`PC`**, then **`PcCount`**, **`PcRetirePushup`**, **`PcRetirePushupAvg`**.

**Dual trace (optional):** compare two single-analyzed stores by **`InstID`**, write **`DualRetirePushup`** and dual PC profiling keys on **both** stores without touching single-trace attributes.

## Pipeline placement

```
Linx .pt  →  pipetrace-linx-parser  →  pipetrace-linx-analyze  →  pipetrace-view --store trace.db
                  (lossless import)      (derived attrs)         (viewer)
```

Single trace:

```bash
./build/pipetrace-linx-synthgen --output /tmp/trace.pt --objects 1000
./build/pipetrace-linx-parser --input /tmp/trace.pt --store /tmp/trace.db --config config/pipetrace.app.json
./build/pipetrace-linx-analyze --store /tmp/trace.db --config config/pipetrace.app.json
./build/pipetrace-view --store /tmp/trace.db --config config/pipetrace.app.json
```

Dual trace:

```bash
./build/pipetrace-linx-parser --input /tmp/trace_a.pt --store /tmp/trace_a.db --config config/pipetrace.app.json
./build/pipetrace-linx-parser --input /tmp/trace_b.pt --store /tmp/trace_b.db --config config/pipetrace.app.json
./build/pipetrace-linx-analyze --store /tmp/trace_a.db --config config/pipetrace.app.json
./build/pipetrace-linx-analyze --store /tmp/trace_b.db --config config/pipetrace.app.json
./build/pipetrace-linx-analyze --store /tmp/trace_a.db --store2 /tmp/trace_b.db --config config/pipetrace.app.json
./build/pipetrace-view --store /tmp/trace_a.db --store2 /tmp/trace_b.db --config config/pipetrace.app.json
```

---

## Cast (`pipetrace-linx-parser`)

See [`LINX_PT_IMPORT.md`](LINX_PT_IMPORT.md) for cast details.

- **Input:** exactly one `.pt` (+ `--store` output path).
- **Output:** DB with **`analysis_state = Raw`**.
- **Skip recast** when store exists, **`source_trace_path`** matches this PT, and PT mtime matches stored **`source_trace_mtime`** (unless **`--force`**).

---

## Single analyze (one DB)

**Input:** `--store PATH.db` only.

**Runs when:** **`analysis_state == Raw`** (or missing/legacy Raw), or **`--force`**.

**Skips when:** state is **`Analyzed`** or **`DualAnalyzed`** and not forced → `analysis skipped: already analyzed`.

**Writes:**

| Object | Single-trace attributes |
|--------|-------------------------|
| Instruction | `InstID` |
| Uop | `InstID`, `PC`, `RetirePushup`, `PcCount`, `PcRetirePushup`, `PcRetirePushupAvg` |

Sets **`analysis_state = Analyzed`**, **`analyzed_at`**.

Does **not** read PT or invoke cast.

---

## Dual analyze (two DBs)

**Input:** `--store PATH.db --store2 PATH2.db`.

**Precondition:** both stores **`Analyzed`** or **`DualAnalyzed`** (not **`Raw`**).

**Skip when** (both stores, unless **`--force`**):

1. **`analysis_state == DualAnalyzed`**
2. **`dual_analyzed_at >= analyzed_at`** (dual still valid vs last single pass)
3. **`dual_partner_path`** on each store equals the **other** store path (same pair as last run)

Message: `dual analysis skipped: up to date`.

**Algorithm:**

1. Read each store's single-trace **`RetirePushup`** by **`InstID`**.
2. For matching **`InstID`**, compute `pushup_trace2 − pushup_trace1`.
3. Write **`DualRetirePushup`** on both stores (same delta value).
4. Run dual PC profiling → **`DualPcRetirePushup`**, **`DualPcRetirePushupAvg`** (no **`DualPcCount`** — PC population counts are unchanged by dual analysis; reuse single-trace **`PcCount`**).

Single-trace **`RetirePushup`** and PC profiling keys are **never modified**.

Sets on **both** stores: **`analysis_state = DualAnalyzed`**, **`dual_analyzed_at`**, **`dual_partner_path`**.

API: **`run_linx_db_dual_analysis()`** in `include/pipetrace/linx_analysis.hpp`.

---

## Task 1: Promote `InstID`

Two streaming join passes (Instruction, then Uop), batched updates, single transaction. See prior sections for algorithm details.

---

## Task 2: Promote `RetirePushup`

Within-trace chain: for retired Uops with **`InstID`**, `RetirePushup = retire_uop_cycle − previous_retired_uop_cycle`. First retired Uop in trace gets no value.

---

## Task 3: Promote `PC` and PC profiling

**Step A:** copy parent Instruction **`PC`** onto Uops.

**Step B:** bucket retired Uops by **`PC`**; write **`PcCount`**, **`PcRetirePushup`**, **`PcRetirePushupAvg`** using single-trace **`RetirePushup`** values.

Dual Step B uses **`DualRetirePushup`** as input and writes **`DualPc*`** keys (same bucket math).

---

## CLI interface

```
pipetrace-linx-analyze --store PATH.db --config PATH [--store2 PATH.db] [--output PATH.db]
                 [--output2 PATH.db] [--force] [--status pretty|plain] [--log PATH]
```

| Flag | Description |
|------|-------------|
| **`--store`** | SQLite store (required) |
| **`--config`** | App config path (required; no env / no default path) |
| **`--store2`** | Second store → **dual mode** |
| **`--output`**, **`--output2`** | Optional copy-out paths |
| **`--force`** | Re-run single or dual analysis despite skip rules |

| Mode | Behavior |
|------|----------|
| **`--store` only** | Single analyze: Tasks 1 → 2 → 3 |
| **`--store` + `--store2`** | Dual analyze only (both must already be analyzed) |

No **`--input`** flag — PT import is cast's job.

---

## Tests (acceptance)

Implemented in `tests/test_linx_db_analysis.cpp` and `tests/test_linx_pt.cpp`:

- Single-trace Tasks 1–3, idempotency, strength colors.
- Cast writes **`analysis_state = Raw`** and source meta; cast skip / force.
- Single analyze skip when already analyzed; **`--force`** re-analyze.
- Dual writes **`DualRetirePushup`** without overwriting **`RetirePushup`**.
- Dual skip when partner + timestamps match; rejects **`Raw`** store.
- Dual meta: **`DualAnalyzed`**, **`dual_partner_path`**.

---

## Future extensibility

Validation pass, denormalized index, selective **`--pass`** flags, viewer pins for dual columns.
