# Architecture

pipetrace is a C++ desktop trace visualizer for large instant-event traces. The MVP uses Dear ImGui + OpenGL; storage is SQLite with viewport-scoped queries.

## Pipeline

```
PTJ file  →  Importer  →  SQLite store  →  Viewport queries  →  Timeline viewer
Generator ----^
```

## Data model

Defined in `include/pipetrace/types.hpp`.

| Concept | Description |
|---------|-------------|
| **Object type** | Schema for a class of traced entities (e.g. `uop`) |
| **Event type** | Schema for events: name, color, display char |
| **Object** | One traced entity; `first_time` / `last_time` bounds |
| **Event** | Single instant at `time` (stored as `start_time` in SQLite); optional key/value attributes |
| **Row** | Viewer row index = dense rank by `objects.id` (`ORDER BY id`, 0-based) |

Events are **instants**, not intervals. Timestamps are 64-bit integers (cycles in the CPU generator).

### Columnar query results

`ColumnarObjects` and `ColumnarEvents` (`include/pipetrace/columnar.hpp`) return parallel arrays for efficient rendering without per-event heap allocations.

### Cycle occurrence counts

`CycleOccurrenceCount { cycle, count }` — number of events of a given type at a cycle (across all objects). Used by marked-type header strips.

## Input format (PTJ)

Pipetrace Trace JSON Lines — one JSON object per line.

| Record | Purpose |
|--------|---------|
| `meta` | Trace name and version |
| `object_type` | Object schema |
| `event_type` | Event schema: `name`, `object_type`, `color`, `char` or `char_code` |
| `object` | Entity with `id`, times, name |
| `event` | `object_id`, `kind`, `time`, optional `attrs` (JSON object) |

Example:

```json
{"type":"event_type","name":"decode","object_type":"uop","color":4281240880,"char":"D"}
{"type":"object","id":1,"object_type":"uop","name":"uop_0_s0","first_time":0,"last_time":5}
{"type":"event","object_id":1,"kind":"decode","time":0,"attrs":{"phase":"front","port":0}}
```

Import path: `src/importer/trace_importer.cpp` → `src/storage/sqlite_store.cpp`.

### Display metadata

Table `event_type_display` stores `display_char` and color per event type. Importer accepts `"char":"D"` or `"char_code":68`.

## Storage

SQLite backend: `src/storage/sqlite_store.cpp`.

**Indexes:** objects by time overlap; events by `(object_id, start_time)`.

**Viewport object query:**

```sql
first_time <= view_end AND last_time >= view_start
```

Plus row-range filtering and prefetch margin (default 24 rows).

**Viewport event query:** events for visible object IDs within the time window. Returns event id, kind, display metadata, and `attributes` JSON per event.

**Global occurrence query** (for marked types):

```sql
SELECT start_time, COUNT(*) FROM events
WHERE event_type_id = ? GROUP BY start_time ORDER BY start_time;
```

Interface: `TraceStore` in `include/pipetrace/storage.hpp`.

## Generators

### CPU pipeline (`src/generator/cpu_pipeline_generator.cpp`)

| Parameter | Default | Meaning |
|-----------|---------|---------|
| `object_count` | 1000 | Number of uops |
| `time_span` | 100000 | Cycle budget |
| `stages` | 6 | Pipeline stages (1–6) |
| `decode_width` | 4 | Uops decoded per cycle (wide machine) |
| `seed` | 42 | RNG seed |

**Scheduling:** uop `i` decodes at cycle `i / decode_width`; stages are consecutive cycles. Names: `uop_<i>_s<i % decode_width>`.

**Event types emitted:**

- 6 pipeline stages (`D R A I E T`)
- 2 common overlays: `cancel`, `stall`
- 100 rare types: `{tlb,icache,dcache,...}_{miss,stall,replay,fault,retry}`

**Overlay rates (per uop):** cancel ~33%, stall ~25%, each rare type ~4%.

### Generic trace (`src/generator/generic_generator.cpp`)

Simple task workflow trace for non-CPU testing.

Both generators write PTJ and import to `<output>.db`.

## Timeline viewer

Main implementation: `src/app/timeline_view.cpp`. GUI shell and side panels: `src/app/main.cpp`.

End-user panel guide: [`docs/USAGE.md` § Layout](USAGE.md#layout).

### Window layout

Left to right: **sidebar** (`BeginChild("sidebar")`) → **detail_panels** (`pinned_markers` + `object_attrs`) → **timeline** (`TimelineView::draw("timeline")`).

The **timeline** child contains a custom-drawn **plot** (`plot_origin` / `plot_size`), optional **left_gutter** (**row_panel** + **occurrence_label_origin**), **plot_header** (**cycle_axis** + **occurrence_panel** rows), scrollable **grid**, and an ImGui **footer** (`kTimelineFooterHeight`).

Full name table: [`docs/USAGE.md` § Layout vocabulary](USAGE.md#layout-vocabulary-code-names).

### Timeline plot layout

```
timeline BeginChild("timeline")
├─ plot (plot_origin, plot_size)          ← ImDrawList custom draw
│  ├─ plot_header (plot_header_height)
│  │  ├─ row_panel + occurrence_label_origin + cycle_axis
│  │  └─ occurrence_panel × marked types
│  └─ grid (grid_origin, grid_size)       ← scrolls with row_panel body
└─ footer (kTimelineFooterHeight)         ← ImGui::Text after Dummy(plot_size)
```

- Header height = `kCycleAxisHeight` (24px) + `kOccurrencePanelHeight` (22px) × marked type count.
- **row_panel** width = `AppConfig::row_panel_width()` (sum of `pinned_row_attributes[].width_px`).
- **occurrence_label_origin** width = `occurrence_label_width()` (min 72px); omitted when no types marked.
- **grid** and header ticks share x-alignment starting at `cycle_origin` (= `plot_origin.x + left_gutter_width`).

### Cell rendering

- One rectangle per (row, cycle).
- Events in the same cell grouped; display chars concatenated by `event_type_id` order when space allows.
- Char size adjustable (8–32 px) from sidebar.

### Interaction

| Input | Action |
|-------|--------|
| Left drag | Pan cycles and rows |
| Wheel | Zoom cycle width and row height (anchor-preserving) |
| Click grid cell | Move active row/column bands; select object on that row if present |
| Ctrl + click grid cell | Pin row/column bands at clicked cell, then move active bands there |
| Sidebar **Clear markers** | Remove all pinned markers (crosshair unchanged) |
| Pinned markers panel | Click entry to navigate; **X** removes one marker |
| Sidebar **Theme** button | Cycle color scheme: Night → Day → Gay |
| Sidebar click | Toggle mark on event type |
| Hover grid cell | Tooltip with events and per-event attributes |
| **X** while hovering cell | Pin sticky attribute popup (foreground overlay) |
| Sticky popup header drag | Move pinned popup |
| Sticky popup **X** | Close that popup |
| Wheel over sticky body | Scroll long attribute lists |

### Sticky attribute popups

Pinned cell-inspection panels are **not** ImGui windows. They are drawn with `ImGui::GetForegroundDrawList()` after the main window closes, so they sit on top of the timeline without parent clipping.

- Layout (`layout_sticky_popup`) measures text once at pin time; size stays fixed.
- Input (`handle_sticky_popups_input`) uses the same screen rects as drawing (drag header, close button, scroll body).
- Hover tooltips (before pinning) remain a small ImGui tooltip window.

### Caching

`refresh_cache()` loads objects/events for viewport ± buffer. Skipped while panning; refreshed on release or when scroll exits cache.

### Sidebar (`src/app/main.cpp`)

- Filter box (case-insensitive match on name or display char).
- Virtualized list (`ImGuiListClipper`) for large type catalogs.
- Marked types stay marked when filtered out.

## Virtualization and scale

At minimum zoom (~8 px row height), ~100 rows fit on screen. The store may hold millions of objects; the viewer always queries and draws **O(visible rows × visible cycles)**.

Not yet implemented: density aggregation when zoomed out, background query workers, minimap.

## Build

```bash
./build.sh
./build/pipetrace-view --store data/sample.ptj.db --config config/pipetrace.app.json
ctest --test-dir build
```

Requires C++20, OpenGL/GLFW dev packages for the GUI.

## Tests

| Test | Covers |
|------|--------|
| `Storage.ViewportQueryReturnsOverlappingObjects` | Viewport queries, display chars, cycle counts |
| `Generator.CreatesCpuPipelineTrace` | CPU trace generation, ≥108 event types |

## Related docs

- `README.md` — original MVP specification and long-term goals
- `AGENTS.md` — AI onboarding and conventions
- `docs/MIGRATION.md` — new machine / new AI handoff guide
- `docs/INSTALLATION.md` — install dependencies, compile, and run
- `docs/STATUS.md` — implemented features and roadmap
