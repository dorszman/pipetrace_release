# pipetrace — AI agent guide

Read this file plus `README.md`, `docs/ARCHITECTURE.md`, `docs/STATUS.md`, `docs/MIGRATION.md`, `docs/INSTALLATION.md`, and `docs/USAGE.md` before making non-trivial changes.

- **`README.md`** — original product spec, scale targets, and long-term goals (some details predate the cycle-grid viewer; treat `ARCHITECTURE.md` as current for implementation).
- **`docs/ARCHITECTURE.md`** — how the code works today.
- **`docs/STATUS.md`** — what's done, what's not, known gaps.
- **`docs/MIGRATION.md`** — new machine / new AI / handoff checklist.
- **`docs/INSTALLATION.md`** — install dependencies, compile, test, run.
- **`docs/USAGE.md`** — viewer controls, crosshair/markers, event attributes, sticky popups, event-type marking, config.

## Project

**pipetrace** is a C++ desktop trace visualizer for very large event traces (millions of rows). CPU pipeline traces are the first use case; the data model and UI stay generic and data-driven.

Repo path (typical): `/home/doron/pipetrace`

## Core design constraints

- **Row = object** (dense row index by `ORDER BY id`, starting at 0; object id 0 is row 0).
- **Time = discrete cycles** (64-bit integer timestamps).
- **Events are instants** — one `time` field per event, not intervals.
- **SQLite on disk** — the viewer loads only **visible rows/cycles + buffer** into memory.
- **Virtualization is mandatory** — never load or draw all objects at once (~100 visible rows max at minimum zoom).
- **Data-driven** — event types, colors, and display chars come from the store / PTJ, not hard-coded UI lists.

## Key files

| Area | Path |
|------|------|
| Types, viewport | `include/pipetrace/types.hpp` |
| Storage interface | `include/pipetrace/storage.hpp` |
| SQLite implementation | `src/storage/sqlite_store.cpp` |
| PTJ importer | `src/importer/trace_importer.cpp` |
| CPU generator | `src/generator/cpu_pipeline_generator.cpp` |
| Generator config | `include/pipetrace/generator.hpp` |
| Timeline viewer | `src/app/timeline_view.cpp`, `timeline_view.hpp` |
| GUI shell / sidebar | `src/app/main.cpp` → binary **`pipetrace-view`** |
| PTJ synthgen CLI | `src/cli/main.cpp` → **`pipetrace-ptj-synthgen`** |
| Linx orchestrator | `src/linx_pipeline/main.cpp` → **`pipetrace-linx`** |
| Tests | `tests/test_storage.cpp`, `tests/test_generator.cpp` |
| Architecture | `docs/ARCHITECTURE.md` |
| Current status / roadmap | `docs/STATUS.md` |

## Build and run

Requires **CMake 3.20+** and a C++20 compiler. Dependencies (SQLite, GLFW, ImGui, GoogleTest) are **vendored in `third_party/`** for offline builds — see [`docs/INSTALLATION.md`](docs/INSTALLATION.md).

```bash
chmod +x build.sh && ./build.sh

# Regenerate sample trace (108 event types, wide decode, ~1000+ events)
./build/pipetrace-ptj-synthgen generate --objects 100 --output data/sample.ptj
./build/pipetrace-ptj-synthgen info --store data/sample.ptj.db

# GUI
./build/pipetrace-view --store data/sample.ptj.db --config config/pipetrace.app.json

# Tests
ctest --test-dir build --output-on-failure
```

CLI generate options: `--objects N`, `--width W` (decode width, default 4), `--generic`, `--output path.ptj`.

## Viewer behavior (current)

- **Cycle × row grid** — one cell per (object, cycle); events shown as colored display chars.
- **Fixed upper header** — cycle number axis + one occurrence strip per marked event type.
- **Occurrence strips** — global per-cycle counts for marked types (`query_event_cycle_counts`); counts drawn with adaptive font size.
- **Left label column** in header when types are marked; ticks/grid aligned to the right of it.
- **Pan** (left drag), **zoom** (wheel, anchor-preserving), **active cross-bands** (click grid cell), **pinned markers** (Ctrl+click), **row select** (click).
- **Sidebar** (260px) — stats, theme cycle button, controls, crosshair readout, clear markers, event char size, filterable event-type list.
- **Detail column** (`detail_panels`, 220px) — **pinned_markers** (150px) + **object_attrs**; see `docs/USAGE.md` § Layout vocabulary.
- **Event attributes** — hover tooltip, **X** to pin sticky overlay popups, selected-cell list in detail column.
- **Color schemes** — Night (default), Day, Gay; `src/app/theme.cpp`.
- **Multi-mark** — several event types can be marked; each gets its own header strip.

## Generator behavior (current)

- **Pipeline stages** — decode, rename, dispatch, issue, execute, retire (configurable count).
- **Wide decode** — `decode_width` uops start on the same decode cycle (default 4).
- **Common overlays** — cancel (~33%), stall (~25%) per uop.
- **100 rare event types** — names like `tlb_miss`, `branch_stall`; ~1/24 chance each per uop per type.
- Object names: `uop_<index>_s<slot>`.

## Coding conventions

- **C++20**, CMake build.
- **Minimal diffs** — match existing style; don't refactor unrelated code.
- **Tests** — extend `tests/` when changing storage queries or generator invariants.
- **Commits** — only when the user asks; use clear one-line messages focused on *why*.
- **Documentation** — when changing architecture, viewer layout, storage queries, generator semantics, or CLI flags, update docs in the same change (see [Documentation maintenance](#documentation-maintenance) below).

## Common pitfalls

- Drawing or querying outside the viewport buffer — keep `refresh_cache` / `view_outside_cache` logic intact.
- Occurrence ticks bleeding into the label column — clip to tick region; redraw labels on top.
- Assuming one event per cycle globally — wide decode puts multiple uops in the same cycle; use **counts**, not distinct cycles.
- Stale sample DB — regenerate with `pipetrace-ptj-synthgen generate` after generator changes.

## Onboarding prompt (new AI / new machine)

```
Read README.md (product spec), then AGENTS.md, docs/ARCHITECTURE.md, docs/STATUS.md, docs/MIGRATION.md, and docs/INSTALLATION.md.
Then inspect git log --oneline -15 for recent history.
Do not change code until you understand the cycle-grid model and viewport virtualization.
```

## Documentation maintenance

These rules apply to **any** AI assistant or human contributor. They live in git so they travel with the repo (Cursor, Claude Code, Copilot, etc.).

When you change behavior, APIs, viewer layout, generator semantics, storage queries, or CLI flags, update the docs in the **same task** (do not defer).

### Files to maintain

| File | Update when |
|------|-------------|
| `README.md` | Product-level scope or deliverables change (keep v0.1 status summary in sync) |
| `docs/ARCHITECTURE.md` | Design, data flow, queries, viewer/generator behavior |
| `docs/STATUS.md` | Feature completed, roadmap item started/done, known limits |
| `AGENTS.md` | Key files, build/run steps, conventions, onboarding hints |
| `docs/MIGRATION.md` | New machine, new AI, or human handoff steps |
| `docs/INSTALLATION.md` | Install commands, build steps, OpenGL/headless notes |
| `docs/USAGE.md` | Viewer controls, layout vocabulary (code names), crosshair/markers, event attributes, sticky popups, sidebar, app config |

### Minimum checklist

After a non-trivial change, ask: *Would a new AI on a fresh machine misunderstand this?* If yes, update docs.

- New storage query or schema → ARCHITECTURE + STATUS
- New viewer interaction or header layout → ARCHITECTURE + AGENTS
- New generator flag or event-type scheme → ARCHITECTURE + STATUS + AGENTS (build/run)
- Removed or renamed feature → remove stale mentions from all three

### Do not

- Let `docs/ARCHITECTURE.md` describe interval bars or old pan behavior (viewer is cycle-grid).
- Commit doc-only changes unless the user asked to commit.
- Duplicate the full MVP spec from `README.md` in other docs — cross-link instead; update README's v0.1 status when major milestones land.

### STATUS.md date

Bump the "Last updated" line in `docs/STATUS.md` when you edit it.

### Optional tool-specific pointers

If you use a tool that reads its own config file, add a **one-line pointer** to this file rather than duplicating rules:

| Tool | Typical file | Suggested content |
|------|--------------|-------------------|
| Cursor | `.cursor/rules/*.mdc` | `Read and follow AGENTS.md and docs/MIGRATION.md in this repo.` |
| Claude Code | `CLAUDE.md` | `Read and follow AGENTS.md and docs/MIGRATION.md in this repo.` |
| GitHub Copilot | `.github/copilot-instructions.md` | Same one-liner |

Keep tool-specific files minimal; `AGENTS.md` is the source of truth.
