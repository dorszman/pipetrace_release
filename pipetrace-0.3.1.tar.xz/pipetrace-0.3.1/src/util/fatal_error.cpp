#include "pipetrace/fatal_error.hpp"

#include <chrono>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <iostream>

#if defined(_WIN32)
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#endif

namespace pipetrace {
namespace {

#if defined(_WIN32)
std::wstring utf8_to_wide(const std::string& utf8) {
  if (utf8.empty()) {
    return {};
  }
  const int needed =
      MultiByteToWideChar(CP_UTF8, 0, utf8.data(), static_cast<int>(utf8.size()), nullptr, 0);
  if (needed <= 0) {
    return {};
  }
  std::wstring wide(static_cast<std::size_t>(needed), L'\0');
  MultiByteToWideChar(CP_UTF8, 0, utf8.data(), static_cast<int>(utf8.size()), wide.data(), needed);
  return wide;
}

std::filesystem::path executable_log_path() {
  std::wstring buf(32768, L'\0');
  const DWORD n = GetModuleFileNameW(nullptr, buf.data(), static_cast<DWORD>(buf.size()));
  if (n == 0 || n >= buf.size()) {
    return std::filesystem::path("pipetrace-view.log");
  }
  buf.resize(n);
  return std::filesystem::path(buf).parent_path() / "pipetrace-view.log";
}
#else
std::filesystem::path executable_log_path() {
  std::error_code ec;
  const std::filesystem::path self = std::filesystem::read_symlink("/proc/self/exe", ec);
  if (!ec && !self.empty()) {
    return self.parent_path() / "pipetrace-view.log";
  }
  return std::filesystem::path("pipetrace-view.log");
}
#endif

void append_fatal_log(const std::string& title, const std::string& message) {
  try {
    const auto path = executable_log_path();
    std::ofstream out(path, std::ios::app);
    if (!out) {
      return;
    }
    const auto now = std::chrono::system_clock::now();
    const std::time_t t = std::chrono::system_clock::to_time_t(now);
    out << "---- " << std::ctime(&t) << title << ": " << message << "\n";
  } catch (...) {
    // Logging must never throw from the fatal reporter.
  }
}

}  // namespace

void report_fatal_error(const std::string& title, const std::string& message) {
  std::cerr << title << ": " << message << '\n';
  std::cerr.flush();
  append_fatal_log(title, message);

#if defined(_WIN32)
  const std::wstring wide_title = utf8_to_wide(title);
  const std::wstring wide_message = utf8_to_wide(message);
  MessageBoxW(nullptr, wide_message.empty() ? L"(no details)" : wide_message.c_str(),
              wide_title.empty() ? L"pipetrace" : wide_title.c_str(),
              MB_OK | MB_ICONERROR | MB_SETFOREGROUND);
#endif
}

}  // namespace pipetrace
